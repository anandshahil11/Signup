<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * @package  Core
 *
 * Sets the default route to "welcome"
 */
    /*echo "------------------------";
    echo $_SERVER['SERVER_NAME']."<br/>"; 
	echo $_SERVER['REQUEST_URI'];
	exit;*/
	if(stripos($_SERVER['REQUEST_URI'],'expand') !==false){
	$config['_default'] = 'user/index';
	//questions
	$config['admin/question_sets/([0-9]+)/questions'] = 'admin/question_sets/questions/show_list/$1';
	$config['admin/question_sets/([0-9]+)/questions/edit/([0-9]+)'] = 'admin/question_sets/questions/edit/$2';
	$config['admin/question_sets/([0-9]+)/questions/create'] = 'admin/question_sets/questions/create/$1';
	$config['admin/question_sets/([0-9]+)/questions/delete'] = 'admin/question_sets/questions/delete';
	
	//results
	$config['admin/results/([0-9]+)'] = 'admin/results/home/$1';
	$config['admin/results/([0-9]+)/([a-z-_]+)'] = 'admin/results/$2/$1';
	$config['admin/results/([0-9]+)/([a-z-_]+)/([0-9]+)'] = 'admin/results/$2/$3';
	}else{
	 $config['_default'] = 'api';
	 
	$config['([A-Za-z0-9-_]+)'] = 'api/$1';
	$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2';
	$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2/$3';
	}
   
 
 
 
/*
 
if ( stripos($_SERVER['SERVER_NAME'],'api.') !==false || stripos($_SERVER['SERVER_NAME'],'amf') !== false )
{   //echo "I am in IF condition";
	$config['_default'] = 'api';
	$config['([A-Za-z0-9-_]+)'] = 'api/$1';
	$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2';
	$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2/$3';
}
else
{   //echo "I am in IF else";
	$config['_default'] = 'user/index';
	
	//questions
	$config['admin/question_sets/([0-9]+)/questions'] = 'admin/question_sets/questions/show_list/$1';
	$config['admin/question_sets/([0-9]+)/questions/edit/([0-9]+)'] = 'admin/question_sets/questions/edit/$2';
	$config['admin/question_sets/([0-9]+)/questions/create'] = 'admin/question_sets/questions/create/$1';
	$config['admin/question_sets/([0-9]+)/questions/delete'] = 'admin/question_sets/questions/delete';
	
	//results
	$config['admin/results/([0-9]+)'] = 'admin/results/home/$1';
	$config['admin/results/([0-9]+)/([a-z-_]+)'] = 'admin/results/$2/$1';
	$config['admin/results/([0-9]+)/([a-z-_]+)/([0-9]+)'] = 'admin/results/$2/$3';
}
*/