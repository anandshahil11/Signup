<?php defined('SYSPATH') OR die('No direct access allowed.');

class Admin_Controller extends Site_Controller 
{
	public $template = 'admin_template';

	function __construct()
	{
		parent::__construct();
		$this->auth = new Admin_Auth_Model;
		if ( $this->uri->segment(2) != 'login' )
		{
			if ( !$this->auth->logged_in() )
			{
				url::redirect('user/login');
			}
		}
	}
	
	function index()
	{
    
		url::redirect('admin/question_sets');
		
	}

	
	function login()
	{
		if ( $_POST )
		{
			if ( $this->input->post('username') == 'admin' && $this->input->post('password') == 'password' )
			{
				$this->auth->login();
				url::redirect('admin');
			}
			else
			{
				$this->session->set_flash('error_message','Bad Username/Password Combo.');
				url::redirect('admin/login');
			}
		}
		else
		{
			$this->template->content = new View('admin/login');
		}
	}
	
	function logout()
	{
		$this->auth->logout();
		url::redirect('admin/login');
	}
}
