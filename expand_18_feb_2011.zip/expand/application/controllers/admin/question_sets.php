<?php defined('SYSPATH') OR die('No direct access allowed.');

class Question_Sets_Controller extends In_Out_Controller 
{
//@Author:: ANAND    
public $template = 'admin_template';
//done
	function __construct()
	{
		parent::__construct();
		$this->model = new Question_Sets_Model;
		$this->schema = $this->model->data_schema;
	}
	
		
	function index(){
	    //@Author:: ANAND 
		//To check kohana session , if its empty , redirect to login page other vise Super admin page
	     if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	  else{
	    //done
		$data['records'] = $this->model->get_all();
		$data['schema'] = $this->schema;
		$this->template->content = View::factory('admin/question_sets/list')->set($data);
		}
	}
}
