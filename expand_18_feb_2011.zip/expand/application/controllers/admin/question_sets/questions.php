<?php defined('SYSPATH') OR die('No direct access allowed.');

class Questions_Controller extends Admin_Controller 
{

	function __construct()
	{
		parent::__construct();
		$this->model = new Questions_Model;

	}
	
	function show_list($set_id)
	{   

		$data['records'] = $this->model->get_questions_in_set($set_id);
		$data['set_id'] = $set_id;
		$this->template->content = View::factory('admin/questions/list')->set($data);
	}
	
	function edit($question_id)
	{
		$data['set_id'] = $this->uri->segment('question_sets');
		if ( $_POST )
		{
			$form_data = form::get_input(array('form_prefix'=>'question'));
			$this->model->update($form_data,$this->input->post('id'));
			url::redirect('admin/question_sets/'.$data['set_id'].'/questions');
		}
		else
		{
			$data['record'] = $this->model->get_question($question_id);
			$this->template->content = View::factory('admin/questions/form')->set($data);
		}
	}
	
	function create()
	{
		$data['set_id'] = $this->uri->segment('question_sets');
		if ( $_POST )
		{
			$form_data = form::get_input(array('form_prefix'=>'question'));
			$this->model->create($form_data);
			url::redirect('admin/question_sets/'.$data['set_id'].'/questions');
		}
		else
		{
			$this->template->content = View::factory('admin/questions/form')->set($data);
		}
	}
	
	function delete()
	{
		if ( $_POST )
		{
			$this->model->delete($this->input->post('id'));
		}
	}
	
}
