<?php defined('SYSPATH') OR die('No direct access allowed.');

class Questions_Controller extends Admin_Controller 
{

	function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{
		
	}
	
}
