<?php defined('SYSPATH') OR die('No direct access allowed.');

class Results_Controller extends Admin_Controller 
{

	function __construct()
	{
		parent::__construct();
		$this->model = new Results_Model;
	}
	
	function home($set_id)
	{
		url::redirect('admin/results/'.$set_id.'/questions');
		//$data['set_id'] = $set_id;
		//$this->template->content = View::factory('admin/results/home')->set($data);
	}
	
	function questions($set_id='')
	{
		$questions_model = new Questions_Model;
		$data['set_id'] = $set_id;
		$data['questions'] = $questions_model->get_questions_in_set($set_id);
		$this->template->content = View::factory('admin/results/questions_list')->set($data);
	}
	
	function question($question_id)
	{
		$data['set_id'] = $this->uri->segment('results');
		$data['answer_results'] = $this->model->get_user_answers_calculated($question_id);
		$questions_model = new Questions_Model;
		$data['question'] = $questions_model->get_question($question_id);
		$this->template->content = View::factory('admin/results/questions_report')->set($data);
	}
	
	function export($set_id)
	{
		$this->auto_render = FALSE;
		$questions_model = new Questions_Model;
		$data['set_id'] = $set_id;
		$results = $this->model->get_set_results($set_id);
		
		if ( $_REQUEST['type'] == 'excel' )
		{
			$excelExport = new Excel_export();
			foreach ($results as $result)
			{
				$arr = array();
				foreach ($result as $value)
				{
					$arr[] = $value;
				}
				$excelExport->addRow($arr);
			}	
			$excelExport->download('results_set'.$set_id.'.xls');
		}
		elseif ( $_REQUEST['type'] == 'csv' )
		{
			$filename = APPPATH.'tmp/results_set_'.$set_id.'.csv';
			ini_set('auto_detect_line_endings',1);
			$fp = fopen($filename, 'w');
			
			foreach ($results as $result)
			{
				$arr = array();
				foreach ($result as $value)
				{
					$arr[] = str_replace('"',"'",$value);
				}
				fputcsv($fp,$arr,',','"');
			}	
			
			fclose($fp);
			
			header("Content-disposition: attachment; filename=".basename($filename));
			header("Content-type: application/octet-stream");
			readfile($filename);		
		}
		else
		{
			print_r($results);
		}
	}
	
}
