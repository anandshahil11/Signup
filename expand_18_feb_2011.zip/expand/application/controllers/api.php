<?php defined('SYSPATH') OR die('No direct access allowed.');

class Api_Controller extends Controller 
{

	public $return = '';
	
	function __construct()
	{
		parent::__construct();
		
		if ( Router::$method != 'index' )
		{
			Event::add('system.post_controller', array($this, '_return'));
		}
	}
	
	function _return()
	{	
		if ( $this->return->error )
		{
			$return_array = array('error_message'=>$this->return->error,'status'=>false);
		}
		else
		{
			$return_array = array();
			
			if ( is_array($this->return->content) )
			{
				$return_array = $this->return->content;
			}
			
			$return_array['status'] = true;
		}
		
		$_REQUEST['amf_return'] = $return_array;

		
	}
}
