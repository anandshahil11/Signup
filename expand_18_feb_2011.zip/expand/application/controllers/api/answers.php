<?php defined('SYSPATH') OR die('No direct access allowed.');

class Answers_Controller extends Api_Controller 
{

	function __construct()
	{
		parent::__construct();
		$this->answers = new Answers_Model;
	}
	
	//============================================================
	//
	// 	POST ANSWER
	//
	//============================================================
	function post_answer()
	{
		$sess_id = $this->input->post('sess_id');
		$question_set_id = $this->input->post('question_set_id');
		$question_id = $this->input->post('question_id');
		$answer = $this->input->post('answer');
		
		if ( $sess_id == '' ){
			$this->return->error = "You must include a Session ID";
			return;
		}		
		if ( $question_set_id == '' ){
			$this->return->error = "You must include a Question Set ID";
			return;
		}
		if ( $question_id == '' ){
			$this->return->error = "You must include a Question ID";
			return;
		}
		if ( $answer == '' ){
			$this->return->error = "You must include an answer";
			return;
		}
		
		$this->answers->post_answer($sess_id,$question_set_id,$question_id,$answer);
	}


	//============================================================
	//
	// 	POST Question Status
	//
	//============================================================
	function post_question()
	{
		$sess_id = $this->input->post('sess_id');
		$question_set_id = $this->input->post('question_set_id');
		$question_id = $this->input->post('question_id');
		$status = $this->input->post('status');
		
		if ( $sess_id == '' ){
			$this->return->error = "You must include a Session ID";
			return;
		}		
		if ( $question_set_id == '' ){
			$this->return->error = "You must include a Question Set ID";
			return;
		}
		if ( $question_id == '' ){
			$this->return->error = "You must include a Question ID";
			return;
		}
		if ( $status == '' ){
			$this->return->error = "You must include an status";
			return;
		}
		
		$this->answers->post_question($sess_id,$question_set_id,$question_id,$status);
	}

	
	

	
	//============================================================
	//
	// 	Contact answer
	//
	//============================================================
	function post_contact()
	{
		$sess_id = $this->input->post('sess_id');
		$question_set_id = $this->input->post('question_set_id');
		$question_id = $this->input->post('question_id');
		$emailid = $this->input->post('emailid');
		$fullname = $this->input->post('fullname');
		$phonenum = $this->input->post('phonenum');
		$product = $this->input->post('product');
				
		$this->answers->post_contact($sess_id,$question_set_id, $question_id, $fullname,$emailid,$phonenum,$product);
	}
	
	
	function post_ganedenform()
	{
		$sess_id = $this->input->post('sess_id');
		$question_set_id = $this->input->post('question_set_id');
		$question_id = $this->input->post('question_id');
		$fieldName = $this->input->post('field_name');
		$fieldValue = $this->input->post('field_value');		
				
		$this->answers->post_ganedenform($sess_id,$question_set_id, $question_id, $fieldName,$fieldValue);
	}
}
