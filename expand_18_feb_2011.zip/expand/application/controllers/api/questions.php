<?php defined('SYSPATH') OR die('No direct access allowed.');

class Questions_Controller extends Api_Controller 
{

	function __construct()
	{
		parent::__construct();
		$this->questions = new Questions_Model;
	}
	
	//============================================================
	//  GET QUESTIONS
	//============================================================
	function get_questions()
	{
		$question_set_id = $this->input->post('question_set_id');

		if ( $question_set_id == '')
		{
			$this->return->error = "You must pass a Question Set ID";
			return;
		}
		
		$questions = $this->questions->get_questions_in_set($question_set_id);
		
//		$questions_edited = array();
		$count = 0;
		$questions_edited = array();
		foreach ($questions as $question)
		{
			$questions[$count]['answers'] = array();
			for ($i=1; $i<=4; $i++)
			{
				$questions[$count]['answers'][] = array(
					'text'=>$question['answer'.$i],
					'media'=>$question['answer'.$i.'_media'],
					'next'=>$question['answer'.$i.'_next']
				);
				
				unset($questions[$count]['answer'.$i]);
				unset($questions[$count]['answer'.$i.'_media']);
				unset($questions[$count]['answer'.$i.'_next']);
				
				$questions_edited[$question['id_in_set']] = $questions[$count];
			}
			$count++;
			
			
		}
		
		$this->return->content = array();
		$this->return->content['total'] = count($questions);
		$this->return->content['questions'] = $questions_edited;
	}
}
