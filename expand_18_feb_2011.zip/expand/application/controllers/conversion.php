<?php
session_start();
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 08-Dec-2010
Page Description:: Conversion Controller 
*********************************************/

class Conversion_Controller extends Controller {

	function __construct(){
	    parent::__construct();
	}
	
	public function openEmail($examid,$action,$TimePeriod){
		if(isset($_SESSION['userContact']) and (!empty($_SESSION['userContact'])) ){
			$userContact=$_SESSION['userContact'];
		}else{
			$userContact[0]['fullname']="NA";
			$userContact[0]['email']="NA";
			$userContact[0]['phonenum']="NA";
			$userContact[0]['product']="NA";
		}
		$view = new View('smartsite/email');
		$view->sender = SENDER;
		$view->subject = SUBJECTLEFT; 
		$html = "<html><head>
				 <style type='text/css'>
				
				.blue_zebra {
					border-bottom: #fff solid 2px;
				}

				.blue_zebra tbody td, .blue_zebra thead th {
					padding: 2px 20px;
				}
				
				.blue_zebra tbody tr {
					height: 20px;
					border-bottom: #000 solid 2px;
					
				}

				.blue_zebra thead th {
					background-color: #000;
					color:#FFF;
					font-family:Verdana;
					font-size:11pt;
					font-weight:bold;
				}
				.blue_zebra tr {
					color:#000;
					background-color: #E5E5E5;
					font-family:Verdana;
					font-size:13pt;
				}				
				
				#footer {
					background: #CCC url(/expand/media/img/header_bg.png) repeat-x;
					height: 100px;
					width: 100%;
				}
				
				
	
				
				 </style>
				 </head>
					<body><p><b><font color='#808080'><h1 style='font-size:18px;'>Lead Contact Information</h1></font></b> </p>
				
				<table class='blue_zebra' style='table-layout:auto;width:900px;'>
				<thead ><tr><th>Name</th><th>Email Id</th><th>Phone Number</th><th>Product</th></tr></thead>
				<tbody>";
	        $html1=""; 			
		
		for($i=0;$i<count($userContact);$i++){	
		        $html1.="<tr ><td>".$userContact[$i]['fullname']."</td><td>".$userContact[$i]['email']."</td><td>".$userContact[$i]['phonenum']."</td><td>".$userContact[$i]['product']."</td></tr>";
		        
		}
		
		$view->html =$html.$html1."</tbody></table><br/><table id='footer'>
				<tr><td width='40%' align='left' cellpadding='20px'>
				 <a href='http://smartsite.expandinteractive.com/'>
				<img src='http://smartsite.expandinteractive.com/media/img/loginSmartsite_btn.PNG' alt='Login to Expand Interactive' />
		                </a></td><td width='60%' align='left'>
			
				<img src='http://smartsite.expandinteractive.com/media/img/logo.png' />
				</td>
				<td>
				<a href='/expand/conversion/exportLeft/$examid/$action/$TimePeriod' >
				<img src='/expand/media/img/export_btn_old.png' alt='Export To CSV'>
                </a>
				</td>
				
				</tr></table></body></html>";  
		$view->message='';
		if(count($_POST)>0){	
			include('Mail.php');
			include('Mail/mime.php');   
			$recipient=$_POST['to'];
			$sender=$_POST['from'];
			$subject=$_POST['subject'];
			$cc=$_POST['cc'];
			$bcc=$_POST['bcc'];
			$headers = array(
					  'From'          => $sender,
					  'Return-Path'   => $sender,
					  'Subject'       => $subject,
					  "Cc" => $cc,
					  "Bcc" => $bcc,
					);
			$crlf = "\n";
			$mime = new Mail_mime($crlf);
			$text = 'This is a text message.';  
			$mime->setTXTBody($text);
			$mime->setHTMLBody($view->html);
			$body = $mime->get();
			$headers = $mime->headers($headers);
			$mail =& Mail::factory('mail');
			$result=$mail->send($recipient, $headers, $body);
			if($result==1){
			$view->message = "<h3>Contact has been Emailed.</h3>";
			}else{
			$view->message = "<h3>Email has some Error.</h3>";
		    }
		}		
		$view->render(TRUE);
	
	}
	
	function openRightEmail($sessid,$name,$email='',$phone='',$product='',$examid='',$notify=''){
		include('Mail.php');
		include('Mail/mime.php');   
		$quesAnswer=$_SESSION['quesAnswer'];
		if((isset($name)) && (strlen(trim($name)) > 0)){
			$name = stripslashes(strip_tags($name));
		}else{
		    $name = 'No Name entered';
		} 
		
		if((isset($email)) && (strlen(trim($email)) > 0)){
			$email = stripslashes(strip_tags($email));
		}else{
		    $email = 'No email entered';
		}
		
		if((isset($phone)) && (strlen(trim($phone)) > 0)){
			$phone = stripslashes(strip_tags($phone));
		}else{
		    $phone = 'No phone entered';
		}
		
		if((isset($product)) && (strlen(trim($product)) > 0)){
			$product = stripslashes(strip_tags($product));
		}else{
		    $product = 'No Product entered';
		} 
		
		if((isset($notify)) && (strlen(trim($notify)) > 0)){
			$notify = "Yes";
		}else{
		    $notify = 'No';
		} 
        $examid=$examid;
		$view = new View('smartsite/email');
		$view->sender = SENDER;
		$view->subject = SUBJECTRIGHT;
		$view->message='';
		$text = '';  
		$html = "<html>
				 <head>
				 <style type='text/css'>
				.blue_zebra {
					border-bottom: #fff solid 2px;
				}

				.blue_zebra tbody tr {
					height: 20px;
				}

				.blue_zebra tbody td, .blue_zebra thead th {
					padding: 2px 20px;
				}

				.blue_zebra thead th {
					background-color: #000;
					color:#FFF;
					font-family:Verdana;
					font-size:11pt;
					font-weight:bold;
				}
				.blue_zebra tr {
					color:#000;
					font-family:Verdana;
					font-size:11pt;
				}
				
				.gray_zebra {
					border-bottom: #fff solid 2px;
				}

				.gray_zebra tbody tr {
					height: 20px;
				}

				.gray_zebra tbody td, .gray_zebra thead th {
					padding: 2px 20px;
				}

				.gray_zebra thead th {
					background-color: #666666;
					color:#FFF;
					font-family:Verdana;
					font-size:11pt;
					font-weight:bold;

				}
				.gray_zebra tr {
					color:#000;
					background-color: #E5E5E5;
					font-family:Verdana;
					font-size:10pt;

				}
				
				#footer {
					background: #CCC url(/expand/media/img/header_bg.png) repeat-x;
					height: 100px;
					width: 100%;
				}
				
				
	
				
				 </style>
				 </head>
				
				<body>
				
				<p><b><font color='#808080'><h1 style='font-size:18px;'>New Lead Information</h1></font></b> </p>
				
				<table class='blue_zebra' style='table-layout:auto;width:800px;'>
				<thead><tr><th>Name</th><th>Email Id</th><th>Phone Number</th><th>Product</th><th>Contacted</th></tr></thead>
				<tbody><tr><td>$name</td><td>$email</td><td>$phone</td><td>$product</td><td>$notify</td></tr>
				</tbody>
				</table>
				<br/>
				<table class='gray_zebra' style='table-layout:auto;width:800px;'>
				<thead><tr><th>Question</th><th>Answer</th></tr></thead>
				<tbody>";
		for($i=0;$i<count($quesAnswer);$i++){	
			$html.="<tr><td>".$quesAnswer[$i]['question']."</td><td><b>".$quesAnswer[$i]['answer']."</b></td></tr>";
		}
		$html.=	"</tbody></table><br/><table id='footer'>
				<tr><td width='40%' align='left' cellpadding='20px'>
				 <a href='http://smartsite.expandinteractive.com/'>
				<img src='http://smartsite.expandinteractive.com/media/img/loginSmartsite_btn.PNG' alt='Login to Expand Interactive' />
		                </a></td><td width='60%' align='left'>
			
				<img src='http://smartsite.expandinteractive.com/media/img/logo.png' />
				</td>
				<td>
				<a href='/expand/conversion/exportRight/$sessid' >
				<img src='/expand/media/img/export_btn_old.png' alt='Export To CSV'>
                </a>
				</td>
				</tr></table></body></html>";  

        $view->html=$html;
		$view->message='';
		if(count($_POST)>0)
		{	
			$recipient=$_POST['to'];
			$sender=$_POST['from'];
			$subject=$_POST['subject'];
			$cc=$_POST['cc'];
			$bcc=$_POST['bcc'];
			$headers = array(
					  'From'          => $sender,
					  'Return-Path'   => $sender,
					  'Subject'       => $subject,
					  "Cc" => $cc,
					  "Bcc" => $bcc,
					);
			$crlf = "\n";
			$mime = new Mail_mime($crlf);
			$text = 'This is a text message.';  
			$mime->setTXTBody($text);
			$mime->setHTMLBody($view->html);
			$body = $mime->get();
			$headers = $mime->headers($headers);
			$mail =& Mail::factory('mail');
			$result=$mail->send($recipient, $headers, $body);
			if($result==1){
			$view->message = "<h3>Contact has been Emailed.</h3>";
			}else{
			$view->message = "<h3>Email has some Error.</h3>";
			}
		}
		$view->render(TRUE);
		
	}
	public function exportLeft($examid,$action,$TimePeriod){
	        if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
				$enddate = date("Y-m-d H:m:s",time()+216000);
				$startdate = "1977-01-01";

			}
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
				
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
				$enddate   = $curdate;
			}
			
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
				$enddate   = $curdate;
			}
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
				$enddate   = $curdate;
			}
		$user_contact = new Answers_Model;
	    if($action=='leads'){
		    $userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
		}elseif($action=='sales'){
			$userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
		}else{
			$userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
		}
		$csv_output = '';
		$csv_output = "Name".", "."Email Id".", "."Phone Number".", "."Product".", ";
		$csv_output .= "\n";
		for($i=0;$i<count($userContact);$i++){	
		        $csv_output .= $userContact[$i]['fullname'].", ".$userContact[$i]['email'].", ".$userContact[$i]['phonenum'].", ".$userContact[$i]['product'].", ";
                $csv_output .= "\n";
		}
		$filename = "usersData"."_".date("Y-m-d_H-i",time());
        //Generate the CSV file header
		header("Content-type: application/vnd.ms-excel");
		header("Content-disposition: csv" . date("Y-m-d") . ".csv");
		header("Content-disposition: filename=".$filename.".csv");
        print $csv_output;
        exit;
		
	}
	
	public function exportRight($sessid){
	    $contact_details = new User_Contact_Model;
		$contactDetails = $contact_details->contactdetails($sessid);
		$userContactData['sess_id'] = $contactDetails['sess_id'];
		$userContactData['fullname'] = $contactDetails['fullname'];
		$userContactData['email'] = $contactDetails['emailid'];
		$userContactData['phonenum'] = $contactDetails['phonenum'];
		$userContactData['product'] = $contactDetails['product'];
		$QuesAnswerList = $contact_details->getQuesAnswerList($userContactData['sess_id']);
        $csv_output = '';
		$csv_output = "Name".", "."Email Id".", "."Phone Number".", "."Product".", ";
		$csv_output .= "\n";
		$csv_output .= $userContactData['fullname'].", ".$userContactData['email'].", ".$userContactData['phonenum'].", ".$userContactData['product'].", ";
        $csv_output .= "\n\n\n\n";
		$csv_output .= "Question".", "."Answer".", ";
		$csv_output .= "\n";
		for($i=0;$i<count($QuesAnswerList);$i++){	
		        $csv_output .= $QuesAnswerList[$i]['question'].", ".$QuesAnswerList[$i]['answer'].", ";
                $csv_output .= "\n";
		}
		$filename = "userDetails"."_".date("Y-m-d_H-i",time());
        //Generate the CSV file header
		header("Content-type: application/vnd.ms-excel");
		header("Content-disposition: csv" . date("Y-m-d") . ".csv");
		header("Content-disposition: filename=".$filename.".csv");
        print $csv_output;
        exit;
		
		
	}
	
	
}