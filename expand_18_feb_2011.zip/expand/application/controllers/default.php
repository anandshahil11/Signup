<?php defined('SYSPATH') OR die('No direct access allowed.');

class Default_Controller extends Site_Controller 
{

	function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{
		$this->template->content = View::factory('default');
	}
}
