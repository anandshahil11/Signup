<?php
session_start();
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 22-Dec-2010
Page Description:: Service Wizard Controller 
*********************************************/

class ServiceWizard_Controller extends Controller {

	function __construct(){
	    parent::__construct();
	}
	
	public function rightServicePane(){
		if(isset($_POST["TimePeriod"])){
	       $TimePeriod = $_POST["TimePeriod"];
	    }
	  	if(isset($_POST["causeid"])){
			$causeid = $_POST["causeid"];
		}
		if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
			$enddate = date("Y-m-d H:m:s",time()+216000);
			$startdate = "1977-01-01";

		}
		if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
			
			$curdate = date('Y-m-d H:m:s');
			$startdate = date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
			$enddate = $curdate;
		}
		
		if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
			$curdate = date('Y-m-d H:m:s');
			$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
			$enddate = $curdate;
		}
		if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
			$curdate = date('Y-m-d H:m:s');
			$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
			$enddate = $curdate;
		}
		$serviceRightpanel = new Servicewizard_Model;
		$serviceCauseList = $serviceRightpanel->getserviceCauseList($causeid,$startdate,$enddate); 
		$view = new View('smartsite/rightServicePane_view');
		$view->serviceCauseList=$serviceCauseList;
		$view->render(TRUE);
	
	}
	

}