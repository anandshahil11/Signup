<?php defined('SYSPATH') or die('No direct script access.');

class Site_Controller extends Template_Controller {
	
    public function __construct()
    {
        parent::__construct();
   
		$this->template->title = 'Skeleton Title (in controllers/site.php)';
		$this->session = Session::instance();
	}
}
?>
