<?php
session_start();
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 02-Sep-2010
Page Description:: Smartsite Controller 
*********************************************/

class Smartsite_Controller extends Controller {

	function __construct(){
	    parent::__construct();
	}
	
    //To display right pane of user Ananlytics
	function rightuserPane(){
		if(isset($_POST["userid"])){
			$userid = $_POST["userid"];
		}
		
		if(isset($_POST["empid"])){
			$empid = $_POST["empid"];
		}
		
		if(isset($_POST["action"])){
			$action = $_POST["action"];
		}
		
		$view = new View('smartsite/rightuserPane');
		$access1 = ORM::factory('user')->where('id',$userid)->find();
		$access2 = ORM::factory('role')->where('id',$userid)->find();
		$username = $access1->username;
		$role = $access2->name;
		$company = $access2->company;
		$userUpdate = ''; 
		$userexamData = '';
		$examName = '';
		$examScore = '';
		
		if($action==="none"){
			$user_Info = new User_Information_Model;
			$userInfo = $user_Info->getuserInformation($company);
			$user_Login = new User_Model; 
			$userLogin = $user_Login->getuserlastLogin($userInfo);
			$count = count($userInfo);
			$idArray = array();
			$userData = array();
			for($i=0;$i<$count;$i++){
				$idArray[] = $userInfo[$i]['id'];	
			}
			if($empid!=="none"){
                
				if(in_array($empid,$idArray)){
				 
					$userData = $user_Info->getuserData($empid);
					$userLoginNum = $user_Login->getuserLoginnum($empid);
					$userLastlogin = $user_Login->getuserLastloginnum($empid);
					$userExamResult = $user_Login->getuserExamresult($empid);  
					$exam_Set = new Exam_User_Answer_Model;
					$examSet = $exam_Set->getExamset($empid);
					$exam_setName = new Exam_Question_Set_Model;
					if($examSet===EXAMMESSAGE){
						$userexamData = EXAMMESSAGE;
					}else{
						$count = count($examSet);
						$exam_question = new Exam_Question_Model;
						$examScore = array();
						$examName = array();
						$value = array();
						for($i=0;$i<$count;$i++){
							$examid = $examSet[$i];
							$result = $exam_Set->get_user_questions_result($examid,$empid);
							$examsetName = $exam_setName->getExamName($examid);
							$value = explode(":",$result);
							$examScore[$examid] = $value[0];
							$examName[$examid] = $examsetName[0];
							
						}
				
					}			
				}else{
					
					$userData = USERMESSAGE;
				}
				
			}else{
			
				$empid = $idArray[0];
				$userData = $user_Info->getuserData($empid);
				$userLoginNum = $user_Login->getuserLoginnum($empid);
				$userLastlogin = $user_Login->getuserLastloginnum($empid);
				$userExamResult = $user_Login->getuserExamresult($empid);  
				$exam_Set = new Exam_User_Answer_Model;
				$examSet = $exam_Set->getExamset($empid);
				$exam_setName = new Exam_Question_Set_Model;
					if($examSet===EXAMMESSAGE){
						$userexamData = EXAMMESSAGE;
					}else{
						$count = count($examSet);
						$exam_question = new Exam_Question_Model;
						$examScore = array();
						$examName = array();
						$value = array();
						for($i=0;$i<$count;$i++){
							$examid = $examSet[$i];
							$result = $exam_Set->get_user_questions_result($examid,$empid);
							$examsetName = $exam_setName->getExamName($examid);
							$value = explode(":",$result);
							$examScore[$examid] = $value[0];
							$examName[$examid] = $examsetName[0];
							
						}
						
					}						
			}
		 		
		}elseif($action==="search"){
					   
						$searchDisplay = 'search';
						if(isset($_POST['submit'])){
						    $search = addslashes(strip_tags(@$_POST['search']));
						    $trimmedSearch = trim($search); 
						    $trimmedSearch_array = explode(" ",$trimmedSearch);
							if (!isset($search)){
							    $resultmsg =  "<p>Search Error..We don't seem to have a search parameter! </p>" ;
							}
							$usersearch_Info = new User_Information_Model;
						    $usersearchInfo = $usersearch_Info->getusersearchInformation($company,$trimmedSearch_array);
							$userInfo = $usersearchInfo;
							$count = count($userInfo);
							if($count>0){
								$idArray = array();
								$userData = array();
								for($i=0;$i<$count;$i++){
									$idArray[] = $userInfo[$i]['id'];	
								}
								$usersearch_Login = new User_Model; 
								$userSearchLogin = $usersearch_Login->getSearchuserlastLogin($idArray);
								$userLogin = $userSearchLogin;
								$empid = $idArray[0];
								$userData = $usersearch_Info->getuserData($empid); 
								$userLoginNum = $usersearch_Login->getuserLoginnum($empid);	
                                $userLastlogin = $usersearch_Login->getuserLastloginnum($empid);
								$userExamResult = $usersearch_Login->getuserExamresult($empid);  
								$exam_Set = new Exam_User_Answer_Model;
								$examSet = $exam_Set->getExamset($empid);
								$exam_setName = new Exam_Question_Set_Model;
									
								if($examSet===EXAMMESSAGE){
									$userexamData = EXAMMESSAGE;
								}else{
									$count = count($examSet);
									$exam_question = new Exam_Question_Model;
									$examScore = array();
									$examName = array();
									$value = array();
									for($i=0;$i<$count;$i++){
										$examid = $examSet[$i];
										$result = $exam_Set->get_user_questions_result($examid,$empid);
										$examsetName = $exam_setName->getExamName($examid);
										$value = explode(":",$result);
										$examScore[$examid] = $value[0];
										$examName[$examid] = $examsetName[0];
										
									}
									
								}
		
							}else{
								$searchResult = "<h3>".SEARCHMESSAGE." $search</h3>";
								
							}
						
						}else{
							$trimmedSearch_array = $_SESSION['search'];
							$usersearch_Info = new User_Information_Model;
							$usersearchInfo = $usersearch_Info->getusersearchInformation($company,$trimmedSearch_array);
							$userInfo = $usersearchInfo;
							$count = count($userInfo);
							if($count>0){
								$idArray = array();
								$userData = array();
								for($i=0;$i<$count;$i++){
									$idArray[] = $userInfo[$i]['id'];	
								}
								$usersearch_Login = new User_Model; 
								$userSearchLogin = $usersearch_Login->getSearchuserlastLogin($idArray);
								$userLogin = $userSearchLogin;
								if($empid!=="none"){
			                        if(in_array($empid,$idArray)){
										
										$userData = $usersearch_Info->getuserData($empid);
										$userLoginNum = $usersearch_Login->getuserLoginnum($empid);
										$userLastlogin = $usersearch_Login->getuserLastloginnum($empid);
										$userExamResult = $usersearch_Login->getuserExamresult($empid);
										$exam_Set = new Exam_User_Answer_Model;
										$examSet = $exam_Set->getExamset($empid);
										$exam_setName = new Exam_Question_Set_Model;
										
										if($examSet===EXAMMESSAGE){
											$userexamData = EXAMMESSAGE;
										}else{
											$count = count($examSet);
											$exam_question = new Exam_Question_Model;
											$examScore = array();
											$examName = array();
											$value = array();
											for($i=0;$i<$count;$i++){
												$examid = $examSet[$i];
												$result = $exam_Set->get_user_questions_result($examid,$empid);
												$examsetName = $exam_setName->getExamName($examid);
												$value = explode(":",$result);
												$examScore[$examid] = $value[0];
												$examName[$examid] = $examsetName[0];
												
											}
											
										}	
											
									}else{
										
										$userData = USERMESSAGE;
									}
									
								}

							}else{
								$searchResult = "<h3>".SEARCHMESSAGE." $search</h3>";
								
							}

						}
					
		}else{
			//
		}
		$view->userInfo = $userInfo;
		$view->userLogin = $userLogin;
		$view->userData = $userData;
		$view->userLoginNum = $userLoginNum;
		$view->userLastlogin = $userLastlogin;
		$view->userExamResult = $userExamResult;
		$view->userid = $userid;
		$view->userUpdate = $userUpdate;
		$view->userexamData = $userexamData;
		$view->examName = $examName;
		$view->examScore = $examScore;
		//$view->emailId=$emailId;
		$view->render(TRUE);
			
	}

	//TO display right panel of Learning Analytics 
	function rightPane($userid){
		if(isset($_POST["TimePeriod"])){
	       $TimePeriod = $_POST["TimePeriod"];
	    }
	  	if(isset($_POST["examid"])){
			$examid = $_POST["examid"];
		}
		if(isset($_POST["quesid"])){
			$quesid = $_POST["quesid"];
		}
		if(isset($_POST["set"])){
			$set = $_POST["set"];
		}
		    // Date calculation 
		
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
				$enddate = date("Y-m-d H:m:s",time()+216000);
				$startdate = "1977-01-01";

			}
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
				
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
				$enddate = $curdate;
			}
			
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
				$enddate = $curdate;
			}
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
				$enddate = $curdate;
			}
		$view = new View('smartsite/rightPane');
		$view->set = $set;
		if($set==="dialogue"){
			   
			$user_contact = new Answers_Model;
			$countProduct = $user_contact->countDigitalProduct($startdate,$enddate,$examid);
			//To Get no of user given specific Flash exam  and no of completion 
			$digital_question = new Answers_Model;
			$result = $digital_question->get_questions_result($examid,$startdate,$enddate);
			$answer = array();
			$answer = explode(":",$result);
			$view->digiAnswer = $answer;
			$view->countProduct = $countProduct;
			//To Get all question list in specific Flash exam set 
			$digital_QuestionList = new Questions_Model;
			$digiQuestionList = $digital_QuestionList->get_questions_set($examid);
			$clicks = $digital_QuestionList->getClicks($examid,$startdate,$enddate);
			$count1 = count($clicks);
			if($count1!=0){
				$response = $digital_QuestionList->getResponses($examid,$startdate,$enddate);
				$count = count($response);
				$questionId = array();
				$quesClicks = array();
				$quesAsked = array();
				for($i=0;$i<$count;$i++){
					$questionId[$i] = $response[$i]['quesid'];
					$quesClicks[$i] = $response[$i]['respond'];
					//$quesAsked[$i] = $clicks[$i]['asked'];
				}
				
				for($i=0;$i<$count1;$i++){
					$quesId[$i] = $clicks[$i]['quesid'];
					$quesAsked[$i] = $clicks[$i]['asked'];
					//$quesAsked[$i] = $clicks[$i]['asked'];
				
				}
				$ques_respond = array_combine($questionId,$quesClicks);
				$clicks = array_combine($quesId,$quesAsked);
			}else {
				$ques_respond = 0;
				$clicks = 0;
			}	
			$view->digiQuestionListid = $digiQuestionList['id'];
			$view->digiQuestions = $digiQuestionList['ques'];
         	$view->Click = $clicks;
			$view->quesRespond = $ques_respond;
				
			//To Display  each Question and its answer 
			if(!isset($quesid)){
				$quesid = "";
			}
			if($quesid==""){
				
				$quesid = $digiQuestionList['id'][0];
			}
			$digital_exam_question = new Questions_Model;
			$digi_ans_list = $digital_exam_question->each_ques($examid,$quesid);
			$view->digiAnswerlist = $digi_ans_list;
			$view->digiQuesid = $quesid;
			$view->digiResponsetype = $digi_ans_list["res_type"];
			$digital_probability = new Answers_Model;
			$digi_probability = $digital_probability->get_probability($examid,$quesid,$startdate,$enddate);
			$view->digiProbability = $digi_probability;
			}else{
                //To get Correct answer from question 
     			$exam_question = new Exam_Question_Model;
				$result = $exam_question->get_questions_result($examid,$startdate,$enddate);
				$answer = array();
				$answer = explode(":",$result);
                $questionlist = $exam_question->get_questions_set($examid);
				//To Display correct and Incorrect answer on page
				$examuser = new Exam_User_Answer_Model;
				$correctanswer = $examuser->get_correct($examid,$questionlist['id'],$startdate,$enddate);
				$incorrectanswer = $examuser->get_incorrect($examid,$questionlist['id'],$correctanswer,$startdate,$enddate);
				
				//To Display  each Question and its answer 
				$exam_question1 = new Exam_Question_Model;
				$ques_ans_list = $exam_question1->each_ques($examid,$quesid);
				
				//To Display Pie chart value for each question 
				$each_question_result = new Exam_User_Answer_Model;
				$answerlist = $each_question_result->get_ques_result($examid,$quesid,$startdate,$enddate);
				
				if(!empty($answerlist)){

					$answernum = array();
					$count = array();
					
					$answernum = array_values($answerlist['answer']);
					$count = array_values($answerlist['answercount']);
					$final = array_combine($answernum,$count);
					$emptyanswer = array();
						if (!array_key_exists(1, $final)) {
							$emptyanswer[1]=0;
						}
						if (!array_key_exists(2, $final)) {
							$emptyanswer[2]=0;
						}
						if (!array_key_exists(3, $final)) {
							$emptyanswer[3]=0;
						}
						if (!array_key_exists(4, $final)) {
							$emptyanswer[4]=0;
						}
					
					$finalresult = $final+$emptyanswer;
				}
				$view->examid = $examid;
				$view->answer = $answer;
				$view->questionlistid = $questionlist['id'];
				$view->questions = $questionlist['ques'];
				$view->correct = $correctanswer;
				$view->incorrect = $incorrectanswer;
				$view->ques_ans_list = $ques_ans_list;
				if(!empty($finalresult)){
				$view->answerresult = $finalresult;
				}else{
				$view->answerresult = MESSAGE;
				}
			}
			$view->render(TRUE);
	
	}
	
	
	function index($userid,$examid=0,$quesid=1,$TimePeriod="none",$set="none",$serviceWizardId="none"){
        if(isset($_POST["TimePeriod"])){
	        $TimePeriod = $_POST["TimePeriod"];
	    }
	    if(isset($_POST["userid"])){
	        $userid = $_POST["userid"];
	    }
	    if(isset($_POST["examid"])){
	        $examid = $_POST["examid"];
	    }
	    if(isset($_POST["quesid"])){
	        $quesid = $_POST["quesid"];
	    }
	    if(isset($_POST["set"])){
	        $set = $_POST["set"];
	    }
	  
        // If user tries to click on backward button , after logout  
	    if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
	     
		    // Date calculation 
		    if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
				$enddate = date("Y-m-d H:m:s",time()+216000);
				$startdate = "1977-01-01";

			}
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
				
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
				$enddate = $curdate;
			}
			
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
				$enddate = $curdate;
			}
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
				$enddate = $curdate;
			}

		//To get UserName and Role based on userid
		$access1 = ORM::factory('user')->where('id',$userid)->find();
		$access2 = ORM::factory('role')->where('id',$userid)->find();
		$username = $access1->username;
		$role = $access2->name;
		$company = $access2->company;
        if($set==="none"){
            $access4 = ORM::factory('company_set')->where('company',$company)->find();
            $set = $access4->type;
			$company_id = $access4->id;
		}
		
	    if(!empty($username) and $role=='admin'){
			$view = new View('smartsite/learninganalytic');
			$view->username = $username;
			$view->role = $role;
			$view->digitalExam = "";
			$view->userid = $userid;
			$view->TimePeriod = $TimePeriod;
			$view->company = $company;
			if($set==="dialogue"){
                $examList = new Exam_Question_Set_Model;
                $examlist = $examList->getexamList($company);    
                $count = count($examlist);
                $c = array();
                for($i=0;$i<$count;$i++){
                    $id = $examlist[$i]['id'];
                    $c[$id] = $examlist[$i]['name'];
                }
                $view->exam = $c;
				$examKeys = array_keys($c);
				if(!empty($examKeys)){
				    if($examid=="0"){
						$examid = $examKeys[0];
					}
				}
				$view->examid = $examid;			
				// To Get List of Digital Demo
				$digital_question = new Question_Sets_Model;
				$digitalExam = $digital_question->exam_list($company);
				$view->digitalExam = $digitalExam;
     			$exam_id = array_keys($digitalExam);
				$examid = $exam_id[0];
				$view->digitalExam = $digitalExam;
                $view->examid = $examid;
                $user_contact = new Answers_Model;
				$countProduct = $user_contact->countDigitalProduct($startdate,$enddate,$examid);
				//To Get no of user given specific Flash exam  and no of completion 
				$digital_question = new Answers_Model;
				$result = $digital_question->get_questions_result($examid,$startdate,$enddate);
				$answer = array();
				$answer = explode(":",$result);
                $view->digiAnswer = $answer;
				$view->countProduct = $countProduct;
				//To Get all question list in specific Flash exam set 
				$digital_QuestionList = new Questions_Model;
				$digiQuestionList = $digital_QuestionList->get_questions_set($examid);
				$clicks = $digital_QuestionList->getClicks($examid,$startdate,$enddate);
				$count1 = count($clicks);
				if($count1!=0){
					$response = $digital_QuestionList->getResponses($examid,$startdate,$enddate);
					$count = count($response);
					$questionId = array();
					$quesClicks = array();
					$quesAsked = array();
					for($i=0;$i<$count;$i++){
						$questionId[$i] = $response[$i]['quesid'];
						$quesClicks[$i] = $response[$i]['respond'];
						//$quesAsked[$i] = $clicks[$i]['asked'];
					}
					
					for($i=0;$i<$count1;$i++){
						$quesId[$i] = $clicks[$i]['quesid'];
						$quesAsked[$i] = $clicks[$i]['asked'];
						//$quesAsked[$i] = $clicks[$i]['asked'];
					}
					if(count($quesClicks)==0 AND count($questionId)==0 ){
					$ques_respond = '';
					}else{
					$ques_respond = array_combine($questionId,$quesClicks);
					}
					$clicks = array_combine($quesId,$quesAsked);
				}else {
					$ques_respond = 0;
					$clicks = 0;
				}	
				$view->digiQuestionListid = $digiQuestionList['id'];
				$view->digiQuestions = $digiQuestionList['ques'];
                $view->Click = $clicks;
				$view->quesRespond = $ques_respond;
				
				//To Display  each Question and its answer 
				if($quesid==1){
				    $quesid = $digiQuestionList['id'][0];
				}
				$digital_exam_question = new Questions_Model;
				$digi_ans_list = $digital_exam_question->each_ques($examid,$quesid);
				$view->digiAnswerlist = $digi_ans_list;
				$view->digiQuesid = $quesid;
				$view->digiResponsetype = $digi_ans_list["res_type"];
				//To calculate the probability of occurrence of each answer in each ques of each ques set
				$digital_probability = new Answers_Model;
				$digi_probability = $digital_probability->get_probability($examid,$quesid,$startdate,$enddate);
				$view->digiProbability = $digi_probability;
				$view->examid = $examid;
				$view->set = $set;

			}elseif($set==="all"){
			    //For Service Wizard List 
				$access = ORM::factory('company_set')->where('company',$company)->find();
                $company_id = $access->id;
			    $serviceWizard = new Servicewizard_Model;
				$serviceWizard_list = $serviceWizard->getserviceWizardList($company_id);
				$view->serviceWizardList = $serviceWizard_list;
				//This for Exam Quizzes
				$examList = new Exam_Question_Set_Model;
                $examlist = $examList->getexamList($company);	
                $count = count($examlist);
                // To Get List of Quiz
		        $c = array();
				for($i=0;$i<$count;$i++){
					$id = $examlist[$i]['id'];
					$c[$id] = $examlist[$i]['name'];
				}				
				$view->exam = $c; 
				$examKeys = array_keys($c);
				if(empty($examKeys)){
								
                    // To Get List of Digital Demo
				    $digital_question = new Question_Sets_Model;
				    $digitalExam = $digital_question->exam_list($company);
				    $view->digitalExam = $digitalExam;
     			    $exam_id = array_keys($digitalExam);
				    $examid = $exam_id[0];
				    $view->digitalExam = $digitalExam;
			        $view->examid = $examid;
				    $user_contact = new Answers_Model;
				    $countProduct = $user_contact->countDigitalProduct($startdate,$enddate,$examid);
				    //To Get no of user given specific Flash exam  and no of completion 
				    $digital_question = new Answers_Model;
				    $result = $digital_question->get_questions_result($examid,$startdate,$enddate);
				    $answer = array();
				    $answer = explode(":",$result);
                    $view->digiAnswer = $answer;
				    $view->countProduct = $countProduct;
				    //To Get all question list in specific Flash exam set 
				    $digital_QuestionList = new Questions_Model;
				    $digiQuestionList = $digital_QuestionList->get_questions_set($examid);
				    $clicks = $digital_QuestionList->getClicks($examid,$startdate,$enddate);
				    $count1 = count($clicks);
				    if($count1!=0){
					    $response = $digital_QuestionList->getResponses($examid,$startdate,$enddate);
					    $count = count($response);
					    $questionId = array();
					    $quesClicks = array();
					    $quesAsked = array();
					    for($i=0;$i<$count;$i++){
						    $questionId[$i] = $response[$i]['quesid'];
						    $quesClicks[$i] = $response[$i]['respond'];
						    //$quesAsked[$i] = $clicks[$i]['asked'];
					    }
					
					    for($i=0;$i<$count1;$i++){
						    $quesId[$i] = $clicks[$i]['quesid'];
						    $quesAsked[$i] = $clicks[$i]['asked'];
						    //$quesAsked[$i] = $clicks[$i]['asked'];
					
				    	}
					    if(count($quesClicks)==0 AND count($questionId)==0 ){
					        $ques_respond='';
					    }else{
					        $ques_respond = array_combine($questionId,$quesClicks);
					    }
					    $clicks = array_combine($quesId,$quesAsked);
				    }else {
					    $ques_respond = 0;
					    $clicks = 0;
				    }	
				    $view->digiQuestionListid = $digiQuestionList['id'];
				    $view->digiQuestions = $digiQuestionList['ques'];
                    $view->Click = $clicks;
				    $view->quesRespond = $ques_respond;
				
				    //To Display  each Question and its answer 
				    if($quesid==1){
				        $quesid = $digiQuestionList['id'][0];
				    }
				    $digital_exam_question = new Questions_Model;
				    $digi_ans_list = $digital_exam_question->each_ques($examid,$quesid);
				    $view->digiAnswerlist = $digi_ans_list;
				    $view->digiQuesid = $quesid;
				    $view->digiResponsetype = $digi_ans_list["res_type"];
				    //To calculate the probability of occurrence of each answer in each ques of each ques set
				    $digital_probability = new Answers_Model;
				    $digi_probability = $digital_probability->get_probability($examid,$quesid,$startdate,$enddate);
				    $view->digiProbability = $digi_probability;
				    $view->examid = $examid;
				    $view->set = 'dialogue';
                }else{
				    if($examid=="0"){
					    $examid = $examKeys[0];
				    }
                    $view->examid = $examid;			
				    //To get Correct answer from question 
				    $exam_question = new Exam_Question_Model;
				    $result = $exam_question->get_questions_result($examid,$startdate,$enddate);
				    $answer = array();
				    $answer = explode(":",$result);
                    $questionlist = $exam_question->get_questions_set($examid);
				    //To Display correct and Incorrect answer on page
				    $examuser = new Exam_User_Answer_Model;
				    $correctanswer = $examuser->get_correct($examid,$questionlist['id'],$startdate,$enddate);
				    $incorrectanswer = $examuser->get_incorrect($examid,$questionlist['id'],$correctanswer,$startdate,$enddate);
				    //To Display  each Question and its answer 
				    $exam_question1 = new Exam_Question_Model;
				    $ques_ans_list = $exam_question1->each_ques($examid,$quesid);
				    //To Display Pie chart value for each question 
				    $each_question_result = new Exam_User_Answer_Model;
				    $answerlist = $each_question_result->get_ques_result($examid,$quesid,$startdate,$enddate);
				    if(!empty($answerlist)){
                        $answernum = array();
					    $count = array();
					    $answernum = array_values($answerlist['answer']);
					    $count = array_values($answerlist['answercount']);
					    $final = array_combine($answernum,$count);
					    $emptyanswer = array();
						if (!array_key_exists(1, $final)) {
							$emptyanswer[1] = 0;
						}
						if (!array_key_exists(2, $final)) {
							$emptyanswer[2] = 0;
						}
						if (!array_key_exists(3, $final)) {
							$emptyanswer[3] = 0;
						}
						if (!array_key_exists(4, $final)) {
							$emptyanswer[4] = 0;
						}
					
					 $finalresult = $final+$emptyanswer;
			 	    }
				
				    $view->answer = $answer;
				    $view->questionlistid = $questionlist['id'];
				    $view->questions = $questionlist['ques'];
				    $view->correct = $correctanswer;
				    $view->incorrect = $incorrectanswer;
				    $view->ques_ans_list = $ques_ans_list;
				    if(!empty($finalresult)){
				        $view->answerresult = $finalresult;
				    }else{
				        $view->answerresult = MESSAGE;
			 	    }
				    $view->set = $set;
			    }
				//This for Dialogue Quizzess
			    // To Get List of Digital Demo
				$digital_question = new Question_Sets_Model;
				$digitalExam = $digital_question->exam_list($company);
				if(!empty($digitalExam)){
				    $view->digitalExam = $digitalExam;
				    $dialogueKey = array_keys($digitalExam);
				    $dialogueid = $dialogueKey[0];
				    //To Get no of user given specific Flash exam  and no of completion 
				    $digital_question = new Answers_Model;
				    $result = $digital_question->get_questions_result($dialogueid,$startdate,$enddate);
				    $answer = array();
				    $answer = explode(":",$result);
                    $view->digiAnswer = $answer;
				
				    //To Get all question list in specific Flash exam set 
				    $digital_QuestionList = new Questions_Model;
				    $digiQuestionList = $digital_QuestionList->get_questions_set($dialogueid);
				    $view->digiQuestionListid = $digiQuestionList['id'];
				    $view->digiQuestions = $digiQuestionList['ques'];
                    //To Display  each Question and its answer 
				    if($quesid==1){
				        $quesid = $digiQuestionList['id'][0];
				    }
				    $digital_exam_question = new Questions_Model;
				    $digi_ans_list = $digital_exam_question->each_ques($dialogueid,$quesid);
				    $view->digiAnswerlist = $digi_ans_list;
				    $view->digiQuesid = $quesid;
				    $view->digiResponsetype = $digi_ans_list["res_type"];
				    //To calculate the probability of occurrence of each answer in each ques of each ques set
				    $digital_probability = new Answers_Model;
				    $digi_probability = $digital_probability->get_probability($dialogueid,$quesid,$startdate,$enddate);
				    $view->digiProbability = $digi_probability;
                } 
		
			}elseif($set==="serviceWizard"){
			    //For Service wizard data
				$access = ORM::factory('company_set')->where('company',$company)->find();
                $company_id = $access->id;
			    $serviceWizard = new Servicewizard_Model;
				$serviceWizard_list = $serviceWizard->getserviceWizardList($company_id);
				$view->serviceWizardList = $serviceWizard_list;
			    $examList = new Exam_Question_Set_Model;
                $examlist = $examList->getexamList($company);	
                $count = count($examlist);
                // To Get List of Quiz
		        $c = array();
				for($i=0;$i<$count;$i++){
					$id = $examlist[$i]['id'];
					$c[$id] = $examlist[$i]['name'];
				}				
				$view->exam = $c;
				// To Get List of Digital Demo
				$digital_question = new Question_Sets_Model;
				$digitalExam = $digital_question->exam_list($company);
				$view->digitalExam = $digitalExam;
				$serviceWizard = new Servicewizard_Model;
				$diagnostic_list = $serviceWizard->getDiagnosticCause($company_id,$serviceWizardId);
				$diagnosticList = $diagnostic_list;
				$view->diagnosticList = $diagnosticList;
				$serviceCauseList = $serviceWizard->getserviceCauseList($diagnosticList[0]['id'],$startdate,$enddate);
				$view->serviceCauseList=$serviceCauseList;
				$view->examid = 1;
				$view->set = $set;
				
			}else{
			    $examList = new Exam_Question_Set_Model;
                $examlist = $examList->getexamList($company);	
                $count = count($examlist);
                // To Get List of Quiz
		        $c = array();
				for($i=0;$i<$count;$i++){
					$id = $examlist[$i]['id'];
					$c[$id] = $examlist[$i]['name'];
				}				
				$view->exam = $c; 
				$examKeys = array_keys($c);
				if($examid=="0"){
					$examid = $examKeys[0];
				}
                $view->examid = $examid;			
				//To get Correct answer from question 
				$exam_question = new Exam_Question_Model;
				$result = $exam_question->get_questions_result($examid,$startdate,$enddate);
				$answer = array();
				$answer = explode(":",$result);
                $questionlist = $exam_question->get_questions_set($examid);
				//To Display correct and Incorrect answer on page
				$examuser = new Exam_User_Answer_Model;
				$correctanswer = $examuser->get_correct($examid,$questionlist['id'],$startdate,$enddate);
				$incorrectanswer = $examuser->get_incorrect($examid,$questionlist['id'],$correctanswer,$startdate,$enddate);
				//To Display  each Question and its answer 
				$exam_question1 = new Exam_Question_Model;
				$ques_ans_list = $exam_question1->each_ques($examid,$quesid);
				//To Display Pie chart value for each question 
				$each_question_result = new Exam_User_Answer_Model;
				$answerlist = $each_question_result->get_ques_result($examid,$quesid,$startdate,$enddate);
				if(!empty($answerlist)){

					$answernum = array();
					$count = array();
					$answernum = array_values($answerlist['answer']);
					$count = array_values($answerlist['answercount']);
					$final = array_combine($answernum,$count);
					$emptyanswer = array();
					if (!array_key_exists(1, $final)) {
						$emptyanswer[1] = 0;
					}
					if (!array_key_exists(2, $final)) {
						$emptyanswer[2] = 0;
					}
					if (!array_key_exists(3, $final)) {
						$emptyanswer[3] = 0;
					}
					if (!array_key_exists(4, $final)) {
						$emptyanswer[4] = 0;
					}
					$finalresult = $final+$emptyanswer;
				}
				
				$view->answer = $answer;
				$view->questionlistid = $questionlist['id'];
				$view->questions = $questionlist['ques'];
				$view->correct = $correctanswer;
				$view->incorrect = $incorrectanswer;
				$view->ques_ans_list = $ques_ans_list;
				if(!empty($finalresult)){
				$view->answerresult = $finalresult;
				}else{
				$view->answerresult = MESSAGE;
				}
				$view->set = $set;
		
			}
            $view->render(TRUE);
		}else{
			url::redirect('user/index');
		}
 
      }  

	}	
	
	//Summary Analytics Page Controller
	function summaryAnalytics($userid,$pieName="User",$total=0,$start=0,$completion=0,$set="none"){
      	if(isset($_POST["TimePeriod"])){
			$TimePeriod = $_POST["TimePeriod"];
		}else{
			$TimePeriod = "none";
		}
		$pieName=str_replace('__','/',$pieName);
		if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
				$enddate = date("Y-m-d H:m:s",time()+216000);
				$startdate = "1977-01-01";
 
			}
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
				
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
				$enddate = $curdate;
			}
			
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
				$enddate = $curdate;
			}
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
				$enddate = $curdate;
			}
			$access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
			$company = $access2->company;
			if($set==="none"){
                $access4 = ORM::factory('company_set')->where('company',$company)->find();
                $set = $access4->type;
		    }
			// To count all registered user
            $userCount = ORM::factory('user');
			$user_count = count($userCount->where('company',$company)->find_all());
			//To get list of Users
			$user_List = new User_Model;
			$userList = $user_List->getUsers($company,$startdate,$enddate);
			$view = new View('smartsite/summaryAnalytics');
			$view->set = $set;
			$view->username = $username;
			$view->userid = $userid;
			$view->role = $role;
			
			if($set==="dialogue"){
			    $exam_info = new Questions_Model;
				$examInfo = $exam_info->getExamid($company);
			    $user_contact = new Answers_Model;
			    $countProduct = $user_contact->countDigitalProduct($startdate,$enddate,$examInfo[0]['id']);
                if(strpos($countProduct['leads'],':')===false){
				    $leads = $countProduct['leads'];
				}else{
				    $leads = explode(':',$countProduct['leads']);
					$leads = array_sum($leads);
				}
				$view->leads = $leads; 	
			} 
			$view->userList = $userList;
			$view->userCount = $user_count;
			$view->company = $company;
			$questionsets = new Question_Sets_Model;
			$exam_Response = new Exam_Question_Model;
			$dialogueexam_Response = new Answers_Model;
			$settype = $questionsets->getCompanySet($company);
			$examName = $questionsets->exam_list_main($company);
			$count = count($examName);
			$dialogue_List = new Research_Model;
			$view->examSearchlist = '';
			$view->dialogueSearchlist = '';
			if($settype=='all'){
				$view->examSearchlist = $dialogue_List->getSavedSearchExam($company);
				if($count!=0){ 
					foreach($examName as $key=>$row)
					{
						$eachexam_Score[$key] = $exam_Response->get_questions_result($key,$startdate,$enddate);
					}
					$view->examName = $examName;
					$view->quizScore = $eachexam_Score;
				}else{ 
					$quizScore=MESSAGE;
				}
			}
			if($settype=='all'|| $settype=='dialogue'){
				$view->dialogueSearchlist = $dialogue_List->getSavedSearchDialogue($company);
                $demoExamName = $questionsets->exam_list($company);
				$count = count($demoExamName);
				if($count!=0){ 
					foreach($demoExamName as $key=>$row)
					{
						$digitalScore[$key] = $dialogueexam_Response->get_questions_result($key,$startdate,$enddate);
					}
					$view->digitalName = $demoExamName;
					$view->digitalScore = $digitalScore;
				}else{ 
					$digitalScore = MESSAGE;
				}
			}
			//To put values in PIE chart array based on exam select
			if($total==0){
				
				$userCount = $user_count;
				$activeUser = count($userList);
				$inactiveUser = ($userCount-$activeUser);
				$piechartArray = array("Registered" =>"$userCount","Active" =>"$activeUser","Inactive"=>"$inactiveUser" );
			}else{ 
				
				 $totalUser = $total;
				 $startUser = $start;
				 $completionUser = $completion;
				 $piechartArray = array("Total Users" =>"$totalUser","Starts" =>"$startUser","Completion"=>"$completionUser" );
			
			}
			//Research saved search
            $view->TimePeriod2 = $TimePeriod;
			$view->piechartArray = $piechartArray;
			$view->pieChartName = $pieName;
			$view->render(TRUE);
		}
	}



	//User Analytics Page Controller
	
	function userAnalytics($userid,$empid="none",$action="none",$set="none"){
		if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
			//To get UserName and Role based on userid
			$access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
			$company = $access2->company;
			if($set==="none"){
                $access4 = ORM::factory('company_set')->where('company',$company)->find();
                $set = $access4->type;
		    }
			$view = new View('smartsite/userAnalytics');
            $view->set = $set; 
			if($set==="dialogue"){
			    $this->conversion($userid); 
			}else{
				if(!empty($username) and $role=='admin'){
				    $userUpdate = ''; 
					$userexamData = '';
					$examName = '';
					$examScore = '';
					$searchResult = '';
					$searchDisplay = '';
					$trimmedSearch_array = '';
					$email_id = new Email_Notification_Model;
					$emailId = $email_id->getEmailId($company);
					if($action==="none"){
						//To get list of Users
						$user_Info = new User_Information_Model;
						$userInfo = $user_Info->getuserInformation($company);
						$user_Login = new User_Model; 
						$userLogin = $user_Login->getuserlastLogin($userInfo);
						//print_r($userLogin);exit;
						$count = count($userInfo);
						$idArray = array();
						$userData = array();
						for($i=0;$i<$count;$i++){
							$idArray[] = $userInfo[$i]['id'];	
						}
						if($empid!=="none"){
	                        if(in_array($empid,$idArray)){
								$userData =  $user_Info->getuserData($empid);
								$userLoginNum = $user_Login->getuserLoginnum($empid);
								$userLastlogin = $user_Login->getuserLastloginnum($empid);
								$userExamResult = $user_Login->getuserExamresult($empid);
								$exam_Set = new Exam_User_Answer_Model;
								$examSet = $exam_Set->getExamset($empid);
								$exam_setName = new Exam_Question_Set_Model;
								if($examSet===EXAMMESSAGE){
									$userexamData = EXAMMESSAGE;
								}else{
								    $count = count($examSet);
									//To get Correct answer from question 
									$exam_question = new Exam_Question_Model;
									$examScore = array();
									$examName = array();
									$value = array();
									for($i=0;$i<$count;$i++){
									    $examid = $examSet[$i];
                                        $result =  $exam_Set->get_user_questions_result($examid,$empid);
										$examsetName = $exam_setName->getExamName($examid);
										$value = explode(":",$result);
										$examScore[$examid] = $value[0];
										$examName[$examid] = $examsetName[0];
										
									}
									
								}	
						
							}else{
								$userData = USERMESSAGE;
							}
							
						}else{
							$empid = $idArray[0];
							$userData =  $user_Info->getuserData($empid);
                            $userLoginNum = $user_Login->getuserLoginnum($empid);
							$userLastlogin = $user_Login->getuserLastloginnum($empid);
							$userExamResult = $user_Login->getuserExamresult($empid);
                            $exam_Set = new Exam_User_Answer_Model;
							$examSet = $exam_Set->getExamset($empid);
							$exam_setName = new Exam_Question_Set_Model;
								
								if($examSet===EXAMMESSAGE){
									$userexamData = EXAMMESSAGE;
								}else{
								    $count = count($examSet);
									//To get Correct answer from question 
									$exam_question = new Exam_Question_Model;
									$examScore = array();
									$examName = array();
									$value = array();
									for($i=0;$i<$count;$i++){
									    $examid = $examSet[$i];
                                        $result =  $exam_Set->get_user_questions_result($examid,$empid);
										$examsetName = $exam_setName->getExamName($examid);
										$value = explode(":",$result);
										$examScore[$examid] = $value[0];
										$examName[$examid] = $examsetName[0];
										
									}
									
								}						
						}
					}elseif($action==="search"){
					    $searchDisplay = 'search';
						if(isset($_POST['submit'])){
						    $search = addslashes(strip_tags(@$_POST['search']));
						    $trimmedSearch = trim($search); 
						    $trimmedSearch_array = explode(" ",$trimmedSearch);
                             if (!isset($search)){
							  $resultmsg =  "<p>Search Error..We don't seem to have a search parameter! </p>" ;
							  }
							$usersearch_Info = new User_Information_Model;
							$usersearchInfo =  $usersearch_Info->getusersearchInformation($company,$trimmedSearch_array);
							$userInfo = $usersearchInfo;
							$count = count($userInfo);
							if($count>0){
								$idArray = array();
								$userData = array();
								for($i=0;$i<$count;$i++){
									$idArray[] = $userInfo[$i]['id'];	
								}
								$usersearch_Login = new User_Model; 
								$userSearchLogin = $usersearch_Login->getSearchuserlastLogin($idArray);
								$userLogin = $userSearchLogin;
								$empid = $idArray[0];
								$userData =  $usersearch_Info->getuserData($empid); 
								$userLoginNum = $usersearch_Login->getuserLoginnum($empid);	
								$userLastlogin = $usersearch_Login->getuserLastloginnum($empid);
								$userExamResult = $usersearch_Login->getuserExamresult($empid);
                                $exam_Set = new Exam_User_Answer_Model;
								$examSet = $exam_Set->getExamset($empid);
								$exam_setName = new Exam_Question_Set_Model;
								if($examSet===EXAMMESSAGE){
									$userexamData = EXAMMESSAGE;
								}else{
									$count = count($examSet);
									$exam_question = new Exam_Question_Model;
									$examScore = array();
									$examName = array();
									$value = array();
									for($i=0;$i<$count;$i++){
										$examid = $examSet[$i];
										$result =  $exam_Set->get_user_questions_result($examid,$empid);
										$examsetName = $exam_setName->getExamName($examid);
										$value = explode(":",$result);
										$examScore[$examid] = $value[0];
										$examName[$examid] = $examsetName[0];
										
									}
									
								}
		
							}else{
								$searchResult = "<h3>".SEARCHMESSAGE." $search</h3>";
							
							}
						
						}else{
							$trimmedSearch_array = $_SESSION['search'];
							$usersearch_Info = new User_Information_Model;
							$usersearchInfo =  $usersearch_Info->getusersearchInformation($company,$trimmedSearch_array);
							$userInfo = $usersearchInfo;
							$count = count($userInfo);
							if($count>0){
								$idArray = array();
								$userData = array();
								for($i=0;$i<$count;$i++){
									$idArray[] = $userInfo[$i]['id'];	
								}
								$usersearch_Login = new User_Model; 
								$userSearchLogin = $usersearch_Login->getSearchuserlastLogin($idArray);
								$userLogin = $userSearchLogin;
								if($empid!=="none"){
			                        if(in_array($empid,$idArray)){
										$userData =  $usersearch_Info->getuserData($empid);
										$userLoginNum = $usersearch_Login->getuserLoginnum($empid);
										$userLastlogin = $usersearch_Login->getuserLastloginnum($empid);
										$userExamResult = $usersearch_Login->getuserExamresult($empid);
										$exam_Set = new Exam_User_Answer_Model;
										$examSet = $exam_Set->getExamset($empid);
										$exam_setName = new Exam_Question_Set_Model;
										if($examSet===EXAMMESSAGE){
											$userexamData = EXAMMESSAGE;
										}else{
											$count = count($examSet);
											//To get Correct answer from question 
											$exam_question = new Exam_Question_Model;
											$examScore = array();
											$examName = array();
											$value = array();
											for($i=0;$i<$count;$i++){
												$examid = $examSet[$i];
												$result =  $exam_Set->get_user_questions_result($examid,$empid);
												$examsetName = $exam_setName->getExamName($examid);
												$value = explode(":",$result);
												$examScore[$examid] = $value[0];
												$examName[$examid] = $examsetName[0];
												
											}
											
										}	
											
									}else{
										$userData = USERMESSAGE;
									}
									
								}

							}else{
								$searchResult = "<h3>".SEARCHMESSAGE." $search</h3>";
							}

						}
					
					}else{
					    
						if($action==='delete'){
						$user_Info = new User_Information_Model;
						$userUpdate = $user_Info->deleteuserInformation($empid);
						$userInfo =  $user_Info->getuserInformation($company);
						$user_Login = new User_Model; 
						$userLogin = $user_Login->getuserlastLogin($userInfo);
						$count = count($userInfo);
						$idArray = array();
						$userData = array();
						for($i=0;$i<$count;$i++){
							$idArray[] = $userInfo[$i]['id'];	
						}
						$empid = $idArray[0];
						$userData =  $user_Info->getuserData($empid); 
                        $userLoginNum = $user_Login->getuserLoginnum($empid);
                        $userLastlogin = $user_Login->getuserLastloginnum($empid);
                        $userExamResult = $user_Login->getuserExamresult($empid);  						
                        $exam_Set = new Exam_User_Answer_Model;
                        $examSet = $exam_Set->getExamset($empid);
						$exam_setName = new Exam_Question_Set_Model;
						if($examSet===EXAMMESSAGE){
							$userexamData = EXAMMESSAGE;
						}else{
							$count = count($examSet);
							//To get Correct answer from question 
							$exam_question = new Exam_Question_Model;
							$examScore = array();
							$examName = array();
							$value = array();
							for($i=0;$i<$count;$i++){
								$examid = $examSet[$i];
								$result =  $exam_Set->get_user_questions_result($examid,$empid);
								$examsetName = $exam_setName->getExamName($examid);
								$value = explode(":",$result);
								$examScore[$examid] = $value[0];
								$examName[$examid] = $examsetName[0];
							}
						
						} 						
						}

					}
					$view->username = $username;
					$view->userid = $userid;
					$view->role = $role;
					$view->company = $company;
					$view->trimmedSearchArray = $trimmedSearch_array;
					if($searchResult!==''){
					$view->userInfo = $userInfo;
					$view->userLogin = '';
					$view->userData = '';
					$view->userLoginNum = '';
					$view->userLastlogin = '';
					$view->userExamResult = '';
					$view->searchResult = $searchResult;
					}else{
					$view->userInfo = $userInfo;
					$view->userLogin = $userLogin;
					$view->userData = $userData;
					$view->userLoginNum = $userLoginNum;
					$view->userLastlogin = $userLastlogin;
					$view->userExamResult = $userExamResult;
					}
					$view->searchDisplay = $searchDisplay;
					$view->userUpdate = $userUpdate;
					$view->userexamData = $userexamData;
					$view->examName = $examName;
					$view->examScore = $examScore;
					$view->emailId = $emailId;
					
					$view->render(TRUE);
	
	            }
			
				
				else{
						url::redirect('user/index');
				}
			}	
		}
	}



    //Import Data Page Controller
	
	function importData($userid){ 
		if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
			//To get UserName and Role based on userid
			$access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
			$company = $access2->company;
				if(!empty($username) and $role=='admin'){
				    //Email Id based on question set Id
					$email_id = new Email_Notification_Model;
					$emailId = $email_id->getEmailId($company);
					$view = new View('smartsite/importData');
					$view->username = $username;
					$view->company = $company;
					$view->userid = $userid;
					$view->role = $role;
					$view->emailId = $emailId;
					// Render the view
					$view->render(TRUE);
				}
				else{
						url::redirect('user/index');
				}
	
	    } 
	}	
	
	 // To generate salt   
	function find_salt($password){
		$salt = '';
		$password = sha1($password);
		foreach (array(1, 3, 5, 9, 14, 15, 20, 21, 28, 30) as $i => $offset){
			
			$salt .= $password[$offset + $i];
		}

		return $salt;
	}
							
									
	// To generate hash password						
	function hash_password($password, $salt = FALSE){
		if ($salt === FALSE){
			
			$salt = substr(hash(uniqid(NULL, TRUE)), 0, count($config['salt_pattern']));
		}
        $hash  = sha1($salt.$password);
        $salt = str_split($salt, 1);
        $password = '';
        $last_offset = 0;
        foreach (array(1, 3, 5, 9, 14, 15, 20, 21, 28, 30) as $offset){
			$part = substr($hash, 0, $offset - $last_offset);
            $hash = substr($hash, $offset - $last_offset);
            $password .= $part.array_shift($salt);
            $last_offset = $offset;
		}

		// Return the password, with the remaining hash appended
		return $password.$hash;
	}
	
	function newUser($userid,$remove="none",$customfield="none"){ 
	    if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
			//To get UserName and Role based on userid
			$access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
			$company = $access2->company;
				if(!empty($username) and $role=='admin'){
				    $insertResult = "";
				    $email_id = new Email_Notification_Model;
				    $emailId = $email_id->getEmailId($company);
				    if(isset($_POST['submit_x']) AND isset($_POST['submit_y']) AND $customfield==="none"){
						$keys = array_keys($_POST);
						$columnList = array('id','fname','lname','email','company','state','country','mailing_address','phone_number','role','submit_y','submit_x');
						$newColumn = array_diff($keys,$columnList);
						$newColumn = array_values($newColumn);
						$countnewColumn = count($newColumn);
						for($i=0;$i<$countnewColumn;$i++){
							$newColumnvalue[] = $_POST[$newColumn[$i]];
							
						}
                        $fname = addslashes(strip_tags(trim($_POST['fname'])));
						$password = addslashes(strip_tags(trim($_POST['fname']))).addslashes(strip_tags(trim($_POST['lname'])));
						if (is_string($password)){
							// Get the salt from the stored password
							$salt  = $this->find_salt($password);
                            // Create a hashed password using the salt from the stored password
							$passwordEncrypt  = $this->hash_password($password, $salt);
							
						}
						$lname = addslashes(strip_tags(trim($_POST['lname'])));
						$email = addslashes(strip_tags(trim($_POST['email'])));
						$company_orig = addslashes(strip_tags(trim($_POST['company'])));
						if(isset($_POST['mailing_address'])){
							$empNumber = addslashes(strip_tags(trim($_POST['mailing_address'])));
						}else{
							$empNumber = "";
						}
						if(isset($_POST['state'])){
							$title = addslashes(strip_tags(trim($_POST['state'])));
						}else{
							$title = "";
						}	
						if(isset($_POST['phone_number'])){
							$territory = addslashes(strip_tags(trim($_POST['phone_number'])));
						}else{
							$territory = "";
						}
						if(isset($_POST['role'])){
							$role = addslashes(strip_tags(trim($_POST['role'])));
						}else{
							$role = "user";
						}	
						if(isset($_POST['country'])){
							$division = addslashes(strip_tags(trim($_POST['country'])));
						}else{
							$division = "";
						}	
						$insert_data = new New_User_Information_Model;
						if(count($newColumn)>0){
						    $insertResult = $insert_data->setTable($fname,$lname,$company,$company_orig,$email,$empNumber,$title,$territory,$role,$division,$passwordEncrypt,$newColumn,$newColumnvalue, $access1->email);
							
						}else{
						    $insertResult = $insert_data->setTable($fname,$lname,$company,$company_orig,$email,$empNumber,$title,$territory,$role,$division,$passwordEncrypt,null,null, $access1->email);
							
						}
						
					}
				
				    $table_field  =  new New_User_Information_Model;
					$tableField =  $table_field->getFieldsname();
					if(isset($_POST['submit_x']) AND $customfield==="cfield"){
					    $custom_Field = "";
						$required = "";
						$customField[] = $_POST['customField'];
						$custom_Field = $_POST['customField'];
						if(isset($_POST['required'])){
							$required = $_POST['required'];
						}else{
							$required = "";
						}
						$table_field_add = new New_User_Information_Model;
					    $tableFieldadd =  $table_field_add->addField($custom_Field);
						$field[] = array_merge($tableFieldadd,$customField);
						$tableField = array_values($field);
                        $tableField = $tableFieldadd;
						
					}
					elseif($remove!=="none"){
						$field[] = $remove;
						$table_field_remove = new New_User_Information_Model;
					    $tableFieldremove =  $table_field_remove->getFieldremove($remove);
						$field = array_diff($tableField,$field);
						$tableField = array_values($field);
					}else{
						$table_field = new User_Information_Model;
						$tableField =  $table_field->getFieldsname();
						//$table_field1 = new New_User_Information_Model;
						//$table_field1->getFieldadd();
					}
					$view = new View('smartsite/newUser');
					$view->username = $username;
					$view->userid = $userid;
					$view->role = $role;
					$view->fieldName = $tableField;
					$view->insertResult = $insertResult;
					$view->emailId = $emailId;
					$view->render(TRUE);
				}else{
					url::redirect('user/index');
				}
	
	    } 
	}
	
	// To display data on right panel of conversion stat
	
	function rightConversionPane(){
		if(isset($_POST["userid"])){
			$userid = $_POST["userid"];
		}
		if(isset($_POST["empid"])){
			$id = $_POST["empid"];
		}
		if(isset($_POST["action"])){
			$action = $_POST["action"];
		}
		if(isset($_POST["TimePeriod"])){
		    
			$TimePeriod = $_POST["TimePeriod"];
		}
		$QuesAnswerList = '';
		
		    // Date calculation 
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
				$enddate = date("Y-m-d H:m:s",time()+216000);
				$startdate = "1977-01-01";
            }
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
				
				$curdate = date('Y-m-d H:m:s');
				$startdate  =  date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
				$enddate   = $curdate;
			}
			
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
				$enddate   = $curdate;
			}
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
				$enddate   = $curdate;
			}		
			//To get UserName and Role based on userid
			$access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
			$company = $access2->company;
			$contactDelete = '';
			$digital_question = new Question_Sets_Model;
					$digitalExam =  $digital_question->exam_list($company);
					$exam_id = array_keys($digitalExam);
					$examid = $exam_id[0];
					$user_contact  =  new Answers_Model;
					$countProduct = $user_contact->countDigitalProduct($startdate,$enddate,$examid);
					if($action=='leads'){
						$userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
					}elseif($action=='sales'){
						$userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
					}else{
						$userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
					}
					$userContactData = array();
					if(empty($userContact)){
					    $userContact = "";
					}else{
						$count = count($userContact);
						$contact_details = new User_Contact_Model;
						$contactDetails = $contact_details->contactdetails($id);
						if(($id!=='none') ){
							if(count($contactDetails)>0){
								$userContactData['sess_id'] = $contactDetails['sess_id'];
								$userContactData['fullname'] = $contactDetails['fullname'];
								$userContactData['email'] = $contactDetails['emailid'];
								$userContactData['phonenum'] = $contactDetails['phonenum'];
								$userContactData['product'] = $contactDetails['product'];
								$QuesAnswerList = $contact_details->getQuesAnswerList($userContactData['sess_id']);
							}else{
							    $userContactData = "";
							}
						}else{
							$userContactData['sess_id'] = $userContact[0]['sess_id'];
							$userContactData['fullname'] = $userContact[0]['fullname'];
							$userContactData['email'] = $userContact[0]['email'];
							$userContactData['phonenum'] = $userContact[0]['phonenum'];
							$userContactData['product'] = $userContact[0]['product'];
							$QuesAnswerList = $contact_details->getQuesAnswerList($userContactData['sess_id']);
							
						}
						
					}
			
		
		$view = new View('smartsite/rightConversionPane');
		$view->username = $username;
		$view->userid = $userid;
		$view->role = $role;
		$view->TimePeriod = $TimePeriod;
		$view->userContact = $userContact;
		$view->userContactData = $userContactData;
		$view->action = $action;
		$view->contactDelete = $contactDelete;
		$view->QuesAnswerList = $QuesAnswerList;
		$view->countProduct = $countProduct;
		$view->examid = $examid;
		$view->id = $id;
		$view->render(TRUE);
	
	}

	
	
	//Conversion Page Controller
	function conversion($userid,$action='none',$TimePeriod='none',$id='none',$delete='none'){ 
	    if(isset($_POST["TimePeriod"])){
		    $TimePeriod = $_POST["TimePeriod"];
		}elseif($TimePeriod!='none'){
		    $TimePeriod = $TimePeriod;
		}
		else{
		    $TimePeriod = "none";
		}
		if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
		    if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
				$enddate = date("Y-m-d H:m:s",time()+216000);
				$startdate = "1977-01-01";

			}
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
				
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
				$enddate   = $curdate;
			}
			
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
				$enddate   = $curdate;
			}
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
				$enddate   = $curdate;
			}
			//To get UserName and Role based on userid
			$access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
			$company = $access2->company;
				if(!empty($username) and $role=='admin'){
				    $contactDelete = '';
					$QuesAnswerList = '';
					$countProduct = '';
					//Email Id based on question set Id
					$email_id = new Email_Notification_Model;
					$emailId = $email_id->getEmailId($company);
					if($delete==='delete'){
						$contact_delete = new User_Contact_Model;
						$contactDelete = $contact_delete->getDelete($id);	
					}
					
					$digital_question = new Question_Sets_Model;
					$digitalExam =  $digital_question->exam_list($company);
					$exam_id = array_keys($digitalExam);
					$examid = $exam_id[0];
					$user_contact = new Answers_Model;
					$countProduct = $user_contact->countDigitalProduct($startdate,$enddate,$examid);
					if($action=='leads'){
					    $userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
					}elseif($action=='sales'){
						$userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
					}else{
						$userContact =  $user_contact->get_user_contact($examid,$startdate,$enddate,$action);
					}
					$userContactData = array();
					if(empty($userContact)){
					    $userContact = "";
					}else{
						$count = count($userContact);
						$contact_details = new User_Contact_Model;
						$contactDetails = $contact_details->contactdetails($id);
						if(($id!=='none') AND ($delete!=='delete')){
							if(count($contactDetails)>0){
								$userContactData['sess_id'] = $contactDetails['sess_id'];
								$userContactData['fullname'] = $contactDetails['fullname'];
								$userContactData['email'] = $contactDetails['emailid'];
								$userContactData['phonenum'] = $contactDetails['phonenum'];
								$userContactData['product'] = $contactDetails['product'];
								$QuesAnswerList = $contact_details->getQuesAnswerList($userContactData['sess_id']);
							}else{
							    $userContactData = "";
							}
						}else{
							$userContactData['sess_id'] = $userContact[0]['sess_id'];
							$userContactData['fullname'] = $userContact[0]['fullname'];
							$userContactData['email'] = $userContact[0]['email'];
							$userContactData['phonenum'] = $userContact[0]['phonenum'];
							$userContactData['product'] = $userContact[0]['product'];
							$QuesAnswerList = $contact_details->getQuesAnswerList($userContactData['sess_id']);
							
						}
						
					}
					
					
					$view = new View('smartsite/conversion');
					$view->username = $username;
					$view->userid = $userid;
					$view->role = $role;
					$view->TimePeriod = $TimePeriod;
					$view->userContact = $userContact;
					$view->userContactData = $userContactData;
					$view->action = $action;
					$view->contactDelete = $contactDelete;
					$view->QuesAnswerList = $QuesAnswerList;
					$view->countProduct = $countProduct;
					$view->examid = $examid;
					$view->emailId = $emailId;
					// Render the view
					$view->render(TRUE);
				}else{
						url::redirect('user/index');
				}
		}
	
	
	}
	//functin save email 
	function saveEmail()
	{
		if(isset($_POST['emailAddresses'])){
			$email = stripslashes(strip_tags($_POST['emailAddresses']));
		}
		$examid = $_POST['examid'];
		$email_id = new Email_Notification_Model;
		$email_id->appendEmail($examid,$email);
	}

    // To display research pane module 	
    public function research($userid,$delete="none",$sess_id="none"){
	    if(empty($_COOKIE['kohanasession'])){ 
			url::redirect();
		}else{
		    //To get UserName and Role based on userid
		    $access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
            $company = $access1->company; 			
			if(!empty($username) and $role=='admin'){
				$display = $delete;
				$view  =  new View('smartsite/research');
				$view->username  =  $username;
				$view->userid = $userid;
				$view->role = $role;
				$view->company = $company;
				$view->display = $display;
				$deleteSaveSearch = "";
				$dialogue_List = new Research_Model;
				if($delete==="delete" and $sess_id!=="none" ){
	                $deleteSaveSearch = $dialogue_List->deleteSearch($sess_id);  
	            }
				$dialogueSearchlist = $dialogue_List->getSavedSearchDialogue($company);
                $examSearchlist = $dialogue_List->getSavedSearchExam($company);
                $view->saveSearchList = "";
                $view->dialogueSearchlist = $dialogueSearchlist;
                $view->examSearchlist = $examSearchlist;     
                $view->deleteSaveSearch = $deleteSaveSearch;
				if($delete!=="view"){	
					$dialogueList = $dialogue_List->getDialogue($company);
					$examList = $dialogue_List->getExam($company);
					$list = array_merge($dialogueList,$examList);
					$view->dialogueList = $dialogueList;
                    $view->examList = $examList;    
                    $view->list = $list; 
                }else{
				    $nameSelected = $dialogue_List->nameSelected($sess_id);
				    $view->nameSelected  =  $nameSelected; 
					$savesearchList = $dialogue_List->saveSearchList($sess_id);
				    $view->savesearchList = $savesearchList;
					$dialogue_List = new Research_Model;
		            if($savesearchList[0]['types']==='dialogue'){
					    $percentageList = $dialogue_List->getSaveDialoguePercentageListNext($savesearchList);
                    }else{
			            $percentageList = $dialogue_List->getSaveExamPercentageListNext($savesearchList);
                    }		
                    $view->percentageList = $percentageList;
					
		        }
				$view->render(TRUE);
				}else{
					url::redirect('user/index');
				}
						
		}
	}

    public function centerResearchPane($userid){
		if(isset($_POST['company'])){
			$company = $_POST['company'];
		}
		if(isset($_POST['dialogue'])){
			$dialogue = $_POST['dialogue'];
		}
		$pos = strripos($dialogue,'dialogue');
		$dialogue_List = new Research_Model;
		if($pos === false){
			$list = $dialogue_List->getExam($company);
			
		}else{
			$list = $dialogue_List->getDialogue($company);
		}
		$view = new View('smartsite/centerResearchPane');
		$view->company = $company;
		$view->list = $list;
        $view->dialogue = $dialogue;		
		$view->render(TRUE);

	}	
	
	public function selectResearchPane(){
	
		if(isset($_POST['optionSelect'])){
		   $optionSelect = $_POST['optionSelect'];
		}
		if(isset($_POST['examName'])){
		   $examName = $_POST['examName'];
		}
		if(isset($_POST['type'])){
		   $type = $_POST['type'];
		}
		$dialogue_List = new Research_Model;
		if($type==='dialogue'){
			$questionList = $dialogue_List->getDialogueQuestionList($optionSelect);
		}else{
			$questionList = $dialogue_List->getExamQuestionList($optionSelect);
		}
		$view = new View('smartsite/selectResearchPane');
		$view->questionList = $questionList;
		$view->render(TRUE);
	}
     
	//To display Answer for selected question in research page
	public function displayAnswerResearchPane(){
		if(isset($_POST['type'])){
		   $type = $_POST['type'];
		}
		if(isset($_POST['setId'])){
		   $setId = $_POST['setId'];
		}
		if(isset($_POST['quesId'])){
		   $quesId = $_POST['quesId'];
		}
		$dialogue_List = new Research_Model;
		if($type==='dialogue'){
			$answerList = $dialogue_List->getDialogueAnswerList($setId,$quesId);
		}else{
			$answerList = $dialogue_List->getExamAnswerList($setId,$quesId);
		}
		if($type==='dialogue'){
			$questionList = $dialogue_List->getDialogueQuestionList($setId);
		}else{
			$questionList = $dialogue_List->getExamQuestionList($setId);
		}
		
		$view = new View('smartsite/displayAnswerResearchPane');
		$view->answerList = $answerList;
		$view->questionList = $questionList;
		$view->quesId = $quesId;
		$view->render(TRUE);
		
	}
	
    //To display Answer for selected question in research page
    public function insertSaveSearch($userid,$display="none"){
        if(empty($_COOKIE['kohanasession'])){ 
            url::redirect();
        }else{
            //To get UserName and Role based on userid
            $access1 = ORM::factory('user')->where('id',$userid)->find();
            $access2 = ORM::factory('role')->where('id',$userid)->find();
            $username = $access1->username;
            $role = $access2->name;
            $company = $access1->company;             
            if(!empty($username) and $role=='admin'){
	            $searchArray = array();
	            $quesArray = array();
	            $splitQues = array();
	            if(isset($_POST['quesSelectionArray'])){
	                $ques = $_POST['quesSelectionArray'];
	                $quesArray = explode("|",$ques);
	                array_pop($quesArray);
	                $count = count($quesArray);
	                for($i=0;$i<$count;$i++){
	           	        $splitQues[] = explode(":",$quesArray[$i]);
	                }
	                $searchArray = $splitQues;
	                
	            }
	        
	            if(isset($_POST['isSelectionArray'])){
	                $setId = $_POST['isSelectionArray'];
	                $setIdArray = explode("|",$setId);
	                array_pop($setIdArray);
	                $count = count($setIdArray);
	                for($i=0;$i<$count;$i++){
	                    array_push($searchArray[$i],$setIdArray[$i]);
	                }
	           
	            }
	        
	            if(isset($_POST['answerArray'])){
	                $answerId = $_POST['answerArray'];
	                $answerIdArray = explode("|",$answerId);
	                array_pop($answerIdArray);
	                for($i=0;$i<$count;$i++){
	                    array_push($searchArray[$i],$answerIdArray[$i]);
	                }
	           
	            }
	            if(isset($_POST['name'])){
	                $name = $_POST['name'];
	                for($i=0;$i<$count;$i++){
	                    array_push($searchArray[$i],$name);
	                }
	            }
	            $saveSearch_List = new Research_Model;
	            $saveSearchList = $saveSearch_List->insertSaveSearch($searchArray);
	            $dialogue_List = new Research_Model;
                $dialogueList = $dialogue_List->getDialogue($company);
                $examList = $dialogue_List->getExam($company);
                $list = array_merge($dialogueList,$examList);
                $dialogueSearchlist = $dialogue_List->getSavedSearchDialogue($company);
		        $examSearchlist = $dialogue_List->getSavedSearchExam($company);
		        $view  =  new View('smartsite/research');
                $view->username  =  $username;
                $view->userid = $userid;
                $view->role = $role;
                $view->company = $company;
                $view->dialogueList = $dialogueList;
                $view->examList = $examList;    
                $view->list = $list;                 
                $view->saveSearchList = $saveSearchList;	
                $view->dialogueSearchlist = $dialogueSearchlist;
                $view->examSearchlist = $examSearchlist;
			    $view->display = $display;
		        $view->render(TRUE);
            }else{
                url::redirect('user/index');
        }
                        
        }
	}	
    
    public function righResearchPanel(){
	    $searchArray = array();
	    $quesArray = array();
	    $splitQues = array();
	    if(isset($_POST['quesSelectionArray'])){
	        $ques = $_POST['quesSelectionArray'];
	        $quesArray = explode("|",$ques);
	        array_pop($quesArray);
	        $count = count($quesArray);
	        for($i=0;$i<$count;$i++){
	           	$splitQues[] = explode(":",$quesArray[$i]);
	        }
	        $searchArray = $splitQues;
	    }
	        
	    if(isset($_POST['isSelectionArray'])){
	        $setId = $_POST['isSelectionArray'];
	        $setIdArray = explode("|",$setId);
	        array_pop($setIdArray);
	        $count = count($setIdArray);
	        for($i=0;$i<$count;$i++){
	            array_push($searchArray[$i],$setIdArray[$i]);
	        }
	    }
	        
	    if(isset($_POST['answerArray'])){
	        $answerId = $_POST['answerArray'];
	        $answerIdArray = explode("|",$answerId);
	        array_pop($answerIdArray);
	        for($i=0;$i<$count;$i++){
	            array_push($searchArray[$i],$answerIdArray[$i]);
	        }
	    
	    }
		
		$dialogue_List = new Research_Model;
		if($searchArray[0][0]==='dialogue'){
			$percentageList = $dialogue_List->getDialoguePercentageListNext($searchArray);
		}else{
			$percentageList = $dialogue_List->getExamPercentageListNext($searchArray);
		}		
        $view = new View('smartsite/righResearchPanel');
        $view->percentageList = $percentageList;
		$view->searchArray = $searchArray;
		$view->render(TRUE);
    
    }	

}	
?>	