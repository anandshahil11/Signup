<?php
session_start();
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 20-Jan-2011
Page Description:: Summary page Controller 
*********************************************/

class Summary_Controller extends Controller {
    function __construct(){
	    parent::__construct();
	}
	
	//Summary Analytics Page Controller
	function summaryAnalytics($userid,$pieName="User",$total=0,$start=0,$completion=0){
      	if(isset($_POST["TimePeriod"])){
			$TimePeriod = $_POST["TimePeriod"];
		}else{
			$TimePeriod = "none";
		}
		$pieName=str_replace('__','/',$pieName);
		if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="none") OR !isset($_POST["TimePeriod"]) OR $TimePeriod=="none"){
				$enddate = date("Y-m-d H:m:s",time()+216000);
				$startdate = "1977-01-01";
 
			}
			if((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="week") OR $TimePeriod=="week"){
				
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-7 days', strtotime($curdate)));
				$enddate = $curdate;
			}
			
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="month"))OR $TimePeriod=="month"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 month', strtotime($curdate)));
				$enddate = $curdate;
			}
			if(((isset($_POST["TimePeriod"]) AND $_POST["TimePeriod"]=="ytd"))OR $TimePeriod=="ytd"){
				$curdate = date('Y-m-d H:m:s');
				$startdate = date('Y-m-d H:m:s', strtotime('-1 year', strtotime($curdate)));
				$enddate = $curdate;
			}
			$access1 = ORM::factory('user')->where('id',$userid)->find();
			$access2 = ORM::factory('role')->where('id',$userid)->find();
			$username = $access1->username;
			$role = $access2->name;
			$company = $access2->company;
			// To count all registered user
            $userCount = ORM::factory('user');
			$user_count = count($userCount->where('company',$company)->find_all());
			//To get list of Users
			$user_List = new User_Model;
			$userList = $user_List->getUsers($company,$startdate,$enddate);
			$view = new View('smartsite/summaryAnalytics');
			$view->username = $username;
			$view->userid = $userid;
			$view->role = $role;
			$view->userList = $userList;
			$view->userCount = $user_count;
			$view->company = $company;
			$questionsets = new Question_Sets_Model;
			$exam_Response = new Exam_Question_Model;
			$dialogueexam_Response = new Answers_Model;
			$settype = $questionsets->getCompanySet($company);
			$examName = $questionsets->exam_list_main($company);
			$count = count($examName);
			$dialogue_List = new Research_Model;
			$view->examSearchlist = '';
			$view->dialogueSearchlist = '';
			if($settype=='all'){
				$view->examSearchlist = $dialogue_List->getSavedSearchExam($company);
				if($count!=0){ 
					foreach($examName as $key=>$row)
					{
						$eachexam_Score[$key] = $exam_Response->get_questions_result($key,$startdate,$enddate);
					}
					$view->examName = $examName;
					$view->quizScore = $eachexam_Score;
				}else{ 
					$quizScore=MESSAGE;
				}
			}
			if($settype=='all'|| $settype=='dialogue'){
				$view->dialogueSearchlist = $dialogue_List->getSavedSearchDialogue($company);
                $demoExamName = $questionsets->exam_list($company);
				$count = count($demoExamName);
				if($count!=0){ 
					foreach($demoExamName as $key=>$row)
					{
						$digitalScore[$key] = $dialogueexam_Response->get_questions_result($key,$startdate,$enddate);
					}
					$view->digitalName = $demoExamName;
					$view->digitalScore = $digitalScore;
				}else{ 
					$digitalScore = MESSAGE;
				}
			}
			//To put values in PIE chart array based on exam select
			if($total==0){
				
				$userCount = $user_count;
				$activeUser = count($userList);
				$inactiveUser = ($userCount-$activeUser);
				$piechartArray = array("Registered" =>"$userCount","Active" =>"$activeUser","Inactive"=>"$inactiveUser" );
			}else{ 
				
				 $totalUser = $total;
				 $startUser = $start;
				 $completionUser = $completion;
				 $piechartArray = array("Total Users" =>"$totalUser","Starts" =>"$startUser","Completion"=>"$completionUser" );
			
			}
			//Research saved search
            $view->TimePeriod2 = $TimePeriod;
			$view->piechartArray = $piechartArray;
			$view->pieChartName = $pieName;
			$view->render(TRUE);
		}
	}
}	