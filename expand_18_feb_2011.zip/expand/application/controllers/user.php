<?php defined('SYSPATH') OR die('No direct access allowed.');
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 02-Sep-2010
Page Description:: User Controller [Default Controller]
*********************************************/
 
 class User_Controller extends Template_Controller {

	const ALLOW_PRODUCTION = FALSE;

	public function index(){    
        $this->template->content = new View('login');
        unset($_COOKIE);

	}
     
	//main login function, return to page if logged in with proper credential
	public function login($role=""){   
		
		if(!empty($_POST['username'])){
			$username=htmlspecialchars(trim(strtolower($_POST['username'])));
			$password=htmlspecialchars($_POST['password']);
			$useraccess=ORM::factory('user')->where('username',$username)->find();
			if($useraccess=='0'){

				$view = new View('login');
				$view->title = "<b><h3>Username or Password not found.</h3></b>";
				$this->template->content=$view;
			}else{   		
			$auth = new Auth();
			//Checking Login Credential
				if($auth->login($username,$password)){

					$access=ORM::factory('user')->where('username',$username)->find();
					$user_id=$access->id;
					$access=ORM::factory('role')->where('id',$access->id)->find();
					if(isset($access->name) and $access->name=='superadmin'){
						url::redirect('admin/index');
					}elseif(isset($access->name) and $access->name=='admin' ){
					    $company=$access->company;
						url::redirect("smartsite/summaryAnalytics/$user_id");
						
					}else{
						echo "<h3>You are General User.</h3>";
					}
					
				}else{ 

					$view = new View('login');
					$view->title = "<b><h3>Username or Password not found.</h3></b>";
					$this->template->content=$view;
				}
			}

		}else{
			
			$view = new View('login');
			$view->title = "<b><h3>Please Login.</h3></b>";
			$this->template->content=$view;
			//$this->template->content= new View('login');
			//$this->template->title="<b><h3>Please Login</h3></b>";
		}
	
	}
 
 
 
	public function logout(){ 	
	    $auth = new Auth();
		$auth->logout(TRUE);
		unset($_COOKIE['kohanasession']);
		url::redirect();
	}
  
 }