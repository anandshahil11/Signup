<?php
session_start();
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 12-Jan-2011
Page Description:: User Data Edit Controller
*********************************************/

class UserEdit_Controller extends Controller {
    function __construct(){
	    parent::__construct();
	}
	
    //To edit user Data
	function edit($id){
	    $user_Info = new User_Information_Model;
		$userData =  $user_Info->getuserData($id);
		$view = new View('smartsite/userEdit_View');
		$view->userData = $userData;
		$view->render(TRUE);
    }
	
	//To Update user Data
	function update(){
	    $empid = $_POST['empid'];
		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$company = $_POST['company'];
		$country = $_POST['country'];
		$role = $_POST['role'];
		$user_Update = new User_Information_Model;
		$user_Update->getuserUpdate($empid,$firstname,$lastname,$company,$country,$role);		
	}
}