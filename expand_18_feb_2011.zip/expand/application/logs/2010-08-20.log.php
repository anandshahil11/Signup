<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-08-20 18:09:27 +05:30 --- error: Uncaught Kohana_Database_Exception: There was an SQL error: Table 'smartsite.exam_question_setses' doesn't exist - SHOW COLUMNS FROM `exam_question_setses` in file C:/xampp/htdocs/kohana/system/libraries/drivers/Database/Mysql.php on line 371
