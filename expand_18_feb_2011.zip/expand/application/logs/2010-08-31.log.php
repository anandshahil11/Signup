<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-08-31 10:21:13 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/nousPieChart.php, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-08-31 10:26:17 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:19 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:22 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:23 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:26 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:27 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:29 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:30 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:33 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:41 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:43 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:45 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:26:51 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:32:37 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:32:38 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:33:09 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:33:11 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:33:14 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-31 10:38:20 +05:30 --- error: Uncaught PHP Error: require_once(/expand/application/views/smartsite/nousPieChart.php) [<a href='function.require-once'>function.require-once</a>]: failed to open stream: No such file or directory in file C:/xampp/htdocs/expand/application/views/smartsite/learninganalytic.php on line 3
2010-08-31 10:40:13 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, nousPieChart.php, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-08-31 14:29:05 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-08-31 14:30:33 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-08-31 14:44:22 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-08-31 14:45:03 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-08-31 14:45:32 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-08-31 14:45:33 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-08-31 14:47:16 +05:30 --- error: Uncaught PHP Error: mysql_query() [<a href='function.mysql-query'>function.mysql-query</a>]: Access denied for user 'ODBC'@'localhost' (using password: NO) in file C:/xampp/htdocs/expand/application/models/question_sets.php on line 31
2010-08-31 16:47:21 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 55
2010-08-31 16:50:13 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 55
2010-08-31 16:50:15 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 55
2010-08-31 16:50:16 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 55
2010-08-31 16:50:16 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 55
2010-08-31 16:52:58 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 56
2010-08-31 16:55:27 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 56
