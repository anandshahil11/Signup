<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-09-01 10:42:14 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-09-01 11:31:26 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
2010-09-01 11:32:15 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 78
