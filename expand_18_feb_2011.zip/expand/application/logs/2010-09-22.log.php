<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-09-22 15:16:27 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 15:19:59 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:03:13 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:03:14 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:03:40 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:03:42 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:03:46 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:03:47 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:06:42 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:06:51 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:08:15 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:08:18 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:19:45 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:19:46 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:44:36 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:44:41 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:44:46 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:44:47 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:44:49 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:45:12 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:45:13 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-22 16:49:40 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for User_Model::getuserlastLogin(), called in C:\xampp\htdocs\expand\application\controllers\smartsite.php on line 853 and defined in file C:/xampp/htdocs/expand/application/models/user.php on line 45
2010-09-22 16:49:42 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for User_Model::getuserlastLogin(), called in C:\xampp\htdocs\expand\application\controllers\smartsite.php on line 853 and defined in file C:/xampp/htdocs/expand/application/models/user.php on line 45
2010-09-22 18:17:47 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 124
