<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-09-27 09:34:35 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-27 12:27:56 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-27 12:28:11 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for User_Model::getuserlastLogin(), called in C:\xampp\htdocs\expand\application\controllers\smartsite.php on line 853 and defined in file C:/xampp/htdocs/expand/application/models/user.php on line 45
2010-09-27 12:28:15 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 61
2010-09-27 12:29:30 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 61
2010-09-27 12:29:31 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 61
2010-09-27 12:29:31 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 61
2010-09-27 12:29:31 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 61
2010-09-27 12:29:31 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 61
2010-09-27 12:29:32 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 61
2010-09-27 14:29:36 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-09-27 16:29:42 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
