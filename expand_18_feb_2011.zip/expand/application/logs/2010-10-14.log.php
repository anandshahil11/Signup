<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-14 01:42:54 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:22:52 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:23:07 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:26:14 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:38:26 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:39:09 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:39:27 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:40:04 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:40:44 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:50:02 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:50:42 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 02:50:58 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 04:37:18 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:38:39 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:43:08 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:43:20 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:44:10 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:44:17 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:44:31 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:48:05 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:48:13 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:48:18 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:51:05 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 04:51:24 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:01:59 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:03:06 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 05:03:27 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:03:31 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:03:45 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:04:10 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:04:14 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:05:19 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:05:25 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 05:12:32 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 21:08:27 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 21:09:21 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 21:11:25 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 21:11:32 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 21:11:36 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 21:11:40 -07:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 21
2010-10-14 23:33:25 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 23:34:21 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-14 23:34:39 -07:00 --- error: Uncaught PHP Error: mysql_query() [<a href='function.mysql-query'>function.mysql-query</a>]: Access denied for user 'ODBC'@'localhost' (using password: NO) in file C:/xampp/htdocs/expand/application/models/answers.php on line 385
2010-10-14 23:38:27 -07:00 --- error: Uncaught PHP Error: include(/expand/application/config/database.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory in file C:/xampp/htdocs/expand/application/models/answers.php on line 4
2010-10-14 23:40:12 -07:00 --- error: Uncaught PHP Error: include(./../config/database.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory in file C:/xampp/htdocs/expand/application/models/answers.php on line 4
2010-10-14 23:40:13 -07:00 --- error: Uncaught PHP Error: include(./../config/database.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory in file C:/xampp/htdocs/expand/application/models/answers.php on line 4
2010-10-14 23:41:56 -07:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 388
2010-10-14 23:43:11 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 157
2010-10-14 23:44:17 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 157
2010-10-14 23:45:32 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 158
2010-10-14 23:45:48 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 158
2010-10-14 23:45:50 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 158
2010-10-14 23:46:18 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/questions.php on line 55
2010-10-14 23:47:24 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 158
2010-10-14 23:47:39 -07:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 177
2010-10-14 23:47:57 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/questions.php on line 55
2010-10-14 23:50:12 -07:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/questions.php on line 146
2010-10-14 23:50:37 -07:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/questions.php on line 174
2010-10-14 23:50:56 -07:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/questions.php on line 74
2010-10-14 23:51:35 -07:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/answers.php on line 213
