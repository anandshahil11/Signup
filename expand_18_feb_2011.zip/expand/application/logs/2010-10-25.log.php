<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-25 01:22:56 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-10-25 02:12:22 -07:00 --- error: Uncaught PHP Error: mail(): Failed to connect to mailserver at "192.168.30.99" port 25, verify your "SMTP" and "smtp_port" setting in php.ini or use ini_set() in file C:/xampp/php/PEAR/Mail/mail.php on line 153
2010-10-25 23:32:48 -07:00 --- error: Uncaught PHP Error: mail(): Failed to connect to mailserver at "192.168.30.99" port 25, verify your "SMTP" and "smtp_port" setting in php.ini or use ini_set() in file C:/xampp/php/PEAR/Mail/mail.php on line 153
