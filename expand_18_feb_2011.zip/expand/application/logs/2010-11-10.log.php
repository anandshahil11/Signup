<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-10 01:24:39 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:25:47 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:28:43 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:29:18 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:29:52 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:30:43 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:31:54 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:32:26 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:32:37 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:32:50 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:32:59 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:36:39 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:36:45 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 01:37:04 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 02:19:48 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 02:20:02 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 02:20:17 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 02:20:47 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 02:23:50 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 02:38:00 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 02:38:36 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 03:31:32 -08:00 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/research.php on line 337
2010-11-10 03:31:45 -08:00 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/research.php on line 337
2010-11-10 03:40:08 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 04:31:26 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 21:16:10 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 21:16:43 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 21:25:41 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 21:32:33 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-11-10 21:53:14 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-10 21:55:04 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 30
2010-11-10 21:56:15 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 35
2010-11-10 21:57:36 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 51
2010-11-10 22:00:13 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 52
2010-11-10 22:00:56 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 52
2010-11-10 22:02:33 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 52
2010-11-10 22:08:20 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 52
2010-11-10 22:33:59 -08:00 --- error: Uncaught PHP Error: array_keys() expects parameter 1 to be array, string given in file C:/xampp/htdocs/expand/application/views/smartsite/learninganalytic.php on line 653
2010-11-10 23:13:21 -08:00 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/research.php on line 367
2010-11-10 23:14:52 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 23:54:33 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 23:54:59 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 23:56:39 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-10 23:58:24 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
