<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-11 00:01:20 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-11 00:02:50 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-11 01:23:55 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_user_answer.php on line 27
2010-11-11 01:26:22 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_user_answer.php on line 27
2010-11-11 01:26:59 -08:00 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_user_answer.php on line 48
2010-11-11 01:59:49 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 69
2010-11-11 02:02:06 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 69
2010-11-11 02:02:44 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 69
2010-11-11 02:39:17 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-11-11 02:40:00 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-11-11 02:40:30 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-11-11 21:24:59 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-11 22:26:02 -08:00 --- error: Uncaught Kohana_Database_Exception: There was an SQL error: Table 'smartsite.company_sets' doesn't exist - SHOW COLUMNS FROM `company_sets` in file C:/xampp/htdocs/expand/system/libraries/drivers/Database/Mysql.php on line 371
2010-11-11 22:36:19 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-11 22:40:47 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-11 22:45:18 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-11 22:45:28 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-11-11 22:45:53 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-11-11 22:47:43 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-11 22:51:01 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-11 22:51:22 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-11 22:53:21 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-11 22:54:25 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-11 22:57:51 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-11 23:05:01 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
2010-11-11 23:18:25 -08:00 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 27
