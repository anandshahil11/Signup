<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-14 21:33:38 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-14 21:41:44 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-14 21:42:33 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-14 21:42:35 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-14 21:42:37 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-14 21:42:39 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-14 23:21:18 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
