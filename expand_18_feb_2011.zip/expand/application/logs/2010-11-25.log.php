<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-25 01:16:58 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-25 03:44:52 -08:00 --- error: Uncaught PHP Error: mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'expandi4_smart'@'localhost' (using password: YES) in file C:/xampp/htdocs/expand/application/models/answers.php on line 11
2010-11-25 03:44:54 -08:00 --- error: Uncaught PHP Error: mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'expandi4_smart'@'localhost' (using password: YES) in file C:/xampp/htdocs/expand/application/models/answers.php on line 11
2010-11-25 03:44:54 -08:00 --- error: Uncaught PHP Error: mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Access denied for user 'expandi4_smart'@'localhost' (using password: YES) in file C:/xampp/htdocs/expand/application/models/answers.php on line 11
2010-11-25 03:46:18 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
