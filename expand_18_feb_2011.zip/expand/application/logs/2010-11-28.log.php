<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-28 22:00:30 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-28 22:39:43 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-28 22:39:47 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-28 22:55:14 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/phPie/phPieResearch.php, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-11-28 22:55:15 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/phPie/phPieResearch.php, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
