<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-12-07 00:44:40 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-07 00:44:55 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-07 00:44:57 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-07 03:10:39 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-07 04:51:40 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
