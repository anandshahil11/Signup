<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-12-08 01:05:24 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-08 01:05:51 -08:00 --- error: Uncaught PHP Error: mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;192.168.30.99&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() in file C:/xampp/php/PEAR/Mail/mail.php on line 153
2010-12-08 01:35:42 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-08 01:44:46 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-08 02:57:39 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-08 02:57:48 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-08 02:58:27 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-08 22:42:59 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-08 23:15:27 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
