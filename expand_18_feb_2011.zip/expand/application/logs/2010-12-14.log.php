<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-12-14 00:57:00 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-12-14 21:26:24 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
