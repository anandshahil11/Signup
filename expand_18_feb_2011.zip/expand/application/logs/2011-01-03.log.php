<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-01-03 21:04:02 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 21:04:08 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 21:36:26 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 22:37:50 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 22:39:44 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 22:40:32 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 22:40:54 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 22:41:22 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-03 22:41:37 -08:00 --- error: Uncaught PHP Error: mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;192.168.30.99&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() in file C:/xampp/php/PEAR/Mail/mail.php on line 153
