<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-01-14 01:37:54 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-14 03:11:14 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-14 03:11:30 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-14 03:11:53 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
