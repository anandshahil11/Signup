<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-01-20 01:44:02 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 02:27:47 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 02:34:19 -08:00 --- error: Uncaught PHP Error: array_search() expects parameter 2 to be array, string given in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 908
2011-01-20 03:14:22 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 03:14:28 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 03:14:45 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 03:15:04 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 03:23:10 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 03:28:12 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 03:29:00 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 22:35:02 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 22:35:09 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, user/kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 22:35:40 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 22:36:25 -08:00 --- error: Uncaught PHP Error: mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;192.168.30.99&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() in file C:/xampp/php/PEAR/Mail/mail.php on line 153
2011-01-20 22:54:53 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, img/footer_bg.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-20 22:54:56 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, med/img/footer_bg.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
