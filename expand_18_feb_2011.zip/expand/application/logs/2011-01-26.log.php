<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-01-26 21:10:24 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2011-01-26 21:25:21 -08:00 --- error: Uncaught PHP Error: mail() [<a href='function.mail'>function.mail</a>]: Failed to connect to mailserver at &quot;192.168.30.99&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() in file C:/xampp/php/PEAR/Mail/mail.php on line 153
