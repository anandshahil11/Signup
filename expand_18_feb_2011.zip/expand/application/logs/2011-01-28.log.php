<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-01-28 04:30:14 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, kohana11.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
