<?php defined('SYSPATH') or die('No direct script access.');
include('Mail.php');
include('Mail/mime.php'); 
 
class Answers_Model extends Model{
 
	public function __construct(){
		parent::__construct();
		$con=mysql_connect('localhost','anan','anan');
		mysql_select_db('smartsite');
	}
	
	function post_answer($sess_id,$question_set_id, $question_id, $answer){   
		$arr = array(
            'sess_id'=>$sess_id,
            'question_set_id'=>$question_set_id,
            'question_id'=>$question_id,
            'answer'=>$answer,
            'datetime'=>date("Y-m-d H:i:s")
        );

        $data = array(
               'answer' => $answer
               
            );
        $this->db->update('user_answers', $data,array('sess_id' => $sess_id,'question_set_id'=>$question_set_id,'question_id'=>$question_id)); 
    }
	
	function post_question($sess_id,$question_set_id, $question_id, $status){   
	    
	    $status=strtolower($status);
		$arr = array(
			'sess_id'=>$sess_id,
			'question_set_id'=>$question_set_id,
			'question_id'=>$question_id,
			'answer'=>'No Answer',
			'status'=>$status,
			'datetime'=>date("Y-m-d H:i:s")
		);
		
		$this->db->insert('user_answers',$arr);
	}
	
		
	
	
	function post_contact($sess_id,$question_set_id, $question_id, $fullname,$emailid,$phonenum,$product){   
		
		$arr = array(
			'sess_id'=>$sess_id,
			'fullname'=>$fullname,
			'question_set_id'=>$question_set_id,
			'question_id'=>$question_id,
			'emailid'=>$emailid,
			'phonenum'=>$phonenum,
			'product'=>$product,
			'datetime'=>date("Y-m-d H:i:s")
		);
		$this->db->insert('user_contacts',$arr);
		$this->db->select('company');
		$this->db->where('id', $question_set_id);
		$query = $this->db->get('question_sets');
		
		foreach ($query->result() as $row){
		    $company=$row->company;
		}
	        $this->db->select('emailid');
	        $this->db->where('company',$company);
	        $query = $this->db->get('email_notification');
	        foreach($query->result() as $row){
				$recipient=$row->emailid;
			}  		
       		if($recipient==""){
			$recipient="eric@getexpanded.com";
		}
		$this->db->select('sess_id','question_set_id','question_id','answer');
		$this->db->where('sess_id',$sess_id);
		$query=$this->db->get('user_answers');
		$i=0;
		foreach($query->result() as $row){
		    if(($row->question_id==='ContactLink' or $row->question_id==='Blank')  and $i==0){
		                $userdata[$i]['question_set_id']='9';
				$userdata[$i]['question_id']='No Answer';
				$userdata[$i]['question_name']='NA';
				$userdata[$i]['answer_name']='NA';
			}else{   
			    $userdata[$i]['question_set_id']=$row->question_set_id;
				$userdata[$i]['question_id']=$row->question_id;
				$ques_id=$userdata[$i]['question_id'];
				$ques_set_id=$userdata[$i]['question_set_id'];
				$query1=$this->db->query("SELECT text FROM questions WHERE id_in_set='$ques_id' and setId='$ques_set_id'");
				foreach ($query1->result() as $row1)
				{
				   $userdata[$i]['question_name']=$row1->text;
				}
				$userdata[$i]['answer_name'] = "";
				$answer = $row->answer;
				if(strpos($answer,",")){
			                    $answerArray=array();
	                            $b = array();
		                        $a=explode(",",$answer);
		                        $b=array_merge($b,$a);
		                        $answerArray=array_count_values($b);
		                        array_pop($answerArray);
		                        $answerArray = array_keys($answerArray);
		                        $count1 = count($answerArray);
		                        for($j=0;$j<$count1;$j++){
		                            $answerId = "answer".$answerArray[$j];
		                            $query2=$this->db->query("SELECT $answerId as answer FROM questions WHERE id_in_set='$ques_id' and setId='$ques_set_id'");
				                foreach ($query2->result() as $row2)
				                {
				                   $userdata[$i]['answer_name'].=$row2->answer.",";
				                }
		                            
		                            
		                        } 
	                        }else{
	                       
		                        if(($answer=="1") or ($answer=="2") or ($answer=="3") or ($answer=="4") ){
					                $answerId="answer".$resultArray[$i]['answer_id'];
					            }else{
					                $answerId="answer1_media";
					            }
					            $query2=$this->db->query("SELECT $answerId as answer FROM questions WHERE id_in_set='$ques_id' and setId='$ques_set_id'");
					            foreach ($query2->result() as $row2)
					            {
					                $userdata[$i]['answer_name']=$row2->answer;
					            }
	                        } 
			}
			$i++;
		}  
		$sender = "admin@smartsite.expandinteractive.com";
		$subject = "New Lead Information";
		$text = ''; 
		$html = "<html>
		
		        
				 <head>
				 <style type='text/css'>
				.blue_zebra {
					border-bottom: #fff solid 2px;
				}

				.blue_zebra tbody tr {
					height: 20px;
				}

				.blue_zebra tbody td, .blue_zebra thead th {
					padding: 2px 20px;
				}

				.blue_zebra thead th {
					background-color: #000;
					color:#FFF;
					font-family:Verdana;
					font-size:11pt;
					font-weight:bold;
				}
				.blue_zebra tr {
					color:#000;
					font-family:Verdana;
					font-size:11pt;
				}
				
				.gray_zebra {
					border-bottom: #fff solid 2px;
				}

				.gray_zebra tbody tr {
					height: 20px;
				}

				.gray_zebra tbody td, .gray_zebra thead th {
					padding: 2px 20px;
				}

				.gray_zebra thead th {
					background-color: #666666;
					color:#FFF;
					font-family:Verdana;
					font-size:11pt;
					font-weight:bold;

				}
				.gray_zebra tr {
					color:#000;
					background-color: #E5E5E5;
					font-family:Verdana;
					font-size:10pt;

				}
				
				#footer {
					background: #CCC url(/smartsite/img/header_bg.png) repeat-x;
					height: 100px;
					width: 100%;
				}
				
				
	
				
				 </style>
				 </head>
				
				<body>
				
				<p><b><font  color='#666666' size='18pt'>New Lead Information</font></b> </p>
				
				<table class='blue_zebra' style='table-layout:auto;width:800px;'>

						
			<thead ><tr><th>Name</th><th>Email Id</th><th>Phone Number</th><th>Product</th></tr></thead>
			<tbody>";
		
					
		$html.="<tr><td>".$fullname."</td><td>".$emailid."</td><td>".$phonenum."</td><td>".$product."</td></tr>";
	
	
	

		$html.="</tbody></table>
				<br/>
				<table class='gray_zebra' style='table-layout:auto;width:800px;'>
				<thead><tr><th>Question</th><th>Answer</th></tr></thead>
				<tbody>";
		if((count($userdata)==0 ) or (!isset($userdata))){
		$html.="<tr><td>".NA."</td><td><b>".NA."</b></td></tr>";
		}else{		
		for($i=0;$i<count($userdata);$i++){	
				$html.="<tr><td>".$userdata[$i]['question_name']."</td><td><b>".$userdata[$i]['answer_name']."</b></td></tr>";
		}
		}
		$html.="</tbody></table><br/><table id='footer'>
				<tr><td width='40%' align='left' cellpadding='20px'>
				 <a href='http://smartsite.expandinteractive.com/'>
				<img src='http://smartsite.expandinteractive.com/media/img/loginSmartsite_btn.PNG' alt='Login to Expand Interactive' />
		                </a></td><td width='60%' align='left'>
			
				<img src='http://smartsite.expandinteractive.com/media/img/logo.png' />
				</td></tr></table></body></html>";  
		$crlf = "\n";
        
		$headers = array(

					  'From'          => $sender,

					  'Return-Path'   => $sender,

					  'Subject'       => $subject

					);
		// Creating the Mime message
        $mime = new Mail_mime($crlf);
		$mime->setTXTBody($text);
		$mime->setHTMLBody($html);
		$body = $mime->get();
		$headers = $mime->headers($headers);
        $mail =& Mail::factory('mail');
		$result=$mail->send($recipient, $headers, $body);
		   
	}
	
	
	function post_ganedenform($sess_id,$question_set_id, $question_id, $fieldName,$fieldValue){   
		$arr = array(
			'sess_id'=>$sess_id,
			'question_set_id'=>$question_set_id,
			'question_id'=>$question_id,
			'field_name'=>$fieldName,
			'field_value'=>$fieldValue,
			'datetime'=>date("Y-m-d H:i:s")
		);
		
		$this->db->insert('ganeden_form',$arr);
	}
	
	
	function get_questions_result($setid,$startdate,$enddate){
		// To get No of user given specific exam based on exam ID
		$query2="SELECT sess_id, count(question_set_id)
				 FROM user_answers
				 WHERE question_set_id =$setid
				 AND datetime BETWEEN  '$startdate' AND  '$enddate' 
				 GROUP BY sess_id";

		$result2 = mysql_query($query2);
		$num_of_users = mysql_num_rows($result2);
		$no_of_ques_answered=array();
		$i=0;
		$sess=array();
			while($row = mysql_fetch_array($result2)){
					$sess[$i]=$row[0];
					$no_of_ques_answered[$i]= $row[1];
					$i++;
				}
		$countanswer=count($no_of_ques_answered);	
        //To count no of question in exam_question table for each set
		$query3="SELECT count(id_in_set)
				 FROM questions
				 WHERE setId =$setid"; 
		$result3 = mysql_query($query3);
		while($row = mysql_fetch_array($result3)){
			$no_of_ques_inset= $row[0];
		}
		$no_of_completion=0;		
		for($i=0;$i<$countanswer;$i++){
			if($no_of_ques_inset==$no_of_ques_answered[$i]){
				$no_of_completion++;
			}
		}

		$noofuser=$num_of_users;
		$noofcompletion=$no_of_completion;
		return $noofuser.":".$noofcompletion;
	}
	
	//To calculate no of answers for specific question and for specific exam set
	function get_probability($examid,$quesid,$startdate,$enddate){

			$query="SELECT answer,count( answer )
					FROM user_answers
					WHERE question_set_id =$examid
					AND question_id = '$quesid'
					AND answer != 'No Answer'
					AND datetime
					BETWEEN '$startdate'
					AND '$enddate'
					group by answer
				   ";
			$result=mysql_query($query);
			$fetchData=mysql_num_rows($result);
			if($fetchData==0){
			    $answerList[]=array("None Of User has answered this question");
				
			}else{
				$i=0;
				$b=array();
				while($row=mysql_fetch_array($result)){
					if(strpos($row[0],",")){
						
						$a=explode(",",$row[0]);
						$b=array_merge($b,$a);
						$answerList=array_count_values($b);
					}else{
						$answerList[$row[0]]=$row[1];
						$i++;
					}
				}
				
            } 
		return $answerList;	
	    
	}
	
	// To  get session id , question set id , question id from user_answers table
	function get_user_contact($examid,$startdate,$enddate,$action){
	    if($action==='leads'){
		    if($examid=="9"){
			$query="SELECT DISTINCT(uc.sess_id),uc.fullname , uc.emailid , uc.phonenum, uc.product , uc.datetime
					FROM user_contacts uc, user_answers ua
					WHERE ua.question_set_id =$examid	
					AND uc.sess_id = ua.sess_id
					AND uc.question_id = ua.question_id
					AND uc.datetime BETWEEN '$startdate' AND '$enddate'
					ORDER BY emailid";
			
			}else{ 
		    $query="SELECT DISTINCT(uc.sess_id),uc.fullname , uc.emailid , uc.phonenum , uc.product ,uc.datetime
					FROM user_contacts uc , user_answers ua 
					WHERE uc.question_set_id =ua.question_set_id
					AND uc.question_set_id='$examid'
					AND uc.question_id = ua.question_id
					AND uc.sess_id= ua.sess_id
					AND ua.answer=1
					AND uc.datetime BETWEEN '$startdate' AND '$enddate' 
					ORDER BY emailid";
			}		
		}elseif($action==='sales'){
		    if($examid=="9"){
			$query="SELECT DISTINCT(uc.sess_id),uc.fullname , uc.emailid , uc.phonenum, uc.product ,uc.datetime
					FROM user_contacts uc , user_answers ua 
					WHERE uc.question_set_id =ua.question_set_id
					AND uc.question_set_id='$examid'
					AND uc.question_id = ua.question_id
					AND uc.sess_id= ua.sess_id
					AND ua.answer='sales'
					AND uc.datetime BETWEEN '$startdate' AND '$enddate' 
					ORDER BY emailid";
			}else{
		    $query="SELECT DISTINCT(uc.sess_id),uc.fullname , uc.emailid , uc.phonenum, uc.product, uc.datetime
					FROM user_contacts uc , user_answers ua 
					WHERE uc.question_set_id =ua.question_set_id
					AND uc.question_set_id='$examid'
					AND uc.question_id = ua.question_id
					AND uc.sess_id= ua.sess_id
					AND ua.answer=2
					AND uc.datetime BETWEEN '$startdate' AND '$enddate' 
					ORDER BY emailid";
			}		
		}else{
		    if($examid=="9"){
			$query="SELECT DISTINCT(uc.sess_id),uc.fullname , uc.emailid , uc.phonenum, uc.product, uc.datetime
					FROM user_contacts uc, user_answers ua
					WHERE ua.question_set_id =$examid	
					AND uc.sess_id = ua.sess_id
					AND uc.question_id = ua.question_id
					AND uc.datetime BETWEEN '$startdate' AND '$enddate'
					ORDER BY emailid";
			
			}else{ 
				$query="SELECT DISTINCT(uc.sess_id),uc.fullname , uc.emailid , uc.phonenum, uc.product, uc.datetime
						FROM user_contacts uc , user_answers ua 
						WHERE uc.question_set_id =ua.question_set_id
						AND uc.question_set_id='$examid'
						AND uc.sess_id= ua.sess_id
						AND uc.datetime BETWEEN '$startdate' AND '$enddate' 
						ORDER BY emailid";
			}
		}		
		$result=mysql_query($query);
		$i=0;
		$userContact=array();
		$error=mysql_num_rows($result);
		if($error>0){
			while($row=mysql_fetch_array($result)){
				$userContact[$i]['sess_id']=$row[0];
				$userContact[$i]['fullname']=$row[1];
				$userContact[$i]['email']=$row[2];
				$userContact[$i]['phonenum']=$row[3];
				$userContact[$i]['product']=$row[4];
				$userContact[$i]['date']=date('m/d/Y',strtotime($row[5]));
				$i++;
			}
		}else{
			$userContact="";
		}	
        return $userContact;
	}
	
	
	
	//To Count Leads , Sales 
	public function countProduct($examid,$startdate,$enddate){
	        $totalCount=0;
                $sales=0;
                $leads=0;		
		$query="SELECT count(DISTINCT(uc.sess_id))					
				FROM user_contacts uc , user_answers ua 					
				WHERE uc.question_set_id =ua.question_set_id
                AND uc.question_set_id='$examid'				
				AND uc.question_id = ua.question_id AND uc.sess_id= ua.sess_id
				AND uc.datetime BETWEEN '$startdate' AND '$enddate'
				ORDER BY emailid";
		$result=mysql_query($query);
		while($row=mysql_fetch_array($result)){
			$totalCount=$row[0];
		}
        $query1="SELECT count(DISTINCT(uc.sess_id))
					FROM user_contacts uc , user_answers ua 
					WHERE uc.question_set_id =ua.question_set_id
					AND uc.question_id = ua.question_id
					AND uc.question_set_id='$examid'
					AND uc.sess_id= ua.sess_id
					AND ua.answer=2
					AND uc.datetime BETWEEN '$startdate' AND '$enddate' 
					ORDER BY emailid";
		$result1=mysql_query($query1);
		while($row=mysql_fetch_array($result1)){
			$sales=$row[0];
		}
        
                $leads=$totalCount-$sales;
                $total=array();
                $total['totalCount']=$totalCount;
                $total['sales']=$sales;
                $total['leads']=$leads;
                return $total; 		
    }
	
	
	//TO Count Leads , Sales 
	public function countDigitalProduct($startdate,$enddate,$examId){
	    $totalCount=0;
        $sales=0;
        $leads=0;	
        
		if($examId=="9"){
		$query="SELECT COUNT( DISTINCT (uc.sess_id) )
				FROM user_contacts uc, user_answers ua
				WHERE ua.question_set_id =$examId	
				AND uc.sess_id = ua.sess_id
				AND uc.question_id = ua.question_id
				AND uc.datetime BETWEEN '$startdate' AND '$enddate'
				ORDER BY emailid";
		
		}else{
		$query="SELECT count(DISTINCT(uc.sess_id))					
				FROM user_contacts uc , user_answers ua 					
				WHERE uc.question_set_id =ua.question_set_id
                AND ua.question_set_id=$examId				
				AND uc.sess_id= ua.sess_id
				AND uc.question_id = ua.question_id
				AND uc.datetime BETWEEN '$startdate' AND '$enddate'
				ORDER BY emailid";
		}
		
  		
		
		$result=mysql_query($query);
		while($row=mysql_fetch_array($result)){
			$totalCount=$row[0];
		}
        if($examId=="8"){
		    
		    $healthformCount=0;
			$consumerformCount=0;
			$businessformCount=0;
			$query1="SELECT count(DISTINCT(uc.sess_id))					
					FROM user_contacts uc , user_answers ua 					
					WHERE uc.question_set_id =ua.question_set_id
					AND ua.question_set_id='$examId'
					AND uc.question_id = ua.question_id 
                                        AND uc.question_id='healthform'
					AND uc.sess_id= ua.sess_id
					AND uc.datetime BETWEEN '$startdate' AND '$enddate'
					ORDER BY emailid";
			$result1=mysql_query($query1);
            if(mysql_num_rows($result1)>0){
			    while($row=mysql_fetch_array($result1)){
					$healthformCount=$row[0];
				} 
				
			}
			$query2="SELECT count(DISTINCT(uc.sess_id))					
					FROM user_contacts uc , user_answers ua 					
					WHERE uc.question_set_id =ua.question_set_id
					AND ua.question_set_id='$examId'
					AND uc.question_id = ua.question_id 
					AND uc.question_id='consumerfor'
					AND uc.sess_id= ua.sess_id
					AND uc.datetime BETWEEN '$startdate' AND '$enddate'
					ORDER BY emailid";
			$result2=mysql_query($query2);
            if(mysql_num_rows($result2)>0){
				while($row=mysql_fetch_array($result2)){
					$consumerformCount=$row[0];
				}
			}
			
			
			$query3="SELECT count(DISTINCT(uc.sess_id))					
					FROM user_contacts uc , user_answers ua 					
					WHERE uc.question_set_id =ua.question_set_id
					AND ua.question_set_id='$examId'
					AND uc.question_id = ua.question_id	
					AND uc.question_id='businessfor'
					AND uc.sess_id= ua.sess_id
					AND uc.datetime BETWEEN '$startdate' AND '$enddate'
					ORDER BY emailid";
			$result3=mysql_query($query3);
                        if(mysql_num_rows($result3)>0){
			    while($row=mysql_fetch_array($result3)){
					$businessformCount=$row[0];
				} 
				
			}
			$leads=$healthformCount.':'.$consumerformCount.':'.$businessformCount; 			
		
		}else{
		    if($examId!="9"){
				$query1="SELECT count(DISTINCT(uc.sess_id))
							FROM user_contacts uc , user_answers ua 
							WHERE uc.question_set_id =ua.question_set_id
							AND ua.question_set_id=$examId	
							AND uc.question_id = ua.question_id
							AND uc.sess_id= ua.sess_id
							AND ua.answer=1
							AND uc.datetime BETWEEN '$startdate' AND '$enddate' 
							ORDER BY emailid";
				$result1=mysql_query($query1);
				while($row=mysql_fetch_array($result1)){
					$leads=$row[0];
				}
			}
		}
        if($examId=="9"){
			$leads=$totalCount;
			$sales=0;
		}else{
		    $leads1=explode(":",$leads);
			$leads1=array_sum($leads1);
			$sales=$totalCount-$leads1;
        }
	
        $total=array();
        $total['totalCount']=$totalCount;
        $total['sales']=$sales;
        $total['leads']=$leads;
        return $total; 		
        		
	}
	
}
	
	
	