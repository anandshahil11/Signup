<?php defined('SYSPATH') or die('No direct script access.');
 
class Question_Sets_Model extends In_Out_Model{
 
 	public $data_schema = array();
 	
	public function __construct(){   
		$this->db = Database::instance();
		parent::__construct();
		$this->data_schema['table'] = 'question_sets';
		$this->data_schema['form_prefix'] = 'set';
		$this->data_schema['fields'] = array();
		$this->data_schema['fields'][] = array('name'=>'name','label'=>'Name', 'type'=>'text');
		$this->data_schema['display_fields'] = array('name','results_login');
	}
	
	public function exam_list($company){
		$query="SELECT id,name
				 FROM question_sets 
				 WHERE company='$company'
				 ORDER BY id asc
				";

		$result = mysql_query($query);
        if(mysql_num_rows($result)>0){  
			$i=0;
			while($row = mysql_fetch_array($result)){
						$id[$i]=$row[0];
						$examlist[$i]= $row[1];
						$i++;
					}
		
			$digitalList=array_combine($id,$examlist);
        }else{
		    $digitalList=array();
		}		
        return $digitalList;
	}
	
	public function exam_list_main($company){
		$query="SELECT id,name
				 FROM exam_question_sets 
				 WHERE company='$company'
				 ORDER BY id asc
				";

		$result = mysql_query($query);
        if(mysql_num_rows($result)>0){  
			$i=0;
			while($row = mysql_fetch_array($result)){
						$id[$i]=$row[0];
						$examlist[$i]= $row[1];
						$i++;
					}
		
			$digitalList=array_combine($id,$examlist);
        }else{
		    $digitalList=array();
		}		
        return $digitalList;
	}
	
	public function exam_id($company){
		$query="SELECT id,name
				 FROM question_sets 
				 WHERE company='$company'
				 ORDER BY id asc
				";

		$result = mysql_query($query);

		$i=0;
		while($row = mysql_fetch_array($result)){
					$id[$i]=$row[0];
					$examlist[$i]= $row[1];
					$i++;
				}
	
        $digitalList=array_combine($id,$examlist);	
        return $digitalList;
	}
	
	public function getCompanySet($company){
		$query="SELECT type FROM company_sets 
				 WHERE company='$company'
				";
		$result = $this->db->query($query);
		return $result[0]->type;
	}
}