<?php defined('SYSPATH') or die('No direct script access.');
class Research_Model extends Model {
	public function __construct(){
		parent::__construct();
		$con=mysql_connect('localhost','anan','anan');
		mysql_select_db('smartsite');
	}
	
    //To get Dialogue list
	public function getDialogue($company){
	 $query="SELECT id,name FROM question_sets WHERE company='$company'";
	 $result=mysql_query($query);
		if($result>0){
			 $i=0;
			 $dialogueArray=array();
			 while($row=mysql_fetch_array($result)){
				$dialogueArray[$i]['id']=$row[0];
				$dialogueArray[$i]['name']=$row[1];
				$dialogueArray[$i]['list']='dialogue';
				$i++;
				}
			 return $dialogueArray;	
	    }else{
		return "<h3>".MESSAGE."</h3>";
		}
	}
	
	// To get Exam list
	public function getExam($company){
		$query="SELECT id,name FROM exam_question_sets WHERE company='$company'";
		$result=mysql_query($query);
		if($result>0){
			 $i=0;
			 $examArray=array();
			 while($row=mysql_fetch_array($result)){
				$examArray[$i]['id']=$row[0];
				$examArray[$i]['name']=$row[1];
				$examArray[$i]['list']='exam';
				$i++;
				}
			 return $examArray;	
	    }else{
		return "<h3>".MESSAGE."</h3>";
		}
	}
	
	//To get Dialogue question list
	public function getDialogueQuestionList($quesId){
		$query="SELECT text , id_in_set , setId FROM questions WHERE setId='$quesId'";
		$result=mysql_query($query);
		$i=0;
		$quesList=array();
		while($row=mysql_fetch_array($result)){
			$quesList[$i]['questionName']=$row[0];
			$quesList[$i]['questionId']=$row[1];
			$quesList[$i]['questionSetId']=$row[2];
			$quesList[$i]['list']='dialogue';
			
			$i++;
		}
	    return $quesList;
	}
	
	//To get Exam question list
	public function getExamQuestionList($quesId){
		$query="SELECT text , id_in_set ,setId FROM exam_questions WHERE setId='$quesId'";
		$result=mysql_query($query);
		$i=0;
		$quesList=array();
		while($row=mysql_fetch_array($result)){
			$quesList[$i]['questionName']=$row[0];
			$quesList[$i]['questionId']=$row[1];
			$quesList[$i]['questionSetId']=$row[2];
			$quesList[$i]['list']='exam';
			$i++;
		}
	    return $quesList;
	}
	
	public function getDialogueAnswerList($setId,$quesId){
		$query="SELECT answer1,answer2,answer3,answer4,setId,id_in_set FROM questions WHERE setId='$setId' and id_in_set='$quesId'";
		$result=mysql_query($query);
		$i=0;
		while($row=mysql_fetch_array($result)){
		    $ansList[$i]['answer1']=$row[0];
            $ansList[$i]['answer2']=$row[1];
            $ansList[$i]['answer3']=$row[2];
            $ansList[$i]['answer4']=$row[3];
            $ansList[$i]['setId']=$row[4];
            $ansList[$i]['quesId']=$row[5];
			$ansList[$i]['list']='dialogue';
			$i++;
            			
		}
		return $ansList;
	
	}
	
	public function getExamAnswerList($setId,$quesId){
	$query="SELECT answer1,answer2,answer3,answer4,setId,id_in_set FROM exam_questions WHERE setId='$setId' and id_in_set='$quesId'";
	$result=mysql_query($query);
	$i=0;
	while($row=mysql_fetch_array($result)){
		$ansList[$i]['answer1']=$row[0];
		$ansList[$i]['answer2']=$row[1];
		$ansList[$i]['answer3']=$row[2];
		$ansList[$i]['answer4']=$row[3];
		$ansList[$i]['setId']=$row[4];
		$ansList[$i]['quesId']=$row[5];
		$ansList[$i]['list']='exam';
		$i++;
					
	}
	return $ansList;
	
	}
	
	//To Insert Data into save_search table
	public function insertSaveSearch($searchArray){
		$count=count($searchArray);
		$day = date('d', time());
		$month = date('m', time());
		$year = date('Y', time());
		$hour = date('H', time());
		$min = date('i', time());
		$sec = date('s', time());
		$session_id=(rand(1,9).$hour.$min.$sec);
		$quesIdArray=array();
		for($i=0;$i<$count;$i++){
	            array_push($searchArray[$i],$session_id);
	            $quesIdArray[$i]['type']=$searchArray[$i][0];
	            $quesIdArray[$i]['setId']=$searchArray[$i][1];
	            $quesIdArray[$i]['quesId']=$searchArray[$i][2];
		}
		
		$countQues=count($quesIdArray);
		for($i=0;$i<$countQues;$i++){
		        if($quesIdArray[$i]['type']=="dialogue"){
			   	    $quesId=$quesIdArray[$i]['quesId'];
			        $setId=$quesIdArray[$i]['setId'];
			        $query="SELECT text FROM questions WHERE setId='$setId' and id_in_set='$quesId'";
			        $result=mysql_query($query);
				    while($row=mysql_fetch_array($result)){
				        $quesName=$row[0];
				        array_push($searchArray[$i],$row[0]);
				    }
				    $answerId=$searchArray[$i][4];
				    $answerName="answer".$answerId;
				    $query1="SELECT $answerName 
				            FROM questions 
							WHERE setId='$setId' and id_in_set='$quesId'";
				    $result1=mysql_query($query1);
                    while($row=mysql_fetch_array($result1)){
				        $answer=$row[0];
                        array_push($searchArray[$i],$row[0]);						
				    }				   
			    }else{
			   
			        $quesId=$quesIdArray[$i]['quesId'];
			        $setId=$quesIdArray[$i]['setId'];
			        $query="SELECT text FROM exam_questions WHERE setId='$setId' and id_in_set='$quesId'";
			        $result=mysql_query($query);
			        while($row=mysql_fetch_array($result)){
				        $quesName=$row[0];
				        array_push($searchArray[$i],$row[0]);
				    }
				    $answerId=$searchArray[$i][4];
				    $answerName="answer".$answerId;
				    $query1="SELECT $answerName 
				            FROM exam_questions 
							WHERE setId='$setId' and id_in_set='$quesId'";
				    $result1=mysql_query($query1);
                    while($row=mysql_fetch_array($result1)){
				        $answer=$row[0];
                        array_push($searchArray[$i],$row[0]);						
				    }
		   
		        }
		
		}
		$countSearch=count($searchArray);
		for($i=0;$i<$countSearch;$i++){
		    $types=$searchArray[$i][0];
		    $setId=$searchArray[$i][1];
		    $question_id=$searchArray[$i][2];
		    $options=$searchArray[$i][3];
		    $answer_id=$searchArray[$i][4];
		    $answer=$searchArray[$i][8];
		    $name=$searchArray[$i][5];
		    $sess_id=$searchArray[$i][6];
		    $question_name=$searchArray[$i][7];
		    $created_on=date("Y-m-d H:i:s");
		    $query="INSERT INTO save_search(sess_id,name,types,setId,question_id,question_name,options,answer_id,answer,created_on)
		        values('$sess_id','$name','$types','$setId','$question_id','$question_name','$options','$answer_id','$answer','$created_on')";
		    $result=mysql_query($query);
		    if(mysql_affected_rows()>0){
		        $message="Search is saved";
		    }else{
		        $message="Some Error occured";
		    }       
		
		}
		return $message;
	}
	
	public function getSavedSearchDialogue($company){
	    $query1="SELECT DISTINCT(setId) 
                 FROM save_search 
                 WHERE setId IN (SELECT id from question_sets where company='$company')
				 ";
        $result1=mysql_query($query1);
		$i=0;
		$id=array();
		while($row=mysql_fetch_array($result1)){
		    $id[$i]=$row[0];
		}
		$list = "'". implode("', '", $id) ."'";
		$query="SELECT distinct(name) , types,sess_id 
		        FROM save_search 
				WHERE types='dialogue' AND setId IN ($list)";
	    $result=mysql_query($query);
	    if(mysql_num_rows($result)>0){
		    $dialogueSaveArray = array();
		    $i=0;
		    while($row=mysql_fetch_array($result)){
		    	$dialogueSaveArray[$i]['name']=$row[0];
		    	$dialogueSaveArray[$i]['type']=$row[1];
		    	$dialogueSaveArray[$i]['sess_id']=$row[2];
		    	$i++;	
		    }
		    return $dialogueSaveArray;
	    }else{
	           return "No Saved Search";
	    }
	}
	
	
	
	public function getSavedSearchExam($company){
	    $query1="SELECT DISTINCT(setId) 
                 FROM save_search 
                 WHERE setId IN (SELECT id from exam_question_sets where company='$company')
				 ";
				 
        $result1=mysql_query($query1);
		$i=0;
		$id=array();
		while($row=mysql_fetch_array($result1)){
		    $id[$i]=$row[0];
		}
		$list = "'". implode("', '", $id) ."'";
		$query="SELECT distinct(name) , types,sess_id 
		        FROM save_search 
				WHERE types='exam' AND setId IN ($list)";
	    $result=mysql_query($query);
	    if(mysql_num_rows($result)>0){
		    $examSaveArray = array();
		    $i=0;
		    while($row=mysql_fetch_array($result)){
		    	$examSaveArray[$i]['name']=$row[0];
		    	$examSaveArray[$i]['type']=$row[1];
		    	$examSaveArray[$i]['sess_id']=$row[2];	
		    	$i++;
		    }
		    return $examSaveArray;
	    }else{
	           return "No Saved Search";
	    }
	}
	
	
	public function deleteSearch($sess_id){
	    $query="DELETE FROM save_search WHERE sess_id='$sess_id'";
	    $result=mysql_query($query);
	    if(mysql_affected_rows()>0){
	    	$msg="Search Deleted";
	    }else{
	        $msg="Some error occured";
	    }
	    return $msg;
	}
	
	
	public function nameSelected($sess_id){
	    $query="SELECT distinct(setId),types FROM save_search WHERE sess_id='$sess_id'";
	    $result=mysql_query($query);
	    while($row=mysql_fetch_array($result)){
	        $nameSelected['setId']=$row[0];
                $nameSelected['types']=$row[1];
	    }
	    $id=$nameSelected['setId'];
	    if($nameSelected['types']=="exam"){
	        $query="SELECT name FROM exam_question_sets WHERE id='$id'";
	        $result=mysql_query($query);
	        while($row=mysql_fetch_array($result)){
	            $nameSelected=$row[0];
	        }
	    }else{
	        $query="SELECT name FROM question_sets WHERE id='$id'";
                $result=mysql_query($query);
                while($row=mysql_fetch_array($result)){
                   $nameSelected=$row[0];
                }
	    
	    }
	    return $nameSelected; 
	
	
	}
	
	public function saveSearchList($sess_id){
             $query="SELECT sess_id , name , types ,setId , question_id , question_name ,options ,answer_id,answer
                     FROM save_search
                     WHERE sess_id='$sess_id'";
             $result=mysql_query($query);
             $savesearchList=array();
             $i=0;
             while($row=mysql_fetch_array($result)){
                 $savesearchList[$i]['sess_id']=$row[0];
                 $savesearchList[$i]['name']=$row[1];
                 $savesearchList[$i]['types']=$row[2];
                 $savesearchList[$i]['setId']=$row[3];
                 $savesearchList[$i]['question_id']=$row[4];
                 $savesearchList[$i]['question_name']=$row[5];
                 $savesearchList[$i]['options']=$row[6];
                 $savesearchList[$i]['answer_id']=$row[7];
				 $savesearchList[$i]['answer']=$row[8];
                 $i++;
             }
                     
	     return $savesearchList;
	}
	public function getDialoguePercentageListNext($searchArray){
	    
		$percentage=array();
		$countSearch=count($searchArray);
		for($i=0;$i<$countSearch;$i++){
		 
		    $types[$i]=$searchArray[$i][0];
		    $setId[$i]=$searchArray[$i][1];
		    $question_id[$i]=$searchArray[$i][2];
		    $options[$i]=$searchArray[$i][3];
		    $answer[$i]=$searchArray[$i][4];
		} 
		// for($i=0;$i<$countSearch;$i++){
				
		    if($countSearch==1){
			    
				$count=$countSearch-1;
			    $query="SELECT count(DISTINCT(sess_id))
                 FROM user_answers
                 WHERE question_set_id ='$setId[$count]'
                 AND question_id = '$question_id[$count]'";
				 if($options[$count]=="is"){
                     $query.= "AND answer = '$answer[$count]'";
				 }else{
				     $query.= "AND answer != '$answer[$count]'";
				 }
                $result=mysql_query($query);
		    	while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage['response']=$row[0];
			    }
            }
			if($countSearch==2){
			    
				$countMinus=$countSearch-1;
				$count=$countSearch-2;
			    $query="SELECT count(DISTINCT(sess_id)) FROM user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer[$count]')";
				        }else{
				            $query.= "AND answer != '$answer[$count]')";
				        }
						
                $result=mysql_query($query);
				while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage['response']=$row[0];
			    }

			}
			
            if($countSearch==3){
			    
				$countMinus=$countSearch-1;
				$count=$countSearch-2;
				$count0=$countSearch-3;
			    $query="SELECT count(DISTINCT(sess_id)) FROM user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer[$count]')";
				        }else{
				            $query.= "AND answer != '$answer[$count]')";
				        }
						
						$query.="AND
                        sess_id IN (SELECT sess_id
                        FROM user_answers
                        WHERE question_set_id ='$setId[$count0]'
                        AND question_id= '$question_id[$count0]'";
                        if($options[$count0]=="is"){
                            $query.= "AND answer = '$answer[$count0]')";
				        }else{
				            $query.= "AND answer != '$answer[$count0]')";
				        }
						
                $result=mysql_query($query);
				while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage['response']=$row[0];
			    }

				

			}
			
		//}
        $query1="SELECT count(sess_id)
					FROM user_answers
					WHERE question_set_id ='$setId[0]'
					AND question_id = '$question_id[0]'";
		$result1=mysql_query($query1);
		while($row=mysql_fetch_array($result1)){
					$percentage['total']=$row[0];
		}
		if($percentage['total']==0){
		    $percentage['percentage']="0";
		}else{
		if(!isset($percentage['response'])){
		    $percentage['response']=0;
		}
        $percent=round(($percentage['response']/$percentage['total'])*100);
        $percentage['percentage']=$percent;
		}
		return $percentage;

	
	}
	
	public function getDialoguePercentageList($setId,$quesId){
	    $query="SELECT count( answer )
				FROM user_answers
				WHERE question_set_id ='$setId'
				AND question_id = '$quesId'
				AND answer != 'No Answer'";
		$result=mysql_query($query);
		$percentage=array();
        while($row=mysql_fetch_array($result)){
			$percentage['response']=$row[0];
		}

        $query1="SELECT count( answer )
				FROM user_answers
				WHERE question_set_id ='$setId'
				AND question_id = '$quesId'";
		$result1=mysql_query($query1);
        while($row=mysql_fetch_array($result1)){
			$percentage['total']=$row[0];
		}
		if($percentage['total']==0){
		    $percentage['percentage']="0%";
		}else{
        $percent=round(($percentage['response']/$percentage['total'])*100)."%";
        $percentage['percentage']=$percent;
		}
		return $percentage;
		
	}
	
	public function getExamPercentageList($setId,$quesId){
	    $query="SELECT count( answer )
				FROM exam_user_answers
				WHERE question_set_id ='$setId'
				AND question_id = '$quesId'
				AND answer != 'No Answer'";
		$result=mysql_query($query);
		$percentage=array();
        while($row=mysql_fetch_array($result)){
			$percentage['response']=$row[0];
		}

        $query1="SELECT count( answer )
				FROM exam_user_answers
				WHERE question_set_id ='$setId'
				AND question_id = '$quesId'";
		$result1=mysql_query($query1);
        while($row=mysql_fetch_array($result1)){
			$percentage['total']=$row[0];
		}
        $percent=round(($percentage['response']/$percentage['total'])*100)."%";
        $percentage['percentage']=$percent;
		
		return $percentage;
		
	}
	
	public function getExamPercentageListNext($searchArray){
	    
		$percentage=array();
		$countSearch=count($searchArray);
		for($i=0;$i<$countSearch;$i++){
		 
		 
		 $types[$i]=$searchArray[$i][0];
		 $setId[$i]=$searchArray[$i][1];
		 $question_id[$i]=$searchArray[$i][2];
		 $options[$i]=$searchArray[$i][3];
		 $answer[$i]=$searchArray[$i][4];
		} 
		// for($i=0;$i<$countSearch;$i++){
				
		    if($countSearch==1){
			    
				$count=$countSearch-1;
			    $query="SELECT count(DISTINCT(sess_id))
                 FROM exam_user_answers
                 WHERE question_set_id ='$setId[$count]'
                 AND question_id = '$question_id[$count]'";
				 if($options[$count]=="is"){
                     $query.= "AND answer = '$answer[$count]'";
				 }else{
				     $query.= "AND answer != '$answer[$count]'";
				 }
                $result=mysql_query($query);
		    	while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage['response']=$row[0];
			    }
            }
			if($countSearch==2){
			    
				$countMinus=$countSearch-1;
				$count=$countSearch-2;
			    $query="SELECT count(DISTINCT(sess_id)) FROM exam_user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM exam_user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer[$count]')";
				        }else{
				            $query.= "AND answer != '$answer[$count]')";
				        }
						
                $result=mysql_query($query);
				while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage['response']=$row[0];
			    }
            }
			
            if($countSearch==3){
			    
				$countMinus=$countSearch-1;
				$count=$countSearch-2;
				$count0=$countSearch-3;
			    $query="SELECT count(DISTINCT(sess_id)) FROM exam_user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM exam_user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer[$count]')";
				        }else{
				            $query.= "AND answer != '$answer[$count]')";
				        }
						
						$query.="AND
                        sess_id IN (SELECT sess_id
                        FROM exam_user_answers
                        WHERE question_set_id ='$setId[$count0]'
                        AND question_id= '$question_id[$count0]'";
                        if($options[$count0]=="is"){
                            $query.= "AND answer = '$answer[$count0]')";
				        }else{
				            $query.= "AND answer != '$answer[$count0]')";
				        }
						
                $result=mysql_query($query);
				while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage['response']=$row[0];
			    }
            }
 		//}
        $query1="SELECT count(sess_id)
					FROM exam_user_answers
					WHERE question_set_id ='$setId[0]'
					AND question_id = '$question_id[0]'";
		$result1=mysql_query($query1);
		while($row=mysql_fetch_array($result1)){
					$percentage['total']=$row[0];
		}
		if($percentage['total']==0){
		    $percentage['percentage']="0";
		}else{
		if(!isset($percentage['response'])){
		    $percentage['response']=0;
		}
        $percent=round(($percentage['response']/$percentage['total'])*100);
        $percentage['percentage']=$percent;
		}
		return $percentage;
    }
	
	// To View Saved Dialogue search
	public function getSaveDialoguePercentageListNext($searchArray){
	    
		$percentage=array();
		$countSearch=count($searchArray);
		for($i=0;$i<$countSearch;$i++){
		    $types[$i]=$searchArray[$i]['types'];
		    $setId[$i]=$searchArray[$i]['setId'];
		    $question_id[$i]=$searchArray[$i]['question_id'];
		    $options[$i]=$searchArray[$i]['options'];
		    $answer[$i]=$searchArray[$i]['answer'];
			$answer_id[$i]=$searchArray[$i]['answer_id'];
		} 
		
        for($i=0;$i<$countSearch;$i++){
				
		    if($i==0){
			    
				$count=$i;
			    $query="SELECT count(DISTINCT(sess_id))
                 FROM user_answers
                 WHERE question_set_id ='$setId[$count]'
                 AND question_id = '$question_id[$count]'";
				 if($options[$count]=="is"){
                        $query.= "AND answer = '$answer_id[$count]'";
				 }else{
				        $query.= "AND answer != '$answer_id[$count]'";
				 }
				$result=mysql_query($query);
		    	while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage[$i]['response']=$row[0];
			    }
                   $query1="SELECT count(sess_id)
					FROM user_answers
					WHERE question_set_id ='$setId[0]'
					AND question_id = '$question_id[0]'";
					$result1=mysql_query($query1);
				while($row=mysql_fetch_array($result1)){
					$percentage[$i]['total']=$row[0];
				}
				if($percentage[$i]['total']==0){
					$percentage[$i]['percentage']="0";
				}else{
				    if(!isset($percentage[$i]['response'])){
						$percentage[$i]['response']=0;
					}
					$percent=round(($percentage[$i]['response']/$percentage[$i]['total'])*100);
					$percentage[$i]['percentage']=$percent;
				}

			}
			if($i==1){
			    
				$countMinus=$i;
				$count=$i-1;
			    $query="SELECT count(DISTINCT(sess_id)) FROM user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer_id[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer_id[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer_id[$count]')";
				        }else{
				            $query.= "AND answer != '$answer_id[$count]')";
				        }
						
                        $result=mysql_query($query);
				        while($row=mysql_fetch_array($result)){
				            $response=$row[0];
				            $percentage[$i]['response']=$row[0];
			            }
			            $query1="SELECT count(sess_id)
					             FROM user_answers
					             WHERE question_set_id ='$setId[0]'
					             AND question_id = '$question_id[0]'";
		                $result1=mysql_query($query1);
		                while($row=mysql_fetch_array($result1)){
					        $percentage[$i]['total']=$row[0];
		                }
		                if($percentage[$i]['total']==0){
		                    $percentage[$i]['percentage']="0";
		                }else{
		                    if(!isset($percentage[$i]['response'])){
		                        $percentage[$i]['response']=0;
		                    }
                            $percent=round(($percentage[$i]['response']/$percentage[$i]['total'])*100);
                            $percentage[$i]['percentage']=$percent;
		                }

			}
			
            if($i==2){
			    
				$countMinus=$i;
				$count=$i-1;
				$count0=$i-2;
			    $query="SELECT count(DISTINCT(sess_id)) FROM user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer_id[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer_id[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer_id[$count]')";
				        }else{
				            $query.= "AND answer != '$answer_id[$count]')";
				        }
						
						$query.="AND
                        sess_id IN (SELECT sess_id
                        FROM user_answers
                        WHERE question_set_id ='$setId[$count0]'
                        AND question_id= '$question_id[$count0]'";
                        if($options[$count0]=="is"){
                            $query.= "AND answer = '$answer_id[$count0]')";
				        }else{
				            $query.= "AND answer != '$answer_id[$count0]')";
				        }
						
                        $result=mysql_query($query);
				        while($row=mysql_fetch_array($result)){
				            $response=$row[0];
				            $percentage[$i]['response']=$row[0];
			            }
                        $query1="SELECT count(sess_id)
					             FROM user_answers
					             WHERE question_set_id ='$setId[0]'
					             AND question_id = '$question_id[0]'";
		                $result1=mysql_query($query1);
		                while($row=mysql_fetch_array($result1)){
					        $percentage[$i]['total']=$row[0];
		                }
		                if($percentage[$i]['total']==0){
		                    $percentage[$i]['percentage']="0";
		                }else{
		                    if(!isset($percentage[$i]['response'])){
		                        $percentage[$i]['response']=0;
		                    }
                            $percent=round(($percentage[$i]['response']/$percentage[$i]['total'])*100);
                            $percentage[$i]['percentage']=$percent;
		                }

			}
 			
		}
        return $percentage;


	
	}
	
	
	// To View saved Exam search
	public function getSaveExamPercentageListNext($searchArray){
	    
		$percentage=array();
		$countSearch=count($searchArray);
		for($i=0;$i<$countSearch;$i++){
		    $types[$i]=$searchArray[$i]['types'];
		    $setId[$i]=$searchArray[$i]['setId'];
		    $question_id[$i]=$searchArray[$i]['question_id'];
		    $options[$i]=$searchArray[$i]['options'];
		    $answer[$i]=$searchArray[$i]['answer'];
			$answer_id[$i]=$searchArray[$i]['answer_id'];
		} 
		
        for($i=0;$i<$countSearch;$i++){
				
		    if($i==0){
			    
				$count=$i;
			    $query="SELECT count(DISTINCT(sess_id))
                 FROM exam_user_answers
                 WHERE question_set_id ='$setId[$count]'
                 AND question_id = '$question_id[$count]'";
				 if($options[$count]=="is"){
                     $query.= "AND answer = '$answer_id[$count]'";
				 }else{
				     $query.= "AND answer != '$answer_id[$count]'";
				 }
				$result=mysql_query($query);
		    	while($row=mysql_fetch_array($result)){
				    $response=$row[0];
				    $percentage[$i]['response']=$row[0];
			    }
                   $query1="SELECT count(sess_id)
					FROM exam_user_answers
					WHERE question_set_id ='$setId[0]'
					AND question_id = '$question_id[0]'";
					$result1=mysql_query($query1);
				while($row=mysql_fetch_array($result1)){
					$percentage[$i]['total']=$row[0];
				}
				if($percentage[$i]['total']==0){
					$percentage[$i]['percentage']="0";
				}else{
				    if(!isset($percentage[$i]['response'])){
						$percentage[$i]['response']=0;
					}
					$percent=round(($percentage[$i]['response']/$percentage[$i]['total'])*100);
					$percentage[$i]['percentage']=$percent;
				}

			}
			if($i==1){
			    
				$countMinus=$i;
				$count=$i-1;
			    $query="SELECT count(DISTINCT(sess_id)) FROM exam_user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer_id[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer_id[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM exam_user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer_id[$count]')";
				        }else{
				            $query.= "AND answer != '$answer_id[$count]')";
				        }
						
                        $result=mysql_query($query);
				        while($row=mysql_fetch_array($result)){
				            $response=$row[0];
				            $percentage[$i]['response']=$row[0];
			            }
			            $query1="SELECT count(sess_id)
					             FROM exam_user_answers
					             WHERE question_set_id ='$setId[0]'
					             AND question_id = '$question_id[0]'";
		                $result1=mysql_query($query1);
		                while($row=mysql_fetch_array($result1)){
					        $percentage[$i]['total']=$row[0];
		                }
		                if($percentage[$i]['total']==0){
		                    $percentage[$i]['percentage']="0";
		                }else{
		                    if(!isset($percentage[$i]['response'])){
		                        $percentage[$i]['response']=0;
		                    }
                            $percent=round(($percentage[$i]['response']/$percentage[$i]['total'])*100);
                            $percentage[$i]['percentage']=$percent;
		                }

			}
			
            if($i==2){
			    
				$countMinus=$i;
				$count=$i-1;
				$count0=$i-2;
			    $query="SELECT count(DISTINCT(sess_id)) FROM exam_user_answers 
				        WHERE question_set_id ='$setId[$countMinus]'
                        AND question_id = '$question_id[$countMinus]'";
						if($options[$countMinus]=="is"){
                            $query.= "AND answer = '$answer_id[$countMinus]'";
				        }else{
				            $query.= "AND answer != '$answer_id[$countMinus]'";
				        }
                        
                        $query.="AND
                        sess_id IN (SELECT sess_id
                        FROM exam_user_answers
                        WHERE question_set_id ='$setId[$count]'
                        AND question_id= '$question_id[$count]'";
                        if($options[$count]=="is"){
                            $query.= "AND answer = '$answer_id[$count]')";
				        }else{
				            $query.= "AND answer != '$answer_id[$count]')";
				        }
						
						$query.="AND
                        sess_id IN (SELECT sess_id
                        FROM exam_user_answers
                        WHERE question_set_id ='$setId[$count0]'
                        AND question_id= '$question_id[$count0]'";
                        if($options[$count0]=="is"){
                            $query.= "AND answer = '$answer_id[$count0]')";
				        }else{
				            $query.= "AND answer != '$answer_id[$count0]')";
				        }
						
                        $result=mysql_query($query);
				        while($row=mysql_fetch_array($result)){
				            $response=$row[0];
				            $percentage[$i]['response']=$row[0];
			            }
                        $query1="SELECT count(sess_id)
					             FROM exam_user_answers
					             WHERE question_set_id ='$setId[0]'
					             AND question_id = '$question_id[0]'";
		                $result1=mysql_query($query1);
		                while($row=mysql_fetch_array($result1)){
					        $percentage[$i]['total']=$row[0];
		                }
		                if($percentage[$i]['total']==0){
		                    $percentage[$i]['percentage']="0";
		                }else{
		                    if(!isset($percentage[$i]['response'])){
		                        $percentage[$i]['response']=0;
		                    }
                            $percent=round(($percentage[$i]['response']/$percentage[$i]['total'])*100);
                            $percentage[$i]['percentage']=$percent;
		                }

			}
 			
		}
        return $percentage;

	
	}
	
	
	
}	