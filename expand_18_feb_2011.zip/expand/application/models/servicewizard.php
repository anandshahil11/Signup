<?php defined('SYSPATH') or die('No direct script access.');
class Servicewizard_Model extends Model{
 
 	public $data_schema = array();
 	
	public function __construct(){
		parent::__construct();
		$con=mysql_connect('localhost','anan','anan');
		mysql_select_db('smartsite');

	}
	
	public function getDiagnosticCause($company_id,$serviceWizardId){
	    $query = "SELECT dc.id, dc.`cause_text` , dc.`cause_description` , count( dr.`cause_id` ) AS total, sum( if( dr.`answer` = 'Yes', 1, 0 ) ) AS yes, sum( if( dr.`answer` = 'No', 1, 0 ) ) AS no
				FROM diagnostic_tool_cause AS dc
				LEFT JOIN diagnostic_tool_response AS dr ON dc.id = dr.cause_id
				JOIN diagnostic_tool_symptom AS ds ON dc.symptom_id = ds.id
				JOIN diagnostic_tool_problem AS dp ON ds.problem_id = dp.id
				JOIN diagnostic_tool_concern AS dtc ON dp.concern_id = dtc.id
				JOIN diagnostic_tool_unittype AS dtu ON dtc.unitType_id = dtu.id
				WHERE dtu.company_id = $company_id and dtu.id = $serviceWizardId 
				GROUP BY dc.id";
		$result = mysql_query($query);
		$diagnosticeList = array();
		$count = 0;
		while($row=mysql_fetch_array($result)){
		    $diagnosticeList[$count]['id'] = $row[0];
			$diagnosticeList[$count]['cause_text'] = $row[1];
			$diagnosticeList[$count]['cause_desc'] = $row[2];
			$diagnosticeList[$count]['total'] = $row[3];
			$diagnosticeList[$count]['yes'] = $row[4];
			$diagnosticeList[$count]['no'] = $row[5];
			$count++;
		}
        return $diagnosticeList;  		
	}
	
	public function getserviceCauseList($causeid,$startdate,$enddate){
	    $query = "SELECT `id` , `cause_text`,`cause_description` 
		          FROM diagnostic_tool_cause
				  WHERE `id`='$causeid'";
		$result = mysql_query($query);
		$serviceCauseList = array();
		while($row = mysql_fetch_array($result)){
		    $serviceCauseList['id'] = $row[0];
			$serviceCauseList['cause_text'] = $row[1];
			$serviceCauseList['cause_desc'] = $row[2];
			$serviceCauseList['task_video_text'] = '';
			$serviceCauseList['task_video_desc'] = '';
		}
        return $serviceCauseList;
	
	}
	
	// To Get Service Wizard List
	public function getserviceWizardList($company_id){
	    $query = "SELECT `id` , `unitType`,`company_id` 
		          FROM diagnostic_tool_unittype
				  WHERE `company_id`='$company_id'";
		$result = $this->db->query($query);
		return $result;
	
	}
	
}	