<?php defined('SYSPATH') or die('No direct script access.');
 
class Skeleton_Model extends In_Out_Model{
 
 	public $data_schema = array();
 	
	public function __construct(){
		$this->db = Database::instance();
		parent::__construct();

		$this->data_schema['table'] = 'skeleton';
		$this->data_schema['form_prefix'] = 'skeleton';
		$this->data_schema['fields'] = array();
		$this->data_schema['fields'][] = array('name'=>'title','label'=>'Title', 'type'=>'text');
		$this->data_schema['fields'][] = array('name'=>'date','label'=>'Date','type'=>'datetext');
	}
	
}