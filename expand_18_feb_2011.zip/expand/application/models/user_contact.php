<?php defined('SYSPATH') or die('No direct script access.');
class User_Contact_Model extends Model {
 
	public function __construct(){
		parent::__construct();
		$con=mysql_connect('localhost','anan','anan');
		mysql_select_db('smartsite');
	}
	// To get Contact details of user who feeded data through flash
	public function contactdetails($sess_id){
	    
		$query="SELECT sess_id,fullname,emailid,phonenum,product 
		        FROM user_contacts 
				WHERE sess_id='$sess_id'";
		$result=mysql_query($query);
		if(mysql_num_rows($result)>0){
			$contactArray=array();
			while($row=mysql_fetch_array($result)){
				$contactArray['sess_id']=$row[0];
				$contactArray['fullname']=$row[1];
				$contactArray['emailid']=$row[2];
				$contactArray['phonenum']=$row[3];
				$contactArray['product']=$row[4];
			}
		}else{
		    $contactArray=array(); 
		}
		return $contactArray;
	}
	
	//To delete Contact details of users
	public function getDelete($id){
		$query="DELETE FROM user_contacts WHERE sess_id='$id'";
		$result=mysql_query($query);
		if(mysql_affected_rows()>0){
			$deleteResult="Data Deleted Successfully.</h3>";
		}else{
		    $deleteResult=""; 
		}
		return $deleteResult;
	
	}
	
	//To get question and answer for each user based on session id
        public function getQuesAnswerList($sess_id){
	        $query="SELECT question_set_id 
			FROM user_contacts
			WHERE sess_id=$sess_id";
		$result=mysql_query($query);
		while($row=mysql_fetch_array($result)){
			$ques_set_id=$row[0];
		}
				 

		$query="SELECT question_set_id,question_id,answer
			FROM user_answers
			WHERE sess_id ='$sess_id' and question_set_id=$ques_set_id";
		$result=mysql_query($query);
		$resultArray=array();
		$i=0;
		while($row=mysql_fetch_array($result)){
			$resultArray[$i]['set_id']=$row[0];
			$resultArray[$i]['ques_id']=$row[1];
			$resultArray[$i]['answer_id']=$row[2];
			$i++;
		}
                $count=count($resultArray);
		$answerList=array();
		for($i=0;$i<$count;$i++){
		        $quesId=$resultArray[$i]['ques_id'];
                        $setId=$resultArray[$i]['set_id'];   
                        if(strpos($resultArray[$i]['answer_id'],",")){
		                $answerArray=array();
                                $b = array();
	                        $a=explode(",",$resultArray[$i]['answer_id']);
	                        $b=array_merge($b,$a);
	                        $answerArray=array_count_values($b);
	                        array_pop($answerArray);
	                        $answerArray = array_keys($answerArray);
	                        $count1 = count($answerArray);
	                        $answer = "";
	                        for($j=0;$j<$count1;$j++){
	                            $answerid = "answer".$answerArray[$j];
	                            $sql="SELECT $answerid FROM questions WHERE id_in_set='$quesId' AND setId=$setId";
	                            $result = mysql_query($sql);
	                            while($row = mysql_fetch_array($result)){
	                            $answer .= $row[0].",";
	                            }
	                        } 
	                        $query="SELECT setId,id_in_set,text,response_type
                                    FROM questions
                                    WHERE id_in_set='$quesId' AND setId=$setId";
	                
	                        $result=mysql_query($query);
	                        while($row=mysql_fetch_array($result)){
	                                    $answerList[$i]['set_id']=$row[0];
	                                    $answerList[$i]['ques_id']=$row[1];
	                                    $answerList[$i]['question']=$row[2];
	                                    $answerList[$i]['answer']=$answer;
	                                    $answerList[$i]['response_type']=$row[3];        
	                       }
	                        
	                }else{  
	                        if(($resultArray[$i]['answer_id']=="1") or ($resultArray[$i]['answer_id']=="2") or ($resultArray[$i]['answer_id']=="3") or ($resultArray[$i]['answer_id']=="4") ){
							$answerId="answer".$resultArray[$i]['answer_id'];
							}else{
								$answerId="answer1_media";
							}
							$query="SELECT setId,id_in_set,text,$answerId,response_type
                                        FROM questions
                                        WHERE id_in_set='$quesId' AND setId=$setId";
        
                             $result=mysql_query($query);
                             while($row=mysql_fetch_array($result)){
                                 $answerList[$i]['set_id']=$row[0];
                                 $answerList[$i]['ques_id']=$row[1];
                                 $answerList[$i]['question']=$row[2];
                                 if($row[4]=="text"){
                                     $answerList[$i]['answer']=$resultArray[$i]['answer_id'];
                                 }else{
                                     $answerList[$i]['answer']=$row[3];
                                 }
                                 $answerList[$i]['response_type']=$row[4];        
                            }
                             
			        }
		   
		}// for end here
		return $answerList;
	}

}
?>	