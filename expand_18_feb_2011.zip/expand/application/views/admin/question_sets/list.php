<h2>Question Sets</h2>
<br />
<div>
		<?php echo html::anchor('admin/question_sets/create','+ Create New Question Set',array("class"=>"create_record"));?>
</div>
<br /><br />
<?php
if ( count($records) == 0 )
{
echo "<strong>No Records Found.</strong>";
}
else
{
?>
<table border='0' cellspacing='0' cellpadding='0' width='100%' class='list_table'>
		<tr>
			<th>Set ID</th>
			<th>Question Set</th>
			<?php /*<th>Results Login</th>*/?>
			<th>Actions</th>
		</tr>
	<?php
	foreach($records as $record)
	{
		?>
		<tbody id="row_<?php echo $record['id'];?>">
		<tr>
			<td>
				<?php echo $record['id'];?>
			</td>
			<td>
				<?php echo $record['name'];?>
			</td>
			<?php
			//echo $record['results_login']
			?>
			<td>
				<?php echo html::anchor('admin/question_sets/'.$record['id'].'/questions','Edit Questions',array('class'=>'list_action'))?>
				<?php echo html::anchor('admin/results/'.$record['id'],'View Results',array('class'=>'list_action'))?>
				<?php echo html::anchor('admin/question_sets/edit/'.$record['id'],'Edit',array('class'=>'list_action'))?>
				<?php echo html::anchor('#','Delete',array('class'=>'delete list_action','id'=>'delete_'.$record['id']))?>
			</td>
		</tr>
		</tbody>
		<?php
	}
	?>
	</table>
<?php
}
?>

<script language='text/javascript'>
	$(".delete").click(function(){
	 //alert("hiiiiiii");
		if ( confirm("Are you sure you want to delete this record?" ) )
		{
			var id = $(this).attr('id').replace('delete_','');
			$.ajax({
				url: "/<?=Router::$current_uri?>/delete",
				data: "id="+id,
				type: "POST",
				success: function(response){
					$("#row_"+id).fadeOut();
				}
			})
		}
	})
</script>