<h2>Question</h2>
<?php echo form::open_multipart(Router::$current_uri,array('class'=>'std_form'))?>
<?php

if ( is_array($record) )
{
	echo form::hidden('id',$record['id']);
}

echo form::hidden('question_set',$set_id);
?>

<div class='field'>
	<label for="question_id_in_set" >Question ID:</label><span class='notes'></span><br />
	<?php echo form::input('question_id_in_set',$record['id_in_set'],' size="5"')?>
</div>

<div class='field'>
	<label for="question_text" >Question:</label><span class='notes'></span><br />
	<?php echo form::input('question_text',$record['text'],' size="60"')?>
</div>

<div class='field'>
	<label for="question_response_type">Answer Type:</label><span class='notes'></span><br />
	<?php
	$select_drop = array("text"=>"Text Input","multiplechoice"=>"Multiple Choice",'checkboxes'=>"Checkboxes");
	echo form::dropdown('question_response_type',$select_drop,$record['response_type']);
	?>
</div>

<?php
for ($i=1; $i<=4; $i++)
{
	?>
	<div class='field'>
		<label for="question_answer<?=$i?>" >Answer <?=$i?>:</label><span class='notes'></span><br />
		<?php echo form::input('question_answer'.$i,$record['answer'.$i],' size="60"')?>
	</div>
	<?php
}
?>

<br /><br />
<?php echo form::submit('submit','Submit')?> or <?php echo html::anchor('admin/question_sets/'.$set_id.'/questions','Cancel')?>
<?php echo form::close()?>
