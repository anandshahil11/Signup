<h2>Questions</h2>
<br />
<div>
		<?php echo html::anchor('admin/question_sets/'.$set_id.'/questions/create','+ Create New Question',array('class'=>'create_record'));?>
</div>
<br /><br />
<?php
if ( count($records) == 0 )
{
	echo "<strong>No Records Found.</strong>";
}
else
{
?>
	<table border='0' cellspacing='0' cellpadding='0' width='100%' class='list_table'>
		<tr>
			<th>Question ID</th>
			<th>Question</th>
			<th>Actions</th>
		</tr>
	<?php
	foreach($records as $record)
	{
		?>
		<tbody id="row_<?php echo $record['id'];?>">
		<tr>
			<td width="50">
				<?php echo $record['id_in_set'];?>
			</td>
			<td width="500">
				<?php echo $record['text'];?>
			</td>
			<td>
				<?php echo html::anchor('admin/question_sets/'.$set_id.'/questions/edit/'.$record['id'],'Edit',array('class'=>'list_action'))?>
				<?php echo html::anchor('#','Delete',array('class'=>'delete list_action','id'=>'delete_'.$record['id']))?>
			</td>
		</tr>
		</tbody>
		<?php
	}
	?>
	</table>
<?php
}
?>

<script language='javascript'>
	$(".delete").click(function(){
		if ( confirm("Are you sure you want to delete this record?" ) )
		{
			var id = $(this).attr('id').replace('delete_','');
			$.ajax({
				url: "/admin/question_sets/<?=$set_id?>/questions/delete",
				data: "id="+id,
				type: "POST",
				success: function(response){
					$("#row_"+id).fadeOut();
				}
			})
		}
	})
</script>