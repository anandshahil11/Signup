<?=html::anchor('admin/results/'.$set_id.'/questions','View Results by Question')?> or <?=html::anchor('admin/results/'.$set_id.'/by_user','View Results by User')?>
<br /><br />
<?=html::anchor('admin/question_sets','Back to Question Sets List')?>
