<br />
<?php echo html::anchor('admin/question_sets','Back to Question Sets',array('class'=>'create_record'))?>
<br /><br />
<a href='/admin/results/<?=$set_id?>/export?type=excel'>Download Excel Export</a>
<br /><br />
<a href='/admin/results/<?=$set_id?>/export?type=csv'>Download CSV Export</a>
<br /><br />
<h3>Questions</h3>
<table border="0" cellspacing="0" cellpadding="5" class="list_table">
	<tr>
		<th>ID</th>
		<th>Question</th>
		<th></th>
	</tr>
<?php
if ( count($questions) > 0 )
{
	foreach ($questions as $question )
	{
	?>
		<tr>
			<td><?php echo $question['id_in_set']?></td>
			<td><?php echo $question['text']?></td>
			<td><?php echo html::anchor('admin/results/'.$set_id.'/question/'.$question['id'],'View Answers',array('class'=>'list_action'))?></td>
		</tr>
	<?php
	}
}
?>
</table>