<h3><?=$question['text']?> (<?=$question['response_type']?>)</h3>
<div style='border: 2px solid #DDD; padding: 10px;'><strong>Answer Stats: </strong>answered <?=$answer_results['number_answered']?> times out of <?=$answer_results['number_taken']?> viewers (<?=$answer_results['percent_answered']?>)</div><br /><br />
<?

if ( $answer_results['type'] == 'multiplechoice' )
{
	foreach ($question as $key=>$value)
	{
		if ( strpos($key,'answer') !== false && $key != 'answer_type' )
		{
			$answer_id = str_replace('answer','',$key);
			if ( trim($value) != '' ) //if the question is not blank
			{
				?>
				<strong><?=$value?></strong><br />
				<div style='font-size: 90%; padding: 5px 10px;'>
					Total: <?=$answer_results[$answer_id]['total']?><br />
					Percent: <?=$answer_results[$answer_id]['percent']?>%
				</div>
				<br /><br />
				<?
			}
		}
	}
}
elseif ( $answer_results['type'] == 'text' )
{
	$results = $answer_results['results'];
	?>
	<ul>
	<?
	for ($i=0; $i<count($results); $i++ )
	{
		if ( $results[$i] != '' )
		{
			?><li><?=$results[$i]?></li><?
		}
	}
	?>
	</ul>
	<?
}	
elseif ( $answer_results['type'] == 'checkboxes')
{
	foreach ($question as $key=>$value)
	{
		if ( strpos($key,'answer') !== false && $key != 'answer_type' )
		{
			$answer_id = str_replace('answer','',$key);
			if ( trim($value) != '' ) //if the question is not blank
			{
				?>
				<strong><?=$value?></strong><br />
				<div style='font-size: 90%; padding: 5px 10px;'>
					Total: <?=intval($answer_results['results'][$answer_id])?><br />
				</div>
				<br /><br />
				<?
			}
		}
	}
}
?>
	
<?=html::anchor('admin/results/'.$set_id.'/questions','Back To List')?>
