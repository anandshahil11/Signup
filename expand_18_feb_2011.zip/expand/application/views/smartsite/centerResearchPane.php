<script type="text/javascript" src="<?php echo url::base(FALSE) ?>/media/jquery/questionPopulate.js"></script>
	<?php 
	if(count($list)==0){
	    echo "<h3>No Quiz Available.</h3>";
	}else{

	?>
<div class="research_bgAlt" id="centerResult">
            	<div class="research_body">
				

			<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight">
                <input type="hidden" name="examName" id="examName" value="<?php echo $dialogue; ?>" />
				<select class="formFull" name="Training" id="training">
        		<option value="none"> <?php echo $dialogue; ?></option>
				
				<?php 
				   	$count=count($list);
                    for($i=0;$i<$count;$i++){
					    $Id=$list[$i]['id'];
						$Name=$list[$i]['name'];
						$List=$list[$i]['list'];
						echo "<option value='$Id:$List'>$Name</option>";
					}
				?>
        		
      			</select>
        		</td>
    			<td width="80" class="formButtons">
      			</td>
 				</tr>
			</table>
			
        </div>
		<?php
        }
    ?> 
	</div>
	<div class="research_bg" id="resultValue">
    	<div class="research_body">
			<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight" id="QuesList">
                <select class="formFull" name="Question" id="question">
        		<option value="none">Select Question</option>
        		<option value="option">Option</option>
      			</select></td>
    			<td width="80" class="formButtons">
				    <img src="<?php echo url::base(FALSE) ?>/media/img/plus_btn.png" width="24" height="24" alt="add" /> 
				    <img src="<?php echo url::base(FALSE) ?>/media/img/minus_btn.png" width="24" height="24" alt="remove" />
      			</td>
 				</tr>
			</table>
        </div>
	</div>
		
        
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>


 	
    