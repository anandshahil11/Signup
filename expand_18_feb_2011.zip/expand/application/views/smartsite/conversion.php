<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 23-Sep-2010
Page Description:: Conversion Page
*********************************************/


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Expand Smart Site | Conversion Page</title>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />


	<!--link before import prevents Flash Of Unstyled Content in ie6pc -->
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/typography.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/tablesorter.css" type="text/css"   />
	<!-- ADDED for Table Sorting using Jquery Plugin -tablesorter.js - -->
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery.js"></script>
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery-tablesorter.js"></script>
    <script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/rowOverOut.js"></script> 
	<script type="text/javascript">
	// add parser through the tablesorter addParser method 
    $.tablesorter.addParser({
        
        id: 'inline',
        is: function(s){
            // return false so this parser is not auto detected 
            return false;
        },
        format: function(s){
            // format your data for normalization 
            return s.replace(new RegExp(/<.*?>/),"");
        },
        // set type, either numeric or text
        type: 'text'
    });


	
	$(document).ready(function() { 

		$ ("#myTable").tablesorter({widgets: ['zebra'],headers: {
		0: {
		sorter:'inline'
		} }
    }); 
	
		// Adds "over" class to rows on mouseover 
		$(".tablesorter tr").mouseover(function(){ $(this).removeClass("even odd").addClass("over"); }); 
		// Removes "over" class from rows on mouseout 
		$(".tablesorter tr").mouseout(function(){ $(this).removeClass("over").addClass(this.rowIndex % 2 == 0 ? "odd" : "even");}); 

	});
	
	//ADDED BY ANAND for Right FORM SUBMISSION
	
	$(function() {
    
		$(".rightButton").click(function() {
			var name = $("input#fullname").val();
			var email = $("input#email").val();
			var phone = $("input#phonenum").val();
			var product = $("input#product").val();
			var notify = $("input#notify1").val();
			var examid = $("input#examId").val();
			var sessid = "<?php if(count($userContactData)>0){
                                    echo $userContactData['sess_id']; 
                                }else{
                                    echo "";
                                }?>";
			var dataString = sessid +'/' +name +'/' + email + '/' + phone+ '/' + product+ '/' + examid+'/'+notify;
			var url= "<?php echo url::base(FALSE) ?>conversion/openRightEmail/"+dataString;
			window.open(url,'welcome','width=950,height=800,menubar=no,status=no,location=no,toolbar=no,scrollbars=no,left=40,top=20')
		});
		return false;
		
	});
	
	//ADDED BY ANAND for left FORM SUBMISSION
	$(function() {
		$(".leftButton").click(function() {
		    var action = "<?php echo $action; ?>"; 
			var TimePeriod = "<?php echo $TimePeriod; ?>";
			var examid = $("input#examid").val();
			url="<?php echo url::base(FALSE) ?>conversion/openEmail/"+examid+"/"+action+"/"+TimePeriod;
			window.open(url,'welcome','width=950,height=800,menubar=no,status=no,location=no,toolbar=no,scrollbars=no,left=40,top=20')
		});
		
	});
	
	
	</script>
	
	<script type="text/javascript">
	//ADDED BY ANAND for left FORM SUBMISSION
	$(function() {
        
		$(".testButton").click(function() {
			$("#right_stat").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
			var userid = "<?php echo $userid; ?>";
			var empid = $(this).val();
			var TimePeriod = $("input#TimePeriod").val();
			var action = $("input#action").val();
			var dataString ='userid='+userid+'&empid='+empid+'&TimePeriod='+TimePeriod+'&action='+action;
			$.ajax({
				type: "POST",
				url: "<?php echo url::base(FALSE) ?>smartsite/rightConversionPane/",
				data: dataString,
				success: function(data) {
					
					$('#right_stat').html(data);			
				}
			});
		return false;
		});
		$("textarea#addresses").blur(function() {
			var emailAddresses = $("textarea#addresses").val();
			var examid = $("input#examid").val();
			var dataString ='emailAddresses=' + emailAddresses+'&examid='+examid;
			$.ajax({
				type: "POST",
				url: "<?php echo url::base(FALSE) ?>smartsite/saveEmail/",
				data: dataString,
				success: function(data) {
					return false;
				}
			});
		});
	});
	</script>

	
</head>
<body>
<div id="wrapper">
<!-- Header -->
  <div id="header">
    <div id="header_content">
      <div id="nav_logo">
	  </div>
      <div id="nav_btn">
			<div id="nav_wrap">
				<ul id="nav">	
				<li><a id="nav_summary" class="navLink" href="<?php echo url::site("smartsite/summaryAnalytics/$userid",'http');?>" title="Summary"><span>Summary</span></a></li>
				<li><a id="nav_users_selected" class="navLink" href="<?php echo url::site("smartsite/userAnalytics/$userid",'http');?>" title="Users"><span>Users</span></a></li>
				<li><a id="nav_learning" class="navLink" href="<?php echo url::site("smartsite/index/$userid",'http');?>" title="Learning Analytics"><span>Learning Analytics</span></a></li>
				<li><a id="nav_research" class="navLink" href="<?php echo url::site("smartsite/research/$userid",'http');?>" title="Research"><span>Research</span></a></li>
				</ul><div class="clear"></div>
			</div>
		</div>
		<div id="nav_user">
			<p class="user_title"><?php echo $role ?></p>
			<p class="user_name"><?php echo $username ?><a href="<?php echo url::site('user/logout','http');?>"> <img src="<?php echo url::base(FALSE) ?>media/img/logout_btn.png" alt="Logout" width="55" height="13" class="img_padleft"  /></a></p>       
		</div>
		<div class="clear">
		</div>
	</div>
  </div>
<!-- End Header -->  
<!-- Content -->
    
	<div id="container">
	    <div id="center_learn" class="column">
		<table width="100%" border="0" id="myTable" cellpadding="0" cellspacing="0" class="tablesorter">
        <thead > 
		  <tr>
			<th scope="col">Full Name</th>
			<th class="center" scope="col">Email</th>
			<th class="center" scope="col">Phone Number</th>
			<th class="center" scope="col">Product</th>
            <th class="center" scope="col">Date</th>
		   </tr>
		</thead>
		<tbody>

		    <?php
			   if(!is_array($userContact)){
		    ?>	   
			<tr>
		    <td colspan='4'><?php echo $userContact;?></td>
		    </tr>
			<?php
			   }else{
                    for($i=0;$i<count($userContact);$i++){
					if((($i+1)%2)==0){
						$id=$userContact[$i]['sess_id'];		
		    ?>
		  <tr class="testButton" id='<?php echo ($i+1);?>' style="background-color: #aad2e2;color:black;"
			onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';" 
			onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $id; ?>';"
			ondblclick="deSelectRow('<?php echo ($i+1)?>')" >
     
		    
			<input type="hidden" name="action" id="action" value="<?php echo $action;?>" />
			<input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
			
			<td><?php echo $userContact[$i]['fullname']; ?></td>
            <td><?php echo $userContact[$i]['email']; ?></td>
            <td><?php echo $userContact[$i]['phonenum']; ?></td>
            <td><?php echo $userContact[$i]['product']; ?></td>
  			<td><?php echo $userContact[$i]['date']; ?></td>
		  </tr>
		  
		  <?php     }else{
						$id=$userContact[$i]['sess_id'];	
		  ?>
		    <tr class="testButton" id='<?php echo ($i+1);?>' style="background-color: #72b4ce;color:black;" 
      			onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
				onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
				onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $id; ?>';"
				ondblclick="deSelectRow('<?php echo ($i+1)?>')">
    
			<input type="hidden" name="action" id="action" value="<?php echo $action;?>" />
			<input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
			
		    <td><?php echo $userContact[$i]['fullname']; ?></td>
            <td><?php echo $userContact[$i]['email']; ?></td>
            <td><?php echo $userContact[$i]['phonenum']; ?></td>
            <td><?php echo $userContact[$i]['product']; ?></td>
  			<td><?php echo $userContact[$i]['date']; ?></td>
		  </tr>
		               
		  <?php       }
		            }
		  ?>
		  <!--<p><span><font color="red" size="1" ><b>NOTE:</b></font></span> hold  shift key and click on  multiple headers/columns to do multiple column sorting!</p>-->
		  <?php			
		        }
		  ?>
		  </tbody>
		</table>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>

			  
	   </div>
	   	<div id="left" class="column">
					
            <div id="conversions" class="selected">			
            <h2><a href="<?php echo url::site("smartsite/conversion/$userid") ?>" >Conversion Stats</a></h2>
			
			<form id="form1" name="form1" method="post" action="<?php echo url::site("smartsite/conversion/$userid") ?>">
			<select style="width:180px;" name="TimePeriod" id="period" onChange="this.form.submit();">
				<option value="none">Time Period</option>
				<option value="week" <?php  if(isset($TimePeriod)){if ($TimePeriod == 'week'):?> selected<?php endif;}?>>Past week</option>
				<option value="month"<?php  if(isset($TimePeriod)){if ($TimePeriod == 'month'):?> selected<?php endif;}?>>Past Month</option>
				<option value="ytd"  <?php  if(isset($TimePeriod)){if ($TimePeriod == 'ytd'):?> selected<?php endif;}?>>YTD</option>

			</select>
			</form>
    
			<p>&nbsp;</p>
			<?php 
			if($examid=="9"){
			?>
			<ul>
				<li><a href="<?php echo url::site("smartsite/conversion/$userid/leads/$TimePeriod") ?>" class="conversIons">Leads (<?php echo $countProduct['leads']; ?>)</a></li>
				<li><a href="<?php echo url::site("smartsite/conversion/$userid/sales/$TimePeriod") ?>" class="conversStat">Sales(<?php echo $countProduct['sales']; ?>)</a></li>
			</ul>
			<?php
			}else{
			$totalLeads=explode(":",$countProduct['leads']);
			$totalLeads=array_sum($totalLeads);
			?>
			
			<ul>
				<li><a href="<?php echo url::site("smartsite/conversion/$userid/leads/$TimePeriod") ?>" class="conversIons">Leads (<?php echo $totalLeads; ?>)</a></li>
				<li><a href="<?php echo url::site("smartsite/conversion/$userid/sales/$TimePeriod") ?>" class="conversStat">Sales(<?php echo $countProduct['sales']; ?>)</a></li>
			</ul>
			<?php
			}
			?>
			
			
			<p>&nbsp;</p>
			<?php 
			
			$_SESSION['userContact']=$userContact;
			?>
			<div id="resultLeft"></div>
			<div id="contact_form_left">
			<form id="conv" name="conv" method="post" action="">
			<p>&nbsp;</p>
			<input name="notify" id="notify" type="checkbox"  checked value="1" onClick="this.value='1'"/><label>Instant Email Notification</label>
			<textarea name="addresses" id="addresses" cols="" rows="5" style="width:175px;" ><?php echo $emailId?></textarea>
			<input name="examid" id="examid" type="hidden" value="<?php echo $examid; ?>">
			&nbsp;
			<div style="border-bottom-color:#CCCCCC;border-bottom-style:solid;border-bottom-width:1px;"></div>
			<br>
			<img name="submit" class="leftButton" src="<?php echo url::base(FALSE) ?>media/img/forwardGroup_btn.png" style="width:180px; height:29px;" />
			</form>
            </div>
			</div>
			<p>&nbsp;</p>


	    </div>
	   <div id="right" class="column">
			<div id="right_header_stat">
			 <h2>User Stats</h2>
		    </div>
		    <div id="right_stat">
			    
			    <?php 
				    if(!is_array($userContact)){
					    echo $userContact;       
					}else{
						
						
						if($contactDelete!==''){
						    echo $contactDelete;
						}	
						if(is_array($userContactData)){ 
						
							
				?>
				
				<?php $id=$userContactData['sess_id']; ?>
				<div class="name"><?php echo $userContactData['fullname']; ?></div>
				<div id="resultRight"></div>
				<div id="contact_form">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a href='<?php echo url::site("smartsite/conversion/$userid/$action/$TimePeriod/$id/delete") ?>'>
					<img src="<?php echo url::base(FALSE) ?>media/img/remove.png">
				</a>
				
				<form id="stats" name="stats" method="post" action="">
				<label>Email</label><input name="email" id="email" type="text" value="<?php echo $userContactData['email']; ?>" />
				<label>Phone Number</label><input name="phonenum" id="phonenum" type="text" value="<?php echo $userContactData['phonenum']; ?>" />
				<input name='sess_id' type="hidden" value="<?php echo $id;?>">
                <input type="hidden" name='fullname' id="fullname" value="<?php echo $userContactData['fullname']; ?>">
				<input type="hidden" name='product' id="product" value="<?php echo $userContactData['product']; ?>">
				
				<?php
				$_SESSION['quesAnswer']=$QuesAnswerList;
				$index=array_keys($QuesAnswerList);
				$count=count($QuesAnswerList);
				?>
				<div class="exam">
				<?php
							$j=1;
							if($count==0){
				                	echo "<h3>No Q&A has been given.</h3>";
				            }else{
						
								$i=$index[0];
								if($i==0){
									$count=$count;
								}else{
									$count=$count+1;
								}
								for($i;$i<$count;$i++){
				?>
								<p>Q<?php echo $j?>: <?php echo $QuesAnswerList[$i]['question']; ?><br />
								<span class="white">A<?php echo $j?>: <?php echo $QuesAnswerList[$i]['answer'];?></span></p>

				<?php
								
									$j++;
								}
							}	
				?>
				
				<p>&nbsp;</p>
				       
						<input name="examId" id="examId" type="hidden" value="<?php echo $examid; ?>">
						
				
				</div>
				
				<?php
						}else { echo $userContactData;}  
				?>		
						
				</div>
				<?php

                        							
					}		
				?>
			</div>
			<?php
			
			if(count($userContactData)==0){
            
			}else{
			?>
            <input type="image" name="submit" class="rightButton" src="<?php echo url::base(FALSE) ?>media/img/forwardLead_btn.png" style="width:180px; height:29px;" />
			<input name="notify" type="checkbox" id="notify1" value="" style="width:15px; margin-left:15px;" OnClick="this.value='1'"/>
			<label  style="vertical-align: top;">Contacted</label>			
			</form>
			<?php } ?>
			</div>
		</div>	
		
	</div>	

 </div>
<!-- End Content -->  

<!-- Footer -->
<div id="footer"></div>
<!-- End Footer -->  

</body>

</html>	
		
	   		

