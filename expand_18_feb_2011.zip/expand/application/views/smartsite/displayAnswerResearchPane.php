
<script type="text/javascript">
    $(document).ready(function() {
        $("#question1").live('change',function() { 			
			var str = $("#question1").val();
			var list=new Array();
			list=str.split(":");
			var type=list[0];
			var setId=list[1];
			var quesId=list[2];
			var dataString='type='+type+'&setId='+setId+'&quesId='+quesId;
			var resultClass=quesId;
			$("div.resultAnswer").addClass(resultClass+'class'); 
            $("div."+resultClass+'class').removeClass('resultAnswer');
            $.ajax({
			    type:"POST", 
			    url:"<?php echo url::base(FALSE) ?>smartsite/displayAnswerResearchPane",
                	    data:dataString,
                            success:function(data){
				    $("."+resultClass+'class').html(data);
				    $("."+resultClass+'class').load();					    
				   
				}  				
			});	
			
	    });
});		 
</script>

<script type="text/javascript">

	function deleteline(buttonObj)
	{
	   var node = buttonObj;
	   do
	   {
		  node = node.parentNode.parentNode.parentNode.parentNode;
	   }
	   while
		  (node.nodeType != 1 && node.nodeName != 'div');
	       node.parentNode.removeChild(node);
	   
	}

</script>
<script type="text/javascript">
	function getResponse(value){
	    var quesIdArray = document.getElementsByName('Question'); //To get quesId 
		var IsArray = document.getElementsByName('Is');           // To get Is or Is not value
		var AnsArray = document.getElementsByName('Answer');      // To get Answer value
		var i = 0;
		var quesArray=new Array();
		var dataArray=new Array();
		var quesSelectionArray="";
		var isSelectionArray="";
		var answerArray="";
		
		 for(i=0;i<quesIdArray.length;i++){
			if (quesIdArray[i].value != "none")
			{
				quesSelectionArray += quesIdArray[i].value+"|";
			}
			
		  }
		  
		 
		 
		 for(i=0;i<IsArray.length;i++){
			isSelectionArray += IsArray[i].value+"|";
		 }	
		 
		 
		  for(i=0;i<AnsArray.length;i++){
			answerArray += AnsArray[i].value+"|";
		 }
		  

	 var p =document.getElementById('right');
	 var count=p.getElementsByTagName('div').length;
	 for(i=1;i<count;i++){
		if(p.getElementsByTagName('div')[i].className=='research_rightGray'){
			p.getElementsByTagName('div')[i].innerHTML="";
			
		}
		

	 }
	 var div = document.createElement('div');
	 var id = quesSelectionArray;
	 var list = new Array();
	 list=id.split('|');
	 list[list.length-2]=list[list.length-2].replace(/:/g,"-"); // to replace all ":"
	 div.id =list[list.length-2];
	 id1=list[list.length-2];
	 div.class = "research_right";
	 p.insertBefore(div,p.getElementsByTagName('div')[p.getElementsByTagName('div').length]);
	 var dataString='quesSelectionArray='+quesSelectionArray+'&isSelectionArray='+isSelectionArray+'&answerArray='+answerArray;
	$.ajax({
					type:"POST", 
					url:"<?php echo url::base(FALSE) ?>smartsite/righResearchPanel",
						data:dataString,
						success:function(data){
							$('#'+id1).html(data);
											

					}  				
			});
	}

</script>


		<div id='<?php echo $quesId;?>'>
		<?php 
		    $questionId=$quesId;
			
		?>
		
		<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight" id="QuesList">
                <select class="formFull"  name="Question">
        		<option value="none">Select Question</option>
        		<?php 
				$count=count($questionList);
				for($i=0;$i<$count;$i++){
				$quesId=$questionList[$i]['questionId'];
				$quesName=$questionList[$i]['questionName'];
				$quesSetId=$questionList[$i]['questionSetId'];
				$quesType=$questionList[$i]['list'];
					if($questionId==$quesId){
						echo "<option value='$quesType:$quesSetId:$quesId' selected>$quesName</option>";
					}else{
						echo "<option value='$quesType:$quesSetId:$quesId'>$quesName</option>";
					}
				
                }
				?>
      			</select><br  />
            
            	<select class="formIs"  name="Is" >
        		<option value="is" >is</option>
        		<option value="is not">is not</option>
      			</select><br  />
            
            	Select Answer 
				<select class="formMid"  name="Answer" onchange='getResponse(this.value);'>
        		<?php
                     				
				    $count=count($answerList);
					for($i=0;$i<$count;$i++){
					    $answer1=$answerList[$i]['answer1'];
				        $answer2=$answerList[$i]['answer2'];
						$answer3=$answerList[$i]['answer3'];
						$answer4=$answerList[$i]['answer4'];
						echo "<option value='none'>select option</option>";
						echo "<option value='1'>$answer1</option>";
			            echo "<option value='2'>$answer2</option>";
			            echo "<option value='3'>$answer3</option>";
			            echo "<option value='4'>$answer4</option>";  						
					}
        		
        		?>     			
				</select>
				
				</td>
    			<td width="80" class="formButtons" 
				    onclick="var a=confirm('Are you sure you want to delete?');
					if(a==true){
					           
							   deleteline(this);
					         }">
					<img src="<?php echo url::base(FALSE) ?>media/img/minus_btn.png" width="24" height="24" alt="remove" />
      			</td>
 				</tr>
			</table>
	               </div>
				   <p>&nbsp;</p>
	                
   		
   	<div class="resultAnswer">
			<table width="540" border="0" cellspacing="0" cellpadding="0">
  			<tr>
   			<td width="460" class="formRight" id="QuesList">
                <select class="formFull" name="Question" id="question1" >
        		<option value="none">Select Question</option>
        		<?php
				
				$count=count($questionList);
				for($i=0;$i<$count;$i++){
					$quesId=$questionList[$i]['questionId'];
					$quesName=$questionList[$i]['questionName'];
					$quesSetId=$questionList[$i]['questionSetId'];
					$quesType=$questionList[$i]['list'];
					echo "<option value='$quesType:$quesSetId:$quesId'>$quesName</option>";
				}
				

			?>
      			</select></td>
    			<td width="80" class="formButtons">
				   <!--<img src="/expand/media/img/plus_btn.png" width="24" height="24" alt="add" />--> 
				   <!--<img src="/expand/media/img/minus_btn.png" width="24" height="24" alt="remove" />-->
      			</td>
 				</tr>
			</table>
        </div>

	