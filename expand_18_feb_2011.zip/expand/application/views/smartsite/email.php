<?php
/********************************************
AUTHOR:: Murugan
Version:: 1.0
Date:: 02-Dec-2010
Page Description:: Mail sending 
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>Mail</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />
	<!--link before import prevents Flash Of Unstyled Content in ie6pc -->
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/typography.css" type="text/css"   />
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery.js"></script>
	<script language="javascript">
	$(function(){
		$('#sendmail').click(function()
		{
			var email=$('#to').val();
			if(email=='')
			{
				alert('Please enter atleast one TO address');
				return false;
			}else
			{
				
			}
		}
		);
	});
	</script>
</head>
<body>
<div id="wrapper" style="margin:20px">
<form name="email" action="" method="post" >
	<table width="95%" border-right=1px>
	<tr>
	<td width="10%"   style="text-align:right"><h1 style="text-align:right;font-size:12px;">To:</h1></td>
	<td width="90%"  ><input type="text" style="width:600px;height:20px" id="to" name="to"/></th>
	</tr>
	<tr>
	<td  style="text-align:right"><h1 style="text-align:right;font-size:12px;">CC:</h1></td>
	<td ><input type="text" style="width:600px;height:20px" id="cc" name="cc"/></th>
	</tr>
	<tr>
	<td  style="text-align:right"><h1 style="text-align:right;font-size:12px;">BCC:</h1></td>
	<td ><input type="text" style="width:600px;height:20px" id="bcc" name="bcc"/></th>
	</tr>
	<tr>
	<td  style="text-align:right"><h1 style="text-align:right;font-size:12px;">Subject:</h1></td>
	<td ><input type="text" style="width:600px;height:20px" value="<?php echo $subject?>" id="subject" name="subject"/></th>
	</tr>
	<tr>
	<td style="text-align:right"><h1 style="text-align:right;font-size:12px;">From:</h1></td>
	<td ><input type="text" style="width:600px;height:20px" value="<?php echo $sender?>" id="from" name="from"/>&nbsp;
	     <input type="submit" value="Send Mail" id="sendmail" name="sendmail-submit"/>
	</td>
	</tr>
	<tr>
	<td colspan="2"><?php if($message!=''){ echo $message; }else { echo '&nbsp;'; }?></td>
	<tr>
	<tr>
	<td colspan="2"><?php echo $html;?>
	</td>
	<tr>
	</table>
</form>
</div>
</body>
</html>