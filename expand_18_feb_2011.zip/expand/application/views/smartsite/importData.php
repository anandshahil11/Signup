<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 07-Sep-2010
Page Description:: Import CSV file 
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Expand Smart Site | Import Data</title>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />
    <!--link before import prevents Flash Of Unstyled Content in ie6pc -->
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/basics.css" type="text/css"   />
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/typography.css" type="text/css"   />
    <!--@Author :: Anand , Javascript for dynamic display of Exam -->
</head>
<body>
<div id="wrapper">
<!-- Header -->
  <div id="header">
    <div id="header_content">
      <div id="nav_logo">
	  </div>
      <div id="nav_btn">
			<div id="nav_wrap">
				<ul id="nav">	
				<li><a id="nav_summary" class="navLink" href="<?php echo url::site("smartsite/summaryAnalytics/$userid",'http');?>" title="Summary"><span>Summary</span></a></li>
				<li><a id="nav_users_selected" class="navLink" href="<?php echo url::site("smartsite/userAnalytics/$userid",'http');?>" title="Users"><span>Users</span></a></li>
				<li><a id="nav_learning" class="navLink" href="<?php echo url::site("smartsite/index/$userid",'http');?>" title="Learning Analytics"><span>Learning Analytics</span></a></li>
				<li><a id="nav_research" class="navLink" href="<?php echo url::site("smartsite/research/$userid",'http');?>" title="Research"><span>Research</span></a></li>
				</ul><div class="clear"></div>
			</div>
		</div>
		<div id="nav_user">
			<p class="user_title"><?php echo $role ?></p>
			<p class="user_name"><?php echo $username ?><a href="<?php echo url::site('user/logout','http');?>"> <img src="<?php echo url::base(FALSE) ?>media/img/logout_btn.png" alt="Logout" width="55" height="13" class="img_padleft"  /></a></p>       
		</div>
		<div class="clear">
		</div>
	</div>
  </div>
<!-- End Header --> 

<!-- Content -->
<div id="container">
  <div id="center_learn" class="column">

  	<div id="form_header">
      <h2>Import Users</h2>
      <p class="import">You can <a href="<?php echo url::base(FALSE) ?>upload/user_informations.csv" target="_top"><font color="white"><u>download a template</u></font></a> file or create your own CSV file from scratch.</p>
    </div>
    <div id="form_body">

		<div id="inputfile" style="background-color:skyblue;text-align:center">
        <?php 
            // To generate salt  for password 
			function find_salt($password){
				$salt = '';
				$password=sha1($password);
				foreach (array(1, 3, 5, 9, 14, 15, 20, 21, 28, 30) as $i => $offset){
					$salt .= $password[$offset + $i];
				}
                return $salt;
			}
									
									
			// To generate hash password						
			function hash_password($password, $salt = FALSE){
				if ($salt === FALSE){
					$salt = substr(hash(uniqid(NULL, TRUE)), 0, count($config['salt_pattern']));
				}
                $hash =sha1($salt.$password);
                $salt = str_split($salt, 1);
                $password = '';
                $last_offset = 0;
                foreach (array(1, 3, 5, 9, 14, 15, 20, 21, 28, 30) as $offset){
					$part = substr($hash, 0, $offset - $last_offset);
                    $hash = substr($hash, $offset - $last_offset);
                    $password .= $part.array_shift($salt);
                    $last_offset = $offset;
				}
                return $password.$hash;
			}

		if(isset($_POST['submit'])){
			$_FILES= Validation::factory( $_FILES)->add_rules('csv_upload', 'upload::valid', 'upload::required', 'upload::type[csv]', 'upload::size[1M]');

		    if ($_FILES->validate()) {
				$csvTempFile = upload::save('csv_upload');
				$con=mysql_connect('localhost','anan','anan');
				mysql_select_db('smartsite'); 
				ini_set('auto_detect_line_endings',1);
				$handle = fopen($csvTempFile, "r");
		        $errorMessage1="";
				$errorMessage2="";
				$first=true;
			    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE){
							if($first==true){
							    $first=false;
							    continue;
							}
								if((!empty($data[0])) AND (!empty($data[1])) AND (!empty($data[2])) AND (!empty($data[3]))){
									   $password=$data[0].$data[1];
									   if (is_string($password)){
											$salt = find_salt($password);
                                            $passwordEncrypt = hash_password($password, $salt);
										}

										$import1="INSERT INTO user_informations(`first name`,`last name`,`company`,`company_orig`,`email address`,`mailing address`,`state`,`country`,`phone number`,`role`) 
												 VALUES('$data[0]','$data[1]','$company','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]')
												 ON DUPLICATE KEY UPDATE `email address` = '$data[3]'
												 ";
										
                                        @mysql_query($import1) or die('Could not inserted in user information table'.mysql_error()); 
										$useridCount=mysql_insert_id();
										$userName=$data[3];	
										$import2="INSERT INTO users(id,email,username,password,company,company_orig)
												  VALUES('$useridCount','$data[3]','$userName','$passwordEncrypt','$company','$data[2]')
												  ON DUPLICATE KEY UPDATE  username='$userName',email='$data[3]'
												  ";
										@mysql_query($import2) or die('Could not inserted in users table'.mysql_error());
										$idCount=mysql_insert_id();
										if($idCount!=0){
										    $import3="INSERT INTO roles(id,name,company) VALUES($idCount,'$data[8]','$data[2]')
											         ON DUPLICATE KEY UPDATE  name='$data[8]',company='$data[2]'
													 ";		  
											@mysql_query($import3) or die('Could not inserted in roles table'.mysql_error());
										}										 
										if ( (mysql_errno() == 1062) or (mysql_errno() == 1022)  ){ 
										    
                                            ?><p>&nbsp;</p><?php
											$errorMessage1 = "<h3><center>Email:-($data[4]) is already registered<br/>
												              Please Upload CSV file again.
												              </center></h3>"; 
												 
											echo $errorMessage1;
                                            ?><p>&nbsp;</p><?php											
											break;
										}
											
										
								}else{
										?><p>&nbsp;</p><?php
										$errorMessage2 = "<h3><center>There is some problem with CSV file.</center></h3>";
										echo $errorMessage2;
										?><p>&nbsp;</p><?php
										break;
								    }		
			    }

				fclose($handle);
				
				if($errorMessage1!=NULL or $errorMessage2!= NULL){
                    echo "";
                }else{ 
                    ?><p>&nbsp;</p><?php 				
					echo "<h3><center>CSV Uploaded Successfully.</center></h3>";
					?><p>&nbsp;</p><?php
                }
				
			}else{ 
			    ?><p>&nbsp;</p><?php
				echo "<h3><center>".'Please select a CSV file to upload before clicking the Upload button.'."</center></h3>";
				?><p>&nbsp;</p><?php
			}
		}else{
			
		?>
		
		<p>&nbsp;</p>
		<form id="import" name="import" method="post" action="#" enctype="multipart/form-data">        
			   
				<input type="file" name="csv_upload" size="80" id="csv_upload"  style="width:580px; height:25px;margin:5px 0px 5px 20px;" /> &nbsp; 
				
				<input type="submit" name="submit" value="submit"src="<?php echo url::base(FALSE) ?>media/img/browse_button.png" style="width:80px; height:25px;" />
		</form> 
		<p>&nbsp;</p>
		
		<?php 
		}
		?>
		       
        </div>
	   <div class="clear"></div>
       <div class="import_body">
			 <h3>Make sure that your CSV file is in the following form and that the email is set for each user:</h3>

			 <p>&nbsp;</p>
			 <h4><font color="white"><b>Sample data as spreadsheet</b></font></h4>
			 <table width="675" border="0" cellspacing="0" cellpadding="0" class="blue_zebra_import">
			   <tr>
				 <th scope="col" bgcolor="skyblue">First Name</th>
				 <th scope="col" class="border" >Last Name</th>
				 <th scope="col" class="border"> Company</th>
				 <th scope="col" class="border"> Email Address</th>
				 <th scope="col" class="border"> Mailing Address</th>
                 <th scope="col" class="border"> State</th>
				 <th scope="col" class="border"> Country</th>
				 <th scope="col" class="border"> Phone number</th>
			   </tr>
			   <tr>
				 <td>John</td>
				 <td>Doe</td>
				 <td>Expand</td>
				 <td>john.doe@example.com</td>
				 <td>4040 Embassy Parkway, Suite 320</td>
				 <td>Ohio</td>
				 <td>US</td>
				 <td>111-222-333</td>
			   </tr>
			   <tr>
				 <td>&nbsp;</td>
				 <td>&nbsp;</td>
				 <td>&nbsp;</td>
				 <td>&nbsp;</td>

				 <td>&nbsp;</td>
			   </tr>
			 </table>
			 <p>&nbsp;</p>
			 <h4><font color="white"><b>Sample data as plain text</b></font></h4>
			 <p>&quot;First Name&quot;,&quot;Last Name&quot;,&quot;Company&quot;,&quot;Email Address&quot;,&quot;Mailing Address&quot;,&quot;State&quot;,&quot;Country&quot;,&quot;Phone number&quot;,&quot;Role&quot;<br />

			 &quot;John&quot;,&quot;Doe&quot;,&quot;Expand&quot;,&quot;john.doe@example.com&quot;,&quot;4040 Embassy Parkway, Suite 320&quot;,&quot;Ohio&quot;,&quot;US&quot;,&quot;111-111-1111&quot;,&quot;user&quot;</p>
			 <p>&nbsp;</p>
         
       </div>
<p>&nbsp;</p>
<p>&nbsp;</p>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
   
	</div>
  </div>

  <div id="left" class="column">
			<div id="users" class="selected">
			<h2><a href="<?php echo url::site("smartsite/userAnalytics/$userid") ?>" >User Library</a></h2>
			

	        <form id="form1" name="form1" method="post" action="<?php echo url::site("smartsite/userAnalytics/$userid/none/search") ?>" >
                <input style="width:175px;" name="search" type="text" value="Search" onClick="this.value=''" />
				<input type="hidden" name="submit" value="submit"/>
            </form>
			
			<p>&nbsp;</p>
    
		    
			<ul>
			    <li><a href='<?php echo url::site("smartsite/userAnalytics/$userid") ?>' class="selected userView">View All Users</a></li>
			    <li><a href="<?php echo url::site("smartsite/newUser/$userid") ?>" class="userNew">New User</a></li>
				<li><a href="<?php echo url::site("smartsite/importData/$userid") ?>" class="userImport">Import Users</a></li>
			</ul>
		    </div>
    
            <p>&nbsp;</p>
            <p>&nbsp;</p> 	
			
   </div> 
  
  
  <div id="right" class="column">
  <div id="right_body">
  <p>&nbsp;</p>

  </div>
    
  </div>
  </div>
 </div>
<!-- End Content -->  

<!-- Footer -->
<div id="footer"></div>
<!-- End Footer -->  

</body>
</html>
