<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 02-Sep-2010
Page Description:: Analytics Page
*********************************************/

/*$serviceWizardList2 = array();
		$count = 0;
		while($row = mysql_fetch_array($serviceWizardList)){
		    $serviceWizardList2 [$count]['wizard_id'] = $row[0];
			$serviceWizardList2[$count]['wizard_name'] = $row[1];
			$serviceWizardList2[$count]['wizard_company'] = $row[2];
			$count++;
		}
		var_dump($serviceWizardList2);*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Expand Smart Site | Analytics</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />
    <!--link before import prevents Flash Of Unstyled Content in ie6pc -->
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/typography.css" type="text/css"   />
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/tablesorter.css" type="text/css"   />
	<!-- ADDED for Table Sorting using Jquery Plugin -tablesorter.js - -->
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery.js"></script>
    <script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery-tablesorter.js"></script>
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/rowOverOutLA.js"></script>
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/rowOverOut.js"></script>
    <script type="text/javascript">
	// add parser through the tablesorter addParser method 
    $.tablesorter.addParser({
        id: 'inline',
        is: function(s){
            return false;
        },
        format: function(s){
            // format your data for normalization 
            return s.replace(new RegExp(/<.*?>/),"");
        },
        // set type, either numeric or text
        type: 'digit'
    });
    $(document).ready(function() { 
    $ ("#myTable").tablesorter({ widgets: ['zebra'],headers: {
		0: {
		sorter:'inline'
		} }
    }); 
	// Adds "over" class to rows on mouseover 
	$(".tablesorter tr").mouseover(function(){ $(this).removeClass("even odd").addClass("over"); }); 
	// Removes "over" class from rows on mouseout 
	$(".tablesorter tr").mouseout(function(){ $(this).removeClass("over").addClass(this.rowIndex % 2 == 0 ? "odd" : "even");}); 
    });
	</script>

	<script type="text/javascript">
	//ADDED  for left FORM SUBMISSION
	$(function() {
        $(".testButton").click(function() {
			$("#right_body").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
			var userid = "<?php echo $userid; ?>";
			var examid = "<?php echo $examid; ?>";
			var quesid = $(this).val();
			var TimePeriod = $("input#TimePeriod").val();
			var set = $("input#digital").val();
			var dataString ='examid='+examid+'&quesid='+quesid+'&TimePeriod='+TimePeriod+'&set='+set;
			$.ajax({
				type: "POST",
				url: "<?php echo url::base(FALSE) ?>smartsite/rightPane/<?php echo $userid;?>/",
				data: dataString,
				success: function(data) {
					$('#right_body').html(data);			
				}
		    });
		    return false;
	    });
	});
	</script>
    
    <script type="text/javascript">
	//Added  for Service Wizard right column display
	$(function() {
        $(".serviceButton").click(function() {
			$("#right_body").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');
			var causeid = $(this).val();
			var TimePeriod = $("input#TimePeriod").val();
			var dataString ='causeid='+causeid+'&TimePeriod='+TimePeriod;
			$.ajax({
				type: "POST",
				url: "<?php echo url::base(FALSE) ?>serviceWizard/rightServicePane/",
				data: dataString,
				success: function(data) {
					$('#right_body').html(data);			
				}
		    });
		    return false;
	    });
	});
	</script>
    
    
    
</head>
<body >
<div id="wrapper">
<!-- Header -->
  <div id="header">
    <div id="header_content">
      <div id="nav_logo"></div>
      <div id="nav_btn">
        <div id="nav_wrap">
        	<ul id="nav">	
          	<li><a id="nav_summary" class="navLink" href="<?php echo url::site("smartsite/summaryAnalytics/$userid",'http');?>" title="Summary"><span>Summary</span></a></li>
            <li><a id="nav_users" class="navLink" href="<?php echo url::site("smartsite/userAnalytics/$userid",'http');?>" title="Users"><span>Users</span></a></li>
            <li><a id="nav_learning_selected" class="navLink" href="<?php echo url::site("smartsite/index/$userid",'http');?>" title="Learning Analytics"><span>Learning Analytics</span></a></li>
            <li><a id="nav_research" class="navLink" href="<?php echo url::site("smartsite/research/$userid",'http');?>" title="Research"><span>Research</span></a></li>
            </ul><div class="clear"></div>
        </div>
      </div>
      <div id="nav_user">
      <p class="user_title"><?php echo $role ?></p>
      <p class="user_name"><?php echo $username ?><a href="<?php echo url::site('user/logout','http');?>"> <img src="<?php echo url::base(FALSE) ?>media/img/logout_btn.png" alt="Logout" width="55" height="13" class="img_padleft"  /></a></p>       
      </div><div class="clear">
    </div>
  </div>
  </div>
<!-- End Header -->  

<!-- Content -->
<div id="container">
  <div id="center_learn" class="column">
  <div id="center_header">
    <div id="center_left">  
    <?php 
    if($set==="dialogue"){
		echo "<h2>".$digitalExam[$examid]."</h2>";
	?>  
    <table width="250px" border="0" cellspacing="0" cellpadding="0" class="header_table">
    <tr>
        <td>Number of starts</td>
        <td class="header_table_bold"><?php echo $digiAnswer[0];?></td>
    </tr>
    <tr>
        <td>Number of completions</td>
        <td class="header_table_bold"><?php echo $digiAnswer[1];?></td>
    </tr>
	<?php
	if($examid=="8"){
        $eachCount=explode(":",$countProduct['leads']);
		$leads=array_sum($eachCount);
	?>
	<tr>
        <td>Leads for Health:</td>
        <td class="header_table_bold"><?php echo $eachCount[0];?></td>
	</tr>
	<tr>
        <td>Leads for Consumer:</td>
        <td class="header_table_bold"><?php echo $eachCount[1];?></td>
	</tr>
	<tr>
        <td>Leads for Business:</td>
        <td class="header_table_bold"><?php echo $eachCount[2];?></td>
	</tr>
	<?php
	}elseif($examid=="9"){
	$leads=$countProduct['leads'];
	?>
	<tr>
        <td>Leads</td>
        <td class="header_table_bold"><?php echo $countProduct['leads'];?></td>
	</tr>
	<?php
	}else{
	$leads=$countProduct['leads']
	?>
    <tr>
        <td>Sales</td>
        <td class="header_table_bold"><?php echo $countProduct['sales'];?></td>
	</tr>
    <tr>
        <td>Leads</td>
        <td class="header_table_bold"><?php echo $countProduct['leads'];?></td>
	</tr>
    <?php 
	}
	?>
	</table>
    </div>
    <div id="center_right" >
    <!-- Checks , if Average score is not available then , it wont display PIE CHART -->
	<!-- Commented on 29 nov 2010 -->
	<?php
    /*
	echo "<h2>Chart</h2>";
	if($digiAnswer[0]!=0){
			$programmers = array(
			'Total Number'=>$digiAnswer[0],
			'No Of Start'=>$digiAnswer[0],
			'No Of completion'=>$digiAnswer[1]
			);
			//$keys=array_keys($programmers);
			
	
	*/
	$programmersNew=array(
			'No Of Start'=>$digiAnswer[0],
			'No of Leads'=>$leads
			);
	?>
    <!--<img src="http://122.166.62.37:1360<?php echo url::base(FALSE) ?>PieChartCenter.php?data=<?php //echo $digiAnswer[0].'*'.$digiAnswer[0].'*'.$digiAnswer[1]?>&label=<?php //echo $keys[0].'*'.$keys[1].'*'.$keys[2] ?>" />-->
	<?php
	/*
     	echo '<IMG SRC="<?php echo url::base(FALSE) ?>media/phPie/phPie.php?data='.urlencode(serialize($programmersNew)).'">';
	*/
	?>
     
	<?php   
	/*
	}else{ 
		echo "<h3><font color='red'>NO PIE CHART</font></h3>";
	}
	*/
	?>
	<!-- End of Comment on 29 nov 2010 --->

    </div>
	<?php
    }elseif($set==="serviceWizard"){
        echo "<h2>".SERVICEWIZARD."</h2>";
	?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p> 
  </div>
    <div id="center_right" >
    </div>
    <?php
    }else{
        if(empty($examid)){ echo "<h2>".$exam[1]."</h2>";}else{ echo "<h2>".$exam[$examid]."</h2>";} 
	?>	
	
    <!--<div id="center_left">-->	
    <table width="250px" border="0" cellspacing="0" cellpadding="0" class="header_table">
    <tr>
        <td>Average score</td>
        <td class="header_table_bold">
		<?php if($answer[0]==MESSAGE){
		      echo "<font >$answer[0]</font>"; 
			  }else{
			  echo $answer[0].'%';
			  }?>
	    </td>
    </tr>
    <tr>
        <td>Number of starts</td>
        <td class="header_table_bold"><?php echo $answer[1];?></td>
    </tr>
    <tr>
        <td>Number of completions</td>
        <td class="header_table_bold"><?php echo $answer[2];?></td>
    </tr>
    <tr>
        <td>&nbsp;</td>
        <td ></td>
    </tr>
    </table>
    </div>
    <div id="center_right" >
    <!-- Checks , if Average score is not available then , it wont display PIE CHART -->
	<!-- Commented on 29 nov 2010 -->
	<?php	
    /*echo "<h2>Chart</h2>";
	if($answer[0]!==MESSAGE){
	        $programmers = array(
			'Total Number'=>$answer[1],
			'Start'=>$answer[1],
			'Completion'=>$answer[2]
			);
			
			//$keys=array_keys($programmers);
	*/		
	?>		

	<?php
	/*
	echo '<IMG SRC="<?php echo url::base(FALSE) ?>media/phPie/phPie.php?data='.urlencode(serialize($programmers)).'">';
	*/
	?>
	
	<?php   
	/*
        }else{ echo "<h3><font color='red'>NO PIE CHART</font></h3>";}
	*/   
	?>
	<!-- End of Comment on 29 nov 2010 -->
    </div>
	<?php } ?>
    </div>
    <?php
    if($set==="dialogue"){
    ?>
    <table width="100%" border="0" cellpadding="0" cellspacing="0" class="blue_zebra1">
    <tr>
        <th scope="col">Questions</th>
        <th class="center" scope="col">Asked </th>
        <th class="center" scope="col">Responses</th>
        <th class="center" scope="col">Path Retention</th>
	<?php 
	if(isset($programmersNew)){
		$NoofStart=$programmersNew['No Of Start'];
	}else{
		$NoofStart=0;
	}	
    ?>
	    <th class="center" scope="col">Question Retention</th>
    </tr>
    <?php 
    for($i=0;$i<count($digiQuestions);$i++){
	    if((($i+1)%2)==0){
	  
    ?>
    <tr class="testButton" id='<?php echo ($i+1)?>' style="background-color: #aad2e2;color:black;" 
    onmouseover="rowOverLA('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
    onmouseout="rowOverLA('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
    onclick="selectRowLA('<?php echo ($i+1)?>');this.value='<?php echo $digiQuestionListid[$i]; ?>';"
    ondblclick="deSelectRowLA('<?php echo ($i+1)?>')">
    
	<input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
	<input type="hidden" name="digital" id="digital" value="dialogue" />
	    <td width="45%">
 	        <?php echo  $digiQuestionListid[$i]."<b>.&nbsp;&nbsp;&nbsp;</b>".$digiQuestions[$i]; ?>
	    </td>
        <td width="11%" class="center">
		    <?php 
	        if(isset($Click[$digiQuestionListid[$i]])){
									
	            $click=$Click[$digiQuestionListid[$i]];
			    echo $click; 
			}else{ 
			    $click=0;
				echo $click;
			}	
	
			?>
		</td>
        <td width="14%" class="center">
		    <?php  
			if(isset($quesRespond[$digiQuestionListid[$i]])){ 
	            $response=$quesRespond[$digiQuestionListid[$i]];
				echo $response; 
			}else{ 
			    $response=0;
				echo $response;
			} 
			?>
	    </td>
        <td width="15%" class="center">
		    <?php
	        if($response==0 or $NoofStart==0 or $click==0){
				$passEff=0;
				$quesEff=0;
			}else{
                $passEff=round(($response/$NoofStart)*100);
				$quesEff=round(($response/$click)*100);
			}
			echo $passEff.'%';
	        ?>
	    </td>
	    <td width="15%" class="center"><?php echo $quesEff.'%'; ?></td>
    </tr>
    <?php  
	    }else{
	 
    ?>
    <tr class="testButton" id='<?php echo ($i+1)?>' style="background-color: #72b4ce;color:black;" 
    onmouseover="rowOverLA('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
    onmouseout="rowOverLA('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
    onclick="selectRowLA('<?php echo ($i+1)?>');this.value='<?php echo $digiQuestionListid[$i]; ?>';"
    ondblclick="deSelectRowLA('<?php echo ($i+1)?>')">
    
	<input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
	<input type="hidden" name="digital" id="digital" value="dialogue" />
	    <td >
		    <?php echo  $digiQuestionListid[$i]."<b>.&nbsp;&nbsp;&nbsp;</b>".$digiQuestions[$i]; ?>
	    </td>
        <td class="center">
		    <?php  
			if(isset($Click[$digiQuestionListid[$i]])){ 
			    $click=$Click[$digiQuestionListid[$i]];
			    echo $click; 
			}else{ 
			    $click=0;
				echo $click;
			}
			?>
		</td>
        <td class="center">
		    <?php  
			if(isset($quesRespond[$digiQuestionListid[$i]])){ 
	            $response=$quesRespond[$digiQuestionListid[$i]];
				echo $response; 
			}else{ 
			    $response=0;
				echo $response;
			} 
			?>
	    </td>
        <td class="center">
		    <?php
			if($response==0 or $NoofStart==0 or $click==0){
				$passEff=0;
				$quesEff=0;
			}else{
                $passEff=round(($response/$NoofStart)*100);
				$quesEff=round(($response/$click)*100);
			}
			echo $passEff.'%';
	        ?>
	    </td>
	    <td class="center"><?php echo $quesEff.'%'; ?></td>
    </tr>
    <?php  
	    }
	}  
    ?>
    </table>
	
    <?php
    // Added for Roland Service wizard
    }elseif($set==="serviceWizard"){
  
    ?>
    <table width="100%" border="0" id="myTable" cellpadding="0" cellspacing="0" class="tablesorter">
    <thead><tr>
        <th scope="col" class="{sorter: false}">Solutions</th>
        <th class="center" scope="col">Total Views </th>
        <th class="center" scope="col">Solved Problem</th>
        <th class="center" scope="col">Didnot Solved Problem</th>
    </tr></thead>
    <?php 
    $countList=count($diagnosticList);
	for($count=0;$count<$countList;$count++){
	    if((($count+1)%2)==0){
	    
    ?>
	<tr class='serviceButton' id='<?php echo ($count+1)?>' style="background-color: #aad2e2;color:black;" 
    onmouseover="rowOver('<?php echo ($count+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
    onmouseout="rowOver('<?php echo ($count+1)?>',0);this.style.fontWeight='normal';"
    onclick="selectRow('<?php echo ($count+1)?>');this.value='<?php echo $diagnosticList[$count]['id']; ?>';"
    ondblclick="deSelectRow('<?php echo ($count+1)?>')">
    <input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
	<input type="hidden" name="digital" id="digital" value="exam" />
	
	    <td width="60%"> 
	        <?php 
			echo $diagnosticList[$count]['id']."<b>.&nbsp;&nbsp;&nbsp;</b>".$diagnosticList[$count]['cause_text'];
			?>
		</td>
        <td width="11%" class="center"><?php echo $diagnosticList[$count]['total']; ?></td>
        <td width="14%" class="center"><?php echo $diagnosticList[$count]['yes']; ?></td>
	    <td width="15%" class="center"><?php echo $diagnosticList[$count]['no'];?></td>
    </tr>
	
    <?php  
	    }else{
	?>	  
	<tr class='serviceButton' id='<?php echo ($count+1)?>' style="background-color: #72b4ce;color:black;" 
    onmouseover="rowOver('<?php echo ($count+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
    onmouseout="rowOver('<?php echo ($count+1)?>',0);this.style.fontWeight='normal';"
    onclick="selectRow('<?php echo ($count+1)?>');this.value='<?php echo $diagnosticList[$count]['id']; ?>';"
    ondblclick="deSelectRow('<?php echo ($count+1)?>')">
	<input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
	<input type="hidden" name="digital" id="digital" value="exam" />
	    <td>
	    <?php echo $diagnosticList[$count]['id']."<b>.&nbsp;&nbsp;&nbsp;</b>".$diagnosticList[$count]['cause_text']; ?></td>
        <td width="11%" class="center"><?php echo $diagnosticList[$count]['total']; ?></td>
        <td width="14%" class="center"><?php echo $diagnosticList[$count]['yes']; ?></td>
	    <td width="15%" class="center"><?php echo $diagnosticList[$count]['no'];?></td>
    </tr>
	
	<?php
        }	
	}
    ?>
    </table>
    <?php  
    }else{  
    ?>  
    <table width="100%" border="0" cellpadding="0" cellspacing="0" class="blue_zebra1">
    <tr>
        <th scope="col">Questions</th>
        <th class="center" scope="col">#Correct</th>
        <th class="center" scope="col">#Incorrect</th>
        <th class="center" scope="col">Effectiveness</th>
    </tr>
    <?php 
    for($i=0;$i<count($questions);$i++){
	    if((($i+1)%2)==0){
	  
    ?>
	<tr class="testButton" id='<?php echo ($i+1)?>' style="background-color: #aad2e2;color:black;" 
    onmouseover="rowOverLA('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
    onmouseout="rowOverLA('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
    onclick="selectRowLA('<?php echo ($i+1)?>');this.value='<?php echo $questionlistid[$i]; ?>';"
    ondblclick="deSelectRowLA('<?php echo ($i+1)?>')">
    <input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
	<input type="hidden" name="digital" id="digital" value="exam" />
	
	    <td width="60%"> 
	    <?php echo $questionlistid[$i]."<b>.&nbsp;&nbsp;&nbsp;</b>".$questions[$i];?></a></td>
        <td width="11%" class="center"><?php echo $correct[$i]; ?></td>
        <td width="14%" class="center"><?php echo $incorrect[$i]; ?></td>
	    <?php
	    $totalanswer=$correct[$i]+$incorrect[$i];
	    if($totalanswer==0){$eff=0;}else{
	        $eff=round(($correct[$i]/$totalanswer)*100);
        }
	    ?>
        <td width="15%" class="center"><?php echo $eff;?>&nbsp;%</td>
    </tr>
	
    <?php  
	    }else{
    ?>	  
	
	<tr class="testButton" id='<?php echo ($i+1)?>' style="background-color: #72b4ce;color:black;" 
    onmouseover="rowOverLA('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
    onmouseout="rowOverLA('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
    onclick="selectRowLA('<?php echo ($i+1)?>');this.value='<?php echo $questionlistid[$i]; ?>';"
    ondblclick="deSelectRowLA('<?php echo ($i+1)?>')">
	<input type="hidden" name="TimePeriod" id="TimePeriod" value="<?php echo $TimePeriod;?>" />
	<input type="hidden" name="digital" id="digital" value="exam" />
	    <td>
	    <?php echo $questionlistid[$i]."<b>.&nbsp;&nbsp;&nbsp;</b>".$questions[$i]; ?></td>
        <td class="center"><?php echo $correct[$i]; ?></td>
        <td class="center"><?php echo $incorrect[$i]; ?></td>
	    <?php
	    $totalanswer=$correct[$i]+$incorrect[$i];
	    if($totalanswer==0){$eff=0;}else{
	        $eff=round(($correct[$i]/$totalanswer)*100);
        }
	    ?>
        <td class="center"><?php echo $eff;?>&nbsp;%</td>
    </tr>
	<?php
        }	
	}
    ?>

    </table>
    <?php 
	}
	?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
  
  <div id="left" class="column">
    <h2>Analytics</h2>
    <?php 
	if($set==="dialogue"){
	    $url="smartsite/index/$userid/$examid/$digiQuesid/$TimePeriod/dialogue";
	}elseif($set==="serviceWizard"){
	    $url="smartsite/index/$userid/1/1/$TimePeriod/serviceWizard";
	}else{ 
	    $url="smartsite/index/$userid/$examid";
	}

	?>
    <form id="form1" name="form1" method="post" action='<?php echo url::site("$url")?>'>
        <select style="width:180px;" name="TimePeriod" id="period" onChange="this.form.submit();">
            <option value="none" >Time Period</option>
            <option value="week" <?php  if(isset($TimePeriod)){if ($TimePeriod == 'week'):?> selected<?php endif;}?>>Past week</option>
            <option value="month"<?php if(isset($TimePeriod)){if ($TimePeriod == 'month'):?> selected<?php endif;}?>>Past Month</option>
            <option value="ytd" <?php if(isset($TimePeriod)){if ($TimePeriod == 'ytd'):?> selected<?php endif;}?>>YTD</option>
        </select>
    </form>
    <p>&nbsp;</p>
    <ul>
        <?php 
		
		if(!empty($exam)){
			$id=array_keys($exam);
			$count=count($exam);
			$i=$id[0];
			if($count<$i){
				$count=$i+$count;
			}else{
				$count=count($id)+1;
			}
		
			if(isset($TimePeriod)){
				 
				for($i;$i<$count;$i++){
	    ?>	
						<li><a href='<?php echo url::site("smartsite/index/$userid/$i/1/$TimePeriod")?>' >
							<?php echo $exam[$i]; ?>
						</a></li>
		<?php       
		            } 
			}
			
		}
		
		?>
		<?php 
		if(!empty($digitalExam)){
		    $digitdemo=$digitalExam;
		    $b=array_keys($digitdemo);
		    $i=$b[0];
		    $count=$i+count($digitdemo);
		?>
        <?php 
			if(isset($TimePeriod)){
				$a=0;
				for($i;$i<$count;$i++){
		?>	
						<li><a href='<?php echo url::site("smartsite/index/$userid/$i/1/$TimePeriod/dialogue")?>' >
							<?php echo $digitdemo[$i]; ?>
						</a></li>
		<?php       
		            } 
			}
		}
		?>
            <?php if($set != "dialogue"){
			?>
			<li>Service Wizard List</li>
		    <?php	
			
			// For Service Wizard List 
			foreach($serviceWizardList as $row){
			    $serviceWizardId = $row->id;
            ?>    
			<li><a href='<?php echo url::site("smartsite/index/$userid/1/1/$TimePeriod/serviceWizard/$serviceWizardId")?>' >
			<?php
			echo $row->unitType;    			
			?>
			</a></li>
			<?php
			}
			}
            ?>    		

    </ul>
    <p>&nbsp;</p>
    
  </div>
  <div id="right" class="column">
  <div id="right_header">
    <h3>Question Breakdown</h3>
  </div>
  <div id="right_body"> 
  <?php
  if($set==="dialogue"){
	$digiProbarray=array();
	$prob=array();
	$keys=array_keys($digiProbability);
	$c=count($keys);
	$total=0;
	if($keys[0]!=0){
		if($digiResponsetype!=="text"){
			for($i=0;$i<$c;$i++){
						$total+=$digiProbability[$keys[$i]];
						
			}
			for($i=0;$i<$c;$i++){
						$ans="ans".($i+1);
						$prob[$ans]=round(($digiProbability[$keys[$i]]/$total)*100); 
			}	
		}
    }	
	
  ?>
  <p class="question"><?php echo htmlspecialchars($digiAnswerlist['ques']); ?></p>
  <?php 
  if($digiResponsetype!=="text"){
  ?>
  <p class="answerA">A.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans1']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
							 <?php if(array_key_exists("ans1",$prob)){
										echo $prob["ans1"].'%';
									}else{
										$prob["ans1"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <p class="answerB">B.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans2']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
                             <?php if(array_key_exists("ans2",$prob)){
										echo $prob["ans2"].'%';
									}else{
										$prob["ans2"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <?php if(htmlspecialchars($digiAnswerlist['ans3'])!=""){
  ?>
  <p class="answerC">C.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans3']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
                             <?php if(array_key_exists("ans3",$prob)){
										echo $prob["ans3"].'%';
									}else{
										$prob["ans3"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <?php 
        }else{
             $prob["ans3"]=0;
        }
  ?>
  <?php if(htmlspecialchars($digiAnswerlist['ans4'])!=""){
  ?>
  <p class="answerD">D.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans4']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
                             <?php if(array_key_exists("ans4",$prob)){
										echo $prob["ans4"].'%';
									}else{
										$prob["ans4"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <?php
  }else{
  $prob["ans4"]=0;
  }
  ?>
  <p>&nbsp;</p>
  <div class="img_center">
  <!--Checks , if Answer result is not available then , it wont display PIE CHART at right side tab -->
    <?php 
		if(($prob["ans1"]==0)AND($prob["ans2"]==0)AND($prob["ans3"]==0)AND($prob["ans4"]==0)){ 
	         echo "<h3>".MESSAGERESPONSE."</h3>"; 
     	}else{      
			$programmers1 = array(
			'A'=>$prob["ans1"],
			'B'=>$prob["ans2"],
			'C'=>$prob["ans3"],
			'D'=>$prob["ans4"]
			);
			$keys=array_keys($programmers1);
    
	?>	
	
	<?php
				echo '<IMG SRC="'.url::base(FALSE).'media/phPie/phPieDown.php?data='.urlencode(serialize($programmers1)).'">';
	?>
	
	<?php
		}
    }else{ 
		echo "<h3><font color='red'>"."This Question takes User Inputs in  TEXT Field, So each user has their own opinion "."</font></h3>"; 
	}
	
    ?>    
  
  
  </div>
  <?php
  }elseif($set==="serviceWizard"){
  ?>	  
      <p class="question"><?php echo $serviceCauseList['cause_text']; ?></p>
      <?php 
          if(!empty($serviceCauseList['cause_desc'])){
      ?>	  
      <p class="answerA"><font color="#FFFFFF">Solution Description:-&nbsp;</font>
      <?php 
              echo $serviceCauseList['cause_desc'];
          }
      ?>
      </p>
      <?php 
          if(!empty($serviceCauseList['task_video_desc'])){
      ?>	  
    
      <p class="answerB"><font color="#FFFFFF">Task Description:-&nbsp;</font>
      <?php 
              echo $serviceCauseList['task_video_desc'];
          }
      ?></p>
 <?php	  
  }else{
  $totalAnswerCount=$answerresult[1]+$answerresult[2]+$answerresult[3]+$answerresult[4];
  $correctAnswerId="ans".$ques_ans_list['correctanswer'];
  $correctAnswer=$ques_ans_list[$correctAnswerId];
  ?>
  <p class="question"><?php echo htmlspecialchars($ques_ans_list['ques']);?></p>
  <p class="answerA">   <?php 
                                if($correctAnswer==$ques_ans_list['ans1']){
								    echo "<font color='#80FF00'>*</font>"."A.&nbsp;".htmlspecialchars($ques_ans_list['ans1']);
                                }else{
								    echo "A.&nbsp;".htmlspecialchars($ques_ans_list['ans1']);
								}							
						?>&nbsp;&nbsp;&nbsp;&nbsp;
							    
						<?php   if($totalAnswerCount!=0){
									$percentage=round(($answerresult[1]/$totalAnswerCount)*100);
									echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
					    ?>
  
  </p>
  <p class="answerB">   <?php 
                                if($correctAnswer==$ques_ans_list['ans2']){
								    echo "<font color='#80FF00'>*</font>"."B.&nbsp;".htmlspecialchars($ques_ans_list['ans2']);
                                }else{
								    echo "B.&nbsp;".htmlspecialchars($ques_ans_list['ans2']);
							    }
							
						?>&nbsp;&nbsp;&nbsp;&nbsp;
							
							
						<?php   if($totalAnswerCount!=0){
									$percentage=round(($answerresult[2]/$totalAnswerCount)*100);
									echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
						?>
  </p>
  <p class="answerC">   <?php 
                                if($correctAnswer==$ques_ans_list['ans3']){
							        echo "<font color='#80FF00'>*</font>"."C.&nbsp;".htmlspecialchars($ques_ans_list['ans3']);
                                }else{
							        echo "C.&nbsp;".htmlspecialchars($ques_ans_list['ans3']);
							    }
						?>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php   if($totalAnswerCount!=0){
								    $percentage=round(($answerresult[3]/$totalAnswerCount)*100);
								    echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
						?>
  </p>
  <p class="answerD">   <?php 
                                if($correctAnswer==$ques_ans_list['ans4']){
								    echo "<font color='#80FF00'>*</font>"."D.&nbsp;".htmlspecialchars($ques_ans_list['ans4']);
                                }else{
								    echo "D.&nbsp;".htmlspecialchars($ques_ans_list['ans4']);
								}
						?>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php   if($totalAnswerCount!=0){
									$percentage=round(($answerresult[4]/$totalAnswerCount)*100);
									echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
						?>
  </p>
  <p>&nbsp;</p>
  <div class="img_center">
  <!-- Checks , if Answer result is not available then , it wont display PIE CHART at right side tab -->
    <?php if(is_array($answerresult)){ 
	
	 $programmers1 = array(
        'A'=>$answerresult[1],
        'B'=>$answerresult[2],
        'C'=>$answerresult[3],
		'D'=>$answerresult[4]
        );
	$keys=array_keys($programmers1);
	?>	
	<?php
		echo '<IMG SRC="'.url::base(FALSE).'media/phPie/phPieDown.php?data='.urlencode(serialize($programmers1)).'">';
	?>
	
	<?php
    }else{ echo "<h3>".MESSAGERESPONSE."</h3>"; }
	
    ?>    
  
  
  </div>
  <?php } ?>
  </div>
    
  </div>
  </div>
 </div>
<!-- End Content -->  

<!-- Footer -->
<div id="footer"></div>
<!-- End Footer -->  

</body>

</html>
