<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 26-oct-2010
Page Description:: Research Page
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Expand Smart Site | Research</title>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />


	<!--link before import prevents Flash Of Unstyled Content in ie6pc -->
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/typography.css" type="text/css"   />
	<!--@Author :: Anand , Javascript for dynamic display of Exam -->
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery.js"></script>
	
    <script type="text/javascript">
	//ADDED BY ANAND for Center panel display
	$(function() {
        
		$(".testButton").click(function() {
			var userid = "<?php echo $userid; ?>";
			var company = "<?php echo $company; ?>";
			var dialogue = $(this).val();
			var dataString ='company='+company+'&dialogue='+dialogue;
			$.ajax({
				type: "POST",
				url: "<?php echo url::base(FALSE) ?>smartsite/centerResearchPane/<?php echo $userid;?>/",
				data: dataString,
				success: function(data) {
					$('#center_import').html(data); 					
					$('#center_import').load();
				}
		});
		
		return false;
	});
	
	});
	</script>

	
	<script type="text/javascript">
	
	function Delayer(){
	setTimeout('Redirection()', 3000);
	}
	function Redirection(){
	document.location = '<?php echo url::base(FALSE) ?>smartsite/research/<?php echo $userid;?>/';
	}
	
	
	
	
	
	function getDivId(){
	
	if(document.getElementById('resultAnswer2')==null){
	 alert('Please Select Any Question , then click on save Button!!');
	}else{
	

	var quesIdArray = document.getElementsByName('Question'); //To get quesId 
	var IsArray = document.getElementsByName('Is');           // To get Is or Is not value
	var AnsArray = document.getElementsByName('Answer');      // To get Answer value
    var i = 0;
	var quesArray=new Array();
	var dataArray=new Array();
	var quesSelectionArray="";
	var isSelectionArray="";
	var answerArray="";
	
     for(i=0;i<quesIdArray.length;i++){
        if (quesIdArray[i].value != "none")
        {
            quesSelectionArray += quesIdArray[i].value+"|";
        }
     	
      }
      
     
     
     for(i=0;i<IsArray.length;i++){
     	isSelectionArray += IsArray[i].value+"|";
     }	
     
     
      for(i=0;i<AnsArray.length;i++){
     	answerArray += AnsArray[i].value+"|";
     }
     if(document.getElementById('inputSave')==null){
        
        var p=document.getElementById('center_import');
        var div=document.createElement('div');
        div.id="inputSave";
        div.style.align = 'center';
 
        p.insertBefore(div,p.getElementsByTagName('div')[0]);

     }
     var haschildren = document.getElementById("inputSave").hasChildNodes();
    if(haschildren==false){
	     var input = document.createElement('input');
	     input.type = 'text';
	     input.value = 'Enter name to Save Search';
	     input.name = 'searchName';
	     input.style.width = '390px';
	     input.style.margin = '5px 0px 5px 20px';
		 
	     
	     
	    document.getElementById("inputSave").appendChild(input);
	    
	    var inputSubmit = document.createElement('input');
	    inputSubmit.type='submit';
	    inputSubmit.value='submit';
		inputSubmit.onclick = function(){
	    var name=input.value;
	   if((name=="Enter name to Save Search")||(name=="")){
	        alert("Please Enter valid name for Search!!");
	    }else{
	         var userid = "<?php echo $userid; ?>";
		     var dataString='quesSelectionArray='+quesSelectionArray+'&isSelectionArray='+isSelectionArray+'&answerArray='+answerArray+'&name='+name;
		     $.ajax({
					type: "POST",
					url: "<?php echo url::base(FALSE) ?>smartsite/insertSaveSearch/<?php echo $userid;?>/",
					data: dataString,
					success: function(){
					    //Do anything after 1 second
	                    alert("Search is saved!");
						$('#inputSave').html("<h3>Search is saved!!!</h3>");
						Delayer();
					     				
					}
			});
		     
	      }
	    } 
	     document.getElementById("inputSave").appendChild(inputSubmit);
     }
    
   }	
		
}

</script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/questionPopulate.js"></script>
</head>
<body>
<div id="wrapper">
<!-- Header -->
  <div id="header">
    <div id="header_content">
      <div id="nav_logo">
	  </div>
      <div id="nav_btn">
			<div id="nav_wrap">
				<ul id="nav">	
				<li><a id="nav_summary" class="navLink" href="<?php echo url::site("smartsite/summaryAnalytics/$userid",'http');?>" title="Summary"><span>Summary</span></a></li>
				<li><a id="nav_users" class="navLink" href="<?php echo url::site("smartsite/userAnalytics/$userid",'http');?>" title="Users"><span>Users</span></a></li>
				<li><a id="nav_learning" class="navLink" href="<?php echo url::site("smartsite/index/$userid",'http');?>" title="Learning Analytics"><span>Learning Analytics</span></a></li>
				<li><a id="nav_research_selected" class="navLink" href="<?php echo url::site("smartsite/research/$userid",'http');?>" title="Research"><span>Research</span></a></li>

				</ul><div class="clear"></div>
			</div>
		</div>
		<div id="nav_user">
			<p class="user_title"><?php echo $role ?></p>
			<p class="user_name"><?php echo $username ?><a href="<?php echo url::site('user/logout','http');?>"> <img src="<?php echo url::base(FALSE) ?>media/img/logout_btn.png" alt="Logout" width="55" height="13" class="img_padleft"  /></a></p>       
		</div>
		<div class="clear">
		</div>
	</div>
  </div>
<!-- End Header -->  
<!-- Content -->
<div id="container">
    
  <div id="center_import" class="column">
       <?php if($display==="none" or $display==="delete"){
       ?>
	
	<?php 
	if($saveSearchList!=""){
	?>
	<div id="inputSave"><?php echo $saveSearchList; ?></div>
	<?php 
	}else{
	?>
	<div id="inputSave"></div>
	<?php
	}
	?>
	<?php
	if(count($list)==0){
	    echo "<h3>No Dialogue&Quiz Available.</h3>";
	}else{
	?>
	
    <!--<div class="research_bgAlt" id="centerResult">-->
    <div  class="research_bgAlt" id="centerResult">	
		<div class="research_body">
			<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight">
				<input type="hidden" name="examName" id="examName" value="<?php echo $company.'Dialogue'; ?>" />
                <select class="formFull" name="Training" id="training">
        		<option value="none"> <?php echo $company.'Dialogue'; ?> </option>
				
				<?php 
				    
					$count=count($list);
                    			for($i=0;$i<$count;$i++){
					    $Id=$list[$i]['id'];
					    $Name=$list[$i]['name'];
					    $List=$list[$i]['list'];
					    echo "<option value='$Id:$List'>$Name</option>";
					}						
				?>
        		
      			</select>
        		</td>
    			<td width="80" class="formButtons">
      			</td>
 				</tr>
			</table>
        </div>
	
	<?php
        }
    ?> 		
	</div>
    
	 
    <div class="research_bg" id="resultValue">
    	
    	<div class="research_body">
			<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight">
                <select class="formFull" name="Question" id="question">
        		<option value="none">Select Question</option>
        		<option value="option">Option</option>
      			</select></td>
    			<td width="80" class="formButtons">
				   <!-- <img src="/media/img/plus_btn.png" width="24" height="24" alt="add" />--> 
				  <!--  <img src="/media/img/minus_btn.png" width="24" height="24" alt="remove" />-->
      			</td>
 				</tr>
			</table>
        </div>
	</div>
		
        
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<p>&nbsp;</p>
<p>&nbsp;</p>
<?php }
else{
?>
<div class="research_bgAlt" id="centerResult">
    	<div class="research_body">
			<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight">
				<input type="hidden" name="examName" id="examName" value="<?php echo $company.'Dialogue'; ?>" />
                <select class="formFull" name="Training" id="training">
        		<option value="none"> <?php echo $nameSelected; ?> </option>
        		</select>
                </td>
                <td width="80" class="formButtons">
                  </td>
                 </tr>
            </table>
        </div>
 </div>   

 <div class="research_bg" id="resultValue">
<?php 
      $count=count($savesearchList);
      for($i=0;$i<$count;$i++){
?>       
    <div class="research_body">
			<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight">
                <select class="formFull" name="Question" id="training">
        		<option value="<?php echo $savesearchList[$i]['types'].':'.$savesearchList[$i]['setId'].':'.$savesearchList[$i]['question_id']; ?>"><?php echo $savesearchList[$i]['question_name']; ?> </option>
        		
      			</select><br  />
            
            	<select class="formIs" name="Is" id="is">
        		<option value="<?php echo $savesearchList[$i]['options'];?>"><?php echo $savesearchList[$i]['options'];?></option>
        		
      			</select><br  />
            
            	Select Answer <select class="formMid" name="Answer" id="answer">
        		<option value="<?php echo $savesearchList[$i]['answer'];?>"><?php echo $savesearchList[$i]['answer'];?></option>
        		
      			</select></td>
    			<td width="80" class="formButtons">
    			    <!-- <img src="/media/img/minus_btn.png" width="24" height="24" alt="remove" /> -->
      			</td>
 				</tr>
			</table>
    </div>
 <?php }
 ?>
 
 </div>


<?php 
}
?>
  </div>
<div id="left" class="column">
    <h2>Research</h2>
    <a href="<?php echo url::site("smartsite/research/$userid",'http');?>" title="New Search">
	<img src="<?php echo url::base(FALSE) ?>media/img/newSearch_btn.png" width="87" height="29" alt="New Search" /></a> 
	<a href="#" onclick="getDivId();" title="Save Search"><img src="<?php echo url::base(FALSE) ?>media/img/saveSearch_btn.png" width="87" height="29" alt="Save Search" /></a>
    <p>&nbsp;</p>
    <?php 
       if(!empty($deleteSaveSearch)){
       	   echo "<h3>".$deleteSaveSearch."</h3>";
       }
    
    ?>
    <ul>
    	<li>
		<?php $value=$company.'Dialogue';?>
		<a href="<?php echo url::site("smartsite/research/$userid/none/none",'http');?>" class="research " onclick="this.value='<?php echo $value;?>';this.className='selected'"><?php echo $company;?> Dialogue</a>
        	    
			
        <ul>
        <table>
        <?php 
             if(is_array($dialogueSearchlist)){
                 $countDialogue=count($dialogueSearchlist);
                 for($i=0;$i<$countDialogue;$i++){
        ?>
        <?php $sess_id=$dialogueSearchlist[$i]['sess_id'];?>	
        <li><tr><td>
            <a href='<?php echo url::site("smartsite/research/$userid/view/$sess_id",'http');?>' title="View Search"><?php echo $dialogueSearchlist[$i]['name'];?></a>
            </td><td><div class="rightRemove">
            <a  href='<?php echo url::site("smartsite/research/$userid/delete/$sess_id",'http');?>' title="Delete Search" onclick="return confirm('Are you sure you want to delete?')">
            <img src="<?php echo url::base(FALSE) ?>media/img/x_btn.png" width="10" height="10"  alt="remove" />
            </a></div>
            </td></tr>
            
        </li>
        <?php 
        	}
            }else{
                 echo "";
            }	
        ?>
        </table>
        </ul>
        </li>
    	<li>
		<?php $value=$company.'Exam';?>
		<a href="<?php echo url::site("smartsite/research/$userid/none/none",'http');?>" class="research " onclick="this.value='<?php echo $value;?>';this.className='selected'">
		<?php echo $company;?> Exam
		</a>
			
			
	<ul>
	<table>
	<?php 
	      if(is_array($examSearchlist)){
                 $countExam=count($examSearchlist);
                 for($i=0;$i<$countExam;$i++){
	        
	?>	
	<?php $sess_id=$examSearchlist[$i]['sess_id'];?> 	
        <li><tr><td>
        <a href='<?php echo url::site("smartsite/research/$userid/view/$sess_id",'http');?>' title="View Search"><?php echo $examSearchlist[$i]['name'];?></a>
            
           
            </td><td><div class="rightRemove">
            <a href='<?php echo url::site("smartsite/research/$userid/delete/$sess_id",'http');?>' title="Delete Search" onclick="return confirm('Are you sure you want to delete?')">            
            <img src="<?php echo url::base(FALSE) ?>media/img/x_btn.png" width="10" height="10" alt="remove" />
            </a>
            </div></td></tr>
 
            
            
       
        <?php
             }
            }else{
                 echo "";
            }	
        ?>
        </table>
        </li>
        </ul> 
        </li>
    </ul>
    <p>&nbsp;</p>
    
  </div>
  <!-- deleted right div -->
  <!-- Added right panel --->
   <div id="right" class="column">
    <div class="research_rightAlt">
    <table width="100%" height="60px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%" class="formButtons"><strong><h3>Total</h3></strong></td>
    <td width="50%" class="formButtons"><strong><h3>Percentage</h3></strong></td>
  </tr>
</table>
</div>
   <?php
        if(isset($savesearchList)){ 
		    $count=count($percentageList);
			for($i=0;$i<$count;$i++){
		
    ?>
	    <table width="100%" height="100px" border="0" cellspacing="0" cellpadding="0">
    <tr>
    <td width="50%" class="formButtons"><h3><?php echo $percentageList[$i]['response'];?> 
	   <span class="gray">/<?php echo $percentageList[$i]['total'];?></span></h3></td>
    <td width="50%" class="formButtons"><h3><?php echo $percentageList[$i]['percentage']."%";?></h3></td>
    </tr>
    </table>
	<?php
	        }
	?>
    <?php
    $programmersNew=array(
			'Response'=>$percentageList[$count-1]['percentage'],
			'No Response' => (100-$percentageList[$count-1]['percentage'])
			
			);
	?>
    <!--<div class="research_rightGray">-->
    <div class="research_rightGray" name="chart">
    <?php
		echo '<IMG SRC="'.url::base(FALSE).'smartsite/phPie/phPieDownResearch.php?data='.urlencode(serialize($programmersNew)).'" alt="chart">';
	?>
      <p>&nbsp;</p>
	<img src="<?php echo url::base(FALSE) ?>media/img/view_users.png" width="156" height="29" 
	     onclick='viewusers()'/>
	
    </div>

	
	<?php	
		}
	?>
   <!-- <div class="research_rightGray">
      <img src="/expand/media/img/researchChart.png" width="150" height="150" alt="chart" />
      <p>&nbsp;</p>
      <img src="/expand/media/img/view_users.png" width="156" height="29"  />
	  </div>-->
  </div>
  </div>

</div>

 
 <!-- End for right panel-->
  

</div>
<!-- End Content -->  

<!-- Footer -->
<div id="footer"></div>
<!-- End Footer -->
<script lanugage="javascript">
function viewusers()
{
	var quesIdArray = document.getElementsByName('Question'); //To get quesId 
	var IsArray = document.getElementsByName('Is');           // To get Is or Is not value
	var AnsArray = document.getElementsByName('Answer');      // To get Answer value
	var quesSelectionArray="";
	var isSelectionArray="";
	var answerArray="";
	for(i=0;i<quesIdArray.length;i++){
		if (quesIdArray[i].value != "none")
		{
			quesSelectionArray += quesIdArray[i].value+"|";
		}
	 }
	for(i=0;i<IsArray.length;i++){
	   isSelectionArray += IsArray[i].value+"|";
	}	
	for(i=0;i<AnsArray.length;i++){
	  answerArray += AnsArray[i].value+"|";
	 }  
	 var dataString='quesSelectionArray='+quesSelectionArray+'&isSelectionArray='+isSelectionArray+'&answerArray='+answerArray;
	 location.href= "<?php echo url::base() ?>smartsite/userAnalytics/<?php echo $userid; ?>/?question="+dataString; 
}
</script>  
</body>
</html>