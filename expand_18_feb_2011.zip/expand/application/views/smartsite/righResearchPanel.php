
 <table width="100%" height="100px" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="50%" class="formButtons"><h3><?php echo $percentageList['response'];?> 
	   <span class="gray">/<?php echo $percentageList['total'];?></span></h3></td>
    <td width="50%" class="formButtons"><h3><?php echo $percentageList['percentage']."%";?></h3></td>
  </tr>
</table>
<?php
    $programmersNew=array(
			'Response'=>$percentageList['percentage'],
			'No Response' => (100-$percentageList['percentage'])
			
			);
		
?>
<!--<div class="research_rightGray">-->
<div class="research_rightGray" name="chart">
    <?php
		echo '<IMG SRC="'.url::base(FALSE).'media/phPie/phPieDownResearch.php?data='.urlencode(serialize($programmersNew)).'" alt="chart">';
	?>
      <p>&nbsp;</p>
	<!-- document.location = "/expand/smartsite/userAnalytics/"+<?php //echo $userid;?>+"/";  -->  
    <img src="<?php echo url::base(FALSE) ?>media/img/view_users.png" width="156" height="29" 
	     onclick='viewusers()'/>
	
</div>
