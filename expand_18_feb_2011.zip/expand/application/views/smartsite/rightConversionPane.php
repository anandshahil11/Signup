    
			    <?php 
				    if(!is_array($userContact)){
					    echo $userContact;       
					}else{
						
						
						if($contactDelete!==''){
						    echo $contactDelete;
						}	
						if(is_array($userContactData)){ 
						
							
				?>
				
				<?php $id=$userContactData['sess_id']; ?>
				<div class="name"><?php echo $userContactData['fullname']; ?></div>
				<div id="resultRight"></div>
				<div id="contact_form">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a href='<?php echo url::site("smartsite/conversion/$userid/$action/$TimePeriod/$id/delete") ?>'>
					<img src="<?php echo url::base(FALSE) ?>media/img/remove.png">
				</a>
				
				<form id="stats" name="stats" method="post" action=''>
				<label>Email</label><input name="email" id="email" type="text" value="<?php echo $userContactData['email']; ?>" />
				<label>Phone Number</label><input name="phonenum" id="phonenum" type="text" value="<?php echo $userContactData['phonenum']; ?>" />
				<input name='sess_id' type="hidden" value="<?php echo $id;?>">
                <input type="hidden" name='fullname' id="fullname" value="<?php echo $userContactData['fullname']; ?>">
				<input type="hidden" name='product' id="product" value="<?php echo $userContactData['product']; ?>">
				
				<?php
				$_SESSION['quesAnswer']=$QuesAnswerList;
				$index=array_keys($QuesAnswerList);
				$count=count($QuesAnswerList);
				?>
				<div class="exam">
				<?php   
						if($count==0){
				                	echo "<h3>No Q&A has been given.</h3>";
				        }else{
						
							$j=1;
							$i=$index[0];
							if($i==0){
								$count=$count;
							}else{
								$count=$count+1;
							}
							for($i;$i<$count;$i++){
				?>
								<p>Q<?php echo $j?>: <?php echo $QuesAnswerList[$i]['question']; ?><br />
								<span class="white">A<?php echo $j?>: <?php echo $QuesAnswerList[$i]['answer'];?></span></p>

				<?php
								
								$j++;
							}
						}	
				?>
				
				<p>&nbsp;</p>
				       
						<input name="examId" id="examId" type="hidden" value="<?php echo $examid; ?>">
						
				</form>
				</div>
				
				<?php
						}else { echo $userContactData;}  
				?>		
						
				</div>
				<?php

                        							
					}		
				?>
				
