<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 02-Sep-2010
Page Description:: Analytics Right panel View Page
*********************************************/  
  if($set==="dialogue"){
	$digiProbarray=array();
	$prob=array();
	$keys=array_keys($digiProbability);
	$c=count($keys);
	$total=0;
	if($keys[0]!=0){
	    if($digiResponsetype!=="text"){
			for($i=0;$i<$c;$i++){
						$total+=$digiProbability[$keys[$i]];
			}
			for($i=0;$i<$c;$i++){
						$ans="ans".$keys[$i];
						$prob[$ans]=round(($digiProbability[$keys[$i]]/$total)*100); 
			}	
		}
    }	
	?>
  <p class="question"><?php echo htmlspecialchars($digiAnswerlist['ques']); ?></p>
  <?php 
  if($digiResponsetype!=="text"){
  ?>
  <p class="answerA">A.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans1']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
							 <?php if(array_key_exists("ans1",$prob)){
										echo $prob["ans1"].'%';
									}else{
										$prob["ans1"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <p class="answerB">B.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans2']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
                             <?php if(array_key_exists("ans2",$prob)){
										echo $prob["ans2"].'%';
									}else{
										$prob["ans2"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <?php if(htmlspecialchars($digiAnswerlist['ans3'])!=""){
  ?>
  <p class="answerC">C.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans3']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
                             <?php if(array_key_exists("ans3",$prob)){
										echo $prob["ans3"].'%';
									}else{
										$prob["ans3"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <?php 
  }else{
  $prob["ans3"]=0;
  }
  ?>
  <?php if(htmlspecialchars($digiAnswerlist['ans4'])!=""){
  ?>
  <p class="answerD">D.&nbsp;<?php echo htmlspecialchars($digiAnswerlist['ans4']); ?>&nbsp;&nbsp;&nbsp;&nbsp;
                             <?php if(array_key_exists("ans4",$prob)){
										echo $prob["ans4"].'%';
									}else{
										$prob["ans4"]=0;
										echo '0'.'%';
									}
							?>
  </p>
  <?php
  }else{
  $prob["ans4"]=0;
  }
  ?>
  <p>&nbsp;</p>
  <div class="img_center">
  <!--Checks , if Answer result is not available then , it wont display PIE CHART at right side tab -->
    <?php 
		if(($prob["ans1"]==0)AND($prob["ans2"]==0)AND($prob["ans3"]==0)AND($prob["ans4"]==0)){ 
	         echo "<h3>".MESSAGERESPONSE."</h3>"; 
     	}else{      
			$programmers1 = array(
			'A'=>$prob["ans1"],
			'B'=>$prob["ans2"],
			'C'=>$prob["ans3"],
			'D'=>$prob["ans4"]
			);
			$keys=array_keys($programmers1);
    
	?>	
	
	<?php
				echo '<IMG SRC="'.url::base(FALSE).'media/phPie/phPieDown.php?data='.urlencode(serialize($programmers1)).'">';
	?>
	
	<?php
		}
    }else{ 
		echo "<h3>"."This Question takes User Inputs in  TEXT Field, So each user has their own opinion "."</h3>"; 
	}
	
    ?>    
  
  
  </div>
  <?php
  }else{
  $totalAnswerCount=$answerresult[1]+$answerresult[2]+$answerresult[3]+$answerresult[4];
  $correctAnswerId="ans".$ques_ans_list['correctanswer'];
  $correctAnswer=$ques_ans_list[$correctAnswerId];
  ?>
  <p class="question"><?php echo htmlspecialchars($ques_ans_list['ques']);?></p>
  <p class="answerA">   <?php 
                                if($correctAnswer==$ques_ans_list['ans1']){
								    echo "<font color='#80FF00'>*</font>"."A.&nbsp;".htmlspecialchars($ques_ans_list['ans1']);
                                }else{
								    echo "A.&nbsp;".htmlspecialchars($ques_ans_list['ans1']);
								}							
						?>&nbsp;&nbsp;&nbsp;&nbsp;
							    
						<?php   if($totalAnswerCount!=0){
									$percentage=round(($answerresult[1]/$totalAnswerCount)*100);
									echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
					    ?>
  
  </p>
  <p class="answerB">   <?php 
                                if($correctAnswer==$ques_ans_list['ans2']){
								    echo "<font color='#80FF00'>*</font>"."B.&nbsp;".htmlspecialchars($ques_ans_list['ans2']);
                                }else{
								    echo "B.&nbsp;".htmlspecialchars($ques_ans_list['ans2']);
							    }
							
						?>&nbsp;&nbsp;&nbsp;&nbsp;
							
							
						<?php   if($totalAnswerCount!=0){
									$percentage=round(($answerresult[2]/$totalAnswerCount)*100);
									echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
						?>
  </p>
  <p class="answerC">   <?php 
                                if($correctAnswer==$ques_ans_list['ans3']){
							        echo "<font color='#80FF00'>*</font>"."C.&nbsp;".htmlspecialchars($ques_ans_list['ans3']);
                                }else{
							        echo "C.&nbsp;".htmlspecialchars($ques_ans_list['ans3']);
							    }
						?>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php   if($totalAnswerCount!=0){
								    $percentage=round(($answerresult[3]/$totalAnswerCount)*100);
								    echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
						?>
  </p>
  <p class="answerD">   <?php 
                                if($correctAnswer==$ques_ans_list['ans4']){
								    echo "<font color='#80FF00'>*</font>"."D.&nbsp;".htmlspecialchars($ques_ans_list['ans4']);
                                }else{
								    echo "D.&nbsp;".htmlspecialchars($ques_ans_list['ans4']);
								}
						?>&nbsp;&nbsp;&nbsp;&nbsp;
						<?php   if($totalAnswerCount!=0){
									$percentage=round(($answerresult[4]/$totalAnswerCount)*100);
									echo $percentage.'%';
								}else{
								    $percentage=0;
									echo $percentage.'%';
										
								}
						?>
  </p>
  <p>&nbsp;</p>
  <div class="img_center">
  <!-- Checks , if Answer result is not available then , it wont display PIE CHART at right side tab -->
    <?php if(is_array($answerresult)){ 
	
	 $programmers1 = array(
        'A'=>$answerresult[1],
        'B'=>$answerresult[2],
        'C'=>$answerresult[3],
		'D'=>$answerresult[4]
        );
	$keys=array_keys($programmers1);
    
	?>	
	<?php
				echo '<IMG SRC="'.url::base(FALSE).'media/phPie/phPieDown.php?data='.urlencode(serialize($programmers1)).'">';
	?>
	
	<?php
    }else{ echo "<h3>".MESSAGERESPONSE."</h3>"; }
	
    ?>    
  
  
  </div>
  <?php } ?>


