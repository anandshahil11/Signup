  <?php
  /********************************************
  AUTHOR:: ANAND 
  Version:: 1.0
  Date:: 22-Dec-2010
  Page Description:: Service Wizard right panel
  *********************************************/
  ?>
  
  <p class="question"><?php echo $serviceCauseList['cause_text']; ?></p>
  <?php 
      if(!empty($serviceCauseList['cause_desc'])){
  ?>	  
  <p class="answerA"><font color="#FFFFFF">Solution Description:-&nbsp;</font>
  <?php 
          echo $serviceCauseList['cause_desc'];
      }
  ?>
  </p>
  <?php 
      if(!empty($serviceCauseList['task_video_desc'])){
  ?>	  

  <p class="answerB"><font color="#FFFFFF">Task Description:-&nbsp;</font>
  <?php 
          echo $serviceCauseList['task_video_desc'];
	  }
  ?></p>