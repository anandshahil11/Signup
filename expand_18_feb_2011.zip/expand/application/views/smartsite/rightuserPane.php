<script language="javascript">
    function openPopup(url){
	    window.open(url,'welcome','width=500,height=400,menubar=no,status=no,location=no,toolbar=no,scrollbars=no,top=100');

    }
</script>
<style type="text/css">
    #lastlogin_header {
	height: 18px;
	width: 100%;
	background: #666;
	color: #fff;
	border-bottom: #000 solid 0.5px;
	padding: 15px 0 10px 10px;
	
	
    }
</style>
<?php 
	if(is_array($userData)){ 
		$empid=$userData['id'];
?>	

<?php if($userUpdate!==""){ echo $userUpdate;} ?> 			
<div class="name"><?php echo $userData['first']." ".$userData['last']; ?><br>
<a href="javascript:openPopup('<?php echo url::site("userEdit/edit/$empid",'http');?>')">
<img src="<?php echo url::base(FALSE) ?>media/img/edit.jpg" alt="edit">
</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href='<?php echo url::site("smartsite/userAnalytics/$userid/$empid/delete") ?>'>
<img src="<?php echo url::base(FALSE) ?>media/img/remove.png">
</a>
</div>

<div class="exam">
<div id="lastlogin_header">
<p><strong>Total Logins&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="white" ><?php echo $userLoginNum;?></span></strong></p>
</div>
<div id="lastlogin_header">
<p><strong>Last Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="white" ><?php 
													if($userLastlogin==''){
														echo '-';
													}else{
														echo date("m/d/Y",$userLastlogin);
													}		
											?> 
                                            </span></strong></p>
</div>											
<img src="<?php echo url::base(FALSE) ?>media/img/moduleSummary.png" alt='Module Summary'>
<?php
	$count = count($userExamResult);
    for($i=0;$i<$count;$i++){			
        if($userExamResult[$i]['exam_id']!=''){
?>	
<p><strong><span class="white" ><?php echo $userExamResult[$i]['examname']; ?><br/></span></strong></p>
<p>
<?php 
if(strtolower($userExamResult[$i]['result'])==='certified'){
?>
<img src="<?php echo url::base(FALSE) ?>media/img/pass.png" alt="certified">
<?php
}elseif(strtolower($userExamResult[$i]['result'])==='failed'){
?>
<img src="<?php echo url::base(FALSE) ?>media/img/fail.png" alt="failed">
<?php
}else{
?>
<img src="<?php echo url::base(FALSE) ?>media/img/incomplete.png" alt="incomplete">
<?php
}
?>
<span class="white" style="font-size:10pt;"><?php echo $userExamResult[$i]['result']; ?></span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span class="white" style="font-size:10pt;"><?php echo date("m/d/Y",strtotime($userExamResult[$i]['date'])); ?></span>
</p>
			
<?php                                        												
       }
    }	
?>
</div>
<?php	
	
	}else{ 
		echo $userData;
	}

?>
