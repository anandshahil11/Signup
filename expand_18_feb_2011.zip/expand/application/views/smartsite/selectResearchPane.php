<script type="text/javascript">
$(document).ready(function() {

        
		$("#question").change(function() {
			
			var str = $('#question').val();
			var list=new Array();
			list=str.split(":");
			var type=list[0];
			var setId=list[1];
			var quesId=list[2];
			var dataString='type='+type+'&setId='+setId+'&quesId='+quesId;
			
			$.ajax({
			    type:"POST", 
			    url:"<?php echo url::base(FALSE) ?>smartsite/displayAnswerResearchPane",
                	data:dataString,
                	success:function(data){
				    	$('#resultAnswer2').html(data);
                        $('#resultAnswer2').load();

				}  				
			});
	     });
});		 
</script>


    	<div class="research_body" id="resultAnswer2">
			<table width="540" border="0" cellspacing="0" cellpadding="0">
  				<tr>
   				<td width="460" class="formRight" id="QuesList">
                <select class="formFull" name="Question" id="question">
        		<option value="none">Select Question</option>
        		<?php 
				$count=count($questionList);
				for($i=0;$i<$count;$i++){
				$quesId=$questionList[$i]['questionId'];
				$quesName=$questionList[$i]['questionName'];
				$quesSetId=$questionList[$i]['questionSetId'];
				$quesType=$questionList[$i]['list'];
				echo "<option value='$quesType:$quesSetId:$quesId' >$quesName</option>";
				}
				

				?>
      			</select></td>
    			<td width="80" class="formButtons">
				    <!--<img src="/expand/media/img/plus_btn.png" width="24" height="24" alt="add" />--> 
				    <!--<img src="/expand/media/img/minus_btn.png" width="24" height="24" alt="remove" />-->
      			</td>
 				</tr>
			</table>
        </div>