<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 03-Sep-2010
Page Description:: Site Analytics Page
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Expand Smart Site | Site Analytics</title>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />


	<!--link before import prevents Flash Of Unstyled Content in ie6pc -->

	<link rel="stylesheet" href="/expand/media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="/expand/media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="/expand/media/css/typography.css" type="text/css"   />
	<!--@Author :: Anand , Javascript for dynamic display of Exam -->

</head>


<body >
<div id="wrapper">
<!-- Header -->
  <div id="header">
    <div id="header_content">
      <div id="nav_logo">
	  </div>
      <div id="nav_btn">
			<div id="nav_wrap">
				<ul id="nav">	
				<li><a id="nav_summary" class="navLink" href="<?php echo url::site("smartsite/summaryAnalytics/$userid",'http');?>" title="Summary"><span>Summary</span></a></li>
				<li><a id="nav_users" class="navLink" href="<?php echo url::site("smartsite/userAnalytics/$userid",'http');?>" title="Users"><span>Users</span></a></li>
				<li><a id="nav_learning" class="navLink" href="<?php echo url::site("smartsite/index/$userid",'http');?>" title="Learning Analytics"><span>Learning Analytics</span></a></li>
				<li><a id="nav_site_selected" class="navLink" href="<?php echo url::site("smartsite/siteAnalytics/$userid",'http');?>" title="Site Analytics"><span>Site Analytics</span></a></li>
				</ul><div class="clear"></div>
			</div>
		</div>
		<div id="nav_user">
			<p class="user_title"><?php echo $role ?></p>
			<p class="user_name"><?php echo $username ?><a href="<?php echo url::site('user/logout','http');?>"> <img src="/expand/smartsite/img/logout_btn.png" alt="Logout" width="55" height="13" class="img_padleft"  /></a></p>       
		</div>
		<div class="clear">
		</div>
	</div>
  </div>
<!-- End Header -->  

<!-- Content -->
	<div id="container">
       <div id="center_learn" class="column">
	   <table width="100%" border="0" cellpadding="0" cellspacing="0" class="blue_zebra">
		  <tr>
			<th scope="col">Elements</th>
			<th class="center" scope="col">Clicks </th>
			<th class="center" scope="col">Rank</th>
			
		  </tr>
		<?php 
			  if(is_array($quesCountList)){
				    arsort($quesCountList,SORT_NUMERIC);
				    $examSort=array();
				    foreach ($quesCountList as $key => $val) {
					    $examSort[$key]=$val;
				    }

				    $examName=array_keys($examSort);
				    $examClick=array_values($examSort);
				    
		?>
	    <?php 
     
					for($i=0;$i<count($quesCountList);$i++){
						if((($i+1)%2)==0){
	  
		?>
		  <tr class="odd">
			<td width="60%"><?php echo $examName[$i]; ?>  </td>
			<td width="11%" class="center"><?php echo $examClick[$i]; ?></td>
			<td width="14%" class="center"><?php echo $i+1; ?></td>
		
		  </tr>
		<?php  
					}else{
		?>  
		  
		  <tr class="even">
			<td><?php echo $examName[$i]; ?></td>
			<td class="center"><?php echo $examClick[$i]; ?></td>
			<td class="center"><?php echo $i+1; ?></td>
			
		  </tr>
		<?php 
					}
				}
			}else{
		?>
          <tr class="odd">
			<td width="60%"><font color='red'><b>No Exam Given During This Time Period</b></font>  </td>
			<td width="11%" class="center"><font color='red'><b>NA</b></font></td>
			<td width="14%" class="center"><font color='red'><b>NA</b></font></td>
		
		  </tr>
		<?php
			
			}	
		?>	
		</table>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>

		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="gray_zebra">
		  <tr>
			  <th scope="col">Site Feedback</th>
		  </tr>
		  <tr class="odd">
			  <td width="100%"> 2010/08/12 NO Database provided for this </td>
		  </tr>
		  <tr class="even">
		    <td class="center">2010/08/02 It will be done in Future </td>
		  </tr>
		  <tr class="odd">
			  <td width="100%"> 2010/08/01 This page is created now </td>
		  </tr>
		  <tr class="even">
		    <td class="center">2010/07/31 I really love this  </td>
		  </tr>
		</table>  
		  
		
		
		
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>


	
		  
	   </div>
	   
	   <div id="left" class="column">
	   <h2>Site Analytics</h2>

	   <form id="form1" name="form1" method="post" action='<?php echo url::site("smartsite/siteAnalytics/$userid");?>'>
		  <select style="width:180px;" name="TimePeriod" id="period" onChange="this.form.submit();">
			<option value="none" >Time Period</option>
			<option value="week" <?php  if(isset($TimePeriod1)){if ($TimePeriod1 == 'week'):?> selected<?php endif;}?>>Past week</option>
			<option value="month"<?php  if(isset($TimePeriod1)){if ($TimePeriod1 == 'month'):?> selected<?php endif;}?>>Past Month</option>
			<option value="ytd" <?php  if(isset($TimePeriod1)){if ($TimePeriod1 == 'ytd'):?> selected<?php endif;}?>>YTD</option>
		  </select>
		</form>
    <p>&nbsp;</p>
	   
	   </div>
	   <div id="right" class="column">
	   </div>
	   
	   
	 </div>
 </div>
<!-- End Content -->  

<!-- Footer -->
<div id="footer"></div>
<!-- End Footer -->  

</body>

</html>