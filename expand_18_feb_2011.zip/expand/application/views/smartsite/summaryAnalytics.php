<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 06-Sep-2010
Page Description:: Summary Analytics Page
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Expand Smart Site | Summary Analytics</title>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />
    <!--link before import prevents Flash Of Unstyled Content in ie6pc -->
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/typography.css" type="text/css"   />
	<!--@Author :: Anand , Javascript for dynamic display of Exam -->
</head>



<body>
<div id="wrapper">
<!-- Header -->
  <div id="header">
    <div id="header_content">
      <div id="nav_logo">
	  </div>
      <div id="nav_btn">
			<div id="nav_wrap">
				<ul id="nav">	
				<li><a id="nav_summary_selected" class="navLink" href="<?php echo url::site("smartsite/summaryAnalytics/$userid",'http');?>" title="Summary"><span>Summary</span></a></li>
				<li><a id="nav_users" class="navLink" href="<?php echo url::site("smartsite/userAnalytics/$userid",'http');?>" title="Users"><span>Users</span></a></li>
				<li><a id="nav_learning" class="navLink" href="<?php echo url::site("smartsite/index/$userid",'http');?>" title="Learning Analytics"><span>Learning Analytics</span></a></li>
				<li><a id="nav_research" class="navLink" href="<?php echo url::site("smartsite/research/$userid",'http');?>" title="Research"><span>Research</span></a></li>

				</ul><div class="clear"></div>
			</div>
		</div>
		<div id="nav_user">
			<p class="user_title"><?php echo $role ?></p>
			<p class="user_name"><?php echo $username ?><a href="<?php echo url::site('user/logout','http');?>"> <img src="<?php echo url::base(FALSE) ?>media/img/logout_btn.png" alt="Logout" width="55" height="13" class="img_padleft"  /></a></p>       
		</div>
		<div class="clear">
		</div>
	</div>
  </div>
<!-- End Header -->  
<!-- Content -->
	<div id="container">
	    <div id="center_learn" class="column">
	    <table width="100%" border="0" cellpadding="0" cellspacing="0" class="blue_zebra">
			
		
		<?php
		    $activeUser=count($userList);
			$inactiveUser=($userCount-$activeUser);
			
		?>
		  <tr>
				<th scope="col" colspan="2">
				<a href="<?php echo url::site("smartsite/summaryAnalytics/$userid/User/",'http');?>" >
				<font color="#FFFFFF">Users</font></a>
				</th>
		  </tr>
		<?php
        if($set==='dialogue'){
        ?>
        <tr class="odd">
			<td width="55%">Total Leads</td>
			<td width="45%" class="center"><?php echo $leads; ?></td>
		</tr>
		<?php 		
		}else{			
	    ?>
		<tr class="odd">
			<td width="55%">Total Registered Users</td>
			<td width="45%" class="center"><?php echo $userCount; ?></td>
		</tr>
		<tr class="even">
			<td >Total active users this period</td>
			<td class="center"><?php 
									echo $activeUser;
                                   	$percentage=round(($activeUser/$userCount)*100);
                                    echo "($percentage"."%)";									
			                   ?>
			</td>
		</tr>
		<tr class="odd">
			<td width="55%">Total inactive users this period </td>
			<td width="45%" class="center"><?php
                                        	echo $inactiveUser; 
											$percentage=round(($inactiveUser/$userCount)*100);
											echo "($percentage"."%)";
											?></td>
		</tr>
	    <?php
		}
		?>
		</table>
		
		<?php
		    // To display Exam List in Main Body 
			$quizArray=array();
			if(isset($quizScore) AND isset($examName))
			{
				
				$count=count($examName)+1;
				$finalArray=array_combine($examName,$quizScore);
					foreach($finalArray as $key => $value)
					{
						$list=explode(":",$value);
		
		?>
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="blue_zebra">
			<tr>
				<th scope="col" colspan="2">
				<a href="<?php $name=str_replace('/','__',$key);echo url::site("smartsite/summaryAnalytics/$userid/$name/$list[1]/$list[1]/$list[2]",'http');?>" >
				<font color="#FFFFFF"><?php echo $key; ?></font></a>
				</th>
			</tr>
		
		

		    <tr class="odd">
			    <td width="55%">Average score</td>
			    <td width="45%" class="center"><?php echo "$list[0]".""."%"; ?></td>
		    </tr>
		    <tr class="even">
			    <td >Number of starts</td>
			    <td class="center"><?php echo "$list[1]";?></td>
		    </tr>
		    <tr class="odd">
			    <td width="55%">Number of completions</td>
			    <td width="45%" class="center"><?php echo "$list[2]";?></td>
		    </tr>
        </table>
			
		<?php			
			        }
		
			}else{//
			}
        ?>
		
		
		
		<?php 
		    /* To display Digital Demo List in Main Body*/				
			$digitalArray=array();
			if(isset($digitalScore) AND isset($digitalName))
			{
				$count=count($digitalName)+1;
				$finalArray=array_combine($digitalName,$digitalScore);
					foreach($finalArray as $key => $value)
					{
						$list=explode(":",$value);
						$noOfstart = $list[0];
						
		?>
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="blue_zebra">
			<tr>
				<th scope="col" colspan="2">
				
				<a href="<?php $name=str_replace('/','__',$key);echo url::site("smartsite/summaryAnalytics/$userid/$name/$list[0]/$list[0]/$list[1]",'http');?>" >
				<font color="#FFFFFF"><?php echo $key; ?></font>
				</a>
				</th>
			</tr>

		    <tr class="odd">
			    <td width="55%">Number of starts</td>
			    <td width="45%" class="center"><?php echo "$list[0]"; ?></td>
		    </tr>
		    <tr class="even">
			    <td >Number of completions</td>
			    <td class="center"><?php echo "$list[1]";?>
			    </td>
		    </tr>
        </table>
			
		<?php			
			        }
		
			}else{ // 
			}
        ?>
		<?php
		if(is_array($examSearchlist) || is_array($dialogueSearchlist) )
		{
		?>
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="blue_zebra">
			<tr>
				<th scope="col" colspan="2">
					Research
				</th>
			</tr>
		<?php 
		$i=1;
		if(is_array($examSearchlist))
		foreach($examSearchlist as $exam)
		{
		if($i%2==0)
		$class="even";
		else
		$class="odd";
		?>
		    <tr class="<?php echo $class?>">
			    <td width="100%"><?php echo $exam['name']?></td>
		    </tr>
		 <?php
		 $i++;
		 }?>
		 <?php 
		 if(is_array($dialogueSearchlist))
		foreach($dialogueSearchlist as $dialogue)
		{
		if($i%2==0)
		$class="even";
		else
		$class="odd";
		?>
		    <tr class="<?php echo $class?>">
			    <td width="100%"><?php echo $dialogue['name']?></td>
		    </tr>
		 <?php
		 $i++;
		 }?>
        </table>
		<?php
		}?>
        <p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
			  
	   </div>
	   
	   <div id="left" class="column">
	   <h2>Summary</h2>

	   <form id="form1" name="form1" method="post" action='<?php echo url::site("smartsite/summaryAnalytics/$userid");?>'>
		  <select style="width:180px;" name="TimePeriod" id="period" onChange="this.form.submit();">
			<option value="none" >Time Period</option>
			<option value="week" <?php  if(isset($TimePeriod2)){if ($TimePeriod2 == 'week'):?> selected<?php endif;}?>>Past week</option>
			<option value="month"<?php  if(isset($TimePeriod2)){if ($TimePeriod2 == 'month'):?> selected<?php endif;}?>>Past Month</option>
			<option value="ytd" <?php  if(isset($TimePeriod2)){if ($TimePeriod2 == 'ytd'):?> selected<?php endif;}?>>YTD</option>
		  </select>
		</form>
		<p>&nbsp;</p>
	   
	   </div>
	   <div id="right" class="column">
			<div id="right_header">
				<h3><?php echo $pieChartName;?></h3>
			</div>
			<div id="right_body">
				  <p>&nbsp;</p>
				 
			<?php 
            if($set=='dialogue'){
			    $piechartArray = array("No of Start"=>$noOfstart ,"Leads"=>$leads);
			?>
			<div class="img_center">
				
			<?php
				echo '<IMG SRC="'.url::base(FALSE).'/media/phPie/phPieDownSummary.php?data='.urlencode(serialize($piechartArray)).'">';
			?>
			</div>
			<?php
			}else{    
				$keys=array_keys($piechartArray);
				$values=array_values($piechartArray);
				
	        ?>		 
  			<div class="img_center">
				
			<?php
				echo '<IMG SRC="'.url::base(FALSE).'/media/phPie/phPieDownSummary.php?data='.urlencode(serialize($piechartArray)).'">';
			?>
			</div>	
			<?php
			}
			?>
			 
			</div>	
	   </div>	
	</div>
 </div>
<!-- End Content -->  

<!-- Footer -->
<div id="footer"></div>
<!-- End Footer -->  

</body>

</html>