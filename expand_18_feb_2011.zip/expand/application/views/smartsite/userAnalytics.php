<?php
/********************************************
AUTHOR:: ANAND
Version:: 1.0
Date:: 07-Sep-2010
Page Description:: User Analytics Page 
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
	<title>Expand Smart Site | User Analytics</title>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />


	<!--link before import prevents Flash Of Unstyled Content in ie6pc -->
    <link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/reset.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/typography.css" type="text/css"   />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/tablesorter.css" type="text/css"   />
	<!-- ADDED for Table Sorting using Jquery Plugin -tablesorter.js - -->
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery.js"></script>
	<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/jquery/jquery-tablesorter.js"></script>
    <script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/rowOverOut.js"></script>
	<script type="text/javascript">
	// add parser through the tablesorter addParser method 
    $.tablesorter.addParser({
        // set a unique id 
        id: 'inline',
        is: function(s){
            // return false so this parser is not auto detected 
            return false;
        },
        format: function(s){
            // format your data for normalization 
            return s.replace(new RegExp(/<.*?>/),"");
        },
        // set type, either numeric or text
        type: 'text'
    });


	
	$(document).ready(function() { 

	$ ("#myTable").tablesorter({ widgets: ['zebra'],headers: {
		0: {
		sorter:'inline'
		} }
    }); 
	
	 // Adds "over" class to rows on mouseover 
	 $(".tablesorter tr").mouseover(function(){ $(this).removeClass("even odd").addClass("over"); }); 
	 // Removes "over" class from rows on mouseout 
	 $(".tablesorter tr").mouseout(function(){ $(this).removeClass("over").addClass(this.rowIndex % 2 == 0 ? "odd" : "even");
     }); 

   });
	</script>
	<script type="text/javascript">
	//ADDED  for left FORM SUBMISSION
	$(function() {
        
		$(".testButton").click(function() {
			$("#right_stat").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
			var userid = "<?php echo $userid; ?>";
			var empid = $(this).val();
			var action = $("input#action").val();
			var dataString ='userid='+userid+'&empid='+empid+'&action='+action;
			$.ajax({
				type: "POST",
				url: "<?php echo url::base(FALSE) ?>smartsite/rightuserPane/",
				data: dataString,
				success: function(data) {
					
					$('#right_stat').html(data);			
				}
		});
		return false;
	});
	});
	</script>
	<script language="javascript">
    function openPopup(url){
	    window.open(url,'welcome','width=500,height=400,menubar=no,status=no,location=no,toolbar=no,scrollbars=no,top=100');

    }
   </script>
    <style type="text/css">
    #lastlogin_header {
	height: 18px;
	width: 100%;
	background: #666;
	color: #fff;
	border-bottom: #000 solid 0.5px;
	padding: 15px 0 10px 10px;
	
    }
	</style>
	
</head>
<body>
<div id="wrapper">
<!-- Header -->
  <div id="header">
    <div id="header_content">
      <div id="nav_logo">
	  </div>
      <div id="nav_btn">
			<div id="nav_wrap">
				<ul id="nav">	
				<li><a id="nav_summary" class="navLink" href="<?php echo url::site("smartsite/summaryAnalytics/$userid",'http');?>" title="Summary"><span>Summary</span></a></li>
				<li><a id="nav_users_selected" class="navLink" href="<?php echo url::site("smartsite/userAnalytics/$userid",'http');?>" title="Users"><span>Users</span></a></li>
				<li><a id="nav_learning" class="navLink" href="<?php echo url::site("smartsite/index/$userid",'http');?>" title="Learning Analytics"><span>Learning Analytics</span></a></li>
				<li><a id="nav_research" class="navLink" href="<?php echo url::site("smartsite/research/$userid",'http');?>" title="Research"><span>Research</span></a></li>
				</ul><div class="clear"></div>
			</div>
		</div>
		<div id="nav_user">
			<p class="user_title"><?php echo $role ?></p>
			<p class="user_name"><?php echo $username ?><a href="<?php echo url::site('user/logout','http');?>"> <img src="<?php echo url::base(FALSE) ?>media/img/logout_btn.png" alt="Logout" width="55" height="13" class="img_padleft"  /></a></p>       
		</div>
		<div class="clear">
		</div>
	</div>
  </div>
<!-- End Header -->  
<!-- Content -->
	<div id="container">
	    <div id="center_learn" class="column" >
		<table width="100%" border="0" id="myTable" cellpadding="0" cellspacing="0" class="tablesorter">
        <thead > 
		  <tr>
			<th  width="10%" class="left">First Name</th>
			<th  width="10%" class="left" >Last Name</th>
			<th  width="10%" class="left" >Company</th>
			<th  width="20%" class="left" >Email Address/Username</th>
			<th  width="10%" class="left" >Country</th>
			<th  width="10%" class="left" >Last Log-in</th>
		  </tr>
		</thead>  
		<?php 
		if(isset($searchResult)){
		?>
		<tr >
			<td class="center" scope="col" colspan="6"><?php echo $searchResult;?></td>

		</tr>
        <?php 		
		}else{
		?>  
		<?php 
			if(isset($trimmedSearchArray)){
				$_SESSION['search']=$trimmedSearchArray;
			}
			if($searchDisplay!==''){ 
			    
				for($i=0;$i<count($userInfo);$i++){
					if((($i+1)%2)==0){
					
		?>
		  <?php  $id=$userInfo[$i]['id']; ?>
		  <tr class="testButton" id='<?php echo ($i+1);?>' 
			onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';" 
			onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $id; ?>';this.class='selected';"
			ondblclick="deSelectRow('<?php echo ($i+1)?>');
			window.open('<?php echo url::site("userEdit/edit/$id",'http');?>','mywindow','width=500,height=400')" >
     
			<input type="hidden" name="action" id="action" value="search" />
  
			<td width="10%" ><?php echo $userInfo[$i]['first']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['last']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['company_orig']; ?></td>
			<td width="20%" class="left" ><?php echo $userInfo[$i]['emailid']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['country']; ?></td>
			
			<td width="10%" class="left"><?php
						     if(($userInfo[$i]['id']==$userLogin[$i]['id']) AND (($userLogin[$i]['lastLogin'])!='')){
							echo date("m/d/Y",$userLogin[$i]['lastLogin']);
						      }else{
							echo "-"; 
						      }
                                 		      ?>
			</td>
			
		  </tr>
		<?php
					}else{  
					
        ?>		<?php  $id=$userInfo[$i]['id']; ?>
		  <tr class="testButton" id='<?php echo ($i+1);?>'  
      			onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
				onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
				onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $id; ?>';this.class='selected';"
				ondblclick="deSelectRow('<?php echo ($i+1)?>');
				window.open('<?php echo url::site("userEdit/edit/$id",'http');?>','mywindow','width=500,height=400')">
  
			
			<input type="hidden" name="action" id="action" value="search" />
			
			<td width="10%" ><?php echo $userInfo[$i]['first']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['last']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['company_orig']; ?></td>
			<td width="20%" class="left"><?php echo $userInfo[$i]['emailid']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['country']; ?></td>
			
			<td width="10%" class="left"><?php
			if(($userInfo[$i]['id']==$userLogin[$i]['id']) AND (($userLogin[$i]['lastLogin'])!='')){
				echo date("m/d/Y",$userLogin[$i]['lastLogin']);
			}else{
				echo "-"; 
			}
					?>
			</td>
					  
			</tr>
		<?php 
                    }
			    }
			}else{
			   
				for($i=0;$i<count($userInfo);$i++){
					if((($i+1)%2)==0){
		?>
		  <?php  $id=$userInfo[$i]['id']; ?>
		  <tr class="testButton" id='<?php echo ($i+1);?>' style="background-color: #aad2e2;color:black;" 
      		onmouseover="rowOver('<?php echo ($i+1);?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
				onmouseout="rowOver('<?php echo ($i+1);?>',0);this.style.fontWeight='normal';"
				onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $id; ?>';"
				ondblclick="deSelectRow('<?php echo ($i+1)?>');
				window.open('<?php echo url::site("userEdit/edit/$id",'http');?>','mywindow','width=500,height=400')">
    
		    <input type="hidden" name="action" id="action" value="none" />
			
			<td width="10%" ><?php echo $userInfo[$i]['first']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['last']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['company_orig']; ?></td>
			<td width="20%" class="left"><?php echo $userInfo[$i]['emailid']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['country']; ?></td>
		   
			<td width="10%" class="left"><?php
			if(array_key_exists($i,$userLogin))
			{
				if(($userInfo[$i]['id']==$userLogin[$i]['id']) AND (($userLogin[$i]['lastLogin'])!='')){
					echo date("m/d/Y",$userLogin[$i]['lastLogin']);
				}else{
					echo "-"; 
				}
			}else
			echo "-"; 
					?>
			</td>
			
			</tr>
		<?php
					}else{  
        ?>	<?php  $id=$userInfo[$i]['id']; ?>	
		  <tr class="testButton" id='<?php echo ($i+1)?>' style="background-color: #72b4ce;color:black;" 
      				onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
				onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
				onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $id; ?>';"
				ondblclick="deSelectRow('<?php echo ($i+1)?>')
				window.open('<?php echo url::site("userEdit/edit/$id",'http');?>','mywindow','width=500,height=400')">
  
  
	            
			<input type="hidden" name="action" id="action" value="none" />
			
			<td width="10%" ><?php echo $userInfo[$i]['first']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['last']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['company_orig']; ?></td>
			<td width="20%" class="left"><?php echo $userInfo[$i]['emailid']; ?></td>
			<td width="10%" class="left"><?php echo $userInfo[$i]['country']; ?></td>
			
			<td width="10%" class="left"><?php
			if(array_key_exists($i,$userLogin))
			{
				if(($userInfo[$i]['id']==$userLogin[$i]['id']) AND (($userLogin[$i]['lastLogin'])!='')){
					echo date("m/d/Y",$userLogin[$i]['lastLogin']);
				}else{
					echo "-"; 
				}
			}else
			echo "-"; 
								?>
			</td>
		
		  </tr>
		<?php 
                    }
			    }	
			
			
			
			
			}	
		?>	
		<!--<p><span><font color="red" size="1" ><b>NOTE:</b></font></span> hold  shift key and click on  multiple headers/columns to do multiple column sorting!</p>-->
	    <?php 
		}	
        ?>		
		</table>
		
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>

			  
	   </div>
	   
	    <div id="left" class="column">
            <?php 
			if($set==="exam"){
			?>    
			<h2><a href="<?php echo url::site("smartsite/userAnalytics/$userid") ?>" class="selected" >User Library</a></h2>
			<div id="users">

	        <form id="form1" name="form1" method="post" action="<?php echo url::site("smartsite/userAnalytics/$userid/none/search") ?>" >
                <input style="width:175px;" name="search" type="text" value="Search" onClick="this.value=''" />
				<input type="hidden" name="submit" value="submit"/>
            </form>
			
			<p>&nbsp;</p>
    
		    
			<ul>
			    <li><a href='<?php echo url::site("smartsite/userAnalytics/$userid") ?>' class="selected userView">View All Users</a></li>
			    <li><a href="<?php echo url::site("smartsite/newUser/$userid") ?>" class="userNew">New User</a></li>
				<li><a href="<?php echo url::site("smartsite/importData/$userid") ?>" class="userImport">Import Users</a></li>
			</ul>
		    </div>
    
            <p>&nbsp;</p>
            <p>&nbsp;</p> 	
			<?php
            }elseif($set==="dialogue"){ 			
			?>
            <div id="conversions" class="on">			
            <h2><a href="<?php echo url::site("smartsite/conversion/$userid") ?>" >Conversion Stats</a></h2>
			
			<form id="form1" name="form1" method="post" action="<?php echo url::site("smartsite/conversion/$userid") ?>">
			<select style="width:180px;" name="TimePeriod" id="period" onChange="this.form.submit();">
				<option value="none">Time Period</option>
				<option value="week">Past week</option>
				<option value="month">Past Month</option>
				<option value="ytd">YTD</option>

			</select>
			</form>
    
			<p>&nbsp;</p>
			<ul>
				<li><a href="#" class="conversIons">Leads</a></li>
				<li><a href="#" class="conversStat">Sales</a></li>
			</ul>
			<p>&nbsp;</p>
			<form id="conv" name="conv" method="post" action="">
			<input type="image" name="submit" src="<?php echo url::base(FALSE) ?>media/img/emailgroup_btn.png" style="width:180px; height:29px;" />

			<p>&nbsp;</p>
			<input name="notify" type="checkbox" value="" /><label>Email Notifications</label>
			<textarea name="addresses" cols="" rows="5" style="width:175px;"><?php echo $emailId; ?></textarea>
			</form>
    
			</div>			
			<p>&nbsp;</p>
            <?php 
			}else{
			?>
			<h2><a href="<?php echo url::site("smartsite/userAnalytics/$userid") ?>" class="selected" >User Library</a></h2>
			<div id="users">

	        <form id="form1" name="form1" method="post" action="<?php echo url::site("smartsite/userAnalytics/$userid/none/search") ?>" >
                <input style="width:175px;" name="search" type="text" value="Search" onClick="this.value=''" />
				<input type="hidden" name="submit" value="submit"/>
            </form>
			
			<p>&nbsp;</p>
    
		    
			<ul>
			    <li><a href='<?php echo url::site("smartsite/userAnalytics/$userid") ?>' class="selected userView">View All Users</a></li>
			    <li><a href="<?php echo url::site("smartsite/newUser/$userid") ?>" class="userNew">New User</a></li>
				<li><a href="<?php echo url::site("smartsite/importData/$userid") ?>" class="userImport">Import Users</a></li>
			</ul>
		    </div>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<?php 
			    $flag=1;
				if($company=='Roland' or $company=='DTE'){
				    $flag=0;
				}
			    if($flag){
			?>
			<div id="conversions" class="off">			
            <h2><a href="<?php echo url::site("smartsite/conversion/$userid") ?>" >Conversion Stats</a></h2>
			
			<form id="form1" name="form1" method="post" action="<?php echo url::site("smartsite/conversion/$userid") ?>">
			<select style="width:180px;" name="TimePeriod" id="period" onChange="this.form.submit();">
				<option value="none">Time Period</option>
				<option value="week">Past week</option>
				<option value="month">Past Month</option>
				<option value="ytd">YTD</option>

			</select>
			</form>
    
			<p>&nbsp;</p>
			<ul>
				<li><a href="#" class="conversIons">Leads</a></li>
				<li><a href="#" class="conversStat">Sales</a></li>
			</ul>
			<p>&nbsp;</p>
			<form id="conv" name="conv" method="post" action="">
			<input type="image" name="submit" src="<?php echo url::base(FALSE) ?>media/img/emailgroup_btn.png" style="width:180px; height:29px;" />

			<p>&nbsp;</p>
			<input name="notify" type="checkbox" value="" /><label>Email Notifications</label>
			<textarea name="addresses" cols="" rows="5" style="width:175px;"><?php echo $emailId; ?></textarea>
			</form>
    
			</div>			
			<p>&nbsp;</p>

            <?php 			
			   }
			}
			?>
 
	    </div>
	   <div id="right" class="column">
			<div id="right_header_stat">
			 <h2>User Stats</h2>
		    </div>
		    <div id="right_stat">
			<?php 
			
			if(is_array($userData)){ 
				    $empid=$userData['id'];
					
			?>	
			
            <?php if($userUpdate!==""){ echo $userUpdate;} ?> 			
			<div class="name"><?php echo $userData['first']." ".$userData['last']; ?><br>
			<a href="javascript:openPopup('<?php echo url::site("userEdit/edit/$empid",'http');?>')">
			<img src="<?php echo url::base(FALSE) ?>media/img/edit.jpg" alt="edit">
			</a>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href='<?php echo url::site("smartsite/userAnalytics/$userid/$empid/delete") ?>'>
			<img src="<?php echo url::base(FALSE) ?>media/img/remove.png">
			</a>
			</div>
			<div class="exam">
            <div id="lastlogin_header">
			<p><strong>Total Logins&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="white"><?php echo $userLoginNum;?></span></strong></p>
			</div>
			<div id="lastlogin_header">
            <p><strong>Last Login&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="white"><?php 
			                                            if($userLastlogin==''){
			                                                echo '-';
														}else{
														    echo date("m/d/Y",$userLastlogin);
														}		
			
											?></span></strong></p>
			</div>								
			<img src="<?php echo url::base(FALSE) ?>media/img/moduleSummary.png" alt='Module Summary'> 								
			<?php
			$count = count($userExamResult);
            for($i=0;$i<$count;$i++){			
                if($userExamResult[$i]['exam_id']!=''){
			?>	
			<p><strong><span class="white"><?php echo $userExamResult[$i]['examname']; ?><br/></span></strong></p>
			<p>
			<?php 
			if(strtolower($userExamResult[$i]['result'])==='certified'){
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/pass.png" alt="certified">
			<?php
			}elseif(strtolower($userExamResult[$i]['result'])==='failed'){
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/fail.png" alt="failed">
			<?php
			}else{
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/incomplete.png" alt="incomplete">
			<?php
			}
			?>
			<span class="white"><?php echo $userExamResult[$i]['result']; ?></span>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<span class="white"><?php echo date("m/d/Y",strtotime($userExamResult[$i]['date'])); ?></span>
			</p>
            
			
			<?php                                        												
			    }
			}	
			?>
			</div>
            <?php	
				
				}else{ 
				    echo $userData;
				}

			?> 
			
			
			 
			</div>	
	   </div>	
	</div>
 </div>
<!-- End Content -->  

<!-- Footer -->
<div id="footer"></div>
<!-- End Footer -->  

</body>

</html>