$(document).ready(function() {

        
		$("#training").change(function() {
			 var p =document.getElementById('right');
			 var count=p.getElementsByTagName('div').length;
			 for(i=1;i<(count-1);i++)
			 {
				 p.removeChild(p.getElementsByTagName('div')[i]);
				 count=count-1;
				 i=i-1;
			 }
			var str = $('#training').val();
			//alert(str);
			var list=new Array();
			list=str.split(":");
			//alert(list[0]);
			//var optionSelect = $('#training').val();
			var optionSelect =list[0];
			//alert('optionselect'+optionSelect);
			var type=list[1];
			//alert('type'+type);
			var examName = $("input#examName").val();
			//alert(examName);
			//var set = $("input#digital").val();
			//var dataString ='examid='+examid+'&quesid='+quesid+'&TimePeriod='+TimePeriod+'&set='+set;
			//alert (dataString);
			var dataString ='optionSelect='+optionSelect+'&examName='+examName+'&type='+type;
			$.ajax({
				type: "POST",
				url: "/expand/smartsite/selectResearchPane/",
				data: dataString,
				success: function(data) {
					
					//$('select#question').html(data);
					$('#resultValue').html(data);			
				}
		});
		return false;
	});
	});
	
	

	