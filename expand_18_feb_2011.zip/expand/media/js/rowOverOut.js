
	
    var clicked = '';
    function rowOver(which, what) {
	var changed = document.getElementById(which);
	    if (which != clicked) {
			if (what == 1){
			    changed.style.backgroundColor = '#C0C0C0';
			    changed.style.color='#fff';
			}else{
				if((which%2)==0){
				//changed.style.backgroundColor = '#aad2e2';
				changed.style.color='#000';
				}else{
				//changed.style.backgroundColor = '#72b4ce';
				changed.style.color='#000';
				}
			}
		}
	}
	function resetRow(which) {
		var changed = document.getElementById('selected');
		//alert('changed'+changed);
		document.getElementById('selected').setAttribute("id", which);
		if((which%2)==0){
		//alert('even');
		document.getElementById(which).setAttribute("class", "odd");
		changed.style.backgroundColor = '#72b4ce';
		changed.style.color='#000';
		}else{
		//alert('odd');
		document.getElementById(which).setAttribute("class", "even");
		changed.style.backgroundColor = '#aad2e2';
		changed.style.color='#000';
		}
	}

	function changeSelect(which) {
		var changed = document.getElementById(which);
		

		document.getElementById(which).setAttribute("id", "selected");
		//changed.style.backgroundColor = '#808080';
		//changed.style.color='red';
		changed.onMouseOver = '';
		changed.onMouseOut = '';	

	}

	function selectRow(which) { 

		if (clicked != '') {
		//alert('1');
		resetRow(clicked);
		clicked = which;
		changeSelect(which);
		} else if (clicked == '') {
		//alert('2');
		clicked = which;
		changeSelect(which);
		}
		//currentRowId = rowIndex;
	}

	function deSelectRow(which) {
	resetRow(which);
	clicked = '';
	}
	
	function DoNav(theUrl){   
	   document.location.href = theUrl;
	}