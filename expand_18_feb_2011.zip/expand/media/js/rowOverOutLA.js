    var clicked = '';
    function rowOverLA(which, what) {
	var changed = document.getElementById(which);
	    if (which != clicked) {
			if (what == 1){
			    changed.style.backgroundColor = '#C0C0C0';
			    changed.style.color='#fff';
			}else{
				if((which%2)==0){
				changed.style.backgroundColor = '#aad2e2';
				changed.style.color='#000';
				}else{
				changed.style.backgroundColor = '#72b4ce';
				changed.style.color='#000';
				}
			}
		}
	}
	function resetRowLA(which) {
		var changed = document.getElementById(which);
		if((which%2)==0){
		changed.style.backgroundColor = '#aad2e2';
		changed.style.color='#000';
		}else{
		changed.style.backgroundColor = '#72b4ce';
		changed.style.color='#000';
		}
	}

	function changeSelectLA(which) {
		var changed = document.getElementById(which);
		changed.style.backgroundColor = '#808080';
		changed.style.color='#fff';
		changed.onMouseOver = '';
		changed.onMouseOut = '';
	}

	function selectRowLA(which) { 

		if (clicked != '') {
		//alert('1');
		resetRowLA(clicked);
		clicked = which;
		changeSelectLA(which);
		} else if (clicked == '') {
		//alert('2');
		clicked = which;
		changeSelectLA(which);
		}
		//currentRowId = rowIndex;
	}

	function deSelectRowLA(which) {
	resetRowLA(which);
	clicked = '';
	}

