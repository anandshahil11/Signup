<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'Katalog %s wybrany do zapisu pliku jest tylko do odczytu. Proszę zmienić uprawnienia i spróbować ponownie.',
	'filename_conflict'    => 'Wybrana nazwa archiwum %s, istnieje i nie może być zapisana. Proszę usunąć plik i spróbować ponownie.',
);