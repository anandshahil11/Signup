<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'O diretório que você requisitiou para salvar o arquivo, %s, não possui permissão para escrita. Por favor, corrija as permissões e tente novamente.',
	'filename_conflict'    => 'O nome de arquivo archive requisitado, %s, já existe e não possui permissão para escrita. Por favor, remova o arquivo conflitante e tente novamente.'
);
