<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'required'					=> 'Некои задолжителни полиња не се пополнети: %s',
	'gateway_connection_error'	=> 'Се појави грешка при поврзување со payment gateway. Ве молиме контактирајте со вебмастерот ако овој проблем цело време се појавува.',
	'invalid_certificate'		=> 'Сертификатот не е валиден: %s',
	'no_dlib'					=> 'Динамичката библиотека не може да се вчита: %s',
	'error'						=> 'Се појави грешка при процесирање на трансакцијата: %s',
);