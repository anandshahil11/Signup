<?php defined('SYSPATH') OR die('No direct access allowed.');
/**
 * @package  Core
 *
 * Sets the default route to "welcome"
 */
//@Author:: Anand , original code is commented
 //$config['_default'] = 'welcome';
//@Author:: Anand 
//$config['_default'] = 'api';
//$config['([A-Za-z0-9-_]+)'] = 'api/$1';
//$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2';
//$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2/$3';

//echo '$_SERVER[SERVER_NAME]'.$_SERVER['SERVER_NAME']."<br/>";
//echo stripos($_SERVER['SERVER_NAME'],'api.');
//echo "------------------------";
//var_dump($_SERVER);exit;
//NOTE:- when we check $_SERVER['SERVER_NAME']==localhost every time thats y its not going in IF condition . To forcefully go to that 
// uncomment above line no 10-13 and comment below lines.
/*if ( stripos($_SERVER['SERVER_NAME'],'api.') !=false || stripos($_SERVER['SERVER_NAME'],'amf') !=false )
{   //echo "I am in IF condition";
	$config['_default'] = 'api';
	$config['([A-Za-z0-9-_]+)'] = 'api/$1';
	$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2';
	$config['([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)/([A-Za-z0-9-_]+)'] = 'api/$1/$2/$3';
}
else
{   //echo "I am in IF else";
	$config['_default'] = 'welcome';
	
	//questions
	$config['admin/question_sets/([0-9]+)/questions'] = 'admin/question_sets/questions/show_list/$1';
	$config['admin/question_sets/([0-9]+)/questions/edit/([0-9]+)'] = 'admin/question_sets/questions/edit/$2';
	$config['admin/question_sets/([0-9]+)/questions/create'] = 'admin/question_sets/questions/create/$1';
	$config['admin/question_sets/([0-9]+)/questions/delete'] = 'admin/question_sets/questions/delete';
	
	//results
	$config['admin/results/([0-9]+)'] = 'admin/results/home/$1';
	$config['admin/results/([0-9]+)/([a-z-_]+)'] = 'admin/results/$2/$1';
	$config['admin/results/([0-9]+)/([a-z-_]+)/([0-9]+)'] = 'admin/results/$2/$3';
}*/