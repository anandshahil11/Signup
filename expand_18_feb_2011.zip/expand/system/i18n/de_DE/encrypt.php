<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => 'Die Gruppe %s ist nicht in Ihrer Konfiguration enthalten.',
	'requires_mcrypt'   => 'Um die Bibliothek Encrypt zu benutzen, muss mcrypt in Ihrer PHP-Installation aktiviert werden',
	'no_encryption_key' => 'Um die Bibliothek Encrypt zu benutzen, müssen Sie einen Schlüssel in Ihrer Konfiguration eintragen'
);
