<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [09/Mar/11]
Page Description:: checklist webpage
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class checklist_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	//list all the check list temp
	public function viewAll()
	{
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->type = "module";
		$viewHeader->render(TRUE);
		$view = new View('checklistViewAll');
		$checklist = new checklist_Model;
		$view->records=$checklist->getChecklist();
       	$view->render(TRUE);
	}
	//for new checklist
	public function newCheckList()
	{
		$view = new View('newchecklist');
		$view->type=isset($_GET['type'])?$_GET['type']:'';
		$checklist = new checklist_Model;
		$CKlistId=$_GET['id'];
		$view->cat=$checklist->getCat($CKlistId);
		$view->CLitem=$checklist->getCLNumericalitems($CKlistId);
		$view->checklistId=$CKlistId;
		$itemId=isset($_GET['itemId'])?$_GET['itemId']:0;
		$view->itemId=$itemId;
		$view->itemCat='';
		$view->itemTitle="Title/Input/Question";
		$view->itemDesc="Description";
		$view->itemNext="";
		$view->itemSubmit="";
		$view->entryFormat="";
		$view->Min="";
		$view->Max="";
		$view->format="";
		$view->Decimals="";
		$view->fractionFormat="";
		$view->dateAutoEntry='';
		$view->dateFormat='';
		$view->optionalText='';
		$view->arrOptions=array();
		$view->unselectedEntry='';
		$view->selectedEntry='';
		$view->totalChar='';
		$view->useSelectionList='';		
		$view->profileType='';
		$view->profileEntryType='';
		$view->profileNameFormat='';
		$view->quest1='';
		$view->quest2='';
		$view->math='';
		$view->arrFields=array();
		$view->summary='';
		$view->currentChecklist='';
		$view->calculateChecklist='';
		$view->mediatype='';
		$view->videoUrl='Video Link';
		$view->ipadlink='Ipad Link';
		$view->mediatitle='Media Title';
		$view->mediadetailtext='Media Description';
		$view->curFormat='';
		if($itemId)
		{
			$result=$checklist->getChecklistItemInfo($itemId);
			$view->type=isset($_GET['type'])?$_GET['type']:$result->items_type;
			$view->itemCat=$result->category_id;
			$view->itemTitle=$result->items_title;
			$view->itemDesc=$result->items_desc;
			$view->itemNext=$result->items_required_next;
			$view->itemSubmit=$result->items_required_submit;
			$view->quest1='';
			$view->quest2='';
			$view->math='';
			if($view->type=='Number')
			{
				$view->entryFormat=$result->items_numerical_entry_format;
				$view->Min=$result->items_numerical_min;
				$view->Max=$result->items_numerical_max;
				$view->format=$result->items_numerical_format;
				$view->Decimals=$result->items_numerical_decimal_format;
				$view->curFormat=$result->item_currency_format;
				$view->fractionFormat=$result->items_numerical_fraction_format;
			}
			if($view->type=='Date')
			{
				$view->dateAutoEntry=$result->items_date_auto_entry;
				$view->dateFormat=$result->items_date_format;
			}
			if($view->type=='Multiple Selection')
			{
				$view->optionalText=$result->items_optional_text_entry;
				$view->arrOptions=$checklist->getCLIoptions($itemId);
			}
			if($view->type=='Binary')
			{
				$view->unselectedEntry=$result->items_binary_unselected_entry;
				$view->selectedEntry=$result->items_binary_selected_entry;
			}
			if($view->type=='Text Entry')
			{
				$view->totalChar=$result->items_text_total_char;
				$view->useSelectionList=$result->items_text_use_selection_list;
				$view->arrOptions=$checklist->getCLIoptions($itemId);
			}
			if($view->type=='User Data')
			{
				$view->profileType=$result->items_profile_type;
				$view->profileEntryType=$result->items_profile_entry_type;
				$view->profileNameFormat=$result->items_profile_name_format;
			}
			if($view->type=='Calculation')
			{
				$view->quest1=$result->items_question1;
				$view->quest2=$result->items_question2;
				$view->math=$result->items_math;
			}
			if($view->type=='Summary')
			{
				$view->arrFields=$checklist->getCLIfields($itemId);
				$view->summary=$result->items_summary;
				$view->currentChecklist=$result->items_calculate_current_checklist;
				$view->calculateChecklist=$result->items_calculate_all_checklist;
			}
			$view->mediatype=$result->media_type;
			$view->videoUrl=!empty($result->media_value)?$result->media_value:'Video Link';
			$view->ipadlink=!empty($result->media_ipad_value)?$result->media_ipad_value:'Ipad Link';
			$view->mediatitle=!empty($result->media_title)?$result->media_title:'Media Title';
			$view->mediadetailtext=!empty($result->media_description)?$result->media_description:'Media Description';
		}
		if(count($_POST)>0)
		{
			$checklist = new checklist_Model;
			$checklist->saveChecklistItems($CKlistId,$itemId);
			
		}
		$view->render(TRUE);
	}
	//checklist setting
	public function setting()
	{
		$view = new View('cksettingView');
		$group = new group_Model;
		$view->groups = $group->getGroups();
		$checklist = new checklist_Model;
		$id=isset($_GET['id'])?$_GET['id']:0;
		$view->name='';
		$view->evaluation='';
		$view->selectedGroup=array();
		if($id)
		{
			$result=$checklist->getChecklistInfo($id);
			foreach($result as $row)
			{
				$view->name=$row->checklist_name;
				$view->evaluation=$row->evaluation;
				$view->selectedGroup[]=$row->group_id;
			}
		}
		if(count($_POST))
		{
			$checklist->saveChecklist($id);
		}		
		$view->render(TRUE);	
	}
	//delete checklist
	public function delCheckList()
	{
		$delId=$_GET['id'];
		$checklist = new checklist_Model;
		$checklist->delChecklist($delId);
		url::redirect("checklist/viewall");
	}
	//view checklist items
	public function viewCKlistItem()
	{
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->type = "module";
		$viewHeader->render(TRUE);
		$CKlistId=$_GET['id'];
		$view = new View('CKlistitemview');
		$view->checklistId=$CKlistId;
		$checklist = new checklist_Model;
		$view->checklistInfo=$checklist->getCLinfo($CKlistId);
		$view->CatRecords=$checklist->getCat($CKlistId);
		$view->CLRecords=$checklist->getCL($CKlistId);
		$view->render(TRUE);	
	}
	//save new category
	public function newCategory()
	{
		$view = new View('newCategory');
		$catId=isset($_GET['catId'])?$_GET['catId']:'';
		$checklist = new checklist_Model;
		$view->catName='';
		if($catId)
		{
			$view->catName=$checklist->getCatInfo($catId);
		}
		if(count($_POST))
		{
			$CKlistId=$_GET['id'];
			$checklist->saveCat($CKlistId,$catId);
		}		
		$view->render(TRUE);	
	}
	//rearrange category
	public function reArrange()
	{
		$checkList=$_GET['checkList'];
		$order=$_GET['positions'];
		$checklist = new checklist_Model;
		$checklist->rearrange($order,$checkList);
	}
	//checklist publish
	public function publish()
	{
		$CKlistId=$_GET['id'];
		$checklist = new checklist_Model;
		$checklist->publish($CKlistId);
		url::redirect("checklist/viewCKlistItem?msg=Published successfully&id=".$CKlistId);
	}
	//checklist unpublish
	public function unpublish()
	{
		$CKlistId=$_GET['id'];
		$checklist = new checklist_Model;
		$checklist->unpublish($CKlistId);
		url::redirect("checklist/viewCKlistItem?msg=Un Published successfully&id=".$CKlistId);
	}
	//checklist delete
	public function deleteItem()
	{
		$CLId=$_GET['CLId'];
		$CLIId=$_GET['CLIId'];
		$checklist = new checklist_Model;
		$checklist->deleteItem($CLIId);
		url::redirect("checklist/viewCKlistItem?msg=Checklist Item Deleted successfully&id=".$CLId);
	}
	//checklist category delete
	public function deleteCat()
	{
		$CatId=$_GET['CatId'];
		$CLId=$_GET['CLId'];
		$checklist = new checklist_Model;
		$checklist->deleteCat($CatId,$CLId);
		url::redirect("checklist/viewCKlistItem?msg=Checklist Category Deleted successfully&id=".$CLId);
	}
	//checklist search
	public function search()
	{
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->type = "module";
		$viewHeader->render(TRUE);
		$view = new View('CLSearchView');
		$view->type="search";
		$view->companyid = 1;
        $view->userid = $_SESSION['user_object']->user_id; 	
		$user = new usersearch_Model;
		$result= $user->getchecklist();
		$checklist = array();
		foreach($result as $item)
		{
			$checklist['checklist-'.$item->checklist_id] = 'Checklist- '.$item->checklist_name;
		}
		$primarylist = array('Profile Data'=>"Profile Data",'checklist'=>$checklist);
		$data_count = 0;
		foreach($primarylist as $val)
		{
			if(is_array($val))
			{
				$arr_count=count($val);
			}
			else
				$data_count++;
		}
		$plistcount = $arr_count+$data_count;
		$view->newlist =array();
		$view->primarylist = $primarylist;
		$view->count = $plistcount;
       	$view->render(TRUE);
	}
	///function get data for the search
	function getDatas()
	{
		$criteriaId=$_GET['criteriaId'];
		$criteria['Cri']=isset($_GET['Cri'])?$_GET['Cri']:'';
		$detailVal=isset($_GET['detailVal'])?$_GET['detailVal']:'';
		$datef=isset($_GET['datef'])?$_GET['datef']:'';
		$datet=isset($_GET['datet'])?$_GET['datet']:'';
	
		$field=isset($_GET['field'])?$_GET['field']:'';
		$list = explode(':',$criteriaId);
		$criteria = explode(':',$criteria['Cri']);
		$detailVal = explode(':',$detailVal);
		$field = explode(':',$field);
		/*foreach($list as $value) {
			$crid_arr[$value] =$value;
		}*/
		//print_r($dVal_arr); exit;
		$checklist = new checklist_Model;
		$totalChek = $checklist->totalChecklist();
		$results=$checklist->getDatas($list,$field,$criteria,$detailVal,$datef,$datet);
		header("content-type: text/xml");
		echo '<datas>';
		$rowCount=0;
		foreach($results as $row)
		{
			$rowCount++;
			echo '<rows>';
			echo '<checklistname>'.wordwrap($row->checklist_name,6,"<br/>\n",true).'</checklistname>';
			$operatorName=$checklist->getOperatorName($row->checklist_id,$row->user_session);
			if(!empty($operatorName))
			$name=$operatorName->firstname.' '.$operatorName->lastname;
			else
			$name='';
			echo '<operatorname>'.$name.'</operatorname>';
			echo '<idnumber>'.wordwrap($row->checklist_id,6,"<br/>\n",true).'</idnumber>';
			echo '<completed>'.wordwrap($row->checklist_completed,5,"<br/>\n",true).'</completed>';
			echo '<sessid>'.wordwrap($row->user_session,5,"<br/>\n",true).'</sessid>';
			echo '</rows>';
			
			
		}
		echo '<rowcount>'.$rowCount.'/'.$totalChek.'</rowcount>';
		echo '</datas>';
		exit;
	}
	//function 
	public function viewAnswer()
	{
		$view = new View('checklistAns');
		$view->checklistId=$_GET['checklistId'];
		$view->userSession=$_GET['userSession'];
		$view->msg=isset($_GET['msg'])?$_GET['msg']:'';
		$checklist = new checklist_Model;
		$view->checklistInfo=$checklist->getCLinfo($_GET['checklistId']);
		$view->info=$this->checklistAns($_GET['checklistId'],$_GET['userSession']);
		$view->render(TRUE);
	}
	public function checklistAns($checklistId,$sessId)
	{
		$checklist = new checklist_Model;
		$catInfo=$checklist->getChecklistCatInfo($checklistId);
		$itemInfo=$checklist->getChecklistItem($checklistId,$sessId);
		$info=array();
		foreach($catInfo as $cat)
		{
			foreach($itemInfo as $item)
			{
				if($cat->category_id==$item->category_id)
				{
					if($item->items_numerical_format=='Currency')
					{
						if($item->item_currency_format=='Dollar')
						$sym='$';
						elseif($item->item_currency_format=='Euro')
						$sym='&euro;';
						elseif($item->item_currency_format=='Yen')
						$sym='&yen;';
						elseif($item->item_currency_format=='Pound')
						$sym='&pound;';
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>$item->item_ans.$sym);
					}
					else if($item->items_numerical_format=='Degrees')
					{
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>$item->item_ans.'&deg;');
					}
					else if($item->items_numerical_format=='Percentage')
					{
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>$item->item_ans.'%');
					}
					else if($item->items_type=='Date' && !empty($item->item_ans))
					{
						if($item->items_date_format=='format1(january 31st,2011)')
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>date('F dS,Y',$item->item_ans));
						elseif($item->items_date_format=='format2(1/31/2011)')
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>date('m/d/Y',$item->item_ans));
						elseif($item->items_date_format=='format3(31/1/2011)')
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>date('d/m/Y',$item->item_ans));
					}
					elseif($item->items_type=='User Data' and $item->items_profile_type=='Name' && !empty($item->item_ans))
					{
						$operatorName=$checklist->getOperatorName($checklistId,$sessId);
						if(!empty($operatorName))
						{
							if($item->items_profile_name_format=='firstname,Lastname')
							$name=$operatorName->firstname.' '.$operatorName->lastname;
							elseif($item->items_profile_name_format=='lastname,firstname')
							$name=$operatorName->lastname.' '.$operatorName->firstname;
							else
							$name=$operatorName->lastname;
						}
						else
						$name='';
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>$name);
					}
					elseif($item->items_type=='Multiple Selection' or $item->items_text_use_selection_list)
					{
						$options=$checklist->getOptions($item->items_id,$_GET['userSession']);
						$optArr=array();
						foreach($options as $option)
						{
							$optArr[]=$option->item_options_value;
						}
						$opt=implode(',',$optArr);
						$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>$opt);
					}
					else
					$info[$cat->category_name][]=array("name"=>$item->items_title,"Ans"=>$item->item_ans);
				}
			}

		}
		return $info;
	}
	public function sendMail()
	{
		$checklist = new checklist_Model;
		$info=$this->checklistAns($_GET['checklistId'],$_GET['userSession']);;
		$html = "<html><head>
				 <style type='text/css'>
				
				.blue_zebra {
					border-bottom: #fff solid 2px;
				}

				.blue_zebra tbody td, .blue_zebra thead th {
					padding: 2px 20px;
				}
				
				.blue_zebra tbody tr {
					height: 20px;
					border-bottom: #000 solid 2px;
					
				}

				.blue_zebra thead th {
					background-color: #000;
					color:#FFF;
					font-family:Verdana;
					font-size:11pt;
					font-weight:bold;
				}
				.blue_zebra tr {
					color:#000;
					background-color: #E5E5E5;
					font-family:Verdana;
					font-size:13pt;
				}				
				#footer {
					background: #CCC url(".url::base(FALSE)."media/img/header_bg.png) repeat-x;
					height: 100px;
					width: 100%;
				}
				 </style>
				 </head>
					<body><p><b><font color='#808080'><h1 style='font-size:18px;'>Checklist Answer Information</h1></font></b> </p>
				<table class='blue_zebra' style='table-layout:auto;width:900px;'>
				<thead ><tr><th>Question</th><th>Answer</th></thead>
				<tbody>";
	    $html1=""; 	
		foreach($info as $cat=>$items)
		{
			$html1.='<tr>
                    	<td colspan=2>'.$cat.'</td>
                    </tr>';
			foreach($items as $item)
			{
                $html1.='<tr>
                    	<td>'.$item['name'].':</td>
                        <td>'.$item['Ans'].'</td></tr>';
			}
		}
		$html =$html.$html1."</tbody></table><br/></body></html>";  
		$message='';
		include('Mail.php');
		include('Mail/mime.php');   
		if(isset($_POST['to']))
		$recipient=$_POST['to'];
		else
		$recipient=$checklist->getOperatorEmail($_GET['checklistId'],$_GET['userSession']);
		$sender='';
		$subject='Checklist Infomation';
		$headers = array(
				'From'          => $sender,
				'Return-Path'   => $sender,
				'Subject'       => $subject
				);
		if(isset($_POST['cc']))
		{
			$headers['Cc']= $_POST['cc'];
		}
		if(isset($_POST['bcc']))
		{
			$headers['Bcc']= $_POST['bcc'];
		}
		$crlf = "\n";
		$mime = new Mail_mime($crlf);
		$text = 'This is a text message.';  
		$mime->setTXTBody($text);
		$mime->setHTMLBody($html);
		$body = $mime->get();
		$headers = $mime->headers($headers);
		$mail =& Mail::factory('mail');
		$result=$mail->send($recipient, $headers, $body);
		$result=1;
		if($result==1){
			url::redirect("checklist/viewAnswer?msg=Checklist Infomation Mailed successfully&checklistId=".$_GET['checklistId']."&userSession=".$_GET['userSession']);
		}else{
			url::redirect("checklist/viewAnswer?msg=Checklist Infomation Mailed Failed&checklistId=".$_GET['checklistId']."&userSession=".$_GET['userSession']);
		}
	}
	public function exportData()
	{
		$info=$this->checklistAns($_GET['checklistId'],$_GET['userSession']);
		$csv_terminated = "\n";
		$csv_separator = ",";
		$csv_enclosed = '"';
		$csv_escaped = "\\";
		$out='';
		foreach($info as $cat=>$items)
		{
			$out.='"'.$cat."\"\n";
			foreach($items as $item)
			{
                $out.='"'.stripslashes(implode('","',$item))."\"\n";
			}
		}
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Length: " . strlen($out));
		// Output to browser with appropriate mime type, you choose ;)
		header("Content-type: text/x-csv");
		//header("Content-type: text/csv");
		//header("Content-type: application/csv");
		header("Content-Disposition: attachment; filename=checklistInfo.csv");
		echo $out;
		exit;

	}
}

