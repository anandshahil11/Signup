<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [09/Mar/11]
Page Description:: checklist webpage
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class exam_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	//checklist setting
	public function exam()
	{
		$view = new View('examView');
		$group = new group_Model;
		$view->groups = $group->getGroups();
		$exam = new exam_Model;
		$id=isset($_GET['id'])?$_GET['id']:0;
		$view->name='';
		$view->passReq=100;
		$view->totalAttempts='';
		$view->numberQuestion='';
		$view->alwaysMantetory='';
		$view->randomExam='';
		$view->randomAns='';
		$view->selectedGroup=array();
		if($id)
		{
			$result=$exam->getExamGroupinfo($id);
			foreach($result as $row)
			{
				$view->name=$row->exam_name;
				$view->passReq=$row->exam_pass_percent;
				$view->totalAttempts=$row->exam_attempt ;
				$view->numberQuestion=$row->exam_number_question_ask ;
				$view->alwaysMantetory=$row->exam_mantetory_question_ask;
				$view->randomExam=$row->exam_random_question;
				$view->randomAns=$row->exam_random_answer;
				$view->selectedGroup[]=$row->group_id;
			}
		}
		if(count($_POST))
		{
			$exam->saveExam($id);
		}		
		$view->render(TRUE);	
	}
	//list all the check list temp
	public function viewAll()
	{
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->type = "module";
		$viewHeader->render(TRUE);
		$view = new View('examViewAll');
		$exam = new exam_Model;
		$view->records=$exam->getExams();
       	$view->render(TRUE);
	}
	//delete exam
	public function delExam()
	{
		$delId=$_GET['id'];
		$checklist = new exam_Model;
		$checklist->delExam($delId);
		url::redirect("exam/viewAll");
	}
	//view exams qusetions
	function viewExamQuestion()
	{
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->type = "module";
		$viewHeader->render(TRUE);
		$ExamId=$_GET['id'];
		$view = new View('examQuestionView');
		$view->examId=$ExamId;
		$exam = new exam_Model;
		$view->examInfo=$exam->getExaminfo($ExamId);
		$view->CatRecords=$exam->getCat($ExamId);
		$view->Questions=$exam->getExamQuestions($ExamId);
		$view->render(TRUE);	
	}
	//save new category
	public function newCategory()
	{
		$view = new View('newCategory');
		$catId=isset($_GET['catId'])?$_GET['catId']:'';
		$exam = new exam_Model;
		$view->catName='';
		if($catId)
		{
			$view->catName=$exam->getCatInfo($catId);
		}
		if(count($_POST))
		{
			$examId=$_GET['id'];
			$exam->saveCat($examId,$catId);
		}		
		$view->render(TRUE);	
	}
	//delete exam category
	public function deleteCat()
	{
		$CatId=$_GET['CatId'];
		$examId=$_GET['examId'];
		$exam = new exam_Model;
		$exam->deleteCat($CatId,$examId);
		url::redirect("exam/viewExamQuestion?msg=Exam Category Deleted successfully&id=".$examId);
	}
	//exam publish
	public function publish()
	{
		$examId=$_GET['id'];
		$exam = new exam_Model;
		$exam->publish($examId);
		url::redirect("exam/viewExamQuestion?msg=Published successfully&id=".$examId);
	}
	//exam unpublish
	public function unpublish()
	{
		$examId=$_GET['id'];
		$exam = new exam_Model;
		$exam->unpublish($examId);
		url::redirect("exam/viewExamQuestion?msg=Un Published successfully&id=".$examId);
	}
	//for new exam question
	public function newExamQuest()
	{
		$view = new View('newExamquest');
		$exam = new exam_Model;
		$examId=$_GET['id'];
		$view->cat=$exam->getCat($examId);
		$view->examId=$examId;
		$itemId=isset($_GET['itemId'])?$_GET['itemId']:0;
		$view->itemId=$itemId;
		$view->itemCat='';
		$view->itemTitle="Title/Input/Question";
		$view->itemDesc="Description";
		$view->itemNext="";
		$view->itemSubmit="";
		$view->arrOptions=array();
		$view->mediatype='';
		$view->videoUrl='Video Link';
		$view->ipadlink='Ipad Link';
		$view->mediatitle='Media Title';
		$view->mediadetailtext='Media Description';
		if($itemId)
		{
			$result=$exam->getExamQuestionInfo($itemId);
			$view->itemCat=$result->category_id;
			$view->itemTitle=$result->question_title;
			$view->itemDesc=$result->question_desc;
			$view->itemNext=$result->question_mantetory;
			$view->arrOptions=$exam->getExamAns($itemId);
			$view->mediatype=$result->media_type;
			$view->videoUrl=!empty($result->media_value)?$result->media_value:'Video Link';
			$view->ipadlink=!empty($result->media_ipad_value)?$result->media_ipad_value:'Ipad Link';
			$view->mediatitle=!empty($result->media_title)?$result->media_title:'Media Title';
			$view->mediadetailtext=!empty($result->media_description)?$result->media_description:'Media Description';
		}
		if(count($_POST)>0)
		{
			$exam = new exam_Model;
			$exam->saveExamQuestions($examId,$itemId);
			
		}
		$view->render(TRUE);
	}
	//delete question
	public function deleteQuestion()
	{
		$examId=$_GET['examId'];
		$itemID=$_GET['itemId'];
		$exam = new exam_Model;
		$exam->deleteQuestion($examId,$itemID);
		url::redirect("exam/viewExamQuestion?msg=Exam Question Deleted successfully&id=".$examId);
	}
}

