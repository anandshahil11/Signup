<?php
/********************************************
AUTHOR:: Anand
Version:: 2.0
Date:: [9/March/11]
Page Description:: group Controller page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class group_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	

	function index()
	{
	/*	$view = new View('groupView');
		$company_id = 1;  //it will taken from analytics_user_information [company_id]
		$user = 'Anand';  //it will taken from analytics_user [username]
		$group = new  user_Model;
		$view->groupData = $group->getGroups($company_id);
		$view->user = $user;
		$view->companyid = $company_id;
		$view->render(TRUE);*/
	}
		
	function group($userid)
	{
		
		if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
		$view = new View('groupView');
		$view->type="group";
		$userLogin = new login_Model;
		$userInfo = $userLogin->getuserName($userid);
		$userCompanyid = $userLogin->getUsercompanyid($userid);
		$company_id = $userCompanyid;
		$user = $userInfo[0]->username;
		$group = new  user_Model;
		$view->groupData = $group->getGroups($company_id);
		$view->user = $user;
		$view->userid = $userid;
		$view->companyid = $company_id;
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view->render(TRUE);
		}
	}
	
	// To display user under a group
	public function viewDetailGroup()
	{
	    $groupid = $_GET['groupid'];
		$companyid = $_GET['companyid'];
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('groupuserView');
		$view->type="group";
		$userAll = new user_Model;
		$view->groupData = $userAll->editGroup($groupid);
        $view->usersData = $userAll->viewgroupUsers($groupid); 
        $view->companyid = $companyid;
        $view->userid = $_SESSION['user_object']->user_id; 		
	    $view->render(TRUE);
	}
	
	public function groupSetting()
	{
		$role = new role_Model;
		$view = new View('addusergroupView');
		$companyid = $_GET['companyid'];
		$groupid = $_GET['groupid'];
		$view->role = $role->getRoles();
		$user = new user_Model;
		$view->groupData = $user->getGroupData($companyid);
		$view->userGroup = $user->getUserId($groupid);
		$view->groupid = $groupid;
		$id = $_GET['id'];
		if($id =='setting' && count($_POST)>0)
		{		
			$arrData = $_POST;
			$arrData['grouplist']= array($groupid);
			$user = new user_Model;
			$user->addUserData($arrData,$companyid);
			echo '<script language="javascript">';
			echo 'parent.tb_remove();';
			echo "parent.location.href='".url::base(FALSE)."index.php/group/viewDetailGroup?companyid=$companyid&groupid=$groupid'";
			echo '</script>';
			exit;
		}	
		if($id !='setting')
		{   
		    $userid = $_GET['id'];
			$user = new user_Model;
			$userData = $user->getUserData($userid);
			$view->userData = $userData;
			$user_info_id = $userData[0]->user_info_id;
			$userInfo = $user->getUserInfo($user_info_id);
			$view->userRole = $user->getUserRole($userid);
			$view->userGroup = $user->getUserGroup($userid);
			$view->firstname = $userInfo[0]->firstname;
			$view->lastname = $userInfo[0]->lastname;
			$view->user_info_id = $user_info_id;
			$view->company = $userInfo[0]->company;
			$view->country = $userInfo[0]->country;
			$view->emailid = $userInfo[0]->emailid;
			if((count($_POST)>0 ) && isset($_POST['update']))
			{   
			    $firstname = $_POST['first_name'];
				$lastname = $_POST['last_name'];
				$emailid = $_POST['email'];
				$company = $_POST['company'];
				$country = $_POST['country'];
				$userid = $_GET['id'];
				if($_POST['rolelist'])
					$rolelist = $_POST['rolelist'];
				else
					$rolelist = $user->getUserRole($userid);			
				$res = $user->getGroupId($userid);
				$i =0 ;
				foreach($res as $row)
				{
					$grouplist[$i++] = $row->group_id;
				}
				$modified_date = date('Y-m-d H:m:s'); 
		        $arrData = array(
					"firstname" => $firstname,
					"lastname" => $lastname,
					"company" => $company,
					"emailid" => $emailid,
                    "country" => $country 					
					);
				$arrSet = array("id" => $user_info_id);	
				$user->updateUserData($arrData,$arrSet);
				$user->updateRoleData($rolelist,$userid);
				$user->updateGroupData($grouplist,$userid);
				echo '<script language="javascript">';
			    echo 'parent.tb_remove();';
			    echo "parent.location.href='".url::base(FALSE)."index.php/group/viewDetailGroup?companyid=$companyid&groupid=$groupid'";
			    echo '</script>';
			}
		}
		
		 $view->render(TRUE);	
	}
	
	
	function deleteGroupUser()
	{
		$userid = $_GET['userid'];
		$groupid = $_GET['groupid'];
		$companyid =$_GET['companyid'];
		$user = new  user_Model;
		$user->deleteUserrecord($userid);
		$view = new View('groupuserView');
		$view->type="group";
		$userAll = new user_Model;
		$view->groupData = $userAll->editGroup($groupid);
        $view->usersData = $userAll->viewUsers($groupid); 
		$view->companyid = $companyid;	
		url::redirect('group/viewDetailGroup?companyid='.$companyid.'&groupid='.$groupid.'&msg=Deleted successfully');		
	   
	}
	
	
	function deleteFullGroup()
	{
		$companyid = $_GET['companyid'];
		$groupid = $_GET['groupid'];
		
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		
		$group = new  user_Model;
		$group->deleteGroupUsers($groupid);
		$group->deleteGrouprecord($groupid);
		$view = new View('groupView');
		$view->type="group";
		$user = 'Anand';  //it will taken from analytics_user [username]
		$view->groupData = $group->getGroups($companyid);
		$view->user = $user;
		$view->userid = $_SESSION['user_object']->user_id;
		$view->companyid = $companyid;
		$view->render(TRUE);
		
	}
	
	function removeUserGroup()
	{
		$userid = $_GET['userid'];
		$groupid = $_GET['groupid'];
		$companyid =$_GET['companyid'];
		
		$user = new  user_Model;
		$user->removeUserrecord($userid ,$groupid);
		
		$view = new View('groupuserView');
		$view->type="group";
		$userAll = new user_Model;
		$view->groupData = $userAll->editGroup($groupid);
        $view->usersData = $userAll->viewUsers($groupid); 
		$view->companyid = $companyid;	
		url::redirect('group/viewDetailGroup?companyid='.$companyid.'&groupid='.$groupid.'&msg=Removed successfully');
	}
	
	public function exportUser()
	{
	    $companyid = $_GET['companyid'];
        $groupid = $_GET['groupid'];
		$check = $_GET['check'];
		$check = explode(',',$check);
		$userInfo = new user_Model;
		if($groupid == " ")
		{
			$userData = $userInfo->exportUsers($companyid ,$check);
		}
		if($groupid != " ")
		{
		    $userData = $userInfo->exportgroupUsers($groupid ,$check);
        }
		$count= count($userData);
		$csv_output = '';
		$csv_output = "First Name".", "."Last Name".", "."Company".", "."Username/EmailId".", "."Country".", "."Last Log-in".", ";
		$csv_output .= "\n";
		for($ii=0;$ii<$count;$ii++)
		{
		    if($userData[$ii]->last_login != "")
			{ 
			    $last_login = date("m/d/Y",$userData[$ii]->last_login); 
			}else
			{ 
			    $last_login = "-"; 
			}
			$csv_output .= $userData[$ii]->firstname.", ".$userData[$ii]->lastname.", ".$userData[$ii]->company.", ".$userData[$ii]->emailid.", ".$userData[$ii]->country.", ".$last_login.", ";
		    $csv_output .= "\n";
		}
		$csv_output .= "\n\n\n\n";
		$filename = "userdata"."_".date("Y-m-d_H-i",time());
        //Generate the CSV file header
		header("Content-type: application/vnd.ms-excel");
		header("Content-disposition: csv" . date("Y-m-d") . ".csv");
		header("Content-disposition: filename=".$filename.".csv");
        print $csv_output;
        exit;
		
		
	}

	
	public function importUser()
	{
	    $companyid = $_GET['companyid'];
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('importUserView');
		$view->type="importuser";
		$view->companyid = $companyid;
		$view->userid = $_SESSION['user_object']->user_id; 
		if(isset($_POST['submit']))
		{
			$insertUser = new user_Model;
			$result = $insertUser->importUser($_FILES,$companyid);
			$view ->response = $result;
			
		}else
		{
			$view ->response = "";
		}
		$view->render(TRUE);
	}
	
}	
	?>