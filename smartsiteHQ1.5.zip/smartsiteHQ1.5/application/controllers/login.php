<?php defined('SYSPATH') OR die('No direct access allowed.');
/********************************************
AUTHOR:: ANAND SHARMA
Version:: 1.0
Date:: 09-March-2011
Page Description::Login Controller [Default Controller]
*********************************************/
 
class Login_Controller extends Template_Controller 
{

	const ALLOW_PRODUCTION = FALSE;

	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
	}
	public function index()
	{ 
        $this->template->content = new View('login');
    }
     
	//main login function, return to User page if logged in with proper credential
	public function login($role="")
	{   
		
		if(!empty($_POST['username']))
		{
			$username=htmlspecialchars(trim(strtolower($_POST['username'])));
			$password=htmlspecialchars($_POST['password']);
			$userAccess = new login_Model;
			$useraccess=$userAccess->checkUsername($username);
			if($useraccess=='0')
			{

				$view = new View('login');
				$view->title = "<b><h3>Username or Password not found.</h3></b>";
				$this->template->content=$view;
			}else
			{   		
			    if($userAccess->login($username,$password))
				{
				    $access = $userAccess->getuserInfo($username);
					$_SESSION['user_object']= $access[0];
					$user_id = $access[0]->user_id;
					$user_info_id = $access[0]->user_info_id;
					$roleArr = $userAccess->getuserRole($user_id);
					if(in_array('admin',$roleArr))
					{
					    url::redirect("user/group/$user_id");
					}elseif(in_array('superadmin',$roleArr) )
					{
					    $company=$access->company;
						url::redirect("admin/index");
						
					}else
					{
						echo "<h3>You are General User.</h3>";
					}
					
				}else
				{ 
                    $view = new View('login');
					$view->title = "<b><h3>Username or Password not found.</h3></b>";
					$this->template->content=$view;
				}
			}

		}else
		{
			
			$view = new View('login');
			$view->name='test';
			$view->title = "<b><h3>Please Login.</h3></b>";
			$this->template->content=$view;
			
		}
	
	}
 
 
 
	public function logout()
	{ 	
	    $_COOKIE['kohanasession']="";
		url::redirect('login/index');
	}
  
 }