<?php
/********************************************
AUTHOR::Anand Sharma
Version:: 2.0
Date:: [13/May/11]
Page Description:: Resource uploader page
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class resource_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	
	public function createCategory()
	{
	    $resource = new resource_Model;
		$companyId = $_SESSION['user_object']->company_id;
		$groupList = $resource->getGroupList($companyId);
		$view = new View('addresourceCategory');
		$view->groupData = $groupList;
		$id = $_GET['id'];
		if($id =='setting' && count($_POST)>0)
		{		
			$arrData = $_POST;
			$resource->insertResourceCategory($arrData,$companyId);
			echo '<script language="javascript">';
			echo 'parent.tb_remove();';
			echo "parent.location.href='".url::base(FALSE)."index.php/resource/viewCategories/'";
			echo '</script>';
			exit;
		}
        if($id !='setting')
		{   
		    $category_id = $_GET['id'];
			$view->categoryname = $resource->getCategoryName($category_id);
			$view->categorygroupList = $resource->getGroups($category_id);
			if((count($_POST)>0 ) && isset($_POST['update']))
			{   
			    $arrData = $_POST;
			    $resource->updateResourceCategory($arrData,$companyId,$category_id);
				echo '<script language="javascript">';
			    echo 'parent.tb_remove();';
			    echo "parent.location.href='".url::base(FALSE)."index.php/resource/viewCategories/'";
			    echo '</script>';
			}
		}
		$view->render(TRUE);
        		
		
	}
	
	
	public function viewCategories()
	{
	    $viewHeader = new View('header');
		$viewHeader->role = "Admin";
		$viewHeader->type = "module";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$companyId = $_SESSION['user_object']->company_id;
		$resource = new resource_Model;
		$view = new View('viewCategories');
		$view->categoryList = $resource->getCategoryList($companyId);
		$view->companyid = $companyId; 
		$view->render(TRUE);
	}
	
	public function addResource()
	{
	    $companyId = $_SESSION['user_object']->company_id;
		$view = new View('addResourceItem');
		$resource = new resource_Model;
		$view->categoryList = $resource->getCategoryList($companyId);
		$id = $_GET['id'];
		if($id =='setting' && count($_POST)>0)
		{		
			$arrData = $_POST;
			$resource->insertResourceItem($arrData,$_FILES);
			echo '<script language="javascript">';
			echo 'parent.tb_remove();';
			echo "parent.location.href='".url::base(FALSE)."index.php/resource/viewResources/'";
			echo '</script>';
			exit;
		}	
		if($id !='setting')
		{   
		    $resource_id = $_GET['id'];
			$view->resourceData = $resource->getResourceinfo($resource_id);
			if((count($_POST)>0 ) && isset($_POST['update']))
			{   
			    
				$resource->updateResourceItem($_POST,$_FILES,$resource_id);
				echo '<script language="javascript">';
			    echo 'parent.tb_remove();';
			    echo "parent.location.href='".url::base(FALSE)."index.php/resource/viewResources/'";
			    echo '</script>';
			}
		}
		$view->render(TRUE);
	}
	
	
	public function viewResources()
	{
	    $viewHeader = new View('header');
		$viewHeader->role = "Admin";
		$viewHeader->type = "module";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$companyId = $_SESSION['user_object']->company_id;
		$view = new View('viewResourceItem');
		$resource = new resource_Model;
		if(isset($_GET['category_id']) AND $_GET['category_id']!="")
		{
		$view->resourceItemList = $resource->getresourceItemList($companyId,$_GET['category_id']);
		}else
		{
		$view->resourceItemList = $resource->getresourceItemList($companyId);
		}
		$view->companyid = $companyId; 
		$view->render(TRUE);
	    
	}
	
	public function deleteCategory()
	{
	    $category_id = $_GET['id'];
		$resource = new resource_Model;
		$resource->deleteCategory($category_id);
		$this->viewCategories();
	}
	
	public function deleteResourceItem()
	{
	    $item_id = $_GET['id'];
		$resource = new resource_Model;
		$resource->deleteResourceitem($item_id);
		$this->viewResources();
	
	}
	
	
	public function forwardEmail()
	{
	    include_once('Mail.php');
		include_once('Mail/mime.php');  
		$companyId = $_GET['companyid'];
		$view = new View('viewForwardMail');
		$view->sender = SENDER;
		$view->subject = SUBJECTFORWARDMAIL;
		$resource = new resource_Model;
		$resourceItemList = $resource->getresourceItemList($companyId);
		$html = "";
		$html.="<p><b><font color='#808080'><h1 style='font-size:18px;width:98%;margin-left:10px;margin-right:1px;'>Resource List</h1></font></b> </p>
	    <table  class='blue_zebra' style='table-layout:auto;width:98%;margin-left:10px;margin-right:1px;' >
            <thead >
            	<tr>
                	
					<th >Resource Title </th>
                	<th >Attached File</th>
					<th >Category </th>
					<th ># ofViews</th>
                	<th >Last Viewed</th>
                </tr>
			</thead>";	
			
			    $i=1;
				$num=0;
	    		foreach($resourceItemList as $row)
				{
					$num++;
					if($num%2==0)
					{
				        $html .= "<tr style='background-color:#aad2e2'>";
					}
					else
					{
			            $html .= "<tr style='background-color:#8ec3d8'>";		
					}
					
					$html .="<td >$row->item_name </td>";
					$html .="<td >".wordwrap($row->original_file_name,'40','<br/>',true);"</td>";
					$html .="<td >$row->category_name </td>";
					$html .="<td >$row->no_of_views</td>";
					if($row->last_viewed=="0000-00-00 00:00:00")
					{
					    $html .="<td  >-</td>";
					}else
					{
					    $last_update = date('m/d/y',strtotime($row->last_viewed));
					    $html .="<td  >$last_update</td>";
					}
					$html .="</tr>";
				}	
			    $html.="</table>";
				
		$view->html=$html;
		$view->message='';
		if(count($_POST)>0)
		{	
			$html.="<table style='background: #fff;height: 50px;width: 98%;'><tr><td style='margin-left:55%;margin-right:40%;'><a href='http://www.smartsitehq.com/smartsiteHQ1.5' target='_blank'>
		        <img  src='http://www.smartsitehq.com/smartsiteHQ1.5/media/img/logo_expandSmartSiteHQ.png' alt='Expand Smart Site logo' />
	            </a></td></tr></table>";
			$recipient=$_POST['to'];
			$sender=$_POST['from'];
			$subject=$_POST['subject'];
			$cc=$_POST['cc'];
			$bcc=$_POST['bcc'];
			$headers = array(
					  'From'          => $sender,
					  'Return-Path'   => $sender,
					  'Subject'       => $subject,
					  "Cc" => $cc,
					  "Bcc" => $bcc,
					);
			$crlf = "\n";
			$mime = new Mail_mime($crlf);
			$text = 'This is a text message.';  
			$mime->setTXTBody($text);
			$mime->setHTMLBody($html);
			$body = $mime->get();
			$headers = $mime->headers($headers);
			$mail =& Mail::factory('mail');
			$result=$mail->send($recipient, $headers, $body);
			if($result==1){
			$view->message = "<h3>Contact has been Emailed.</h3>";
			}else{
			$view->message = "<h3>Email has some Error.</h3>";
			}
		}
		$view->render(TRUE);
	}
	
	
	public function exportResource()
	{
		$companyId = $_GET['companyid'];
		$resource = new resource_Model;
		$resourceItemList = $resource->getresourceItemList($companyId);
		$count= count($resourceItemList);
		//echo '$count'.$count;exit;
		$csv_output = '';
		$csv_output = "Resource Title".", "."Attached File".", "."Category".", "."# ofViews".", "."Last Viewed".", ";
		$csv_output .= "\n";
		foreach($resourceItemList as $row)
		{
			if($row->last_viewed=="0000-00-00 00:00:00")
			{
			    $last_update = "-";
			}else
			{
			    $last_update = date('m/d/y',strtotime($row->last_viewed));
			}
			$csv_output .= $row->item_name.",".$row->original_file_name.",".$row->category_name.",".$row->no_of_views.",".$last_update.",";
		    $csv_output .= "\n";
		}
		$csv_output .= "\n\n\n\n";
		$filename = "ResourceList"."_".date("Y-m-d_H-i",time());
        //Generate the CSV file header
		header("Content-type: application/vnd.ms-excel");
		header("Content-disposition: csv" . date("Y-m-d") . ".csv");
		header("Content-disposition: filename=".$filename.".csv");
        print $csv_output;
        exit;

	}
}	