<?php
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [24/Feb/11]
Page Description:: user Controller page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class user_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	function index()
	{
		/*$view = new View('groupView');
		$company_id = 1;  //it will taken from analytics_user_information [company_id]
		$user = 'Anand';  //it will taken from analytics_user [username]
		$group = new  user_Model;
		$view->groupData = $group->getGroups($company_id);
		$view->user = $user;
		$view->companyid = $company_id;
		$view->render(TRUE);*/
	}
	
	function group($userid)
	{
		
		if(empty($_COOKIE['kohanasession'])){ url::redirect();}
	    else{
			$view = new View('groupView');
			$view->type="group";
			$userLogin = new login_Model;
			$userInfo = $userLogin->getuserName($userid);
			$userCompanyid = $userLogin->getUsercompanyid($userid);
			$company_id = $userCompanyid;
			$user = $userInfo[0]->username;
			$group = new  user_Model;
			$view->groupData = $group->getGroups($company_id);
			$view->user = $user;
			$view->userid = $userid;
			$view->companyid = $company_id;
			$viewHeader = new View('header');
			$viewHeader->role="Admin";
			$viewHeader->userid = $_SESSION['user_object']->user_id;
			$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
			$viewHeader->render(TRUE);
			$view->render(TRUE);
		}
	}
	
	function deleteGroup($companyid,$userid)
	{
		$groupid = $_GET['groupid'];
		$group = new  user_Model;
		$group->deleteGroupUsers($groupid);
		$group->deleteGrouprecord($groupid);
		$view = new View('groupView');
		$view->type="group";	
		$userLogin = new login_Model;
		$userInfo = $userLogin->getuserName($userid);
		$user = $userInfo[0]->username;
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view->groupData = $group->getGroups($companyid);
		$view->user = $user;
		$view->userid = $userid;
		$view->companyid = $companyid;
		$view->render(TRUE);
		
	}
	
	
	public function setting()
	{
		$rec = new group_Model;
		$view = new View('groupAddView');
		$view->groups = $rec->getGroups();	
		$id = $_GET['id'];
		$user = $_GET['user'];
		$companyid = $_GET['companyid'];
		$userid = $_GET['userid'];
		$userList = new user_Model;
		$userAdminList = $userList->getUserAdminList($companyid);
		$view->userAdminList = $userAdminList;
		if($id =='setting' && count($_POST)>0)
		{		
			
			$user = new user_Model;
			$groupname = $_POST['groupName'];
			if(isset($_POST['adminList'])&& !empty($_POST['adminList']))
			{
			    $userAdminName = $user->adminName($_POST['adminList']);
				$groupmanager = $userAdminName;
			}else
			{
			    $groupmanager = $_POST['groupManager'];
			}
			$companyid = $_POST['companyId'];
			$groupdesc = $_POST['groupDesc'];
			$category = $_POST['category'];
			$created_date = date('Y-m-d H:m:s');
			$arrData = array(
				"group_name" => $groupname ,
				"group_manager"=>$groupmanager,
				"group_category" => $category,
				"group_description" => $groupdesc,
				"created_on" => $created_date
				);
			$user->addGroup($arrData,$companyid);
			echo '<script language="javascript">';
			echo 'parent.tb_remove();';
			echo "parent.location.href='".url::base(FALSE)."index.php/user/group/$userid'";
			echo '</script>';
			exit;
		}	
		
		if($id !='setting')
		{   
		    $id = $_GET['id'];
			$group = new user_Model;
			$data = $group->editGroup($id);	
			$view->groupname = $data[0]->group_name;
			$view->category = $data[0]->group_category;
			$view->groupmanager = $data[0]->group_manager;
			$view->groupdesc = $data[0]->group_description;
			if((count($_POST)>0 ) && isset($_POST['update']))
			{   
			    $groupName = $_POST['groupName'];
				$groupCategory = $_POST['category'];
				$groupDesc = $_POST['groupDesc'];
				if(isset($_POST['adminList'])&& !empty($_POST['adminList']))
				{
					$userAdminName = $group->adminName($_POST['adminList']);
					$groupmanager = $userAdminName;
				}else
				{
					$groupmanager = $_POST['groupManager'];
				}
				$id = $_GET['id'];
				$modified_date = date('Y-m-d H:m:s'); 
		        $arrData = array(
					"group_name" => $groupName,
					"group_manager"=>$groupmanager,
					"group_category" => $groupCategory,
					"group_description" => $groupDesc,
                    "created_on" => $modified_date 					
					);
				$arrSet = array("group_id" => $id);	
				$group->updateGroup($arrData,$arrSet);
				echo '<script language="javascript">';
			    echo 'parent.tb_remove();';
			    echo "parent.location.href='".url::base(FALSE)."index.php/user/group/$userid'";
			    echo '</script>';
			}
		}
		$view->render(TRUE);	
	}
	
	
	public function viewUsers($userid,$companyid)
	{   
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('alluserView');
		$view->type="user";
		$userAll = new user_Model;
        $view->usersData = $userAll->viewUsers($companyid); 
        $view->companyid = $companyid;
		$view->userid = $userid;
        $view->render(TRUE);
	}
	
	function deleteUser($adminid,$companyid)
	{
		$userLogin = new login_Model;
		$userInfo = $userLogin->getuserName($adminid);
		$user = $userInfo[0]->username;
		$viewHeader = new View('header');
		$viewHeader->role = "Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$userid = $_GET['userid'];
		$user = new  user_Model;
		$user->deleteUserrecord($userid);
		$view = new View('alluserView');
		$userAll = new user_Model;
        $view->usersData = $userAll->viewUsers($companyid); 
        $view->companyid = $companyid;
        $view->userid = $adminid;
        $view->type = "user";		
	    $view->render(TRUE);
	}
	
	public function userSetting()
	{
		$role = new role_Model;
		$view = new View('adduserView');
		$companyid = $_GET['companyid'];
		$adminid = $_GET['userid'];
		$view->userid = $adminid;
		$view->type = "adduser";
		$view->companyid = $companyid;
		$view->role = $role->getRoles();
		$user = new user_Model;
		$view->groupData = $user->getGroupData($companyid);
		$id = $_GET['id'];
		if($id =='setting' && count($_POST)>0)
		{		
			$arrData = $_POST;
			$user = new user_Model;
			$user->addUserData($arrData,$companyid);
			echo '<script language="javascript">';
			echo 'parent.tb_remove();';
			echo "parent.location.href='".url::base(FALSE)."index.php/user/viewUsers/$adminid/$companyid'";
			echo '</script>';
			exit;
		}	
		if($id !='setting')
		{   
		    $userid = $_GET['id'];
			$user = new user_Model;
			$userData = $user->getUserData($userid);
			$view->userData = $userData;
			$user_info_id = $userData[0]->user_info_id;
			$userInfo = $user->getUserInfo($user_info_id);
			$view->userRole = $user->getUserRole($userid);
			$view->userGroup = $user->getUserGroup($userid);
			$view->firstname = $userInfo[0]->firstname;
			$view->lastname = $userInfo[0]->lastname;
			$view->user_info_id = $user_info_id;
			$view->company = $userInfo[0]->company;
			$view->country = $userInfo[0]->country;
			$view->emailid = $userInfo[0]->emailid;
			if((count($_POST)>0 ) && isset($_POST['update']))
			{   
			    $firstname = $_POST['first_name'];
				$lastname = $_POST['last_name'];
				$emailid = $_POST['email'];
				$company = $_POST['company'];
				$country = $_POST['country'];
				$userid = $_GET['id'];
				$rolelist = $_POST['rolelist'];
				$grouplist = $_POST['grouplist'];
				$modified_date = date('Y-m-d H:m:s'); 
		        $arrData = array(
					"firstname" => $firstname,
					"lastname" => $lastname,
					"company" => $company,
					"emailid" => $emailid,
                    "country" => $country 					
					);
				$arrSet = array("id" => $user_info_id);	
				$user->updateUserData($arrData,$arrSet);
				$user->updateRoleData($rolelist,$userid);
				$user->updateGroupData($grouplist,$userid);
				echo '<script language="javascript">';
			    echo 'parent.tb_remove();';
			    echo "parent.location.href='".url::base(FALSE)."index.php/user/viewUsers/$adminid/$companyid'";
			    echo '</script>';
			}
		}
		$view->render(TRUE);	
	}
	
	public function checkEmail()
	{
	    if(isset($_POST["email"]))
		{
		    $emailid = $_POST["email"];
		    $user = new user_Model;
		    $response = $user->checkUserName($emailid);
			if($response >0)
			{
			    echo 0;
			}else
			{
			    echo 1;
			}
		   
	    }
	}
	
	
	public function viewUserGroup()
	{
	    $userid = $_GET['userid'];
		
	}
	
	
	public function rightuserPane()
	{
		if(isset($_POST["userid"]))
		{
			$userid = $_POST["userid"];
		}
		if(isset($_POST["companyid"]))
		{
		  $companyid=$_POST["companyid"];
		}
		if(isset($_POST["action"]))
		{
			$action = $_POST["action"];
		}
		$view = new View('rightuserPane');
		if(isset($_POST["userid"]))
		{
		    $view->id = $userid;
		}
		if(isset($_POST["companyid"]))
		{
		    $view->companyid = $companyid;
		}
		if($action==="none")
		{
			$user_Info = new User_Information_Model;
			$userInfo = $user_Info->getuserInformation($userid);
			$userExamResult = $user_Info->getuserExamresult($userid);
			$view->firstname = $userInfo[0]->firstname;
			$view->lastname = $userInfo[0]->lastname; 
			$userLogin = $user_Info->getuserlastLogin($userid);
			$view->userLoginNum = $userLogin[0]->logins;
			$view->userLastlogin = $userLogin[0]->last_login;
            $view->userExamResult = $userExamResult;
            $view->userid = $userid; 			
		}
		$view->render(TRUE);
	}
	
	public function moduleSummary()
	{
	    $view = new View('modulesummaryView');
		if(isset($_GET['userid']))
		{
		    $userid = $_GET['userid'];
		}
		$user_Info = new User_Information_Model;
		$userInfo = $user_Info->getuserInformation($userid);
		$userExamResult = $user_Info->getuserExamresult($userid);
		$view->firstname = $userInfo[0]->firstname;
		$view->lastname = $userInfo[0]->lastname;
		$view->userExamResult = $userExamResult;
		$view->userid = $userid;
		$view->render(TRUE);
	}
	
	public function getModuleDetails()
	{
	    if(isset($_GET['userid']))
		{
		    $userid = $_GET['userid'];
		}
		if(isset($_GET['examid']))
		{
		    $examid = $_GET['examid'];
		}
		$user_Info = new User_Information_Model;
		$userExamResult = $user_Info->getuserExamresult($userid);
		$userEachExamResult = $user_Info->geteachExamResult($userid,$examid);
		$view = new View('divsummaryView');
		$view->userExamResult = $userExamResult;
		$view->userEachExamResult = $userEachExamResult;
		$view->userid = $userid;
		$view->render(TRUE);
	}
	
	public function getModuleQuesDetails()
	{
	    if(isset($_GET['userid']))
		{
		    $userid = $_GET['userid'];
		}
		if(isset($_GET['examid']))
		{
		    $examid = $_GET['examid'];
		}
        $user_Info = new User_Information_Model;
        $userEachExamResult = $user_Info->geteachExamResult($userid,$examid);
		$sessionid = $userEachExamResult['session_id'];
		$userAnswerList = $user_Info->getuserQuesAnswerList($userid,$examid,$sessionid);
		$ques_ans_list = $user_Info->getQuesAnsSet($examid);
		$count = count($ques_ans_list);
		$eachQuesResponse = array();
		for($index=0;$index<$count;$index++)
		{
		    $quesid = $ques_ans_list[$index]['quesid'];
            $eachQuesResponse[$index] = $user_Info->getAnsSelect($examid,$quesid);
        }
		$view = new View('divsummaryQuesView');
		$view->userEachExamResult = $userEachExamResult;
		$view->ques_ans_list = $ques_ans_list;
		$view->userAnswerList = $userAnswerList;
		$view->eachQuesResponse = $eachQuesResponse;
		$view->userid = $userid;
		$view->render(TRUE);		
	}
	
}	