<?php
/********************************************
AUTHOR:: Anand
Version:: 1.0
Date:: 15-Mar-2011
Page Description:: User Data Edit Controller
*********************************************/

class UserEdit_Controller extends Controller {
    function __construct(){
	    parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	
   
	function delete($id,$companyid){
		$user_Info = new User_Information_Model;
		$userid = $_SESSION['user_object']->user_id;
		$userUpdate = $user_Info->deleteuserInformation($id);
		url::redirect('user/viewUsers/'.$userid.'/'.$companyid);
	
	}
		
		
	function deleteGroupUser($companyid,$id,$groupid)
	{
		$user = new  user_Model;
		$user->deleteUserrecord($id);
		url::redirect('group/viewDetailGroup?companyid='.$companyid.'&groupid='.$groupid.'&msg=Deleted successfully');
	}
}