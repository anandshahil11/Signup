<?php
/********************************************
AUTHOR:: Anand
Version:: 2.0
Date:: [18/March/11]
Page Description:: user search page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class userSearch_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	
	//To Serach User
	function search()
	{
		$companyid = $_GET['companyid'];
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('usersearchView');
		$view->type="search";
		$view->companyid = $companyid;
        $view->userid = $_SESSION['user_object']->user_id; 	
		$user = new usersearch_Model;
		$result= $user->getchecklist();
		$checklist = array();
		foreach($result as $item)
		{
			$checklist['checklist-'.$item->checklist_id] = 'Checklist- '.$item->checklist_name;
		}
		$primarylist = array('Profile Data'=>"Profile Data",'checklist'=>$checklist);
		$data_count = 0;
		foreach($primarylist as $val)
		{
			if(is_array($val))
			{
				$arr_count=count($val);
			}
			else
				$data_count++;
		}
		$plistcount = $arr_count+$data_count;
		$view->newlist =array();
		$view->primarylist = $primarylist;
		$view->count = $plistcount;
       	$view->render(TRUE);
	}
	
	
	function getfieldList()
	{
		$criteriaId = $_GET['criteriaId'];
		$selectedValue=isset($_GET['selectedValue'])?$_GET['selectedValue']:'';
		$primarytype = explode('-',$criteriaId);
		$selected_arr = explode(':',$selectedValue);
		$view = new View('usersearchView');
		if(count($selected_arr))
		{
			foreach($selected_arr as $val)
			{
				$temp[$val]=$val;
			}
		}
		
		switch($primarytype[0])
		{
			case 'Profile Data': $result=array('firstname'=>'Firstname','lastname'=>'Lastname','emailid'=>'Email','company'=>'Company','country'=>'Country');
								 if(count($selected_arr))
								 {
									$result = array_diff_key($result,$temp);
								 }
								 
								 break;
			case 'checklist' : $user = new userSearch_Model;
							   $id = $primarytype[1];
							   $result = $user->getchecklistdetails($id);
							   if(count($selected_arr))
							   {
									$result = array_diff_key($result,$temp);
							   } 
							   break;
			default: break;
		}
		
		$view->count =count($result);
		echo '<option value="" >Select</option>';
		foreach($result as $key => $value)
		{
			echo '<option value="'.$key.'" >'.$value.'</option>';
		}			
	
	}
	
	
	
	function getvalueList()
	{
		$criteriaId=$_GET['criteriaId'];
		$field = $_GET['field'];
		$cri = isset($_GET['Cri']) ? $_GET['Cri'] :'';
		$primarytype = explode('-',$criteriaId);
		if($primarytype[0] == 'Profile Data' )
		{
			switch($field)
			{
				case 'country':$value=array(
								'USA'=>'United States',
								'Afghanistan'=>'Afghanistan',
								'Albania'=>'Albania',
								'Algeria'=>'Algeria',
								'American Samoa'=>'American Samoa',
								'Andorra'=>'Andorra',
								'Angola'=>'Angola',
								'Anguilla'=>'Anguilla',
								'Antarctica'=>'Antarctica',
								'Antigua and Barbuda'=>'Antigua and Barbuda',
								'Argentina'=>'Argentina',
								'Armenia'=>'Armenia',
								'Aruba'=>'Aruba',
								'Australia'=>'Australia',
								'Austria'=>'Austria',
								'Azerbaijan'=>'Azerbaijan',
								'Bahamas'=>'Bahamas',
								'Bahrain'=>'Bahrain',
								'Bangladesh'=>'Bangladesh',
								'Barbados'=>'Barbados',
								'Belarus'=>'Belarus',
								'Belgium'=>'Belgium',
								'Belize'=>'Belize',
								'Benin'=>'Benin',
								'Bermuda'=>'Bermuda',
								'Bhutan'=>'Bhutan',
								'Bolivia'=>'Bolivia',
								'Bosnia and Herzegowina'=>'Bosnia and Herzegowina',
								'Botswana'=>'Botswana',
								'Bouvet Island'=>'Bouvet Island',
								'Brazil'=>'Brazil',
								'British Indian Ocean Territory'=>'British Indian Ocean Territory',
								'Brunei Darussalam'=>'Brunei Darussalam',
								'Bulgaria'=>'Bulgaria',
								'Burkina Faso'=>'Burkina Faso',
								'Burundi'=>'Burundi',
								'Cambodia'=>'Cambodia',
								'Cameroon'=>'Cameroon',
								'Canada'=>'Canada',
								'Cape Verde'=>'Cape Verde',
								'Cayman Islands'=>'Cayman Islands',
								'Central African Republic'=>'Central African Republic',
								'Chad'=>'Chad',
								'Chile'=>'Chile',
								'China'=>'China',
								'Christmas Island'=>'Christmas Island',
								'Cocos (Keeling) Islands'=>'Cocos (Keeling) Islands',
								'Colombia'=>'Colombia',
								'Comoros'=>'Comoros',
								'Congo'=>'Congo',
								'Congo, the Democratic Republic '=>'Congo, the Democratic Republic',
								'Cook Islands'=>'Cook Islands',
								'Costa Rica'=>'Costa Rica',
								'Cote d\'Ivoire'=>'Cote d\'Ivoire',
								'Croatia (Hrvatska)'=>'Croatia (Hrvatska)',
								'Cuba'=>'Cuba',
								'Cyprus'=>'Cyprus',
								'Czech Republic'=>'Czech Republic',
								'Denmark'=>'Denmark',
								'Djibouti'=>'Djibouti',
								'Dominica'=>'Dominica',
								'Dominican Republic'=>'Dominican Republic',
								'East Timor'=>'East Timor',
								'Ecuador'=>'Ecuador',
								'Egypt'=>'Egypt',
								'El Salvador'=>'El Salvador',
								'Equatorial Guinea'=>'Equatorial Guinea',
								'Eritrea'=>'Eritrea',
								'Estonia'=>'Estonia',
								'Ethiopia'=>'Ethiopia',
								'Falkland Islands (Malvinas)'=>'Falkland Islands (Malvinas)',
								'Faroe Islands'=>'Faroe Islands',
								'Fiji'=>'Fiji',
								'Finland'=>'Finland',
								'France'=>'France',
								'France, Metropolitan'=>'France, Metropolitan',
								'French Guiana'=>'French Guiana',
								'French Polynesia'=>'French Polynesia',
								'French Southern Territories'=>'French Southern Territories',
								'Gabon'=>'Gabon',
								'Gambia'=>'Gambia',
								'Georgia'=>'Georgia',
								'Germany'=>'Germany',
								'Ghana'=>'Ghana',
								'Gibraltar'=>'Gibraltar',
								'Greece'=>'Greece',
								'Greenland'=>'Greenland',
								'Grenada'=>'Grenada',
								'Guadeloupe'=>'Guadeloupe',
								'Guam'=>'Guam',
								'Guatemala'=>'Guatemala',
								'Guinea'=>'Guinea',
								'Guinea-Bissau'=>'Guinea-Bissau',
								'Guyana'=>'Guyana',
								'Haiti'=>'Haiti',
								'Heard and Mc Donald Islands'=>'Heard and Mc Donald Islands',
								'Holy See (Vatican City State)'=>'Holy See (Vatican City State)',
								'Honduras'=>'Honduras',
								'Hong Kong'=>'Hong Kong',
								'Hungary'=>'Hungary',
								'Iceland'=>'Iceland',
								'India'=>'India',
								'Indonesia'=>'Indonesia',
								'Iran (Islamic Republic of)'=>'Iran (Islamic Republic of)',
								'Iraq'=>'Iraq',
								'Ireland'=>'Ireland',
								'Israel'=>'Israel',
								'Italy'=>'Italy',
								'Jamaica'=>'Jamaica',
								'Japan'=>'Japan',
								'Jordan'=>'Jordan',
								'Kazakhstan'=>'Kazakhstan',
								'Kenya'=>'Kenya',
								'Kiribati'=>'Kiribati',
								'Korea, Democratic People\'s Republic of'=>'Korea, Democratic People\'s Republic of',
								'Korea, Republic of'=>'Korea, Republic of',
								'Kuwait'=>'Kuwait',
								'Kyrgyzstan'=>'Kyrgyzstan',
								'Lao People\'s Democratic Republic'=>'Lao People\'s Democratic Republic',
								'Latvia'=>'Latvia',
								'Lebanon'=>'Lebanon',
								'Lesotho'=>'Lesotho',
								'Liberia'=>'Liberia',
								'Libyan Arab Jamahiriya'=>'Libyan Arab Jamahiriya',
								'Liechtenstein'=>'Liechtenstein',
								'Lithuania'=>'Lithuania',
								'Luxembourg'=>'Luxembourg',
								'Macau'=>'Macau',
								'Macedonia, The Former Yugoslav Republic of'=>'Macedonia, The Former Yugoslav Republic of',
								'Madagascar'=>'Madagascar',
								'Malawi'=>'Malawi',
								'Malaysia'=>'Malaysia',
								'Maldives'=>'Maldives',
								'Mali'=>'Mali',
								'Malta'=>'Malta',
								'Marshall Islands'=>'Marshall Islands',
								'Martinique'=>'Martinique',
								'Mauritania'=>'Mauritania',
								'Mauritius'=>'Mauritius',
								'Mayotte'=>'Mayotte',
								'Mexico'=>'Mexico',
								'Micronesia, Federated States of'=>'Micronesia, Federated States of',
								'Moldova, Republic of'=>'Moldova, Republic of',
								'Monaco'=>'Monaco',
								'Mongolia'=>'Mongolia',
								'Montserrat'=>'Montserrat',
								'Morocco'=>'Morocco',
								'Mozambique'=>'Mozambique',
								'Myanmar'=>'Myanmar',
								'Namibia'=>'Namibia',
								'Nauru'=>'Nauru',
								'Nepal'=>'Nepal',
								'Netherlands'=>'Netherlands',
								'Netherlands Antilles'=>'Netherlands Antilles',
								'New Caledonia'=>'New Caledonia',
								'New Zealand'=>'New Zealand',
								'Nicaragua'=>'Nicaragua',
								'Niger'=>'Niger',
								'Nigeria'=>'Nigeria',
								'Niue'=>'Niue',
								'Norfolk Island'=>'Norfolk Island',
								'Northern Mariana Islands'=>'Northern Mariana Islands',
								'Norway'=>'Norway',
								'Oman'=>'Oman',
								'Pakistan'=>'Pakistan',
								'Palau'=>'Palau',
								'Panama'=>'Panama',
								'Papua New Guinea'=>'Papua New Guinea',
								'Paraguay'=>'Paraguay',
								'Peru'=>'Peru',
								'Philippines'=>'Philippines',
								'Pitcairn'=>'Pitcairn',
								'Poland'=>'Poland',
								'Portugal'=>'Portugal',
								'Puerto Rico'=>'Puerto Rico',
								'Qatar'=>'Qatar',
								'Reunion'=>'Reunion',
								'Romania'=>'Romania',
								'Russian Federation'=>'Russian Federation',
								'Rwanda'=>'Rwanda',
								'Saint Kitts and Nevis'=>'Saint Kitts and Nevis',
								'Saint LUCIA'=>'Saint LUCIA',
								'Saint Vincent and the Grenadines'=>'Saint Vincent and the Grenadines',
								'Samoa'=>'Samoa',
								'San Marino'=>'San Marino',
								'Sao Tome and Principe'=>'Sao Tome and Principe',
								'Saudi Arabia'=>'Saudi Arabia',
								'Senegal'=>'Senegal',
								'Seychelles'=>'Seychelles',
								'Sierra Leone'=>'Sierra Leone',
								'Singapore'=>'Singapore',
								'Slovakia (Slovak Republic)'=>'Slovakia (Slovak Republic)',
								'Slovenia'=>'Slovenia',
								'Solomon Islands'=>'Solomon Islands',
								'Somalia'=>'Somalia',
								'South Africa'=>'South Africa',
								'South Georgia and the South Sandwich Islands'=>'South Georgia and the South Sandwich Islands',
								'Spain'=>'Spain',
								'Sri Lanka'=>'Sri Lanka',
								'St. Helena'=>'St. Helena',
								'St. Pierre and Miquelon'=>'St. Pierre and Miquelon',
								'Sudan'=>'Sudan',
								'Suriname'=>'Suriname',
								'Svalbard and Jan Mayen Islands'=>'Svalbard and Jan Mayen Islands',
								'Swaziland'=>'Swaziland',
								'Sweden'=>'Sweden',
								'Switzerland'=>'Switzerland',
								'Syrian Arab Republic'=>'Syrian Arab Republic',
								'Taiwan, Province of China'=>'Taiwan, Province of China',
								'Tajikistan'=>'Tajikistan',
								'Tanzania, United Republic of'=>'Tanzania, United Republic of',
								'Thailand'=>'Thailand',
								'Togo'=>'Togo',
								'Tokelau'=>'Tokelau',
								'Tonga'=>'Tonga',
								'Trinidad and Tobago'=>'Trinidad and Tobago',
								'Tunisia'=>'Tunisia',
								'Turkey'=>'Turkey',
								'Turkmenistan'=>'Turkmenistan',
								'Turks and Caicos Islands'=>'Turks and Caicos Islands',
								'Tuvalu'=>'Tuvalu',
								'Uganda'=>'Uganda',
								'Ukraine'=>'Ukraine',
								'UAE'=>'United Arab Emirates',
								'UK'=>'United Kingdom',
								'Uruguay'=>'Uruguay',
								'Uzbekistan'=>'Uzbekistan',
								'Vanuatu'=>'Vanuatu',
								'Venezuela'=>'Venezuela',
								'Viet Nam'=>'Viet Nam',
								'Virgin Islands (British)'=>'Virgin Islands (British)',
								'Virgin Islands (U.S.)'=>'Virgin Islands (U.S.)',
								'Wallis and Futuna Islands'=>'Wallis and Futuna Islands',
								'Western Sahara'=>'Western Sahara',
								'Yemen'=>'Yemen',
								'Yugoslavia'=>'Yugoslavia',
								'Zambia'=>'Zambia',
								'Zimbabwe'=>'Zimbabwe');
								break;
				case 'company': $user = new userSearch_Model;
								$value= $user->getfieldlist('company');
								break;
				case 'firstname':$user = new userSearch_Model;
								 $value= $user->getfieldlist('firstname');
								 break;
				case 'lastname':$user = new userSearch_Model;
								 $value= $user->getfieldlist('lastname'); 
								break;
				case 'emailid' : $user = new userSearch_Model;
								 $value= $user->getfieldlist('emailid' );
								break;
			}
			$type=''; 
		}	
		if($primarytype[0]=='checklist')
		{
			$id = $_GET['field'];
			$user = new userSearch_Model;
			$type = $user->getItemtype($id);
			$PType = $user->getItemProfileType($id);
			if($type=='Multiple Selection')
			$value= $user->getMultipleTypeItems($id);	
			if($type=='User Data' and $PType=='Name')
			$value= $user->getCheckListUser($id);
			else
			$value= $user->getItems($id);	
		}
			echo'<option value="" >Select</option>';
			foreach($value as $key => $value)
			{
				if($type =='Date')
				{	
					$value=intval($value);
					echo '<option value="'.date("m/d/Y",$value).'"  >'.date("m/d/Y",$value) .'</option>';
				}
				else
					echo '<option value="'.$key.'" >'.$value.'</option>';
			}
		if($primarytype[0]=='checklist' && $cri =='Is Within')
		{
			echo'<option value="">Select</option>';
			foreach($value as $key => $value)
			{
				if($type =='Date')
					echo '<option value="'.date("m/d/Y",$value).'" >'.date("m/d/Y",$value) .'</option>';
				else
					echo '<option value="'.$key.'" >'.$value.'</option>';
			}

		}
			
		
	}
	
	function getDatas()
	{
		$criteriaId=$_GET['criteriaId'];
		$criteria['Cri']=isset($_GET['Cri'])?$_GET['Cri']:'';
		$detailVal=isset($_GET['detailVal'])?$_GET['detailVal']:'';
		$datef=isset($_GET['datef'])?$_GET['datef']:'';
		$datet=isset($_GET['datet'])?$_GET['datet']:'';
	
		$field=isset($_GET['field'])?$_GET['field']:'';
		$list = explode(':',$criteriaId);
		$criteria = explode(':',$criteria['Cri']);
		//print_r($criteria);exit;
		$detailVal = explode(':',$detailVal);
		$field = explode(':',$field);
		/*foreach($list as $value) {
			$crid_arr[$value] =$value;
		}*/
		//print_r($dVal_arr); exit;
		$user = new userSearch_Model;
		$totalusers = $user->totalusers();
		$results=$user->getDatas($list,$field,$criteria,$detailVal,$datef,$datet);
		header("content-type: text/xml");
		echo '<datas>';
		$rowCount=0;
		foreach($results as $row)
		{
			$rowCount++;
			if($row->last_login )
				$timestamp = date('Y-m-d',$row->last_login);
			else
				$timestamp= "-";
			echo '<rows>';
			echo '<FirstName>'.wordwrap($row->firstname,6,"<br/>\n",true).'</FirstName>';
			echo '<LastName>'.wordwrap($row->lastname,6,"<br/>\n",true).'</LastName>';
			echo '<Company>'.wordwrap($row->company,5,"<br/>\n",true).'</Company>';
			echo '<Email>'.wordwrap($row->emailid,18,"<br/>\n",true).'</Email>';
			echo '<Country>'.wordwrap($row->country,8,"<br/>\n",true).'</Country>';
			echo '<LastLogin>'.$timestamp.'</LastLogin>';
			echo '<id>'.$row->id.'</id>';
			echo '</rows>';
			
			
		}
		echo '<rowcount>'.$rowCount.'/'.$totalusers.'</rowcount>';
		echo '</datas>';
		exit;
	}
	
	//search for user
	function userLib()
	{
		$companyid = $_GET['companyid'];
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('userlibView');
		$view->companyid = $companyid;
        $view->userid = $_SESSION['user_object']->user_id; 
		define('SEARCHMESSAGE','No Result Found for');
		if(isset($_POST['submit'])){
			$search = addslashes(strip_tags(@$_POST['search']));
			$trimmedSearch = trim($search); 
			$trimmedSearch_array = explode(" ",$trimmedSearch);
            if (!isset($search)){
				$resultmsg =  "<p>Search Error..We don't seem to have a search parameter! </p>" ;			  
			}
			$usersearch_Info = new userSearch_Model;
			$usersearchInfo =  $usersearch_Info->getusersearchInformation($companyid,$trimmedSearch_array);
			$userInfo = $usersearchInfo;
			$count = count($userInfo);
			if($count>0){
				$view->usersData = $userInfo ;
			}else{
				$view->usersData = array();
				$view->searchResult = "<h3>".SEARCHMESSAGE." $search</h3>";
			}
					
		}
		else{
			$trimmedSearch_array = $_SESSION['search'];
			$usersearch_Info = new userSearch_Model;
			$usersearchInfo =  $usersearch_Info->getusersearchInformation($companyid,$trimmedSearch_array);
			$userInfo = $usersearchInfo;
			$count = count($userInfo);
			if($count>0){
				$view->usersData = $userInfo ;
			}else{
				$view->usersData = array();
				$view->searchResult = "<h3>".SEARCHMESSAGE." $search</h3>";
			}
		}
		$view->render(TRUE);
       
	}
	function changeoption()
	{
		$criteriaId=$_GET['criteriaId'];
		$primarytype = explode('-',$criteriaId);
		if($primarytype[0] == "Profile Data")
			$arr = array('Is','Is Not','Contains','Begins With','Ends With');
		if($primarytype[0] == "checklist")
		{
			$id = $_GET['item'];
			$user = new userSearch_Model;
			$res = $user->getItemtype($id);
			switch($res)
			{
				case 'Number':$arr = array('Equals','Doesn\'t Equals','Greater Than','Less Than');
									 break;
				case 'Text Entry':$arr = array('Is','Is Not','Contains','Begins With','Ends With');
									 break;	
				case 'Date':$arr = array('Is Exactly','Is Within','Is Before','Is After');
									 break;	
				case 'Multiple Selection'://$arr = array('Is Correct','Is Incorrect','Contains','Doesn\'t Contains');
										  $arr = array('Contains','Doesn\'t Contains');
									 break;
				default : $arr = array('Is','Is Not','Contains','Begins With','Ends With');
									 break;
			}
			
		}
			echo '<option value="">Select</option>';
			foreach($arr as $ele)
			{
				echo '<option value="'.$ele.'" >'.$ele.'</option>';
			}
	
		
	}
	
	function getOptions()
	{
		//$selectedValue=isset($_GET['selectedValue'])?$_GET['selectedValue']:'';
		//echo '$selectedValue'.$selectedValue;exit;
		$user = new userSearch_Model;
		$result= $user->getchecklist();
		$checklist = array();
		foreach($result as $item)
		{
			$checklist['checklist-'.$item->checklist_id] = 'Checklist- '.$item->checklist_name;
		}
		
			$primarylist = array('Profile Data'=>"Profile Data",'checklist'=>$checklist);
			
		echo'<option value="">Select</option>';
				foreach($primarylist as $list)
				{
					if(!is_array ($list))
					{
						echo '<option value="'.$list.'" >'.$list.'</option>';
					}
					else
					{
						foreach($list as $key => $value)
						{

							echo '<option value="'.$key.'" >'.$value.'</option>';
						}
					}
				}
	}
		
}

?>