<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [04/Feb/11]
Page Description:: wizard page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class wizard_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	function index()
	{
		$viewHeader = new View('header');
		$viewHeader->role = "Admin";
		$viewHeader->type = "module";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('wizardView');
		$question = new wizard_Model;
		$wizardId = $_GET['id'];
		$view->results=$question->getQuestion($wizardId);
		$view->wizardInfo=$question->getWizardInfo($wizardId);
       	$view->render(TRUE);
	}
	
	function viewAll()
	{
		$viewHeader = new View('header');
		$viewHeader->role = "Admin";
		$viewHeader->type = "module";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username = $_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('wizardViewAll');
		$rec = new wizardview_Model;
		$view->records = $rec->getallRecords();
		$view->render(TRUE);
	}
	
	//function for issue
	function ajaxIssue()
	{
		$question = new wizard_Model;
		$wizardId = $_GET['id'];
		switch($_GET['action'])
		{
			case 'delete':
				$question->delete($wizardId);
				break;
				
			case 'rearrange':
				$arrage= str_replace("'","",$_GET['positions']);
				$question->rearrange($arrage,$wizardId);
				break;
				
			case 'edit':
				$question->update($wizardId,$_GET['text']);
				break;
				
			case 'new':
				$question->createNew($_GET['text'],$wizardId);
				break;
		}
	}
	
	//function for symptom
	function ajaxSymptom()
	{
		$question = new wizard_Model;
		$wizardId = $_GET['id'];
		switch($_GET['action'])
		{
			case 'getsymptom':
				$question->getSymptom($_GET['issueId']);
				break;
			case 'delete':
				$question->deleteSymptom($wizardId);
				break;
				
			case 'rearrange':
				$arrage= str_replace("'","",$_GET['positions']);
				$question->rearrangeSymptom($_GET['issueId'],$arrage);
				break;
				
			case 'edit':
				$question->updateSymptom($wizardId,$_GET['text']);
				break;
				
			case 'newSymptom':
				$question->createNewSymptom($_GET['issueId'],$_GET['text']);
				break;
		}
	}
	//function for cause
	function ajaxCause()
	{
		$question = new wizard_Model;
		$wizardId = $_GET['id'];
		switch($_GET['action'])
		{
			case 'getCause':
				$question->getCause($_GET['symptomId']);
				break;
			case 'deleteCause':
				$question->deleteCause($wizardId);
				break;
				
			case 'rearrange':
				$arrage= str_replace("'","",$_GET['positions']);
				$question->rearrangeCause($_GET['symptomId'],$arrage);
				break;
				
			case 'editCause':
				$question->updateCause($wizardId,$_GET['text'],$_GET['type']);
				break;
				
			case 'newCause':
				$question->createNewCause($_GET['symptomId'],$_GET['text']);
				break;
		}
	}
	
	//function for solution
	function ajaxSolution()
	{
		$question = new wizard_Model;
		switch($_GET['action'])
		{
			case 'getSolution':
				$question->getSolution($_GET['causeId']);
				break;
			case 'deleteSolution':
				$question->deleteSolution($_GET['id']);
				break;
				
			case 'rearrangeSolution':
				$arrage= str_replace("'","",$_GET['positions']);
				$question->rearrangeSolution($_GET['causeId'],$arrage);
				break;
				
			case 'editSolution':
				$question->updateSolution($_GET['id'],$_GET['text']);
				break;
			case 'editSolutionSubtitle':
				$question->updateSolutionSubtitle($_GET['id'],$_GET['text']);
				break;
				
			case 'newSolution':
				$question->createNewSolution($_GET['causeId'],$_GET['text']);
				break;
			case 'newSolutionSteps':
			$question->createNewSolutionSteps($_GET['solutionId'],$_GET['text']);
				break;
			case 'getSolutionSteps':
				$question->getSolutionSteps($_GET['solutionId']);
				break;
			case 'rearrangeSolutionSteps':
				$arrage= str_replace("'","",$_GET['positions']);
				$question->rearrangeSolutionSteps($_GET['solutionId'],$arrage);
				break;
			case 'editSolutionSteps':
				$question->updateSolutionSteps($_GET['solutionStepId'],$_GET['text']);
				break;
			case 'deleteSolutionSteps':
				$question->deleteSolutionSteps($_GET['id']);
				break;
					
				
		}
	}
	
	
    function media()
	{
			$view = new View('mediaView');
			$id=$_GET['id'];
			$type=$_GET['type'];
			$question = new wizard_Model;
			$lastdata =$question->checkdata($id);
			$view->mediatile='';
			if($lastdata->count())
			{
				$view->mode = 'edit';
				foreach($lastdata as $data)
				{
					$view->mediatype = $data->media_type;
					$view->mediaValue= $data->media_value;
					$view->mediaIpadValue= $data->media_ipad_value;
					$view->detailtext = $data->media_description;
					$view->type = $data->link_type;
					$view->mediatile=$data->media_title;
				}
				if(count($_POST)>0)
				{
					if($_POST['mediatype']=='image')
					{
						$typeArr=explode('/',$_FILES['image']['type']);
						$type=$_GET['type'];
						$tmpName=rand().time().".".$typeArr[1];
						$path=$_SERVER['DOCUMENT_ROOT'].url::base(FALSE);
						move_uploaded_file($_FILES['image']['tmp_name'],$path."media/serviceimage/$tmpName");
						$mediaValue=$tmpName;
						$mediaIPadValue='';
					}else
					{
						$mediaValue=$_POST['videoUrl'];
						$mediaIPadValue=$_POST['ipadlink'];
					}
				
						$arrData=array(
							"media_type"=>$_POST['mediatype'],
							"media_value"=>$mediaValue,
							"media_ipad_value"=>$mediaIPadValue,
							"media_description"=>$_POST['detailtext'],
							"link_id"=>$id,
							"media_title"=>$_POST['title']
							);
						$question->updateMedia($arrData);
						$queryString=$_SERVER['QUERY_STRING'];
						//echo 'wizard/media?'.$queryString.'msg=Updated Successfully'; exit;
						url::redirect('wizard/media?'.$queryString.'&msg=Updated Successfully');
				
				
				}
			}
			else
				{
					$view->mode = 'new';
					$view->mediatype = '';
					$view->mediaValue= '';
					$view->detailtext = '';
					$view->type = '';
					
					if(count($_POST)>0)
					{	
						if($_POST['mediatype']=='image')
						{
							$typeArr=explode('/',$_FILES['image']['type']);
							$type=$_GET['type'];
							$tmpName=rand().time().".".$typeArr[1];
							$path=$_SERVER['DOCUMENT_ROOT'].url::base(FALSE);
							move_uploaded_file($_FILES['image']['tmp_name'],$path."media/serviceimage/$tmpName");
							$mediaValue=$tmpName;
							$mediaIPadValue='';
						}else
						{
							$mediaValue=$_POST['videoUrl'];
							$mediaIPadValue=$_POST['ipadlink'];
						}
						$arrData=array(
						"media_type"=>$_POST['mediatype'],
						"media_value"=>$mediaValue,
						"media_ipad_value"=>$mediaIPadValue,
						"media_description"=>$_POST['detailtext'],
						"link_id"=>$id,
						"link_type"=>$type,
						"media_title"=>$_POST['title']
						);	
						
						$question->saveMedia($arrData);
						$queryString=$_SERVER['QUERY_STRING'];
						url::redirect('wizard/media?'.$queryString.'&msg=Saved Successfully');
					}
					
					
					
					
				}
			$view->render(TRUE);
		
	}
	
	function deleteWizard()
	{
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->type = "module";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$id= $_GET['id'];
		$view = new View('wizardViewAll');
		$rec = new wizardview_Model;
		$rec->deleteRecord($id); 
		$view->records = $rec->getallRecords();
		$view->render(TRUE);
		
	}
  
}

