<?php
/********************************************
AUTHOR:: Anand
Version:: 2.0
Date:: [16/Feb/11]
Page Description:: wizard setting page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class wizardSetting_Controller extends Controller
{
	
    public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
	}
	
    public function setting()
	{
		$rec = new group_Model;
		$view = new View('settingView');
		$view->groups = $rec->getGroups();	
		$id = $_GET['id'];
		
		
		if($id =='setting' && count($_POST)>0)
		{		
			$wizard = new group_Model;
			$modulename = $_POST['modulename'];
			$selectedgroups = $_POST['selectedgroups'];
			$infomedia = $_POST['infomedia'];
			$_SESSION['modulename'] = $modulename;
			$created_date =date('Y-m-d');
			$arrData_w =array(
				"wizard_name" => $modulename ,
				"subject_id" => '1',
				"created_date" => $created_date ,
				"last_used" => ''	
				);
			$arrData = array(
				"group_id" => $selectedgroups,
				"info_media" => $infomedia
				);
			$wizard_id=$wizard->saveWizard($arrData_w,$arrData);
			echo '<script language="javascript">';
			echo 'parent.tb_remove();';
			echo "parent.location.href='".url::base(FALSE)."index.php/wizard?id=".$wizard_id."'";
			echo '</script>';
			
		}	
		
		if($id !='setting')
		{
			$id = $_GET['id'];
			$wizard = new group_Model;
			$data= $wizard->editWizard($id);	
			$view->modulename = $data['mod_name'];
			$view->checkgroup = $data['groups'];
			$view->showicon=$data['info'];
			$modified_date =date('Y-m-d');
			if((count($_POST)>0 ) &&  count($_POST['update']))
			{
				$modulename = $_POST['modulename'];
				if($_POST['selectedgroups'])
					$selectedgroups = $_POST['selectedgroups'];
				else
					$selectedgroups = $data['groups'];
				if($_POST['infomedia'])
					$infomedia = $_POST['infomedia'];
				else
					$infomedia = $data['info'];
				$id = $_GET['id'];
				$arrData_w =array(
				"wizard_name" => $modulename ,
				"last_used" =>$modified_date ,
				"id" => $id 
				);
				$arrData = array(
					"group_id" => $selectedgroups,
					"info_media" => $infomedia,
					"id" => $id 
					);
				$wizard->updateWizard($arrData_w,$arrData);
				echo '<script language="javascript">';
			    echo 'parent.tb_remove();';
			    echo "parent.location.href='".url::base(FALSE)."index.php/wizard?id=".$id."'";
			    echo '</script>';
			}
		}
		
		 $view->render(TRUE);	
	}
	
    public function publish()
	{
		$rec = new wizardview_Model;
		$view->records = $rec->getallRecords();	
		$id = $_GET['id'];
		$action = $_GET['action'];
		$wizard = new group_Model;
		if($action=='unpublish')
		{
			$wizard->unPulishWizard($id);	
			url::redirect('wizard?id='.$id.'&msg=Un Published successfully');
		}
		else
		{
			$wizard->pulishWizard($id);	
			url::redirect('wizard?id='.$id.'&msg=Published successfully');
		}
	}
	
	
}