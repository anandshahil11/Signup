<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [22/Feb/11]
Page Description:: wizard search page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class wizardsearch_Controller extends Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		if( !isset($_SESSION['user_object']))
		{
		    url::redirect("login/index");
		}
	}
	//search for wizard
	function search()
	{
		$viewHeader = new View('header');
		$viewHeader->role="Admin";
		$viewHeader->type = "module";
		$viewHeader->userid = $_SESSION['user_object']->user_id;
		$viewHeader->username=$_SESSION['user_object']->firstname.' '.$_SESSION['user_object']->lastname;
		$viewHeader->render(TRUE);
		$view = new View('wizardsearch');
		$wizard = new wizardsearch_Model;
		$view->results=$wizard->getWizards();
       	$view->render(TRUE);
	}
	function getList()
	{
		$wizardId=$_GET['wizardId'];
		$listopt=$_GET['listopt'];
		$issueId=isset($_GET['Issues'])?$_GET['Issues']:'';
		$symptomId=isset($_GET['Symptom'])?$_GET['Symptom']:'';
		$causeId=isset($_GET['Cause'])?$_GET['Cause']:'';
		$solutionId=isset($_GET['Solution'])?$_GET['Solution']:'';
		$wizard = new wizardSearch_Model;
		$results=$wizard->getList($wizardId,$listopt,$issueId,$symptomId,$causeId,$solutionId);
			echo '<option value="">select</option>';
		foreach($results as $row)
		{
			echo '<option value="'.$row->id.'">'.$row->name.'</option>';
		}
		exit;
	}
	function getOptions()
	{
		$selectedValue=isset($_GET['selectedValue'])?$_GET['selectedValue']:'';
		echo '<option value="">Select</option>';
		if($selectedValue)
		{
			$arr=array("Issues","Symptom","Cause","Solution");
			$arrflip=array_flip($arr);
			$selectedId=$arrflip[$selectedValue];
			$length=count($arr);
			for($i=$selectedId+1;$i<$length;$i++)
			{
				echo '<option value="'.$arr[$i].'">'.$arr[$i].'</option>';;
			}
		}
		exit;
	}
	function getDatas()
	{
		$wizardId=$_GET['wizardId'];
		$issueId=isset($_GET['Issues'])?$_GET['Issues']:'';
		$symptomId=isset($_GET['Symptom'])?$_GET['Symptom']:'';
		$causeId=isset($_GET['Cause'])?$_GET['Cause']:'';
		$solutionId=isset($_GET['Solution'])?$_GET['Solution']:'';
		$lastIssue=isset($_GET['lastIssue'])?$_GET['lastIssue']:'';
		$criteria['IssuesCri']=isset($_GET['IssuesCri'])?$_GET['IssuesCri']:'';
		$criteria['SymptomCri']=isset($_GET['SymptomCri'])?$_GET['SymptomCri']:'';
		$criteria['CauseCri']=isset($_GET['CauseCri'])?$_GET['CauseCri']:'';
		$criteria['SolutionCri']=isset($_GET['SolutionCri'])?$_GET['SolutionCri']:'';
		$wizard = new wizardSearch_Model;
		$results=$wizard->getDatas($wizardId,$issueId,$symptomId,$causeId,$solutionId,$lastIssue,$criteria);
		header("content-type: text/xml");
		echo '<datas>';
		$rowCount=0;
		foreach($results['records'] as $row)
		{
			$rowCount=$rowCount+$row->views;
			echo '<rows>';
			echo '<name>'.$row->name.'</name>';
			echo '<type>'.$row->type.'</type>';
			echo '<wizard>'.$row->wizard_name.'</wizard>';
			echo '<views>'.$row->views.'</views>';
			echo '<created>'.$row->created_date.'</created>';
			echo '</rows>';
		}
		echo '<rowcount>'.$rowCount."/".$results['totalview'].'</rowcount>';
		echo '</datas>';
		exit;
	}
}

