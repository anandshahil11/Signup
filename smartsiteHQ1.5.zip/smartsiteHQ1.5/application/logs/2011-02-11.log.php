<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-02-11 00:42:54 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, wizard/media?keepThis=true, could not be found. in file C:/xampp/htdocs/analyticsv2/system/core/Kohana.php on line 841
2011-02-11 00:43:08 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, wizard/media?keepThis=true, could not be found. in file C:/xampp/htdocs/analyticsv2/system/core/Kohana.php on line 841
2011-02-11 00:43:17 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, wizard/media?keepThis=true, could not be found. in file C:/xampp/htdocs/analyticsv2/system/core/Kohana.php on line 841
2011-02-11 00:43:28 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, wizard/media?keepThis=true, could not be found. in file C:/xampp/htdocs/analyticsv2/system/core/Kohana.php on line 841
2011-02-11 00:43:47 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, wizard/media?keepThis=true, could not be found. in file C:/xampp/htdocs/analyticsv2/system/core/Kohana.php on line 841
2011-02-11 00:44:23 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, wizard/media?keepThis=true, could not be found. in file C:/xampp/htdocs/analyticsv2/system/core/Kohana.php on line 841
2011-02-11 00:44:34 -08:00 --- error: Uncaught Kohana_404_Exception: The page you requested, wizard/media?keepThis=true, could not be found. in file C:/xampp/htdocs/analyticsv2/system/core/Kohana.php on line 841
2011-02-11 01:47:12 -08:00 --- error: Uncaught Kohana_Database_Exception: There was an SQL error: Unknown column 'W' in 'where clause' - update analytic_wizard_solution_steps set  `order`=1 where W=7 in file C:/xampp/htdocs/analyticsv2/system/libraries/drivers/Database/Mysql.php on line 371
