<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [11/Mar/11]
Page Description:: checklist page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class checklist_Model extends Model
{
	//function for get checklist
	public function getChecklist()
	{
		
		$sql = "SELECT * FROM analytic_checklist checklist 
				join analytic_user  user on checklist.checklist_author=user.user_id
				join analytic_user_information  userinfo on user.user_info_id=userinfo.id
				";
		$results = $this->db->query($sql);
		return $results;
	}
	//function for get checklist info 
	public function getChecklistInfo($id)
	{
		$sql = "SELECT * FROM analytic_checklist CL
				left join analytic_checklist_group CLG on CL.checklist_id=CLG.checklist_id
				where CL.checklist_id=$id";
		$results = $this->db->query($sql);
		return $results;
	}
	//function for get checklist info 
	public function getCLinfo($id)
	{
		$sql = "SELECT * FROM analytic_checklist CL 	where CL.checklist_id=$id";
		$results = $this->db->query($sql);
		return $results[0];
	}
	//function for get checklist item info 
	public function getChecklistItemInfo($id)
	{
		$sql = "SELECT * FROM analytic_checklist_items CLI 	
				left join analytic_checklist_media CLmedia on CLI.items_id=CLmedia.checklist_item_id
				where CLI.items_id=$id";
		$results = $this->db->query($sql);
		return $results[0];
	}
	//function save checklistitems
	public function saveChecklist($id)
	{
		$chkName=$_POST['name'];
		$evalarr=isset($_POST['evalution'])?$_POST['evalution']:array();
		$evalVal=implode(',',$evalarr);
		$group=isset($_POST['group'])?$_POST['group']:array();
		if($id==0)
		{
			$arrData=array(
					'checklist_name'=>$chkName,
					'checklist_created'=>date('Y-m-d'),
					'checklist_author'=>$_SESSION['user_object']->user_id,
					'evaluation'=>$evalVal
			);
			$sql=$this->db->insert('analytic_checklist',$arrData); 
			$checklistId=$sql->insert_id();
		}else
		{
			$arrData=array(
					'checklist_name'=>$chkName,
					'evaluation'=>$evalVal
			);
			$sql=$this->db->update('analytic_checklist',$arrData,array('checklist_id'=>$id)); 
			$sql = "delete FROM analytic_checklist_group where checklist_id=$id";
			$results = $this->db->query($sql);
			$checklistId=$id;
		}
		foreach($group as $row)
		{
			$arrData=array(
				"group_id"=>$row,
				"checklist_id"=>$checklistId);
			$this->db->insert('analytic_checklist_group',$arrData); 
		}
		echo '<script language="javascript">';
		echo 'parent.tb_remove();';
		echo "parent.location.href='".url::base(FALSE)."index.php/checklist/viewCKlistItem?id=".$checklistId."'";
		echo '</script>';
		exit;
	}
	//function save checklist items
	public function saveChecklistItems($CKlistId,$itemId=0)
	{	
		$category_id=$_POST['Cat'];
		$_POST['title']=str_replace('Title/Input/Question','',$_POST['title']);
		$_POST['desc']=str_replace('Description','',$_POST['desc']);
		if($itemId!=0)
		{
			$sql = "delete FROM analytic_checklist_summary_field where checklist_item_id=$itemId";
			$this->db->query($sql);
			$sql = "delete FROM analytic_checklist_item_options where checklist_item_id=$itemId";
			$this->db->query($sql);	
		}
		//default it will empty
		$arrData_main=array(
			"items_numerical_entry_format"=>NULL,
			"items_numerical_min"=>NULL,
			"items_numerical_max"=>NULL,
			"items_numerical_format"=>NULL,
			"items_numerical_decimal_format"=>NULL,
			"items_numerical_fraction_format"=>NULL,
			"items_optional_text_entry"=>NULL,
			"item_currency_format"=>NULL,
			"items_date_auto_entry"=>NULL,
			"items_date_format"=>NULL,
			"items_binary_unselected_entry"=>NULL,
			"items_binary_selected_entry"=>NULL,
			"items_text_use_selection_list"=>0,
			"items_text_total_char"=>NULL,
			"items_profile_type"=>NULL,
			"items_profile_entry_type"=>NULL,
			"items_profile_name_format"=>NULL,
			"items_question1"=>NULL,
			"items_question2"=>NULL,
			"items_math"=>NULL,
			"items_calculate_current_checklist"=>NULL,
			"items_calculate_all_checklist"=>NULL,
			"items_summary"=>NULL
		);
		if($itemId==0)
		{
			$sql = "select max(item_order) as orderNum from analytic_checklist_items where category_id=".$category_id;
			$results = $this->db->query($sql);
			$order=1;
			if($results->count()>0)
			{
				$order=$results[0]->orderNum+1;
			}
			$arrData_main['item_order']=$order;
		}
		if($_POST['tempType']=='Number')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$fraction=isset($_POST['fraction'])?$_POST['fraction']:'';
			$min=!empty($_POST['min'])?$_POST['min']:null;
			$max=!empty($_POST['max'])?$_POST['max']:null;
			$decimals=isset($_POST['decimals'])?$_POST['decimals']:'';
			$currency=isset($_POST['currency'])?$_POST['currency']:'';
			$arrData=array(
			"checklist_id"=>$CKlistId,
			"category_id"=>$_POST['Cat'],
			"items_type"=>$_POST['tempType'],
			"items_title"=>$_POST['title'],
			"items_desc"=>$_POST['desc'],
			"items_required_next"=>$reqNext,
			"items_required_submit"=>$submitreq,
			"items_numerical_entry_format"=>$_POST['entryformat'],
			"items_numerical_min"=>$min,
			"items_numerical_max"=>$max,
			"items_numerical_format"=>$_POST['format'],
			"item_currency_format"=>$currency,
			"items_numerical_decimal_format"=>$decimals,
			"items_numerical_fraction_format"=>$fraction
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
		}
		if($_POST['tempType']=='Checkbox Only')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$optext=isset($_POST['optext'])?$_POST['optext']:0;
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
		}
		if($_POST['tempType']=='Multiple Selection')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$optext=isset($_POST['optext'])?$_POST['optext']:0;
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq,
				"items_optional_text_entry"=>$optext
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
			$arrOptions=explode(";;",$_POST['options']);
			$count=count($arrOptions);
			for($i=1;$i<$count;$i++)
			{
				$arrData=array(
				"item_options_value"=>$arrOptions[$i],
				"item_options_order"=>$i,
				"checklist_item_id"=>$checklistItemId);
				$this->db->insert('analytic_checklist_item_options',$arrData); 
			}
		}
		if($_POST['tempType']=='Date')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq,
				"items_date_auto_entry"=>$_POST['dateEntry'],
				"items_date_format"=>$_POST['dateFormat']
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
		}
		if($_POST['tempType']=='Binary')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq,
				"items_binary_unselected_entry"=>$_POST['unselectedText'],
				"items_binary_selected_entry"=>$_POST['selectedText']
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
		}
		if($_POST['tempType']=='Text Entry')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$evalution=isset($_POST['evalution'])?1:0;
			$maxChar=isset($_POST['maxchar'])?$_POST['maxchar']:0;
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq,
				"items_text_use_selection_list"=>$evalution,
				"items_text_total_char"=>$maxChar
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
			if($evalution==1)
			{
				$arrOptions=explode(";;",$_POST['options']);
				$count=count($arrOptions);
				for($i=1;$i<$count;$i++)
				{
					$arrData=array(
					"item_options_value"=>$arrOptions[$i],
					"item_options_order"=>$i,
					"checklist_item_id"=>$checklistItemId);
					$this->db->insert('analytic_checklist_item_options',$arrData); 
				}
			}
		}
		if($_POST['tempType']=='User Data')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$_POST['nameformat']=isset($_POST['nameformat'])?$_POST['nameformat']:'';
			$_POST['nameformat']=$_POST['profileField']=='Country'?'':$_POST['nameformat'];
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq,
				"items_profile_type"=>$_POST['profileField'],
				"items_profile_entry_type"=>$_POST['entryType'],
				"items_profile_name_format"=>$_POST['nameformat']
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
		}
		if($_POST['tempType']=='Calculation')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq,
				"items_question1"=>$_POST['Field1'],
				"items_question2"=>$_POST['Field2'],
				"items_math"=>$_POST['Operator']
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
		}
		if($_POST['tempType']=='Summary')
		{
			$reqNext=isset($_POST['nextline'])?$_POST['nextline']:0;
			$submitreq=isset($_POST['submitreq'])?$_POST['submitreq']:0;
			$currentCL=isset($_POST['currentCL'])?$_POST['currentCL']:0;
			$allCL=isset($_POST['allCL'])?$_POST['allCL']:0;
			$arrData=array(
				"checklist_id"=>$CKlistId,
				"category_id"=>$_POST['Cat'],
				"items_type"=>$_POST['tempType'],
				"items_title"=>$_POST['title'],
				"items_desc"=>$_POST['desc'],
				"items_required_next"=>$reqNext,
				"items_required_submit"=>$submitreq,
				"items_calculate_current_checklist"=>$currentCL,
				"items_calculate_all_checklist"=>$allCL,
				"items_summary"=>$_POST['Operator']
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_checklist_items',$arrData); 
				$checklistItemId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_checklist_items',$arrData,array('items_id'=>$itemId)); 
				$checklistItemId=$itemId;
			}
			foreach($_POST['Field'] as $row)
			{	$arrData=array(
					"item_summary_checklist_id"=>$row,
					"checklist_item_id"=>$checklistItemId
				);
				$this->db->insert('analytic_checklist_summary_field',$arrData); 
			}
		}
		if(isset($_POST['mediatype']))
		$this->updateMedia($checklistItemId);
		echo '<script language="javascript">';
		echo 'parent.tb_remove();';
		echo "parent.location.href='".url::base(FALSE)."index.php/checklist/viewCKlistItem?id=".$CKlistId."'";
		echo '</script>';
	}
	//function update media
	function updateMedia($checklistItemId)
	{
		$_POST['videoUrl']=str_replace('Video Link','',$_POST['videoUrl']);
		$_POST['mediatitle']=str_replace('Media Title','',$_POST['mediatitle']);
		$_POST['mediadetailtext']=str_replace('Media Description','',$_POST['mediadetailtext']);
		$_POST['ipadlink']=str_replace('Ipad Link','',$_POST['ipadlink']);
		$sql = "select *  from analytic_checklist_media where checklist_item_id=$checklistItemId";
		$results = $this->db->query($sql);
		$arrData=array(
			"media_type"=>$_POST['mediatype'],
			"media_description"=>$_POST['mediadetailtext'],
			"media_title"=>$_POST['mediatitle'],
			"checklist_item_id"=>$checklistItemId
		);
		if($_POST['mediatype']=='image')
		{
			if(!empty($_FILES['image']['type']))
			{
				$typeArr=explode('/',$_FILES['image']['type']);
				$tmpName=rand().time().".".$typeArr[1];
				$path=$_SERVER['DOCUMENT_ROOT'].url::base(FALSE);
				move_uploaded_file($_FILES['image']['tmp_name'],$path."media/serviceimage/$tmpName");
				$mediaValue=$tmpName;
				$arrData['media_value']=$mediaValue;
			}
			
		}else
		{
				$mediaValue=$_POST['videoUrl'];
				$arrData['media_value']=$mediaValue;	
				$arrData['media_ipad_value']=$_POST['ipadlink'];
		}
		if($results->count()>0)
		{
			$this->db->update('analytic_checklist_media',$arrData,array('checklist_item_id'=>$checklistItemId)); 
		}else
		{
			$this->db->insert('analytic_checklist_media',$arrData); 
		}
	}
	//delete check list 
	public function delChecklist($id)
	{
		$sql = "delete FROM analytic_checklist where checklist_id=$id";
		$results = $this->db->query($sql);
	}
	//save category
	public function saveCat($CKlistId,$catId)
	{
		$arrData=array(
		'category_name'=>$_POST['name'],
		'checklist_id'=>$CKlistId
		);
		if($catId==0)
		{
			$sql = "select max(category_order) as category_order from analytic_checklist_category where checklist_id=$CKlistId";
			$results = $this->db->query($sql);
			$order=1;
			if($results->count()>0)
			{
				$order=$results[0]->category_order+1;
			}
			$arrData['category_order']=$order;
			$this->db->insert('analytic_checklist_category',$arrData); 
		}else
		{
			$this->db->update('analytic_checklist_category',$arrData,array('checklist_id'=>$CKlistId,"category_id"=>$catId)); 
		}
		echo '<script language="javascript">';
		echo 'parent.tb_remove();';
		echo "parent.location.href='".url::base(FALSE)."index.php/checklist/viewCKlistItem?id=".$CKlistId."'";
		echo '</script>';
		exit;
	}
	//get category for the check list
	public function getCat($CKlistId)
	{
		$sql = "SELECT * FROM analytic_checklist_category where checklist_id=$CKlistId";
		$results = $this->db->query($sql);
		return $results;
	}
	//get checklist items
	public function getCL($CKlistId)
	{
		$sql = "SELECT * FROM analytic_checklist_items where checklist_id=$CKlistId order by item_order";
		$results = $this->db->query($sql);
		return $results;
	}
	//save checklsit
	public function rearrange($order,$checkList)
	{
		$arrOrder=explode('|',$order);
		$num=0;
		foreach($arrOrder as $order)
		{
			$num++;
			$arr=explode('/',$order);
			$sql = "update analytic_checklist_items set item_order=$num  where checklist_id=$checkList and category_id=$arr[0]
					and items_id=$arr[1]";
			$results = $this->db->query($sql);
		}
	}
	//get checklist numerical items
	public function getCLNumericalitems($CKlistId)
	{
		$sql = "SELECT * FROM analytic_checklist_items where checklist_id=$CKlistId and items_type='Number'";
		$results = $this->db->query($sql);
		return $results;
	}
	//checklist publish
	public function  publish($CKlistId)
	{
		$sql = "update analytic_checklist set publish =1 where checklist_id=".$CKlistId;
		$results = $this->db->query($sql);
	}
	//checklist publish
	public function  unpublish($CKlistId)
	{
		$sql = "update analytic_checklist set publish =0 where checklist_id=".$CKlistId;
		$results = $this->db->query($sql);
	}
	//get checklist options
	public function getCLIoptions($itemId)
	{
		$sql = "SELECT * FROM analytic_checklist_item_options where checklist_item_id=$itemId order by item_options_order";
		$results = $this->db->query($sql);
		return $results;
	}
	//get summary fields
	public function getCLIfields($itemId)
	{
		$sql = "SELECT * FROM analytic_checklist_summary_field where checklist_item_id=$itemId";
		$results = $this->db->query($sql);
		return $results;
	}
	//delete checklist item
	public function deleteItem($CLIId)
	{
		$sql = "delete FROM analytic_checklist_items where items_id=$CLIId";
		$results = $this->db->query($sql);
	}
	//delete checklist cat
	public function deleteCat($CatId,$CLId)
	{
		$sql = "delete FROM analytic_checklist_category where category_id =$CatId and checklist_id=$CLId";
		$results = $this->db->query($sql);
		$sql = "delete FROM analytic_checklist_items where category_id=$CatId";
		$results = $this->db->query($sql);
	}
	//get summary fields
	public function getCatInfo($catId)
	{
		$sql = "SELECT * FROM analytic_checklist_category where category_id=$catId";
		$results = $this->db->query($sql);
		return $results[0]->category_name;
	}
	//get datas for the advanced search
	public function getDatas($criteriaId,$field,$criteria,$detailVal,$datef,$datet)
	{	
		$count = count($criteriaId);
		$sql =" SELECT CL.*,CLIA1.*   from   analytic_checklist CL  ";
		$checklist=1;
	    for($i=0;$i<($count-1);$i++)
		{	
			$check = explode('-',$criteriaId[$i]);
			if($check[0] == "checklist")
			{
				$itemtype = $this->getItemtype($field[$i]);
				if($itemtype =='Multiple Selection')
				{
					$sql.="join analytic_checklist_item_answer  CLIA$checklist on CL.checklist_id=CLIA$checklist.checklist_id
						   join analytic_checklist_item_answer_options CLIAO on CLIAO.checklist_item_answer_id=CLIA$checklist.item_ans_id
						   join analytic_checklist_item_options CLIO on CLIAO.checklist_item_options_id=CLIO.item_options_id ";
					if($criteria[$i] == 'Is Correct' && $detailVal[$i] != '')
					$sql.=" and item_options_value='$detailVal[$i]'";
					if($criteria[$i] == 'Is Incorrect' && $detailVal[$i] != '')
					$sql.=" and item_options_value!='$detailVal[$i]'";
					if($criteria[$i] == 'Contains' && $detailVal[$i] != '')
					$sql.=" and item_options_value like '%$detailVal[$i]%'";
					if($criteria[$i] == 'Doesn\'t Contains' && $detailVal[$i] != '')
					$sql.=" and item_options_value  not like'%$detailVal[$i]%'";
					
				}
				else
				{
					$sql.="join analytic_checklist_item_answer  CLIA$checklist on CL.checklist_id =CLIA$checklist.checklist_id";
				}
				if($criteria[$i] == 'Is' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans='$detailVal[$i]'";
				if($criteria[$i] == 'Is Not' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans!='$detailVal[$i]'";
				if($criteria[$i] == 'Begins With' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans LIKE '$detailVal[$i]%'";
				if($criteria[$i] == 'Contains' && $detailVal[$i] != '' and $itemtype !='Multiple Selection')
				$sql .=" and CLIA$checklist.item_ans LIKE '%$detailVal[$i]%'";
				if($criteria[$i] == 'Ends With'&& $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans LIKE '%$detailVal[$i]'";
				if($criteria[$i] == 'Equals' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans='$detailVal[$i]'";
				if($criteria[$i] == 'Doesn\'t Equals' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans!='$detailVal[$i]'";
				if($criteria[$i] == 'Greater Than' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans > '$detailVal[$i]'";
				if($criteria[$i] == 'Less Than' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans < '$detailVal[$i]'";
				if($itemtype=='Date')
				{
					$timestamp = strtotime($detailVal[$i]);
					$today =strtotime(date("m/d/Y"));
				}
				if($criteria[$i] == 'Is Exactly' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans ='$timestamp'";
				if($criteria[$i] == 'Is Before' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans <='$timestamp'";
				if($criteria[$i] == 'Is After' && $detailVal[$i] != '')
				$sql .=" and CLIA$checklist.item_ans >='$timestamp'";
				if($criteria[$i] == 'Is Within' && $datef != '' && $datet != '')
				$sql .=" and CLIA$checklist.item_ans BETWEEN '".strtotime($datef)."'  AND '".strtotime($datet)."'";
				$numCon=$checklist;
				for($num=1;$num<$numCon;$num++)
				{
					$sql .="and CLIA$checklist.item_ans!='$detailVal[$num]'";	
				}
				$sql .=" and CLIA$checklist.checklist_item_id=". $field[$i];
				
			}
			if($check[0] == "Profile Data")
			{
				/*
				$sql .="join analytic_checklist_item_answer  CLIA$checklist on CL.checklist_id=CLIA$checklist.checklist_id
						join analytic_checklist_items CLI$checklist on CLIA$checklist.checklist_item_id=CLI$checklist.items_id and items_type='User Data' and items_profile_type='Name'
						join analytic_user user on user.user_id=item_ans
						join analytic_user_information on user.user_info_id=id ";
				*/
				$sql .="join analytic_checklist_item_answer  CLIA$checklist on CL.checklist_id=CLIA$checklist.checklist_id
						join analytic_user user on user.user_id=CLIA1.user_id
						join analytic_user_information on user.user_info_id=id ";
				if($criteria[$i] == 'Is' && $detailVal[$i] != '')
					$sql .= " and $field[$i] ='$detailVal[$i]'";
				if($criteria[$i] == 'Is Not' && $detailVal[$i] != '')
					$sql .= " and $field[$i] != '$detailVal[$i]'";
				if($criteria[$i] == 'Contains' && $detailVal[$i] != '')
					$sql .= " and $field[$i] LIKE '%$detailVal[$i]%'";
				if($criteria[$i] == 'Doesn\'t Contains' && $detailVal[$i] != '')
					$sql .= " and $field[$i] NOT LIKE '%$detailVal[$i]%'";
				if($criteria[$i] == 'Begins With' && $detailVal[$i] != '')
					$sql .= " and $field[$i] LIKE '$detailVal[$i]%'";
				if($criteria[$i] == 'Ends With' && $detailVal[$i] != '')
					$sql .= " and $field[$i] LIKE '%$detailVal[$i]'";
			}
			$checklist++;
		
		}
		$sql .=" group by user_session";
		//echo $sql;exit;
		$result = $this->db->query($sql);
		return $result;
		
	}
	//get total users
	public function totalChecklist()
	{
		$sql = "SELECT * FROM `analytic_checklist_item_answer` group by user_session ";
		$result = $this->db->query($sql);
		return count($result);
	}
	//get item type
	public function getItemtype($id)
	{
		$sql = "SELECT items_type FROM  `analytic_checklist_items` WHERE items_id=$id";
		$result = $this->db->query($sql);
		foreach($result as $row)
				$type = $row->items_type;
	
		return $type; 
	}
	//function get operator name
	public function getOperatorName($id,$sess)
	{
		$sql = "select firstname,lastname  from analytic_checklist_item_answer  CLIA 	
				join analytic_checklist_items CLI on CLIA.checklist_item_id=CLI.items_id and items_type='User Data' and items_profile_type='Name'
				join analytic_user user on user.user_id=item_ans
				join analytic_user_information on user.user_info_id=id 
				where CLIA.checklist_id=".$id." and user_session=$sess";
		$result = $this->db->query($sql);
		if($result->count()>0)
		return $result[0];
		else
		{
			$sql = "select  firstname,lastname  from analytic_checklist_item_answer  CLIA 	
				join analytic_user user on user.user_id=CLIA.user_id 
				join analytic_user_information on user.user_info_id=id 
				where CLIA.checklist_id=".$id. "and user_session=$sess";
			$result = $this->db->query($sql);
			if($result->count()>0)
			return $result[0];
		}
		/*
		$sql = "select  firstname,lastname  from analytic_checklist_item_answer  CLIA 	
				join analytic_user user on user.user_id=CLIA.user_id 
				join analytic_user_information on user.user_info_id=id 
				where CLIA.checklist_id=".$id;
		$result = $this->db->query($sql);
		if($result->count()>0)
		return $result[0];
		*/
	}
	//function get checklist category info
	public function getChecklistCatInfo($id)
	{
		$sql = "SELECT * FROM  analytic_checklist_category 	WHERE checklist_id=$id";
		$result = $this->db->query($sql);
		return $result;
	}
	//function get the checklist item info
	public function getChecklistItem($id,$sess)
	{
		$sql = "SELECT * FROM  analytic_checklist_items ACI 
				left join analytic_checklist_item_answer ACIA on  ACI.items_id=ACIA.checklist_item_id  and user_session=$sess
				where ACI.checklist_id=$id ";
		$result = $this->db->query($sql);
		return $result;
	}
	//function to get options
	public function getOptions($id,$opt)
	{
		$sql = "SELECT * FROM  analytic_checklist_item_answer 	acia
				join analytic_checklist_item_answer_options aciao on  aciao.checklist_item_answer_id=acia.item_ans_id
				join analytic_checklist_item_options acio on acio.item_options_id=aciao.checklist_item_options_id
				WHERE acia.checklist_item_id=$id and user_session=$opt";
		$result = $this->db->query($sql);
		return $result;
	}
	//function to get operator email
	public function getOperatorEmail($id,$sess)
	{
		$sql = "select emailid  from analytic_checklist_item_answer  CLIA 	
				join analytic_checklist_items CLI on CLIA.checklist_item_id=CLI.items_id and items_type='User Data' and items_profile_type='Name' 
				join analytic_user user on user.user_id=item_ans
				join analytic_user_information on user.user_info_id=id 
				where CLIA.checklist_id=".$id." and user_session=$sess";
		$result = $this->db->query($sql);
		if($result->count()>0)
		return $result[0]->emailid;
		else
		{
			$sql = "select emailid  from analytic_checklist_item_answer  CLIA 	
				join analytic_user user on user.user_id=CLIA.user_id 
				join analytic_user_information on user.user_info_id=id 
				where CLIA.checklist_id=".$id." and user_session=$sess";
			$result = $this->db->query($sql);
			if($result->count()>0)
			return $result[0]->emailid;
		}
	}
}
