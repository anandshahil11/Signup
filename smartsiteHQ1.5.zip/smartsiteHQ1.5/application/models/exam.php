<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [11/Mar/11]
Page Description:: checklist page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class exam_Model extends Model
{
	//function save exam
	public function saveExam($id)
	{
		$examName=$_POST['name'];
		$pass=$_POST['passvalue'];
		$totalAttempt=$_POST['totalattempts'];
		$numberQuestion=$_POST['numquest'];
		$mantetoryQues=isset($_POST['mandatory'])?$_POST['mandatory']:'';
		$randomQues=isset($_POST['randomexamquestion'])?$_POST['randomexamquestion']:'';
		$randomAns=isset($_POST['randomexamqans'])?$_POST['randomexamqans']:'';
		$group=isset($_POST['group'])?$_POST['group']:array();
		if($id==0)
		{
			$arrData=array(
					'exam_name'=>$examName,
					'exam_created'=>date('Y-m-d'),
					'exam_author'=>$_SESSION['user_object']->user_id,
					'exam_number_question_ask'=>$numberQuestion,
					'exam_pass_percent'=>str_replace('%','',$pass),
					'exam_attempt'=>$totalAttempt,
					'exam_mantetory_question_ask'=>$mantetoryQues,
					'exam_random_question'=>$randomQues,
					'exam_random_answer'=>$randomAns
			);
			$sql=$this->db->insert('analytic_exam',$arrData); 
			$checklistId=$sql->insert_id();
		}else
		{
			$arrData=array(
					'exam_name'=>$examName,
					'exam_author'=>$_SESSION['user_object']->user_id,
					'exam_number_question_ask'=>$numberQuestion,
					'exam_pass_percent'=>str_replace('%','',$pass),
					'exam_attempt'=>$totalAttempt,
					'exam_mantetory_question_ask'=>$mantetoryQues,
					'exam_random_question'=>$randomQues,
					'exam_random_answer'=>$randomAns
			);
			$sql=$this->db->update('analytic_exam',$arrData,array('checklist_id'=>$id)); 
			$sql = "delete FROM analytic_exam_group where exam_id=$id";
			$results = $this->db->query($sql);
			$checklistId=$id;
		}
		foreach($group as $row)
		{
			$arrData=array(
				"group_id"=>$row,
				"exam_id"=>$checklistId);
			$this->db->insert('analytic_exam_group',$arrData); 
		}
		echo '<script language="javascript">';
		echo 'parent.tb_remove();';
		echo "parent.location.href='".url::base(FALSE)."index.php/checklist/viewCKlistItem?id=".$checklistId."'";
		echo '</script>';
		exit;
	}
	//get exams
	function getExams()
	{
		$sql = "SELECT * FROM analytic_exam exam 
				join analytic_user  user on exam.exam_author=user.user_id
				join analytic_user_information  userinfo on user.user_info_id=userinfo.id
				";
		$results = $this->db->query($sql);
		return $results;
	}
	//delete exams
	function delExam($id)
	{
		$sql = "delete FROM analytic_exam where exam_id=$id";
		$results = $this->db->query($sql);
	}
	//exam model
	//function for get checklist info 
	public function getExaminfo($id)
	{
		$sql = "SELECT * FROM analytic_exam where exam_id =$id";
		$results = $this->db->query($sql);
		return $results[0];
	}
	//function for get checklist info 
	public function getExamGroupinfo($id)
	{
		$sql = "SELECT * FROM analytic_exam  ex
				left join analytic_exam_group EXG on ex.exam_id =EXG.exam_id 
				where ex.exam_id =$id";
		$results = $this->db->query($sql);
		return $results;
	}
	//get category for the Exam
	public function getCat($examId)
	{
		$sql = "SELECT * FROM analytic_exam_category where exam_id =$examId";
		$results = $this->db->query($sql);
		return $results;
	}
	//get question for the exam
	public function getExamQuestions($examId)
	{
		$sql = "SELECT * FROM analytic_exam_questions where   	exam_id=$examId order by question_order";
		$results = $this->db->query($sql);
		return $results;
	}
	//save category
	public function saveCat($examId,$catId)
	{
		$arrData=array(
		'category_name'=>$_POST['name'],
		'exam_id'=>$examId
		);
		if($catId==0)
		{
			$sql = "select max(category_order) as category_order from analytic_exam_category where exam_id=$examId";
			$results = $this->db->query($sql);
			$order=1;
			if($results->count()>0)
			{
				$order=$results[0]->category_order+1;
			}
			$arrData['category_order']=$order;
			$this->db->insert('analytic_exam_category',$arrData); 
		}else
		{
			$this->db->update('analytic_exam_category',$arrData,array('exam_id'=>$examId,"category_id"=>$catId)); 
		}
		echo '<script language="javascript">';
		echo 'parent.tb_remove();';
		echo "parent.location.href='".url::base(FALSE)."index.php/exam/viewExamQuestion?id=".$examId."'";
		echo '</script>';
		exit;
	}
	//get summary fields
	public function getCatInfo($catId)
	{
		$sql = "SELECT * FROM analytic_exam_category where category_id=$catId";
		$results = $this->db->query($sql);
		return $results[0]->category_name;
	}
	//delete exam category
	public function deleteCat($CatId,$examId)
	{
		$sql = "delete FROM analytic_exam_category where exam_id =$examId and  category_id=$CatId";
		$results = $this->db->query($sql);
	}
	//exam publish
	public function  publish($exId)
	{
		$sql = "update analytic_exam set publish =1 where exam_id =".$exId;
		$results = $this->db->query($sql);
	}
	//exam unpublish
	public function  unpublish($exId)
	{
		$sql = "update analytic_exam set publish =0 where exam_id =".$exId;
		$results = $this->db->query($sql);
	}
	//save exam question 
	public function saveExamQuestions($examId,$itemId)
	{
		$category_id=$_POST['Cat'];
		$_POST['title']=str_replace('Title/Input/Question','',$_POST['title']);
		$_POST['desc']=str_replace('Description','',$_POST['desc']);
		//default it will empty
		$arrData_main=array();
		if($itemId==0)
		{
			$sql = "select max(question_order) as orderNum from analytic_exam_questions where category_id=".$category_id;
			$results = $this->db->query($sql);
			$order=1;
			if($results->count()>0)
			{
				$order=$results[0]->orderNum+1;
			}
			$arrData_main['question_order']=$order;
		}
		if($_POST['tempType']=='Multiple Selection')
		{
			$mandatory=isset($_POST['mandatory'])?$_POST['mandatory']:0;
			$arrData=array(
				"exam_id"=>$examId,
				"category_id"=>$_POST['Cat'],
				"question_type"=>$_POST['tempType'],
				"question_title"=>$_POST['title'],
				"question_desc"=>$_POST['desc'],
				"question_mantetory"=>$mandatory
			);
			$arrData=array_merge($arrData_main,$arrData);
			if($itemId==0)
			{
				$sql=$this->db->insert('analytic_exam_questions',$arrData); 
				$examQuesId=$sql->insert_id();
			}else
			{
				$sql=$this->db->update('analytic_exam_questions',$arrData,array('question_id'=>$itemId)); 
				$examQuesId=$itemId;
			}
			$arrOptions=explode(";NQA;",$_POST['options']);
			$count=count($arrOptions);
			for($i=1;$i<$count;$i++)
			{
				$arrOpt=explode(";QA;",$arrOptions[$i]);
				$correctAns=$arrOpt[1]=='true'?1:0;
				$arrData=array(
				"answer_text"=>$arrOpt[0],
				"answer_order"=>$i,
				"exam_id"=>$examId,
				"correct_answer"=>$correctAns,
				"question_id"=>$examQuesId);
				if($this->checkAns($arrOpt[2],$examQuesId,$examId))
				{
					$this->db->insert('analytic_exam_questions_answer',$arrData); 
				}else
				{
					$this->db->update('analytic_exam_questions_answer',$arrData,array('answer_id'=>$arrOpt[2])); 
				}
			}
		}
		if(isset($_POST['mediatype']))
		$this->updateMedia($examQuesId);
		echo '<script language="javascript">';
		echo 'parent.tb_remove();';
		echo "parent.location.href='".url::base(FALSE)."index.php/exam/viewExamQuestion?id=".$examId."'";
		echo '</script>';
	}
	//check exam answer exists
	public function checkAns($ansId,$question,$exam)
	{	
		$sql = "SELECT * FROM analytic_exam_questions_answer where 	question_id =$question and answer_id =$ansId and exam_id=$exam";
		$results = $this->db->query($sql);
		if($results->count())
		return false;
		else
		return true;
	}
	//get exam question info
	public function getExamQuestionInfo($QId)
	{
		$sql = "SELECT * FROM analytic_exam_questions EQ 	
				left join analytic_exam_question_media media on EQ.question_id=media.question_id
				where EQ.question_id=$QId";
		$results = $this->db->query($sql);
		return $results[0];
	}
	//get exam options
	public function getExamAns($itemId)
	{
		$sql = "SELECT * FROM analytic_exam_questions_answer where 	question_id =$itemId order by answer_order";
		$results = $this->db->query($sql);
		return $results;
	}
	//function update media
	function updateMedia($examQuesId)
	{
		$_POST['videoUrl']=str_replace('Video Link','',$_POST['videoUrl']);
		$_POST['mediatitle']=str_replace('Media Title','',$_POST['mediatitle']);
		$_POST['mediadetailtext']=str_replace('Media Description','',$_POST['mediadetailtext']);
		$_POST['ipadlink']=str_replace('Ipad Link','',$_POST['ipadlink']);
		$sql = "select *  from analytic_checklist_media where checklist_item_id=$examQuesId";
		$results = $this->db->query($sql);
		$arrData=array(
			"media_type"=>$_POST['mediatype'],
			"media_description"=>$_POST['mediadetailtext'],
			"media_title"=>$_POST['mediatitle'],
			"question_id"=>$examQuesId
		);
		if($_POST['mediatype']=='image')
		{
			if(!empty($_FILES['image']['type']))
			{
				$typeArr=explode('/',$_FILES['image']['type']);
				$tmpName=rand().time().".".$typeArr[1];
				$path=$_SERVER['DOCUMENT_ROOT'].url::base(FALSE);
				move_uploaded_file($_FILES['image']['tmp_name'],$path."media/serviceimage/$tmpName");
				$mediaValue=$tmpName;
				$arrData['media_value']=$mediaValue;
			}
			
		}else
		{
				$mediaValue=$_POST['videoUrl'];
				$arrData['media_value']=$mediaValue;	
				$arrData['media_ipad_value']=$_POST['ipadlink'];
		}
		if($results->count()>0)
		{
			$this->db->update('analytic_exam_question_media',$arrData,array('question_id'=>$examQuesId)); 
		}else
		{
			$this->db->insert('analytic_exam_question_media',$arrData); 
		}
	}
	//
	function deleteQuestion($examId,$questionId)
	{
		$sql = "delete FROM analytic_exam_questions where question_id=$questionId and exam_id=$examId";
		$results = $this->db->query($sql);
	}
}
