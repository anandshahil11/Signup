<?php
/********************************************
AUTHOR:: Anupama
Version:: 2.0
Date:: [14/Feb/11]
Page Description:: wizard  view  all page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');

class group_Model extends Model
{	
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
	}
	
	function getGroups()
	{
		$sql = "SELECT * FROM analytic_group";
		$groups = $this->db->query($sql);
		return $groups;
	}
	
	function saveWizard($arrData_w,$arrData)
	{
		$query=$this->db->insert('analytic_wizard',$arrData_w);
		$id = $query->insert_id();
	  	$arrData['wizard_id'] = $id;
	  	$data= $arrData['group_id'];
	  	$arr=explode(':',$data);
	  	$len = count($arr);
		for($i=0;$i<= $len-2;$i++)
		{
			if($arr[$i])
			$arrData['group_id']= $arr[$i];
	  		$query=$this->db->insert('analytic_wizard_group',$arrData);
		}
		return $id;
	}
	
	function pulishWizard($id)
	{
		$sql = "update analytic_wizard set  publish_wizard='1' where   wizard_id='".$id."'";
		$this->db->query($sql);
	}
	function unPulishWizard($id)
	{
		$sql = "update analytic_wizard set  publish_wizard='0' where   wizard_id='".$id."'";
		$this->db->query($sql);
	}
	function editWizard($id)
	{
		$sql = "SELECT * FROM analytic_wizard WHERE wizard_id='".$id."'";
		$result = $this->db->query($sql);
		foreach($result as $row)
		{
			$mod_name = $row->wizard_name;
		}
		$sql_g = "SELECT * FROM analytic_wizard_group WHERE wizard_id='".$id."'";
		$result_g = $this->db->query($sql_g);
		$i=0;
		$groups=array();
		$infomedia='';
		foreach($result_g as $row)
		{
			$groups[$i++]= $row->group_id ;
			$infomedia = $row->info_media;
		}
	
		$ids = implode($groups,':');
		$Data = array(
				"mod_name"=>$mod_name,
				"groups"=>$ids,
				"info"=>$infomedia
		);
		return $Data;
	
	}
	
	function updateWizard($arrData_w,$arrData)
	{
		
		$sql = "update analytic_wizard set  wizard_name='".$arrData_w['wizard_name']."' , last_used ='".$arrData_w['last_used']."' where wizard_id='".$_GET['id']."'";
		$this->db->query($sql);
		$sqld = "DELETE FROM analytic_wizard_group WHERE wizard_id='".$_GET['id']."'";
		$this->db->query($sqld);
		$str = $arrData['group_id'];
		$selected =explode(':',$str);
		$info = $arrData['info_media'];
		
	  foreach($selected as $index => $val)
		{ 
			if(isset($selected[$index]) )
			{
				if(($selected[$index]!= ""))
				{
					$arr = array("wizard_id" =>$_GET['id'],
							 "group_id" => $selected[$index],
							 "info_media" => $info);
					$this->db->insert('analytic_wizard_group',$arr);
		
				}
				
			}
		}
			
	
	}


	function getIssueDetails($id)
	{
		$sql = "SELECT  issue_id FROM analytic_wizard_issue WHERE wizard_id='".$id."'";
		$result=$this->db->query($sql);
		foreach($result as $row)
		{
			$issue_id = $row->issue_id;
		}
		return $issue_id;
	}
	
	function getSymptomDetails($id)
	{
		$sql = "SELECT  symptom_id FROM analytic_wizard_symptom WHERE issue_id='".$id."'";
		$result=$this->db->query($sql);
		foreach($result as $row)
		{
			$symId = $row->symptom_id;
		}
		return $symId;
	}
	
	
	
}

?>