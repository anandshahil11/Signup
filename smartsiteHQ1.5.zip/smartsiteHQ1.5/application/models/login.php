<?php defined('SYSPATH') OR die('No direct access allowed.');
class Login_Model extends Model
{
	
 
	public function checkUsername($username)
	{
		$sql = $this->db->query("SELECT * FROM `analytic_user` WHERE username='$username'");
		$record = $sql->count($sql);
		return $record;
	}
	
	public function login($username,$password)
	{
	    $sql = $this->db->query("SELECT * FROM `analytic_user` WHERE username='$username' and password='$password'");
		$record = $sql->count($sql);
		if($record >0)
		{
		    $time = time();
			$query = "update `analytic_user` set last_login=$time,logins=logins+1 where user_id=".$sql[0]->user_id;
			$this->db->query($query);
		}
		return $record;
	}
	
	public function getuserInfo($username)
	{
	    $record = $this->db->query("SELECT * FROM `analytic_user` user join analytic_user_information userinfo
									on userinfo.id=user_info_id WHERE username='$username'");
		return $record;
	}
	
	public function getuserName($userid)
	{
	    $record = $this->db->query("SELECT * FROM `analytic_user` user join analytic_user_information userinfo
									on userinfo.id=user_info_id WHERE user_id=$userid");
		return $record;
	}
	
	public function getUsercompanyid($userid)
	{
	    $record = $this->db->query("SELECT user_info_id FROM `analytic_user` WHERE user_id=$userid");
		$user_info_id = $record[0]->user_info_id;
		$companyId = $this->db->query("SELECT company_id FROM `analytic_user_information` WHERE id=$user_info_id");
		return $companyId[0]->company_id;
	}
	
	
	
	public function getuserRole($userid)
	{
	    $sql = "SELECT role_id FROM `analytic_user_role` WHERE user_id=$userid";
		$record = $this->db->query($sql);
		$count = count($record);
		$roleArray = array();
		for($ii=0;$ii<$count;$ii++)
		{
		    $role_id = $record[$ii]->role_id;
			$sql = "SELECT role_name FROM `analytic_role` WHERE role_id=$role_id";
			$role = $this->db->query($sql);
			$roleArray[] = $role[0]->role_name;
		}
		return $roleArray;
	}
}	