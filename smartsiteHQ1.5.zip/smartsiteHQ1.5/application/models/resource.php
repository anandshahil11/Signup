<?php
/********************************************
AUTHOR:: Anand sharma
Version:: 2.0
Date:: [13/May/11]
Page Description:: Resource Uploader Model  
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class resource_Model extends Model
{
    public function getGroupList($companyid)
	{
	    $sql = "SELECT ag.group_id, ag.group_name
				FROM analytic_group ag
				INNER JOIN analytic_company_group acg ON ag.group_id = acg.group_id
				WHERE acg.company_id =$companyid";
		$result = $this->db->query($sql);
        return $result; 		
	}
	
	public function insertResourceCategory($arrData,$companyId)
	{
	    $created_date = date('Y-m-d h:i:s',time());
		$categoryName = array(
		                'category_name' => $arrData['categoryName'],
						'last_updated' => $created_date
						);
		$result = $this->db->insert('analytic_resource_category',$categoryName);
		$category_id = $result->insert_id();
		foreach($arrData['grouplist'] as $row)
        {
		    $groupArray = array('group_id'=>$row,'category_id'=>$category_id,'company_id'=>$companyId);
			$this->db->insert('analytic_resource_group',$groupArray);
		}
        
				
	}
	
	public function updateResourceCategory($arrData,$companyId,$category_id)
	{
	    $updated_date = date('Y-m-d h:i:s',time());
		$categoryName = array(
		                'category_name' => $arrData['categoryName'],
						'last_updated' => $updated_date
						);
						
		$this->db->update('analytic_resource_category',$categoryName,array('category_id'=>$category_id));
		$sql = "DELETE FROM analytic_resource_group WHERE category_id=$category_id";
		$this->db->query($sql);
		foreach($arrData['grouplist'] as $row)
        {
		    $groupArray = array('group_id'=>$row,'category_id'=>$category_id,'company_id'=>$companyId);
			$this->db->insert('analytic_resource_group',$groupArray);
		}
		
	}
	
	public function getCategoryList($companyId)
	{
	    $sql = "SELECT arc.category_id, arc.category_name , count(ari.item_id) as item_no , arc.last_updated
				FROM analytic_resource_category arc 
				LEFT JOIN analytic_resource_item ari ON ari.category_id = arc.category_id 
				WHERE arc.category_id IN (SELECT DISTINCT(arc.category_id)
				FROM analytic_resource_category arc 
				INNER JOIN analytic_resource_group arg
				ON arg.category_id = arc.category_id
				WHERE arg.company_id = $companyId)
				GROUP BY arc.category_id";
		$result = $this->db->query($sql);
        return $result;		
	}
	
	public function insertResourceItem($arrData,$_FILES)
	{
	    $path=$_SERVER['DOCUMENT_ROOT'].url::base(FALSE);
		$typeArr=explode('/',$_FILES['resource_upload']['type']);
		$type=$_GET['type'];
		$tmpName=rand().time().".".$typeArr[1];
		move_uploaded_file($_FILES['resource_upload']['tmp_name'],$path."media/resourceUpload/$tmpName");
		$upload_date = date('Y-m-d h:i:s',time());
		$arrItem = array(
		                "item_name" => $arrData['resourceName'],
						"item_description" => $arrData['resourceDesc'],
						"category_id" => $arrData['categoryList'],
						"original_file_name" => $_FILES['resource_upload']['name'],
						"attached_file_name" => $tmpName,
						"no_of_views" => 0,
						"last_viewed" => "$upload_date"
		           );
		$this->db->insert('analytic_resource_item',$arrItem);
		$arrTime = array("last_updated" =>$upload_date );
		$arrCategory = array("category_id" => $arrData['categoryList']);
		$this->db->update('analytic_resource_category',$arrTime,$arrCategory);
			
	}
	
	public function updateResourceItem($arrData,$_FILES,$resource_id)
	{
	    $path=$_SERVER['DOCUMENT_ROOT'].url::base(FALSE);
		$typeArr=explode('/',$_FILES['resource_upload']['type']);
		$type=$_GET['type'];
		$tmpName=rand().time().".".$typeArr[1];
		move_uploaded_file($_FILES['resource_upload']['tmp_name'],$path."media/resourceUpload/$tmpName");
		unlink("media/resourceUpload/".$arrData['attachedFile']);
		$upload_date = date('Y-m-d h:i:s',time());
		$arrItem = array(
		                "item_name" => $arrData['resourceName'],
						"item_description" => $arrData['resourceDesc'],
						"category_id" => $arrData['categoryList'],
						"original_file_name" => $_FILES['resource_upload']['name'],
						"attached_file_name" => $tmpName,
						"last_viewed" => "$upload_date"
		           );
		$this->db->update('analytic_resource_item',$arrItem,array("item_id"=>$resource_id));
		$arrTime = array("last_updated" =>$upload_date );
		$arrCategory = array("category_id" => $arrData['categoryList']);
		$this->db->update('analytic_resource_category',$arrTime,$arrCategory);
	
	}
	
	public function getResourceinfo($resourceId)
	{
	    $sql = "SELECT item_id,item_name,item_description,original_file_name,attached_file_name,category_id
		        FROM analytic_resource_item
				WHERE item_id =$resourceId";
		$result = $this->db->query($sql);
		return $result;
	}
	
	
	public function getresourceItemList($companyId,$category_id="")
	{
	    $sql = "SELECT arc.category_id,arc.category_name,ari.item_id,ari.item_name,ari.original_file_name,ari.no_of_views,ari.last_viewed
				FROM analytic_resource_category arc
				INNER JOIN  analytic_resource_item ari ON ari.category_id = arc.category_id
				WHERE arc.category_id IN (SELECT DISTINCT(arc.category_id)
				FROM analytic_resource_category arc 
				INNER JOIN analytic_resource_group arg
				ON arg.category_id = arc.category_id";
		if($category_id!="")
        {		
		$sql.=" "."WHERE arg.company_id = $companyId AND arc.category_id=$category_id)";
		}else
		{
		$sql.=" "."WHERE arg.company_id = $companyId)";
		}
		$result = $this->db->query($sql);
        return $result; 		
	}
	
	public function deleteCategory($categoryId)
	{
	    $sql = "DELETE FROM analytic_resource_category WHERE category_id=$categoryId";
		$this->db->query($sql);
	}
	
	public function deleteResourceitem($itemId)
	{
	    $sql = "DELETE FROM analytic_resource_item WHERE item_id=$itemId";
		$this->db->query($sql);
		
	}
	
	public function getCategoryName($categoryId)
	{
	    $sql = "SELECT category_name FROM analytic_resource_category WHERE category_id = $categoryId";
		$result = $this->db->query($sql);
		return $result[0]->category_name;
	}
	
	public function getGroups($categoryId)
	{
	    $sql = "SELECT group_id FROM analytic_resource_group WHERE category_id = $categoryId";
		$result = $this->db->query($sql);
		return $result;
	}
	
}