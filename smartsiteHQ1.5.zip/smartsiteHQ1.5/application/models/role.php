<?php
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [5/March/11]
Page Description:: Role Model  page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');

class role_Model extends Model
{	
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
	}
	
	function getRoles()
	{
	    $sql = "SELECT * FROM `analytic_role`";
		$result = $this->db->query($sql);
		return $result;
	}
	
}