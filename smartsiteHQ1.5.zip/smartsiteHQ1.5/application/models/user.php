<?php
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [1/March/11]
Page Description:: User Model  page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');

class user_Model extends Model
{	
	
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
	}
	
	
	function getGroups($companyId)
	{
		$sql = "
				SELECT ag.*,count(aug.user_id) as participants , ac.company_id,ac.company_name from analytic_group ag 
				join analytic_company_group acg on  acg.`group_id`=ag.group_id
				left join analytic_user_group aug on  aug.`group_id`=ag.group_id
				join analytic_company ac on ac.company_id=acg.company_id
				where acg.company_id='$companyId'
				GROUP BY ag.group_id";
		$records = $this->db->query($sql);
		return $records;
	}
	
	
	
	function addGroup($arrData,$companyid)
	{
		$query = $this->db->insert('analytic_group',$arrData);
		$groupid = $query->insert_id();
		$arrD = array("company_id"=>$companyid , "group_id"=>$groupid);
		$this->db->insert('analytic_company_group',$arrD);
	}
	
	function deleteGrouprecord($groupid)
	{
		$sql = "delete FROM `analytic_group` where `group_id`=$groupid";
		$this->db->query($sql);
	}
	
	function editGroup($groupid)
	{
	    $sql = "SELECT * FROM `analytic_group` WHERE `group_id`=$groupid";
		$data = $this->db->query($sql);
		return $data;
	}
	
	function updateGroup($data , $groupid)
	{
	    $this->db->update('analytic_group',$data,$groupid);
	}
	
	function viewUsers($companyid)
	{
	    $sql = "SELECT aui.* , au.*
                FROM `analytic_user_information` aui 
                JOIN `analytic_user` au 
                ON aui.id = au.user_info_id 
                WHERE aui.company_id = $companyid";
		$data = $this->db->query($sql);
        return $data;		
	}
	
	function viewgroupUsers($groupid)
	{
	    $sql = "SELECT aug.* , au.*,aui.*
                FROM `analytic_user_group` aug
                JOIN `analytic_user` au 
                ON au.user_id  = aug.user_id 
				JOIN `analytic_user_information` aui 
				ON aui.id = au.user_info_id 
                WHERE aug.group_id =$groupid ";

		$data = $this->db->query($sql);
        return $data;		
	}
	
	function exportgroupUsers($groupid ,$check)
	{
		$list = '';
		
		$arr = array();
		$k=0;
		for($j =0;$j<=(count($check) -1);$j++)
		{
			if($check[$j]!='')
			{
				$arr[$k++] = $check[$j];
			}
		}
		$len = count($arr) -1;
		for($i=0 ;$i<=$len;$i++)
		{
			if($arr[$i]!= '' and $i != $len)
			$list .= $arr[$i].',';
			if($arr[$i]!= '' and $i == $len)
			$list .= $arr[$i];
			if($arr[$len] == ''and $i == $len)
			$list .= $arr[$len-1];
		}
		$sql = "SELECT distinct aug.* , au.*,aui.*
                FROM `analytic_user_group` aug
                JOIN `analytic_user` au 
                ON au.user_id  = aug.user_id 
				JOIN `analytic_user_information` aui 
				ON aui.id = au.user_info_id 
                WHERE aug.group_id =$groupid  AND au.user_id IN (".$list.")";

		$data = $this->db->query($sql);
        return $data;		
	}
	
	function exportUsers($companyid ,$check)
	{
		$list = '';
		
		$arr = array();
		$k=0;
		for($j =0;$j<=(count($check) -1);$j++)
		{
			if($check[$j]!='')
			{
				$arr[$k++] = $check[$j];
			}
		}
		$len = count($arr) -1;
		for($i=0 ;$i<=$len;$i++)
		{
			if($arr[$i]!= '' and $i != $len)
			$list .= $arr[$i].',';
			if($arr[$i]!= '' and $i == $len)
			$list .= $arr[$i];
			if($arr[$len] == ''and $i == $len)
			$list .= $arr[$len-1];
		}
		
		//echo $len.$list;exit;
	    $sql = "SELECT distinct  au.*,aui.*
                FROM  `analytic_user` au 
				JOIN `analytic_user_information` aui 
				ON aui.id = au.user_info_id 
                WHERE  au.user_id IN (".$list.")";
		//echo  $sql;exit;
		$data = $this->db->query($sql);
        return $data;		
	}
	
	function viewAllUsers($companyid)
	{
	    $sql = "SELECT au.*,aui.*
                FROM `analytic_user` au
                JOIN `analytic_user_information` aui 
                ON aui.id = au.user_info_id 
                WHERE aui.company_id =$companyid";

		$data = $this->db->query($sql);
        return $data;		
	}
	
	
	function deleteUserrecord($userid)
	{
	    $query = "SELECT `user_info_id` FROM `analytic_user` WHERE `user_id`=$userid";
		$result = $this->db->query($query);
		$userinfoid = $result[0]->user_info_id;
		$sql = "delete FROM `analytic_user` where  `user_id`=$userid";
		$this->db->query($sql);
		$sql1 = "delete FROM `analytic_user_information` where  `id`=$userinfoid";
		$this->db->query($sql1);
		$query1 = "delete FROM `analytic_user_group` where `user_id`=$userid";
		$this->db->query($query1);
	}
	
	function getGroupData($companyid)
	{
	    $sql = "SELECT *
				FROM `analytic_group`
				WHERE `group_id`
				IN (

				SELECT `group_id`
				FROM `analytic_company_group`
				WHERE `company_id` =$companyid
				)
				";
		$result = $this->db->query($sql);
        return $result; 		
	}
	
	
	function checkUserName($emailid)
	{
	    $query = $this->db->query("SELECT * FROM analytic_user WHERE username='$emailid'");
		return $query->count();
	}
	
	function addUserData($arrData , $companyid)
	{
	    $emailid = $arrData['email'];
		$name = $arrData['first_name'];
		$query = $this->db->query("SELECT * FROM analytic_user WHERE username='$emailid'");
		//echo $query->count();exit;
		if($query->count()>0){
			
		}else{
		    $user_information = array(
								"firstname" => $arrData['first_name'],
								"lastname" => $arrData['last_name'],
								"emailid" => $arrData['email'],
								"country" => $arrData['country'],
								"company" => $arrData['company'],
								"company_id" => $companyid 							
								);
			$sql = $this->db->insert('analytic_user_information',$user_information);
			$user_info_id = $sql->insert_id();
			$arrUser = array(
						   "username" => $arrData['email'],
						   "password" => $arrData['first_name'].$arrData['last_name'],
						   "user_info_id" => $user_info_id
					   );
			
			$sql1 = $this->db->insert('analytic_user',$arrUser);
			$userid = $sql1->insert_id();
			foreach($arrData['rolelist'] as $row)
			{
				$arrRole = array(
						   "user_id" => $userid,
						   "role_id" => $row
					   );
				$sql2 = $this->db->insert('analytic_user_role',$arrRole);	   
			}
			
			foreach($arrData['grouplist'] as $row)
			{
				$arrRole = array(
						   "user_id" => $userid,
						   "group_id" => $row
					   );
				$sql3 = $this->db->insert('analytic_user_group',$arrRole);	   
			} 
			// sending mail to each user
			include_once('Mail.php');
			include_once('Mail/mime.php');   
			$recipient = $emailid;
			$sender = SENDER;
			$password = strip_tags($arrData['first_name'].$arrData['last_name']);
			$username = $arrData['email'];
			$html="<h1>Welcome to Expand site</h1></a><br><br>
				   Dear $name ,<br/> 
				   Please find your  credential to <a href='http://www.smartsitehq.com/smartsiteHQ1.5'>Login  into Expand</a><br/><br/>
				   Your username is:<span>&nbsp;&nbsp;</span>". $username."<br><br>
				   Your Password is:$password<br/><br/><br/>
				   thanks,<br/>
				   Expand Admin (eric@getexpanded.com)";
			$subject='Username and Password Details';
			$headers = array(
				  'From'          => $sender,
				  'Return-Path'   => $sender,
				  'Subject'       => $subject
				);
			$crlf = "\n";
			$mime = new Mail_mime($crlf);
			$text = 'This is a text message.';  
			$mime->setTXTBody($text);
			$mime->setHTMLBody($html);
			$body = $mime->get();
			$headers = $mime->headers($headers);
			$mail = Mail::factory('mail');
			$result=$mail->send($recipient, $headers, $body);
			
		}
		
		
	}
	
	
	function getUserData($userid)
	{
	    $sql = "SELECT * FROM `analytic_user` WHERE user_id=$userid";
        $record = $this->db->query($sql);
        return $record; 		
	}
	
	function getUserInfo($user_info_id)
	{
	    $sql = "SELECT * FROM `analytic_user_information` WHERE id=$user_info_id";
		$record = $this->db->query($sql);
		return $record;
	}
	
	function getUserRole($userid)
	{
	    $sql = "SELECT * FROM `analytic_user_role` WHERE user_id=$userid";
		$record = $this->db->query($sql);
		return $record;
	}
	
	function getUserGroup($userid)
    {
	    $sql = "SELECT * FROM `analytic_user_group` WHERE user_id=$userid";
		$record = $this->db->query($sql);
		return $record;
	}
    
    function updateUserData($data,$user_info_id)
    {
	    $this->db->update('analytic_user_information',$data,$user_info_id);
	}

    function updateRoleData($rolelist,$userid)
    {
	    $sql ="DELETE FROM `analytic_user_role` WHERE user_id=$userid";
		$this->db->query($sql);
		foreach($rolelist as $row)
		{
		    $arrRole = array(
		               "role_id" => $row,
					   "user_id" => $userid
		           );
			$this->db->insert('analytic_user_role',$arrRole);	   
		}
		
	}

    function updateGroupData($grouplist,$userid)
    {
	    $sql ="DELETE FROM `analytic_user_group` WHERE user_id=$userid";
		$this->db->query($sql);
		foreach($grouplist as $row)
		{
		    $arrGroup = array(
		               "group_id" => $row,
					   "user_id" => $userid
		           );
			$this->db->insert('analytic_user_group',$arrGroup);	   
		}
	}	
	
	
	//added by Anupama for Group functionality
	function getUserId($groupid)
	{
		$sql = "SELECT * FROM `analytic_user_group` WHERE group_id=$groupid";
		//echo $sql;
		$record = $this->db->query($sql);
		return $record;
	}
	
	function deleteGroupUsers($groupid)
	{
		$query = "SELECT `user_id` FROM `analytic_user_group` WHERE `group_id`=$groupid";
		$result = $this->db->query($query);
		
		foreach($result as $row)
		{
			$userid = $row->user_id;
			$checkq = "SELECT `group_id` FROM `analytic_user_group` WHERE `user_id`=$userid ";
			$reschk = $this->db->query($checkq);
			$chkgroupid = $reschk[0]->group_id;
			if($chkgroupid == $groupid )
			{
				$query1 = "SELECT `user_info_id` FROM `analytic_user` WHERE `user_id`=$userid";
				//echo $query1;
				$result1 = $this->db->query($query1);
				$userinfoid = $result1[0]->user_info_id;
				
				$sql = "delete FROM `analytic_user` where  `user_id`=$userid";
				$this->db->query($sql);
				
				if($userinfoid){
					$sql1 = "delete FROM `analytic_user_information` where  `id`=$userinfoid";
					$this->db->query($sql1);
				}
			}
			
		}
		$sqld = "delete FROM `analytic_user_group` where `group_id`=$groupid";
		$this->db->query($sqld);
		
		$sqlw = "delete FROM `analytic_wizard_group` where `group_id`=$groupid";
		$this->db->query($sqlw);
		
	}
	
	function removeUserrecord($userid,$groupid)
	{	
		$checkq = "SELECT `group_id` FROM `analytic_user_group` WHERE `user_id`=$userid ";
		$reschk = $this->db->query($checkq);
		foreach($reschk as $chk)
		{
			$chkgroupid = $chk->group_id;
			if($chkgroupid == $groupid )
			{	
				$query1 = "delete FROM `analytic_user_group` where  `user_id`=$userid and group_id=$groupid";
				$this->db->query($query1);
			}
		}
		
	}
	
	function getGroupId($userid)
	{		
		$query = "SELECT `group_id` FROM `analytic_user_group` WHERE `user_id`=$userid";
		$result = $this->db->query($query);
		return $result;
	}
	
	
	function getUserAdminList($companyid)
	{
	    $query = "SELECT au.user_id,au.username
					FROM analytic_user_role aur
					INNER JOIN analytic_user au
					ON aur.user_id = au.user_id
					INNER JOIN analytic_user_information aui
					ON aui.id = au.user_id
					WHERE aur.role_id=2 AND aui.company_id=$companyid";
		$result = $this->db->query($query);
		return $result;
	}
	
	function adminName($adminId)
	{
	    $query = "SELECT au.user_id,au.username
					FROM analytic_user au
					WHERE au.user_id=$adminId";
		$result = $this->db->query($query);
		return $result[0]->username;
	}
	
	function importUser($_FILES,$companyid)
	{
	    $_FILES= Validation::factory( $_FILES)->add_rules('csv_upload', 'upload::valid', 'upload::required', 'upload::type[csv]', 'upload::size[5M]');
				if ($_FILES->validate()) 
				{
					$csvTempFile = upload::save('csv_upload');
					ini_set('auto_detect_line_endings',1);
					$handle = fopen($csvTempFile, "r");
					//$errorMessage1="";
					//$errorMessage2="";
					$response = "";
					$first=true;
                    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
					{
						if($first==true)
						{
							$first=false;
							continue;
						}
						if((!empty($data[0])) AND (!empty($data[1])) AND (!empty($data[2])) AND (!empty($data[3])))
						{
							$arrUser = array(
		                                "firstname" => $data[0],
					                    "lastname" => $data[1],
										"company" => $data[2],
										"emailid" => $data[3],
										"country" => $data[4],
										"company_id" => $companyid
		                                );
							$emailid = $arrUser['emailid'];
		                    $query = $this->db->query("SELECT * FROM analytic_user WHERE username='$emailid'");
		                    if($query->count()>0){
			                    $response = "<h3><center>Email:-($data[3]) is already registered<br/>Please Upload CSV file again.</center></h3>";
		                    }else{
							    $result = $this->db->insert('analytic_user_information',$arrUser);
							    $userid=$result->insert_id();
							    $userName=$data[3];	
							    $password = $data[0].$data[1];
								$password = strip_tags($password);
							    if($userid!=0)
							    {
						            $import2="INSERT INTO  analytic_user(user_id,user_info_id,username,password)
VALUES('$userid','$userid','$userName','$password')
ON DUPLICATE KEY UPDATE  username='$userName'";
     							    $this->db->query($import2);
							    }
							    $role = trim($data[5]);
							    $role = explode(',',$role);
							    for($i=0;$i<count($role);$i++)
							    {		
									$rolename = $role[$i];
									$rolename = trim(ucfirst($rolename));
									if($userid!=0)
									{
										if($rolename == "Admin")
										{
										$import3="INSERT INTO analytic_user_role(role_id,user_id) VALUES('2','$userid') ON DUPLICATE KEY UPDATE  user_id='$userid'";
										}
										if($rolename == "User")
										{
										$import3="INSERT INTO analytic_user_role(role_id,user_id) VALUES('1','$userid') ON DUPLICATE KEY UPDATE  user_id='$userid'";
										}
										$this->db->query($import3);
									}
							    }
                                // sending mail to each user
                                include_once('Mail.php');
								include_once('Mail/mime.php');   
								$recipient = $emailid;
								$sender = SENDER;
								$html="<h1>Welcome to Expand site</h1></a><br><br>
								       Dear $data[0] ,<br/> 
									   Please find your  credential to <a href='http://www.smartsitehq.com/smartsiteHQ1.5'>Login  into Expand</a><br/><br/>
									   Your username is:<span>&nbsp;&nbsp;</span>". $emailid."<br><br>
									   Your Password is:$password<br/><br/><br/>
									   thanks,<br/>
									   Expand Admin (eric@getexpanded.com)";
								$subject='Username and Password Details';
								$headers = array(
									  'From'          => $sender,
									  'Return-Path'   => $sender,
									  'Subject'       => $subject
									);
								$crlf = "\n";
								$mime = new Mail_mime($crlf);
								$text = 'This is a text message.';  
								$mime->setTXTBody($text);
								$mime->setHTMLBody($html);
								$body = $mime->get();
								$headers = $mime->headers($headers);
								$mail = Mail::factory('mail');
								$result=$mail->send($recipient, $headers, $body); 								
                                 								
							}
						}
					}	
                    fclose($handle);
					if($response == ""){
						$response = "<h3><center>CSV Uploaded and Email is sent to new users Successfully.</center></h3>";
					}
				}else
				{ 
					$response = "<h3><center>".'Please select a CSV file to upload before clicking the Upload button.'."</center></h3>";
					
				}
		return $response;
	}
}	
