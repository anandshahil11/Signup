<?php defined('SYSPATH') or die('No direct script access.');
class User_Information_Model extends Model{
   
    public function __construct(){   
		parent::__construct();
		$this->session = Session::instance();
		
	}
	
	
	public function getuserInformation($userid){
	
		$query1 = "SELECT user_info_id FROM analytic_user
		            WHERE user_id = $userid";
		$res = $this->db->query($query1);
		$user_info_id = $res[0]->user_info_id;
		
	    $query="SELECT * FROM analytic_user_information
		            WHERE id=$user_info_id";
		$result=$this->db->query($query);
		return $result;
	}
		
	//To Get users last login
	public function getuserlastLogin($userid){
		$query="SELECT last_login,logins FROM analytic_user WHERE user_id='$userid'";
		$result=$this->db->query($query);  		
	    return $result; 	
	}
	
	// To get data based on Employee id
	public function getuserData($id){

	    $query ="SELECT * FROM analytic_user_information WHERE id='$id'";
        $result = $this->db->query($query);
		return $result;		
	
	}
	
	// to Update User data
	public function getuserUpdate($id,$firstname,$lastname,$company,$country,$email){
	    $query = "UPDATE analytic_user_information
		         SET `firstname`='$firstname' ,
				 `lastname`='$lastname' ,`company`='$company',
                  `country`='$country' ,`emailid`='$email'
				 WHERE `id`='$id'";

	    $result = $this->db->query($query);
		
						   
        		
	}
	
	// To Delete User Information from DB
	public function deleteuserInformation($id){
		
		$query2="DELETE FROM analytic_user WHERE user_info_id='$id'";
		$result2=$this->db->query($query2);
	    $success2=$result2->count();
	    $query1="DELETE FROM analytic_user_information WHERE id='$id'";
		$result1=$this->db->query($query1);
	    $success1=$result1->count();
		
		if($success1>0 ){
			$result="Successfully Deleted";
		}else{
		     
		    $result="Either Database Problem or user doesn't Exists.";
		}
		return $result;
		
	}
	
	public function getuserExamresult($empid){
	    
	    $query = "SELECT er.exam_set_id , er.result , er.sess_id  , er.datetime , eqs.name ,er.result_percentage
                 FROM exam_result er , exam_question_sets eqs
                 WHERE er.userid='$empid' AND er.exam_set_id=eqs.id
                 ORDER BY datetime DESC";
		$result = $this->db->query($query);
        $examResult = array();
		$ini = 0;
		$numofattempts = $result->count();
        foreach($result->result() as $row){
            $examResult[$ini]['exam_id'] = $row->exam_set_id;
            $examResult[$ini]['result'] = $row->result;
            $examResult[$ini]['noofattempt'] = $numofattempts;
            $examResult[$ini]['date'] = $row->datetime;
            $examResult[$ini]['examname'] = $row->name;
            $examResult[$ini]['percentage'] = $row->result_percentage;
			$examResult[$ini]['session_id'] = $row->sess_id;
            $ini++;
            break;
        }
		return $examResult;
	}
	
	public function geteachExamResult($empid,$examid)
	{
	    $sql = "SELECT er.exam_set_id, er.result, er.sess_id, er.datetime, eqs.name, er.result_percentage
				FROM exam_result er
				JOIN exam_question_sets eqs ON er.exam_set_id = eqs.id
				WHERE er.userid =$empid
				AND er.exam_set_id =$examid
				ORDER BY datetime DESC
				LIMIT 0 , 1";
		$query = $this->db->query($sql);
        $eachExamResult = array();
		foreach($query->result() as $row)
        {
		    $eachExamResult['examid'] = $row->exam_set_id;
			$eachExamResult['result'] = $row->result;
			$eachExamResult['datetime'] = $row->datetime;
			$eachExamResult['result_percentage'] = $row->result_percentage;
			$eachExamResult['session_id'] = $row->sess_id;
	
		}
        return $eachExamResult;		
	}
	
	public function getuserQuesAnswerList($userid,$examid,$sessionid)
	{
	    $sql = "SELECT question_id,answer, datetime 
		        FROM exam_user_answers
				WHERE sess_id=$sessionid AND userid=$userid AND question_set_id=$examid
				ORDER BY CAST(question_id AS signed)";
		$query = $this->db->query($sql);
		$quesAnsList = array();
		$index = 0;
		foreach($query->result() as $row)
		{
		    $quesAnsList[$index]['ques_id'] = $row->question_id;
            $quesAnsList[$index]['answer'] = $row->answer;
			$quesAnsList[$index]['date'] = $row->datetime;
            $index++;			
		}
		return $quesAnsList;
		
	}
	
	function getQuesAnsSet($examid){
	
		$sql='SELECT id_in_set,text,answer1,answer2,answer3,answer4,correctanswer 
		      FROM exam_questions 
		      WHERE  setId="'.$examid.'"
			  ORDER BY id_in_set' ;
		$query = $this->db->query($sql); 
		$ques_ans=array();
		$index = 0;
		foreach($query->result() as $row){
			$ques_ans[$index]['quesid']= $row->id_in_set;
			$ques_ans[$index]['ques']= $row->text;
			$ques_ans[$index]['ans1']=$row->answer1;
			$ques_ans[$index]['ans2']=$row->answer2;
			$ques_ans[$index]['ans3']=$row->answer3;
			$ques_ans[$index]['ans4']=$row->answer4;
			$ques_ans[$index]['correctanswer']=$row->correctanswer;
			$index++;
		}
	
	    return $ques_ans;
	}
	
	
    function getAnsSelect($examid,$quesid)
	{
		$sql = "SELECT answer,count(answer) as response
                FROM exam_user_answers
				WHERE question_set_id =$examid
				AND question_id=$quesid 
				GROUP BY answer";
		$query = $this->db->query($sql);
		$answer = array();
		$index = 0;
		foreach($query->result() as $row)
		{
			$answer[$row->answer] = $row->response;
		    $index++;
		}
	    return $answer;
	}
	

	
}
?>