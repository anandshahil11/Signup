<?php
/********************************************
AUTHOR:: Anand
Version:: 2.0
Date:: [21/March/11]
Page Description:: user search
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');

class usersearch_Model extends Model
{
	
	public function getfieldlist($field)
	{
		switch($field)
		{
			case 'company':	$sql = "SELECT distinct company FROM analytic_user_information";
							$records = $this->db->query($sql);
							$array = array();
							$i=1;
							foreach($records as $row)
							{
								$array[$row->company]= $row->company;
							}
							print_r($array);
							break;
							
			case 'firstname': $sql = "SELECT distinct firstname FROM analytic_user_information";
							  $records = $this->db->query($sql);
							  $array = array();
							  $i=1;
							  foreach($records as $row)
							  {
								$array[$row->firstname]= $row->firstname;
							  }
							  break;
							  
			case 'lastname':  $sql = "SELECT  distinct lastname FROM analytic_user_information";
							  $records = $this->db->query($sql);
							  $array = array();
							  $i=1;
							  foreach($records as $row)
							  {
								$array[$row->lastname]= $row->lastname;
							  } 
							  break;
							  
			case 'emailid': $sql = "SELECT distinct emailid FROM analytic_user_information";
							$records = $this->db->query($sql);
							$array = array();
							$i=1;
							foreach($records as $row)
							{
							  $array[$row->emailid]= $row->emailid;
							} 
							break;
			default : break;
		}
		return $array;
	}
	
	
	public function getDatas($criteriaId,$field,$criteria,$detailVal,$datef,$datet)
	{	
		$count = count($criteriaId);
		$sql ="SELECT  distinct (id),aui.* ,au.last_login FROM analytic_user_information aui 
				JOIN analytic_user au ON au.user_info_id = aui.id  ";
		$checklist=1;
		$sqlFinal = " where 1";
	    for($i=0;$i<($count-1);$i++)
		{	
			$check = explode('-',$criteriaId[$i]);
			if($check[0] == "checklist")
			{
				$sql .= " JOIN `analytic_checklist_item_answer` acia$checklist ON acia$checklist.user_id=";
				if($checklist==1)
				$sql .= "au.user_id";
				else
				{
					$num=$checklist-1;
					$sql .= "acia".$num.".user_id";
				}
				
				$user = new userSearch_Model;
				$itemtype = $user->getItemtype($field[$i]);
				if($itemtype =='Multiple Selection')
				{
					$sql .=" JOIN analytic_checklist_item_answer_options  aciao$checklist ON  acia$checklist.item_ans_id=aciao$checklist.checklist_item_answer_id
							 join analytic_checklist_item_options acio$checklist on aciao$checklist.checklist_item_options_id=acio$checklist.item_options_id";
					if($criteria[$i] == 'Is Correct' && $detailVal[$i] != '')
					$sql.=" and acio$checklist.item_options_value='$detailVal[$i]'";
					if($criteria[$i] == 'Is Incorrect' && $detailVal[$i] != '')
					$sql.=" and acio$checklist.item_options_value!='$detailVal[$i]'";
					if($criteria[$i] == 'Contains' && $detailVal[$i] != '')
					$sql.=" and acio$checklist.item_options_value like '%$detailVal[$i]%'";
					if($criteria[$i] == 'Doesn\'t Contains' && $detailVal[$i] != '')
					$sql.=" and acio$checklist.item_options_value  not like'%$detailVal[$i]%'";
				}
				else
				{
					if($criteria[$i] == 'Is' && $detailVal[$i] != '' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans='$detailVal[$i]'";
					if($criteria[$i] == 'Is Not' && $detailVal[$i] != '' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i] ." and acia$checklist.item_ans!='$detailVal[$i]'";
					if($criteria[$i] == 'Contains' && $detailVal[$i] != ''  )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i] ." and acia$checklist.item_ans LIKE '%$detailVal[$i]%'";
					if($criteria[$i] == 'Doesn\'t Contains' && $detailVal[$i] != '' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i] ." and acia$checklist.item_ans NOT LIKE '%$detailVal[$i]%'";
					if($criteria[$i] == 'Begins With' && $detailVal[$i] != '' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i] ." and acia$checklist.item_ans LIKE '$detailVal[$i]%'";
					if($criteria[$i] == 'Ends With'&& $detailVal[$i] != '' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i] ." and acia$checklist.item_ans LIKE '%$detailVal[$i]'";
					if($criteria[$i] == 'Equals' && $detailVal[$i] != '' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans=$detailVal[$i]";
					if($criteria[$i] == 'Doesn\'t Equals' && $detailVal[$i] != '')
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans!=$detailVal[$i]";
					if($criteria[$i] == 'Greater Than' && $detailVal[$i] != '' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans > $detailVal[$i]";
					if($criteria[$i] == 'Less Than' && $detailVal[$i] != '')
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans < $detailVal[$i]";
					if($itemtype=='Date')
					{
						$timestamp = strtotime($detailVal[$i]);
						
						$today =strtotime(date("m/d/Y"));
					}
		
					if($criteria[$i] == 'Is Exactly' && $detailVal[$i] != '')
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans ='$timestamp'";
					if($criteria[$i] == 'Is Before' && $detailVal[$i] != '')
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans <='$timestamp'";
					if($criteria[$i] == 'Is After' && $detailVal[$i] != '')
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans >='$timestamp'";
					if($criteria[$i] == 'Is Within' && $datef != '' && $datet != '')
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i]." and acia$checklist.item_ans BETWEEN '".strtotime($datef)."'  AND '".strtotime($datet)."'";
			
					if($criteria[$i] == 'Is Correct' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i];
					if($criteria[$i] == 'Is Incorrect' )
					$sql .=" and acia$checklist.checklist_item_id=". $field[$i];
				}
				$checklist++;
			}
			if($check[0] == "Profile Data")
			{
				if($criteria[$i] == 'Is' && $detailVal[$i] != '')
					$sqlFinal .= " and $field[$i] ='$detailVal[$i]'";
				if($criteria[$i] == 'Is Not' && $detailVal[$i] != '')
					$sqlFinal .= " and $field[$i] != '$detailVal[$i]'";
				if($criteria[$i] == 'Contains' && $detailVal[$i] != '')
					$sqlFinal .= " and $field[$i] LIKE '%$detailVal[$i]%'";
				if($criteria[$i] == 'Doesn\'t Contains' && $detailVal[$i] != '')
					$sqlFinal .= " and $field[$i] NOT LIKE '%$detailVal[$i]%'";
				if($criteria[$i] == 'Begins With' && $detailVal[$i] != '')
					$sqlFinal .= " and $field[$i] LIKE '$detailVal[$i]%'";
				if($criteria[$i] == 'Ends With' && $detailVal[$i] != '')
					$sqlFinal .= " and $field[$i] LIKE '%$detailVal[$i]'";

				
			}
		}
			$sql.=$sqlFinal;
			//echo $sql;exit;
			$result = $this->db->query($sql);
			return $result;
		
	}
	
	
	function getusersearchInformation($companyid,$trimmed_array)
	{
		foreach ($trimmed_array as $trimm){
			  
			$query = "SELECT aui.* ,au.last_login 
			          FROM analytic_user_information aui
					  JOIN analytic_user au 
					  ON au.user_info_id =aui.id	
				      WHERE company_id LIKE '%$companyid%' AND 
				      (`firstname` LIKE '%$trimm%' OR `lastname` like '%$trimm%' OR `emailid` like '%$trimm%' OR `company` like '%$trimm%' OR `country` like '%$trimm%') ORDER BY id  ASC" ; 	   
			$numresults=$this->db->query($query);
            $row_num_links_main =$numresults->count();
		        $userInfo=array();
		        $i=0;
		    foreach($numresults->result_array(FALSE) as $row){
				$userInfo[$i]['id']=$row['id'];
				$userInfo[$i]['first']=$row['firstname'];
				$userInfo[$i]['last']=$row['lastname'];
				$userInfo[$i]['company']=$row['company'];
				$userInfo[$i]['emailid']=$row['emailid'];
			    $userInfo[$i]['country']=$row['country'];
				$userInfo[$i]['last_login']=$row['last_login'];
				$i++;
				}
		}	
		return $userInfo;
	}
	
	
	function getchecklist()
	{
		$query = "SELECT * FROM analytic_checklist";
		$result = $this->db->query($query);
		return $result;
	}
	
	function getchecklistdetails($id)
	{	
		
		if(!is_numeric($id))
		{
			$id = trim($id); 
			$sql ="SELECT checklist_id FROM analytic_checklist WHERE checklist_name='$id'";
			$res = $this->db->query($sql);
			$id = $res[0]->checklist_id;
		}

		$sql = "SELECT * FROM analytic_checklist_items WHERE checklist_id ='$id' ";
		$result = $this->db->query($sql);
		$type = $result[0]->items_type;
		
		$array = array();
		$i=1;
		foreach($result as $row)
		{
			$array[$row->items_id]= $row->items_title;
		}
		//$array['type']=$type;
		return $array;
	}
	
	function getItems($id)
	{
		$sql = "SELECT distinct item_ans FROM analytic_checklist_item_answer WHERE checklist_item_id ='$id' ";
		//echo $sql; exit;
		$result = $this->db->query($sql);
		$array = array();
		foreach($result as $row)
		{
			$array[$row->item_ans]= $row->item_ans;
		}
		//print_r($array);exit;
		return $array;
		
	}
	function getMultipleTypeItems($id)
	{
		$sql = "SELECT item_options_value  FROM analytic_checklist_item_options  join analytic_checklist_item_answer_options on `checklist_item_options_id`=`item_options_id` where `checklist_item_id` ='$id' ";
		//echo $sql; exit;
		$result = $this->db->query($sql);
		$array = array();
		foreach($result as $row)
		{
			$array[$row->item_options_value]= $row->item_options_value;
		}
		//print_r($array);exit;
		return $array;
		
	}
	function getCheckListUser($id)
	{
		$sql = "SELECT au.user_id,concat(firstname,' ',lastname) as name FROM analytic_user_information aui
					  JOIN analytic_user au ON au.user_info_id =aui.id	
					  join analytic_checklist_item_answer on item_ans=au.user_id
					  where `checklist_item_id` ='$id' ";
		//echo $sql; exit;
		$result = $this->db->query($sql);
		$array = array();
		foreach($result as $row)
		{
			$array[$row->user_id]= $row->name;
		}
		//print_r($array);exit;
		return $array;
		
	}
	function getItemtype($id)
	{
		$sql = "SELECT items_type FROM  `analytic_checklist_items` WHERE items_id=$id";
		$result = $this->db->query($sql);
		foreach($result as $row)
				$type = $row->items_type;
	
		return $type; 
	}
	function getItemProfileType($id)
	{
		$sql = "SELECT items_profile_type FROM  `analytic_checklist_items` WHERE items_id=$id";
		$result = $this->db->query($sql);
		foreach($result as $row)
				$type = $row->items_profile_type;
	
		return $type; 
	}
	
	function totalusers()
	{
		$sql = "SELECT distinct emailid FROM `analytic_user_information`";
		$result = $this->db->query($sql);
		return count($result);
	}
}


?>