<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [04/Feb/11]
Page Description:: wizard page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');
class wizard_Model extends Model
{
	//function for get question
	public function getQuestion($wizardId)
	{
		
		$sql = "SELECT * FROM analytic_wizard_issue where wizard_id=$wizardId order by `order`";
		$results = $this->db->query($sql);
		return $results;
	}
	//function for wizard info
	public function getWizardInfo($wizardId)
	{
		
		$sql = "SELECT * FROM analytic_wizard where wizard_id=$wizardId ";
		$results = $this->db->query($sql);
		return $results[0];
	}
	//function for create new issue
	public function createNew($text,$wizardId){
		
		$sql = "SELECT if( MAX( `order` ) ,MAX(`order`), 0 ) as order_num  FROM 
				analytic_wizard_issue where wizard_id=$wizardId";
		$results = $this->db->query($sql);
		$order=$results[0]->order_num+1;
		$arrData=array(
				"order"=>$order,
				"wizard_id"=>$wizardId,
				"issue_name"=>$text
				);
		$query=$this->db->insert('analytic_wizard_issue',$arrData);
		echo  '<li id="todo-'.$query->insert_id().'" class="todo  odd">
				<div class="text"><a href="#" class="edit">'.$text.'</a>
				<div class="text"><a href="#" class="edit">'.$text.'</a>
				<a href="'.url::base(FALSE).'index.php/wizard/media?id='.$query->insert_id().'&type=I&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> 
				<script language="javascript">
					tb_init("a.thickbox, area.thickbox, input.thickbox");
				</script>
				</div>
				
			</li>';
		exit;
	}
	//function for delete issue
	public function delete($deleteId)
	{
		$sql = "delete FROM analytic_wizard_issue where  issue_id=$deleteId";
		$this->db->query($sql);
	}
	//function for update issue
	public function update($editId,$text)
	{
		$sql = "update analytic_wizard_issue set  issue_name='".$text."' where   issue_id=$editId";
		$this->db->query($sql);
	}
	//function for rearrange the issue
	public function rearrange($arrage,$wizardId)
	{	
		$arrArrange=explode(',',$arrage);
		$order=0;
		$sql = "SELECT * FROM analytic_wizard_issue where wizard_id =$wizardId order by `order`";
		$results = $this->db->query($sql);
		foreach($results as $row)
		{
			$sql = "update analytic_wizard_issue set  `order`=".($order+1)." where issue_id=".$arrArrange[$order];
			$this->db->query($sql);
			$order++;
		}
	}
	//function for create new symptom
	public function createNewSymptom($issue_id,$text){
		
		$sql = "SELECT if( MAX( `order` ) ,MAX(`order`), 0 ) as order_num FROM 
				analytic_wizard_symptom where issue_id=$issue_id";
		$results = $this->db->query($sql);
		$order=$results[0]->order_num+1;
		$arrData=array(
				"order"=>$order,
				"issue_id"=>$issue_id,
				"symptom_name"=>$text
				);
		$query=$this->db->insert('analytic_wizard_symptom',$arrData);
		echo  '<li id="todo-'.$query->insert_id().'" class="todo odd">
				<div class="text"><a href="#" class="edit">'.$text.'</a>
				<a href="'.url::base(FALSE).'index.php/wizard/media?id='.$query->insert_id().'&type=S&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> 
				<script language="javascript">
					tb_init("a.thickbox, area.thickbox, input.thickbox");
				</script>
				</div>
			</li>';
		exit;
	}
	//function for get the symptom
	public function getSymptom($issue_id)
	{
		$sql = "SELECT *  FROM 	analytic_wizard_symptom where issue_id=$issue_id order by `order`";
		$results = $this->db->query($sql);
		$i=0;
		foreach($results as $row)
		{
			$i++;
			if($i%2==0)
			$class='odd';
			else
			$class='even';
			echo  '<li id="todo-'.$row->symptom_id.'" class="todo '.$class.'">
					<div class="text"><a href="#" class="edit" >'.$row->symptom_name.'</a>
					<a href="'.url::base(FALSE).'index.php/wizard/media?id='.$row->symptom_id.'&type=S&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> 
					<script language="javascript">
						tb_init("a.thickbox, area.thickbox, input.thickbox");
					</script>
					</div>
				</li>';
		}
		exit;
	}
	//function for update the symptom
	public function updateSymptom($editId,$text)
	{
		$sql = "update analytic_wizard_symptom set  symptom_name='".$text."' where   symptom_id=$editId";
		$this->db->query($sql);
	}
	//function for delete symptom
	public function deleteSymptom($deleteId)
	{
		$sql = "delete FROM analytic_wizard_symptom where  symptom_id=$deleteId";
		$this->db->query($sql);
	}
	//function for rearrange the issue
	public function rearrangeSymptom($issueId,$arrage)
	{	
		$arrArrange=explode(',',$arrage);
		$order=0;
		$sql = "SELECT * FROM analytic_wizard_symptom where issue_id =$issueId order by `order`";
		$results = $this->db->query($sql);
		foreach($results as $row)
		{
			$sql = "update analytic_wizard_symptom set  `order`=".($order+1)." where symptom_id=".$arrArrange[$order];
			$this->db->query($sql);
			$order++;
		}
	}
	//function for get the cause
	public function getCause($symptomId)
	{
		$sql = "SELECT *  FROM 	analytic_wizard_cause where   	symptom_id=$symptomId order by `order`";
		$results = $this->db->query($sql);
		$i=0;
		foreach($results as $row)
		{
			$i++;
			if($i%2==0)
			$class='odd';
			else
			$class='even';
			echo  '<li id="todo-'.$row->cause_id.'" class="todo '.$class.'">
					<div class="text"><a href="#" class="edit" >'.$row->cause_name.'</a>
					<a href="'.url::base(FALSE).'index.php/wizard/media?id='.$row->cause_id.'&type=C&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> <span style="float:right">'.$row->cause_type 	.'</span>
					<script language="javascript">
						tb_init("a.thickbox, area.thickbox, input.thickbox");
					</script>
					</div>
					
				</li>';
		}
		exit;
	}
	//function for create new cause
	public function createNewCause($symId,$text){
		$sql = "SELECT if( MAX( `order` ) ,MAX(`order`), 0 ) as order_num FROM 
				analytic_wizard_cause where symptom_id=$symId";
		$results = $this->db->query($sql);
		$order=$results[0]->order_num+1;
		$arrData=array(
				"order"=>$order,
				"symptom_id"=>$symId,
				"cause_name"=>$text
				);
		$query=$this->db->insert('analytic_wizard_cause',$arrData);
		echo  '<li id="todo-'.$query->insert_id().'" class="todo odd">
				<div class="text"><a href="#" class="edit">'.$text.'</a>
				<a href="'.url::base(FALSE).'index.php/wizard/media?id='.$query->insert_id().'&type=C&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> 
					<script language="javascript">
						tb_init("a.thickbox, area.thickbox, input.thickbox");
					</script>
				</div>
			   </li>';
		exit;
	}
	//function for delete symptom
	public function deleteCause($deleteId)
	{
		$sql = "delete FROM analytic_wizard_cause where  cause_id =$deleteId";
		$this->db->query($sql);
	}
	//function for update cuase
	public function updateCause($editId,$text,$type)
	{
		$sql = "update analytic_wizard_cause set  cause_name='".$text."',cause_type='".$type."' where   cause_id =$editId";
		$this->db->query($sql);
	}
	//function for rearrange the cause
	public function rearrangeCause($symptomId,$arrage)
	{	
		$arrArrange=explode(',',$arrage);
		$order=0;
		$sql = "SELECT * FROM analytic_wizard_cause where symptom_id =$symptomId order by `order`";
		$results = $this->db->query($sql);
		foreach($results as $row)
		{
			$sql = "update analytic_wizard_cause set  `order`=".($order+1)." where cause_id=".$arrArrange[$order];
			$this->db->query($sql);
			$order++;
		}
	}
	//function for get the cause
	public function getSolution($causeId)
	{
		$sql = "SELECT *  FROM 	analytic_wizard_solution where  cause_id=$causeId order by `order`";
		$results = $this->db->query($sql);
		$i=0;
		foreach($results as $row)
		{
			$i++;
			if($i%2==0)
			$class='odd';
			else
			$class='even';
			echo  '<li id="todo-'.$row->solution_id.'" class="todo '.$class.'">
					<div class="text" style="border:1px solid #EEEEEE"><a href="#" class="edit" >'.$row->solution_title.'</a>
					
					</div>
					<div class="text2" style="border:1px solid #EEEEEE"><a href="#" class="edit2" >'.$row->solution_subtitle.'</a></div>
				</li>';
		}
		exit;
	}
	//function for create new Solution
	public function createNewSolution($cause_id,$text){
		$sql = "SELECT if( MAX( `order` ) ,MAX(`order`), 0 ) as order_num FROM 
				 analytic_wizard_solution where cause_id=$cause_id";
		$results = $this->db->query($sql);
		$order=$results[0]->order_num+1;
		$arrData=array(
				"order"=>$order,
				"cause_id"=>$cause_id,
				"solution_title"=>$text,
				"solution_subtitle"=>'Enter Solution Sub Title'
				);
		$query=$this->db->insert('analytic_wizard_solution',$arrData);
		echo  '<li id="todo-'.$query->insert_id().'" class="todo odd">
				<div class="text" style="border:1px solid #EEEEEE"><a href="#" class="edit">'.$text.'</a></div>
				<div class="text2" style="border:1px solid #EEEEEE"><a href="#" class="edit2">Enter Solution Sub Title</a></div>
			</li>';
		exit;
	}
	//function for update solution
	public function updateSolution($editId,$text)
	{
		$sql = "update analytic_wizard_solution set  solution_title='".$text."' where   solution_id =$editId";
		$this->db->query($sql);
	}
	//function for update solution
	public function updateSolutionSubtitle($editId,$text)
	{
		$sql = "update analytic_wizard_solution set  solution_subtitle='".$text."' where   solution_id =$editId";
		$this->db->query($sql);
	}
	//function for delete solution
	public function deleteSolution($deleteId)
	{
		$sql = "delete FROM analytic_wizard_solution where  solution_id =$deleteId";
		$this->db->query($sql);
	}
	//function for rearrange the solution
	public function rearrangeSolution($causeId,$arrage)
	{	
		$arrArrange=explode(',',$arrage);
		$order=0;
		$sql = "SELECT * FROM analytic_wizard_solution where cause_id =$causeId order by `order`";
		$results = $this->db->query($sql);
		foreach($results as $row)
		{
			$sql = "update analytic_wizard_solution set  `order`=".($order+1)." where solution_id=".$arrArrange[$order];
			$this->db->query($sql);
			$order++;
		}
	}
	//function for create new Solution steps
	public function createNewSolutionSteps($solutionId,$text){
		$sql = "SELECT if( MAX( `order` ) ,MAX(`order`), 0 ) as order_num FROM 
				 analytic_wizard_solution_steps where solution_id=$solutionId";
		$results = $this->db->query($sql);
		$order=$results[0]->order_num+1;
		$arrData=array(
				"order"=>$order,
				"solution_id"=>$solutionId,
				"solution_steps"=>$text
				);
		$query=$this->db->insert('analytic_wizard_solution_steps',$arrData);
		echo  '<li id="todo-'.$query->insert_id().'" class="todo odd">
				<div class="text" ><a href="#" class="edit">'.$text.'</a>
				<a href="'.url::base(FALSE).'index.php/wizard/media?id='.$query->insert_id().'&type=ST&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> 
					<script language="javascript">
						tb_init("a.thickbox, area.thickbox, input.thickbox");
					</script>
				
				</div>
			</li>';
		exit;
	}
	//function for get the solution steps
	public function getSolutionSteps($solutionId)
	{
		$sql = "SELECT *  FROM 	analytic_wizard_solution_steps where  solution_id=$solutionId order by `order`";
		$results = $this->db->query($sql);
		$i=0;
		foreach($results as $row)
		{
			$i++;
			if($i%2==0)
			$class='odd';
			else
			$class='even';
			echo  '<li id="todo-'.$row->solution_steps_id.'" class="todo '.$class.'">
					<div class="text" ><a href="#" class="edit" >'.$row->solution_steps.'</a>
					<a href="'.url::base(FALSE).'index.php/wizard/media?id='.$row->solution_steps_id.'&type=ST&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> 
					<script language="javascript">
						tb_init("a.thickbox, area.thickbox, input.thickbox");
					</script>
					</div>
				</li>';
		}
		exit;
	}
	//function for rearrange the solution steps
	public function rearrangeSolutionSteps($solutionId,$arrage)
	{	
		$arrArrange=explode(',',$arrage);
		$order=0;
		$sql = "SELECT * FROM analytic_wizard_solution_steps where   solution_id =$solutionId order by `order`";
		$results = $this->db->query($sql);
		foreach($results as $row)
		{
			$sql = "update analytic_wizard_solution_steps set  `order`=".($order+1)." where W=".$arrArrange[$order];
			$this->db->query($sql);
			$order++;
		}
	}
	//function for update solution steps
	public function updateSolutionSteps($editId,$text)
	{
		$sql = "update analytic_wizard_solution_steps set  solution_steps='".$text."' where   solution_steps_id =$editId";
		$this->db->query($sql);
	}
	//function for delete steps
	public function deleteSolutionSteps($deleteId)
	{
		$sql = "delete FROM analytic_wizard_solution_steps where  solution_steps_id=$deleteId";
		$this->db->query($sql);
	}
	public function checkdata($id)
	{	
		$sql = "select * from analytic_wizard_media where link_id='".$id."'";
		$lastdata = $this->db->query($sql);
		return $lastdata;
	}
	public function saveMedia($arrData)
	{
		$query=$this->db->insert('analytic_wizard_media',$arrData);
	}
	
	public function updateMedia($arrData)
	{
		$sql = "update analytic_wizard_media  SET media_type ='".$arrData['media_type']."', media_value ='".$arrData['media_value']."',media_ipad_value ='".$arrData['media_ipad_value']."', media_description ='".$arrData['media_description']."' where  link_id='".$arrData['link_id']."'";
		$this->db->query($sql);
	}
}
