<?php
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [24/Feb/11]
Page Description:: wizard  search
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');

class wizardsearch_Model extends Model
{
		
	public function getWizards()
	{
		$sql = "SELECT  * FROM analytic_wizard";
		$records = $this->db->query($sql);
		return $records;
	}
	public function getList($wizardId,$listopt,$issueId,$symptomId,$causeId,$solutionId)
	{
		if($listopt=='Issues')
		$sql="select issue_id id ,issue_name name from analytic_wizard_issue where wizard_id=$wizardId";
		if($listopt=='Symptom')
		{
			$sql="select symptom_id id ,symptom_name name from analytic_wizard_symptom  ws
				  join analytic_wizard_issue wi on wi.issue_id=ws.issue_id
				  where wizard_id=$wizardId ";
			if(!empty($issueId))
			$sql.= "and ws.issue_id=$issueId";
		}
		if($listopt=='Cause')
		{
			$sql="select cause_id id ,cause_name name from analytic_wizard_cause  wc
				  join analytic_wizard_symptom ws on wc.symptom_id=ws.symptom_id
				  join analytic_wizard_issue wi on wi.issue_id=ws.issue_id
				  where wizard_id=$wizardId";
			if(!empty($issueId))
			$sql.= " and ws.issue_id=$issueId";
			if(!empty($symptomId))
			$sql.= " and wc.symptom_id=$symptomId";
		}
		if($listopt=='Solution')
		{
			$sql="select solution_id id ,solution_title name from analytic_wizard_solution  wsol
				  join analytic_wizard_cause wc on wc.cause_id=wsol.cause_id
				  join analytic_wizard_symptom ws on wc.symptom_id=ws.symptom_id
				  join analytic_wizard_issue wi on wi.issue_id=ws.issue_id
				  where wizard_id=$wizardId ";
			if(!empty($issueId))
			$sql.= " and ws.issue_id=$issueId";
			if(!empty($symptomId))
			$sql.= " and wc.symptom_id=$symptomId";
			if(!empty($causeId))
			$sql.= " and wc.cause_id=$causeId";
		}
		//echo $sql;exit;
		$records = $this->db->query($sql);
		return $records;
	}
	public function getDatas($wizardId,$issueId,$symptomId,$causeId,$solutionId,$lastIssue,$criteria)
	{
		$sqlTotalIssueView="select count(wr.issue_id) as totalview from analytic_wizard_issue wi  
								join analytic_wizard_response wr on wi.issue_id=wr.issue_id where wi.wizard_id=$wizardId";
		$records = $this->db->query($sqlTotalIssueView);
		$TotalIssueView=$records[0]->totalview;
		if($lastIssue=='Issues')
		{
			$sql="select ws.symptom_id id ,symptom_name name,'Symptom' as type,wizard_name,created_date,sum(if(wr.symptom_id is null,0,1)) as views 
				from analytic_wizard_symptom  ws
				join analytic_wizard_issue wi on wi.issue_id=ws.issue_id
				join analytic_wizard wiz on wiz.wizard_id=wi.wizard_id
				left join analytic_wizard_response wr on ws.symptom_id=wr.symptom_id
				where wiz.wizard_id=$wizardId";
			if(!empty($issueId))
			{
				if($criteria['IssuesCri']=='Is')
				$sql.= " and ws.issue_id=$issueId";
				else
				$sql.= " and ws.issue_id!=$issueId";
			}
			
			$sql.= " group by wr.symptom_id";
			//echo $sql;exit;
		}
		if($lastIssue=='Symptom')
		{
			$sql="select wc.cause_id id ,cause_name name,'Cause' as type,wizard_name,created_date,sum(if(wr.symptom_id is null,0,1)) as views
				  from analytic_wizard_cause  wc
				  join analytic_wizard_symptom ws on wc.symptom_id=ws.symptom_id
				  join analytic_wizard_issue wi on wi.issue_id=ws.issue_id
				  join analytic_wizard wiz on wiz.wizard_id=wi.wizard_id
				  left join analytic_wizard_response wr on wc.cause_id=wr.cause_id
				  where wiz.wizard_id=$wizardId";
			if(!empty($issueId))
			{
				if($criteria['IssuesCri']=='Is')
				$sql.= " and ws.issue_id=$issueId";
				else
				$sql.= " and ws.issue_id!=$issueId";
			}
			if(!empty($symptomId))
			{
				if($criteria['SymptomCri']=='Is')
				$sql.= " and wc.symptom_id=$symptomId";
				else
				$sql.= " and wc.symptom_id!=$symptomId";
			}
			$sql.= " group by wc.cause_id";
		}
		if($lastIssue=='Cause')
		{
			$sql="select wsol.solution_id id,solution_title name,'Solution' as type,wizard_name,created_date,sum(if(wr.symptom_id is null,0,1)) as views
				  from analytic_wizard_solution  wsol
				  join analytic_wizard_cause wc on wc.cause_id=wsol.cause_id
				  join analytic_wizard_symptom ws on wc.symptom_id=ws.symptom_id
				  join analytic_wizard_issue wi on wi.issue_id=ws.issue_id
				  join analytic_wizard wiz on wiz.wizard_id=wi.wizard_id
				  left join analytic_wizard_response wr on wsol.solution_id=wr.solution_id
				  where wiz.wizard_id=$wizardId ";
			if(!empty($issueId))
			{
				if($criteria['IssuesCri']=='Is')
				$sql.= " and ws.issue_id=$issueId";
				else
				$sql.= " and ws.issue_id!=$issueId";
			}
			if(!empty($symptomId))
			{
				if($criteria['SymptomCri']=='Is')
				$sql.= " and wc.symptom_id=$symptomId";
				else
				$sql.= " and wc.symptom_id!=$symptomId";
			}
			if(!empty($causeId))
			{
				if($criteria['CauseCri']=='Is')
				$sql.= " and wc.cause_id=$causeId";
				else
				$sql.= " and wc.cause_id!=$causeId";
			}
			$sql.= " group by wsol.solution_id";
		}
		if($lastIssue=='Solution')
		{
			$sql="select wsol.solution_id id,solution_title name,'Solution' as type,wizard_name,created_date,sum(if(wr.symptom_id is null,0,1)) as views
				  from analytic_wizard_solution  wsol
				  join analytic_wizard_cause wc on wc.cause_id=wsol.cause_id
				  join analytic_wizard_symptom ws on wc.symptom_id=ws.symptom_id
				  join analytic_wizard_issue wi on wi.issue_id=ws.issue_id
				  join analytic_wizard wiz on wiz.wizard_id=wi.wizard_id
				  left join analytic_wizard_response wr on wsol.solution_id=wr.solution_id
				  where wiz.wizard_id=$wizardId ";
			if(!empty($issueId))
			{
				if($criteria['IssuesCri']=='Is')
				$sql.= " and ws.issue_id=$issueId";
				else
				$sql.= " and ws.issue_id!=$issueId";
			}
			if(!empty($symptomId))
			{
				if($criteria['SymptomCri']=='Is')
				$sql.= " and wc.symptom_id=$symptomId";
				else
				$sql.= " and wc.symptom_id!=$symptomId";
			}
			if(!empty($causeId))
			{
				if($criteria['CauseCri']=='Is')
				$sql.= " and wc.cause_id=$causeId";
				else
				$sql.= " and wc.cause_id!=$causeId";
			}
			if(!empty($solutionId))
			{
				if($criteria['SolutionCri']=='Is')
				$sql.= " and wsol.solution_id=$solutionId";
				else
				$sql.= " and wsol.solution_id!=$solutionId";
			}
			$sql.= " group by wsol.solution_id";
		}
		//echo $sql;exit;
		$records = $this->db->query($sql);
		$datas['totalview']=$TotalIssueView;
		$datas['records']=$records;
		return $datas;
	}
}
?>