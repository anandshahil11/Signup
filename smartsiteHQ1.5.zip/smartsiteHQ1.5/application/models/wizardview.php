<?php
/********************************************
AUTHOR:: Anupama
Version:: 2.0
Date:: [14/Feb/11]
Page Description:: wizard  view  all page 
*********************************************/
defined('SYSPATH') or die('No Direct Script Access');

class wizardview_Model extends Model
{
		
	function getallRecords()
	{
		//$sql = "SELECT  * FROM analytic_wizard GROUP BY wizard_name ";
		$sql = "SELECT  * FROM analytic_wizard ";
		$records = $this->db->query($sql);
		return $records;
	}
	
	function deleteRecord($id)
	{
		$sql = "DELETE FROM analytic_wizard_group WHERE wizard_id in(".$id.")";
		$this->db->query($sql);
		$sql_w = "DELETE FROM analytic_wizard WHERE wizard_id in(".$id.")";
		$this->db->query($sql_w);
	}
}
?>