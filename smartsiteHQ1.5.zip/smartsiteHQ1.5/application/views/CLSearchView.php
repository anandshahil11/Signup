<?php 
require_once('header.php');
?>
<style type="text/css">
@import "<?php echo url::base(FALSE) ?>media/css/calender/jquery.datepick.css";
</style>
<script language="javascript">
var url='<?php echo url::base(FALSE) ?>index.php/userSearch';
</script>
<div id="module_middle">
    <?php require_once('userLeftPanel2.php');?>
	<div id="module_content" style="width:81.8%">
		<form id="viewAll" name ="viewAll"  method="post">
		<input type="hidden" id="deleterow" name="deleterow"  value=""/>
	    <input type="hidden" id="editid" name="editid"  value=""/>
    	<div id="module_edit_header">
        	<h1>All Completed Checklists</h1>
        </div><!-- end #module_content_header -->
		 <div id="user_content" style="width:100%">
        <form id="search" action="">
		 <div  id="append">
		 <div id="append1" class="popup_addusers_controls"  style="width:100%">
            	<div class="popup_addusers_controls_items">
                	<select name="user_criteria1" id="user_criteria1" onchange="getfieldlist(this,1);changeRows(1);" style='width:170px;'>
						<option value="">Select</option>		
						<?php 
							foreach($primarylist as $list)
							{
								if(!is_array ($list))
									echo '<option value="'.$list.'"  style="width:150px;">'.$list.'</option>';
								else
									{
										foreach($list as $key => $value)
										{
											echo '<option value="'.$key.'"  >'.$value.'</option>';
										}
									}
							}
						?>
                	</select>
                    
                	<span class="popup_addusers_controls_pad">|</span>
                    
                	<select name="user_detail1" id="user_detail1" onchange="getvaluelist(this,1);changerow(1);changeoption(this,1);" style='width:180px;'>
						<option value="">Select</option>
                		
                	</select>
                    
                	<span class="popup_addusers_controls_pad">|</span>
                    
                	<select name="options1" id="options1"   onchange="checkoption(this,1)" style='width:170px;'>
						<option value="">Select</option>	
					
                	</select>
                    
                	<span class="popup_addusers_controls_pad">|</span>
					
					    <div id="hideShow11"  style="float:right;display:none;margin-left:1px;margin-top:-3px;margin-right:-10px;" > 
						<span style="margin-left:-2px;">From</span><input type="text" id="popupDatepicker1" size='10' style="margin-left:1px;margin-top:8px;">|
						<span style="margin-left:-2px;">To</span><input type="text" id="popupDatepicker21" size='10' style="margin-left:1px;margin-top:8px;">
					</div>
					
					<div id="hideShow1" style="float:right;display:block;"> 
						<select name="user_detail_val1" id="user_detail_val1" onchange="getDatas(1)" style='width:170px;'>
							<option value="">Select</option>

						</select>
					</div>
					
				
                </div><!-- end .popup_addusers_controls_items -->
                
                <div class="controls_addremove" style="margin-left:5px">
					<a href="#" class="control_add" onclick="add()"></a>
            		<a href="#" class="control_remove" onclick="remove()"></a>
                </div>
				<div id="recordsCount1" style="margin-left:780px;">
            	    <p> </p>
                </div>
            </div><!-- end .popup_addusers_controls -->
			</div>
          </div><!-- end .popup_addusers_controls -->
            
            <div id="usersearch_content" style="width:100%;overflow:hidden">
            <table  id="datarow" width="100%"  class="tablesorter">
                	<tr>
						<th >Checklist Name</th>
                	    <th >ID Number</th>
                	    <th >Completed</th>
                	    <th >Operator</th>
                    </tr>
                </table>
                </div><!-- end #usersearch_content -->
            </form>    
    </div><!-- end #user_content -->
   
			
    </div><!-- end #module_content -->    
<div class="clearfloat"></div>
</div><!-- end #module_middle -->
<script language="javascript">
rownum=1;
var clicked = '';

function getfieldlist(obj,boxnum)
{
	tempUrl=url+'/getfieldList';
	criteriaId=$('#user_criteria1').val();
	selectedValue ='&selectedValue=';
	for(i=1;i<=boxnum;i++)
	{
		value='?criteriaId='+document.getElementById('user_criteria'+i).value;
		ele = document.getElementById("hideShow"+i);
		cal = document.getElementById("hideShow1"+i);
		ele.style.display = "block";
		cal.style.display = "none"; 
		
		//alert(value);
		if(i>1)
			{
				selectedValue +=document.getElementById('user_detail'+(i-1)).value+':';
			}
		
	}
	tempUrl = tempUrl+value+selectedValue;
	//alert(tempUrl);
	$.get(tempUrl,{'listopt':obj.value,'rand':Math.random()},function(msg){ 
		$('#user_detail'+boxnum).html(msg);
	});

}

function getvaluelist(obj,boxnum)
{	
	tempUrl=url+'/getvalueList';
	criteriaId=$('#user_criteria1').val();
	field = $('#user_detail1').val();
	
	for(i=1;i<=boxnum;i++)
	{
		value ='?criteriaId='+document.getElementById('user_criteria'+i).value+'&field='+document.getElementById('user_detail'+i).value;
		ele = document.getElementById("hideShow"+i);
		cal = document.getElementById("hideShow1"+i);
		ele.style.display = "block";
		cal.style.display = "none"; 
	}
	tempUrl=tempUrl+value;
	//alert(tempUrl);
	$.get(tempUrl,{'listopt':obj.value,'rand':Math.random()},function(msg){ 
		$('#user_detail_val'+boxnum).html(msg);
	});
	
}

function changeoption(obj,boxnum)
{
	tempUrl=url+'/changeoption';
	criteriaId=$('#user_criteria1').val();
	for(i=1;i<=boxnum;i++)
	{
		value='?criteriaId='+document.getElementById('user_criteria'+i).value+'&item='+document.getElementById('user_detail'+i).value;
		
	}
	tempUrl=tempUrl+value;
	//alert(tempUrl);
	$.get(tempUrl,{'listopt':obj.value,'rand':Math.random()},function(msg){ 
		$('#options'+boxnum).html(msg);
	});
}

function checkoption(obj,boxnum)
{
	var field = document.getElementById('options'+boxnum).value;
	var ele = document.getElementById("hideShow1");
	var cal = document.getElementById("hideShow11");	
	ele.style.display = "block";
	cal.style.display = "none"; 
	tempUrl=url+'/getvalueList';
	if( field =='Is Correct' || field =='Is Incorrect')
	{	
		for(i=1;i<=boxnum;i++)
		{
			value ='?criteriaId='+document.getElementById('user_criteria'+i).value+'&field='+document.getElementById('user_detail'+i).value+'&Cri='+document.getElementById('options'+i).value;
		}
		tempUrl=tempUrl+value;
		$.get(tempUrl,{'listopt':obj.value,'rand':Math.random()},function(msg){ 
					$('#user_detail_val'+boxnum).html(msg);
		});
		//getDatas(boxnum);
	}
	else
	{
		for(i=1;i<=boxnum;i++)
		{
			value ='?criteriaId='+document.getElementById('user_criteria'+i).value+'&field='+document.getElementById('user_detail'+i).value+'&Cri=';
		}
		tempUrl=tempUrl+value;
		$.get(tempUrl,{'listopt':obj.value,'rand':Math.random()},function(msg){ 
					$('#user_detail_val'+boxnum).html(msg);
		});
	}

		for(i=1;i<=boxnum;i++)
		{
			field = document.getElementById('options'+i).value;
			ele = document.getElementById("hideShow"+i);
			cal = document.getElementById("hideShow1"+i);
			if(field =='Is Within')
			{

				if(ele.style.display == "block") {
					ele.style.display = "none";
					cal.style.display = "inline-block";
				}

				$('#popupDatepicker'+i).datepick({onSelect:validate});
				$('#popupDatepicker2'+i).datepick({onSelect:validate});
				
			}
			else
			{
				ele.style.display = "block";
				cal.style.display = "none"; 
			}

	}

}

function add()
{
	var count =<?php echo $count; ?> +1;
	var selectedItem ='?selectedItem=';

	if(rownum<count){
		rownum=rownum+1;
		var val='<div class="popup_addusers_controls" id="append'+rownum+'" style="width:100%">';
        val+='<div class="popup_addusers_controls_items" >';
        val+='<select name="user_criteria'+rownum+'" id="user_criteria'+rownum+'" onchange="getfieldlist(this,rownum);changeRows(rownum);" style="width:170px;">';
		selectedValue =document.getElementById('user_criteria1').value;
		tempUrl=url+'/getOptions?companyid=<?php echo $companyid;?>&selectedValue='+selectedValue;
		//alert(tempUrl);
		$.ajax({url:tempUrl,
		success:function(msg){ 
			val+=msg;
		},async:false});
        val+='</select>';
        val+='<span class="popup_addusers_controls_pad"> | </span>';
		val+='<select name="user_detail'+rownum+'" id="user_detail'+rownum+'" onchange="getvaluelist(this,rownum);changerow(rownum);changeoption(this,rownum);" style="width:180px;">';
        val+='<option value="">Select</option>';
        val+='</select>';
        val+='<span class="popup_addusers_controls_pad"> | </span>';
        val+='<select name="options'+rownum+'" id="options'+rownum+'"  onchange="checkoption(this,rownum)" style="width:170px;">';
        val+='<option value="">Select</option>';
        val+='</select>';
        val+='<span class="popup_addusers_controls_pad"> | </span>';
		val+='<div id="hideShow1'+rownum+'"  style="float:right;display:none;"  style="float:right;display:none;margin-left:1px;margin-top:-3px;margin-right:-10px;">'; 
		val+='<span style="margin-left:-2px;">From</span><input type="text" id="popupDatepicker'+rownum+'" size="10" style="margin-left:1px;margin-top:-1px;margin-bottom:-10px;">|';
		val+='<span style="margin-left:-2px;">To</span><input type="text" id="popupDatepicker2'+rownum+'" size="10" style="margin-left:1px;margin-top:-1px;margin-bottom:-10px;">'; 
		val+='</div>';
        val+='<div id="hideShow'+rownum+'" style="float:right;display:block;">';
		val+='<select name="user_detail_val'+rownum+'" id="user_detail_val'+rownum+'" onchange="getDatas(rownum)" style="width:170px;">';
        val+='<option value="">Select</option>';
        val+='</select>';
        val+='</div></div>';	
		val+='<div class="controls_addremove" style="margin-left: 5px;">';
		val+='<a href="#" class="control_add" onclick="add()"></a>';
        val+='<a href="#" class="control_remove" onclick="remove()"></a>';
        val+='</div>';
		val+='<div id="recordsCount'+rownum+'" style="margin-left:780px;">';
        val+='<p>  </p>';
        val+='</div></div>';
		var app = '#append'+rownum;
		$('#append').append(val);
	}
}

function remove()
{
	if(rownum >1)
	{
		$('#row'+rownum).remove();
		$('#append'+rownum).remove();
		rownum=rownum-1;
	}
}

function getDatas(selNum)
{
		tempUrl='<?php echo url::base(FALSE) ?>index.php/checklist'+'/getDatas';
		var cri ='?criteriaId=';
		var opt = '&field=';
		var dval = '&detailVal=';
		var Cri= '&Cri=';
		var datef ='&datef=';
		var datet = '&datet=';
		
		for(i=1;i<=rownum;i++)
		{
			cri +=document.getElementById('user_criteria'+i).value+':';
			opt +=document.getElementById('user_detail'+i).value+':';
			dval += document.getElementById('user_detail_val'+i).value+':';
			if(document.getElementById('user_detail_val'+i).value =='')
			{
				//changeRow2(i);
				rownum=i;
			}
			Cri += document.getElementById('options'+i).value+':';
			var field = document.getElementById('options'+i).value;
			
				 datef += $('#popupDatepicker'+i).val();
				 datet += $('#popupDatepicker2'+i).val();
				 if( datef != '' && datet !='')
					value=cri+opt+dval+Cri+datef+datet;
				 else
					value=cri+opt+dval+Cri;
			
			
		}
		
       
		tempUrl=tempUrl+value;
		//alert(tempUrl);
		
		$('.even').remove();
		$('.odd').remove();
		$.ajax({url:tempUrl,
		success:function(xml){ 
			$(xml).find('rowcount').each(function(){
				$('#recordsCount'+rownum+' p').html('<b>&nbsp;'+$(this).text()+'</b>'); 
			});
			i=0;
			$(xml).find('rows').each(function(){
				i++;
				if(i%2==0)
				sty='odd';
				else
				sty='even';		
				var id= $(this).find('id').text();
				val='<tr id="'+i+'" class="'+sty+'" onclick="this.value=\''+id+'\';" >';
				val+='<td width="10%"><a href="<?php echo url::base(FALSE)."index.php/checklist/viewAnswer?checklistId=" ?>'+$(this).find('idnumber').text()+'&userSession='+$(this).find('sessid').text()+'&keepThis=true&TB_iframe=true&height=460&width=615" class="thickbox" >'+ $(this).find('checklistname').text()+"</a></td>";
				val+='<td width="10%">'+ $(this).find('idnumber').text()+"</td>";
				val+='<td width="10%">'+ $(this).find('completed').text()+"</td>";
				val+='<td width="10%">'+ $(this).find('operatorname').text()+'</td>';
				val+='</tr>';
				$('#datarow > tbody:last').append(val);
				tb_init('a.thickbox, area.thickbox, input.thickbox');//pass where to apply thickbox
			});
		}});
		for(i=selNum+1;i<=rownum;i++)
		{
			$('#'+i).remove();
			rownum=rownum-1;
		}
		
}

function changeRows(rownum)
{
	$('#user_detail'+rownum).val('');
	$('#options'+rownum).val('');
	$('#user_detail_val'+rownum).val('');
	$('#recordsCount'+rownum+' p').html('<b>&nbsp;</b>');
	if(rownum == 1)
	{	if(navigator.appName == 'Netscape')
			$('#datarow > tbody:last').html('<datas><tr><th>Checklist Name</th><th>ID Number</th><th>Completed</th><th>Operator</th></tr></datas>');
		if(navigator.appName == 'Microsoft Internet Explorer')
			$('#datarow > tbody:last').html('<datas><div id="usersearch_content" ><table  id="datarow" width="100%"><tr><th>Checklist Name</th><th>ID Number</th><th>Completed</th><th>Operator</th></tr></table></div></datas>');
	}
}

function changeRow2(i)
{
	for(j=i;j<=rownum;j++)
	{
		$('#user_criteria'+j).val('');
		$('#user_detail'+j).val('');
		$('#options'+j).val('');
		$('#user_detail_val'+j).val('');
		$('#recordsCount'+j+' p').html('<b>&nbsp;</b>');
	}
}

function changerow(rownum)
{
	$('#options'+rownum).val('');
}

function validate()
{
	for(i=1;i<=rownum;i++)
	{
		var field = document.getElementById('options'+i).value;
		var startdatevalue = $('#popupDatepicker'+i).val();
		var enddatevalue = $('#popupDatepicker2'+i).val();
			if(field == 'Is Within')
			{
				if(startdatevalue=='')
				{
		
					$('#popupDatepicker2'+i).datepick($.datepick.clear(this));
					alert('Please Select From Date.'); 
					return false;
				}
				
				if( Date.parse(startdatevalue) >  Date.parse(enddatevalue) )
				{
					$('#popupDatepicker2'+i).datepick($.datepick.clear(this));
					alert('To Date Should Be Greater Than From Date.');
					//$('#popupDatepicker2'+i).datepick({onSelect:validate});
					return false;
				}
				
				if(startdatevalue !='' && ( Date.parse(startdatevalue) <  Date.parse(enddatevalue) ))
				{
					getDatas();
				}
			}
	}
	
}

</script>

<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/calender/jquery.datepick.js"></script>
<script type="text/javascript">
$(function() {
	
	//$('#inlineDatepicker').datepick({onSelect: showDate});
});

function showDate(date) {
	//alert('The date chosen is ' + date);
}


</script>

</body>
</html>