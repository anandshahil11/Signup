<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [13/May/11]
Page Description:: Add Resource Category  page 
*********************************************/
ini_set('post_max_size','8M');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/thickbox.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script.js"></script>
<script type="text/javascript">

//initiate validator on load
	$(function() {
	// validate contact form on keyup and submit
	$("#userForm").validate({
	//set the rules for the field names
	rules: {
	resourceName: {
	required: true
	},
	resource_upload: {
	required: true,
	},
	categoryList:{
	required: true,
	minlength: 1
	},
	},
	//set messages to appear inline
	messages: {
	
	resourceName:{
	required: "*Please enter Resource Name"
	},
	resource_upload:{
	required: "*Please submit resource file"
	},
    categoryList:{
	required: "*Please enter category Name",
	minlength: "*Please enter category Name"
	} 	
	}
	});
	});

function chkUpload()
{
	var imgpath = document.getElementById('resource_upload').value;
	if(imgpath != "")
	{
	// code to get File Extension..
		var arr1 = new Array;
		arr1 = imgpath.split("\\");
		var len = arr1.length;
		var img1 = arr1[len-1];
		var filext = img1.substring(img1.lastIndexOf(".")+1);
		filext=filext.toLowerCase();
		// Checking Extension
		if(filext == "exe" || filext == "ini" || filext == "txt" || filext == "zip" || filext == "rar" || filext == ".dll" || filext == ".sql")
		{
		    alert("Invalid File Format Selected");
			return false;
		}
	    else
		{
			
		}
	}
}
	
</script>

<style type="text/css">
	.error {
	color: red;
	font: 12pt verdana;
	padding-left: 10px
	}
</style>
</head>
<body>
<div id="popup_newgroup">
	<div id="popup_newgroup_header">
		<?php 
		if($_GET['id']=='setting')
		{
		?>
			<h1>Upload New Resource</h1>
		<?php 
		}
		else
		{ ?>
			<h1>Edit New Resource</h1>
		<?php
		} ?>
		
    </div>
    <div id="popup_newgroup_content"> 
    <form  name="myform" id="userForm"  method='post' enctype='multipart/form-data' onsubmit="return chkUpload()">
    <div id="popup_newgroup_content_middle">
	    <div class="popup_resource">
		    
			<?php 
			if($_GET['id'] != 'setting')
			{ 
			    echo "<div id='upload_file'>".$resourceData[0]->original_file_name."</div>";
				echo "<input type='hidden' name='attachedFile' value='".$resourceData[0]->attached_file_name."' />";
			}
			?>

            <label for="resourceName">Choose file to upload&nbsp;&nbsp;&nbsp;&nbsp;Maximum upload file size 8M  </label><br />
	        <input type="file" name="resource_upload" size="65" id="resource_upload"  style="margin-left:1px;width:100px;" /> 
    	</div>
		<div class="popup_resource">
            <label for="resourceName">Resource Name</label><br />
          	<input type="text"  style="width:480px;" name="resourceName" id="resourceName" class="inputbox" onclick="if(this.value=='Resource Name'){this.value=''}" value='<?php if($_GET['id'] != 'setting'){ echo $resourceData[0]->item_name;}else{ echo "Resource Name";}?>' />
        </div>
		<div class="popup_resource">
			<label for="resourceDesc">Resource Description</label><br />
			<input type="text" style="width:480px;" name="resourceDesc" id="resourceDesc" class="inputbox" onclick="if(this.value=='Resource Description'){this.value=''}" value='<?php if($_GET['id'] != 'setting'){ echo $resourceData[0]->item_description;}else{ echo "Resource Description";}?>' />
		</div>
		<div class="popup_resource">
		<label for="categoryList">Category List</label><br />
			<select name="categoryList" style="width:480px;" id="categoryList">
						<?php
						if($_GET['id']!='setting')
						{
						foreach($categoryList as $row)
						{
							if($resourceData[0]->category_id == $row->category_id )
							{
							    echo "<option value='".$row->category_id."' selected='selected'>$row->category_name</option>";
							}else
							{
							    echo "<option value='".$row->category_id."'>$row->category_name</option>";
                            }							
						} 
						?>
						
						<?php
						}else
						{
						?>
						<option value="" selected>(please select a category)</option>
						<?php
						}
						foreach($categoryList as $row)
						{
							echo "<option value='".$row->category_id."'>$row->category_name</option>";
						}
					?>	
			</select>
		</div>
                
    
    </div><!-- end #popup_newgroup_content_middle -->
        
    <div id="popup_newgroup_content_bottom">
	    <?php 
		if($_GET['id']=='setting')
		{
		?>
       	<input type="submit" class="submit_moreinfo" value="" />
		<?php
		}else
		{
		?>
		<input type="submit" name="update"  class="update_moreinfo" value="" />
		<?php
		}
		?>
		<a href="#"><input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
    </div><!-- end #popup_newgroup_content_bottom -->
    </form>
    </div><!-- end #popup_newgroup_content -->
</div><!-- end #popup_newuser -->
</body>
</html>
