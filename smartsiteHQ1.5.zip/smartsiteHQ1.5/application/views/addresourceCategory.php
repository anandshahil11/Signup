<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [13/May/11]
Page Description:: Add Resource Category  page 
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/thickbox.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script.js"></script>
<script type="text/javascript">
//initiate validator on load
	$(function() {
	$("#userForm").validate({
	//set the rules for the field names
	rules: {
	categoryName: {
	required: true
	},
	last_name: {
	required: true,
	minlength: 2,
	maxlength:15
	},
	
	},
	//set messages to appear inline
	messages: {
	
	categoryName:{
	required: "*Please enter Category Name"
	},
	last_name:{
	required: "*Please enter Last Name",
	minlength: "*Please enter atleast 2 Character",
	maxlength: "*Please enter less than 15 Character"
	}	
	}
	});
	});
</script>
<SCRIPT LANGUAGE="JavaScript">
$(document).ready(function()
{
    $("#group_all").click(function()				
	{
				var checked_status = this.checked;
				$("input[name=grouplist[]]").each(function()
				{
					this.checked = checked_status;
				});
	});	
});
</SCRIPT>
<style type="text/css">
	.error {
	color: red;
	font: 12pt verdana;
	padding-left: 10px
	}
</style>
</head>
<body>
<div id="popup_newgroup">
	<div id="popup_newgroup_header">
		<?php 
		if($_GET['id']=='setting')
		{
		?>
			<h1>New Category</h1>
		<?php 
		}
		else
		{ ?>
			<h1>Edit Category</h1>
		<?php
		} ?>
		
    </div>
    <div id="popup_newgroup_content"> 
    <form  name="myform" id="userForm"  method='post' enctype='multipart/form-data'>
	<div id="popup_newgroup_content_middle">
    	<div id="popup_newgroup_inputwrapper" class="clearfix">
                <div class="popup_newuser_inputwrapper_left">
                	<label for="first_name">Category Name</label><br />
                	<input type="text" name="categoryName" id="categoryName" class="inputbox" value='<?php if($_GET['id'] != 'setting')echo $categoryname;?>' />
                </div>
                
               
                	<div class="popup_newuser_checklist_left">
                    	<label>Group</label><br /><br />
                		<div class="popup_newuser_checklist_wrapper">
                        	<div class="popup_newuser_checklist_wrapper_top">
                            <table class="resource_table">
                            	<tr>
                                	<th>
									<input type="checkbox" id="group_all" class="checkbox"  >Select All
									</th>
                                </tr>
                            </table>
                            </div>
                            
                            <div class="popup_newuser_checklist_wrapper_bottom">
                            <table class="new_user_table">
							<?php 
							$countGroup = count($groupData);
							if($_GET['id']!='setting'){
							    $countUserGroup = count($categorygroupList); 
								for($i=0;$i<$countGroup;$i++)
								{   
									if((($i+1)%2)==0)
									{
							?>
                                <tr>
                                	<td class="odd">
									<input type="checkbox" name="grouplist[]" class="checkbox" value="<?php echo $groupData[$i]->group_id;?>"
									<?php 
									    for($ii=0;$ii<$countUserGroup;$ii++)
										{
										    if($groupData[$i]->group_id==$categorygroupList[$ii]->group_id)
											{ 
											    echo "checked=\"true\"";
											}
										}	
									?>
									/><?php echo  $groupData[$i]->group_name; ?>
									</td>
                                </tr>
							<?php
									}else
									{
                            ?>							
                                <tr>
                                	<td class="even">
									<input type="checkbox" name="grouplist[]" class="checkbox" value="<?php echo $groupData[$i]->group_id;?>" 
									<?php 
									    for($ii=0;$ii<$countUserGroup;$ii++)
										{
										    if($groupData[$i]->group_id==$categorygroupList[$ii]->group_id)
											{ 
											    echo "checked=\"true\"";
											}
										}	
									?>
									/> <?php echo  $groupData[$i]->group_name; ?>
									
									</td>
                                </tr>
                            <?php
									}
								}
							
							}else
							{
								for($i=0;$i<$countGroup;$i++)
								{   
									if((($i+1)%2)==0)
									{
							?>
                                <tr>
                                	<td class="odd">
									<input type="checkbox"  name="grouplist[]" class="checkbox" value="<?php echo $groupData[$i]->group_id;?>"/><?php echo  $groupData[$i]->group_name; ?>
									</td>
                                </tr>
							<?php
									}else
									{
                            ?>							
                                <tr>
                                	<td class="even">
									<input type="checkbox" name="grouplist[]" class="checkbox" value="<?php echo $groupData[$i]->group_id;?>" /> <?php echo  $groupData[$i]->group_name; ?>
									</td>
                                </tr>
                            <?php
									}
								}
                            }								
                            ?>							
                            </table>
                            </div><!-- end .popup_newuser_checklist_wrapper_bottom -->
                        </div><!-- end .popup_newuser_checklist_wrapper -->
                	</div><!-- end .popup_newuser_checklist_left -->
                
        </div>
    </div><!-- end #popup_newgroup_content_middle -->
        
    <div id="popup_newgroup_content_bottom">
	    <?php 
		if($_GET['id']=='setting')
		{
		?>
       	<input type="submit" class="submit_moreinfo" value="" />
		<?php
		}else
		{
		?>
		<input type="submit" name="update"  class="update_moreinfo" value="" />
		<?php
		}
		?>
		<a href="#"><input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
    </div><!-- end #popup_newgroup_content_bottom -->
    </form>
    </div><!-- end #popup_newgroup_content -->
</div><!-- end #popup_newuser -->
</body>
</html>
