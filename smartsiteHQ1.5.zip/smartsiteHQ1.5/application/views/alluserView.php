<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [03/March/11]
Page Description:: Users  View All  page 
*********************************************/
require_once('header.php');
?>
<script type="text/javascript">

function tb_init(){
	$(document).click(function(e){
	e = e || window.event;
	var el = e.target || e.scrElement || null;
	if(el && el.parentNode && !el.className || !/thickbox/.test(el.className))
	el = el.parentNode;
	if(!el || !el.className || !/thickbox/.test(el.className))
	return;
	var t = el.title || el.name || null;
	var a = el.href || el.alt;
	var g = el.rel || false;
	tb_show(t,a,g);
	el.blur();
	return false;
	});
};

var durl='<?php echo url::base(FALSE) ?>index.php/user/deleteUser/<?php echo $userid;?>/<?php echo $companyid;?>?userid=';
$(document).ready(function()
{
    $("#myTable tr").click(function(event) 
	{
		var tr_id= $(this).val();
		$('#deleterow').val(tr_id);
		$('#editid').val(tr_id);
		
    });
	
    //To Delete record 
    $('.delete').click(function(e) 
	{
        var del = $('#deleterow').val();
		if(del == '' || del == 0)
		{
			alert("Please select record to delete");
			return  false;
		}
		 
		if(del)
		{
			e.preventDefault();
			var href =durl+del;
			del = 0;
			if(confirm('Do you really want to delete this user?')) 
			{
				window.location = href;
			}
					
		}

	});
	
	$('.edit').click(function(e) 
	{
        var id = $('#editid').val();
		var companyid = '<?php echo $companyid; ?>';
		var userid = '<?php echo $userid; ?>';
		var url = '<?php echo url::base(FALSE) ?>index.php/user/userSetting?userid='+userid+'&companyid='+companyid+'&id='+id+'&type=I&keepThis=true&TB_iframe=true&height=500&width=780';
		if(id == '' || id == 0)
		{
			alert("Please select record to edit");
			return false;
        }
		if(id)
		{
			e.preventDefault();
			var href =url;
			id = 0;
            //window.location = href;
			$('#lightlink').attr('href',url);
			
		}else
		{
			alert('Please select only one row for edit');
			return false;
		}

    });
	


	
	
});
</script>

<script type="text/javascript">
var checked =  new Array();
var i = 0;
//ADDED  for left FORM SUBMISSION
$(function() {
	
	$(".testButton").click(function() {
		var id = $(this).val();
		$("#right_stat").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
		var userid = $(this).val();
		var action = $("input#action").val();
		var companyid = '<?php echo $companyid; ?>';
		var dataString ='companyid='+companyid+'&userid='+userid+'&action='+action;
		$.ajax({
			type: "POST",
			url: "<?php echo url::base(FALSE) ?>/index.php/user/rightuserPane/",
			data: dataString,
			success: function(data) {
				
				$('#right_stat').html(data);			
			}
	});
		$("#check"+id).attr('checked','checked');
		checked[i++] = $("#check"+id+":checked").val() ;
		$('#checkgroup').val(checked);
});

$(".testButton").dblclick(function() {
	var id = $(this).val();
	$("#check"+id+":checkbox").removeAttr('checked');
	if($("#check"+id+":checkbox").is(':not(:checked)'))
		{
			$("#check"+id+":checkbox").removeAttr('checked');
			$("#myTable thead tr th:first input:checkbox").removeAttr('checked');
			var index ;
			for (var j=0;j<checked.length;j++)
			{
				if(checked[j] == id)
				{
					index = j;
					checked.splice(index,1,"");
				}
			}
			
		}
		var arr = new Array();
		var k= 0;
		for(var i=0;i < checked.length;i++)
		{
			if(checked[i]!='')
			{
				arr[k++] = checked[i];
			}
		}
		$('#checkgroup').val(arr);
		
});

$("#myTable tbody tr  input:checkbox").click(function() {
	var id = $(this).val();
	if($("#check"+id+":checkbox").is(':checked'))
	{
		checked[i++] = $("#check"+id+":checked").val();
		$("#check"+id).attr('checked','checked');	
	}
		
	if($("#check"+id+":checkbox").is(':not(:checked)'))
	{
		$("#check"+id+":checkbox").removeAttr('checked');
		$("#myTable thead tr th:first input:checkbox").removeAttr('checked');
		var index ;
		for (var j=0;j<checked.length;j++)
		{
			if(checked[j] == id)
			{
				index = j;
				checked.splice(index,1,"");
			}
		}
		
	}
		
	$('#checkgroup').val(checked);
	$("#right_stat").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
		var userid = $(this).val();
		var action = $("input#action").val();
		var companyid = '<?php echo $companyid; ?>';
		var dataString ='companyid='+companyid+'&userid='+userid+'&action='+action;
		$.ajax({
			type: "POST",
			url: "<?php echo url::base(FALSE) ?>/index.php/user/rightuserPane/",
			data: dataString,
			success: function(data) {
				
				$('#right_stat').html(data);			
			}
	});
	
});

$("#myTable thead tr th:first input:checkbox").click(function() {
	
		var checkedStatus = this.checked;
		$("#myTable  input:checkbox").each(function() {	
				this.checked = checkedStatus;
				if($(this).val() != 'selectAll')
				checked[i++] = $(this).val();
		});
		if($(this).is(':not(:checked)'))
		{
			 $("#myTable  input:checkbox").each(function() {
				$(this).removeAttr('checked');
				checked = new Array();
			});
		}
		$('#checkgroup').val(checked);
		//alert(checked);
	});
	$('.export').click(function(e) 
	{
        var checkgroup = $('#checkgroup').val();
		if(checkgroup == '')
		{
			alert('Please select users to export');
			return  false;
		}
		var companyid = '<?php echo $companyid; ?>';
		var url = '<?php echo url::base(FALSE).'index.php/group/exportUser?companyid='.$companyid.'&groupid= ';?>';
		url +='&check='+checkgroup; 
		if(checkgroup)
		$('.export').attr('href',url);
	});	

});
</script>
<div id="module_middle">
    <?php require_once('userLeftPanel.php');?>
	<div id="module_content" >
		<form id="viewAll" name ="viewAll"  method="post">
        <input type="hidden" id="deleterow"  value=""/>
	    <input type="hidden" id="editid"  value=""/>
		<input type="hidden" id="checkgroup" name="checkgroup"  value=""/>
    	<div id="module_edit_header">
        	<h1>Users</h1>
			<div id="module_edit_header_options" >
                <?php
				if(!isset($groupid))
				{
				    $groupid="";
				}
                ?>					
				<a class="export user_export" href="#">Export Users</a>
				<a class="edit thickbox user_edit" id="lightlink" href="#" style="text-decoration:none;color:black;" >
				Edit User
				</a>
				<a href="<?php echo url::base(FALSE)."index.php/user/userSetting?userid=$userid&companyid=$companyid&id=setting&type=I&keepThis=true&TB_iframe=true&height=500&width=780"; ?>"  
				   style="text-decoration:none;color:black;" 
				   class="thickbox addusers edittemp_addnew" >
				Add User
				</a>
				<a class="delete user_delete" href="#">Delete User</a>
			</div>
        </div><!-- end #module_edit_header -->
		
        <div id="usersearch_content" style="max-height:750px;height:750px;">
            <table   border="0" id="myTable" cellpadding="0" cellspacing="0" class="tablesorter">
            	<thead>
				<tr>
					<th  align="left" style="padding-right:0px;padding-left:0px;"> 
					<input type="checkbox" name="selectAll"  value="selectAll"   style="margin-left:18px;margin-right:0px;margin-top:0px;margin-bottom:0px;padding-right:0px;padding-left:0px;"></th>
                	<th  style="padding-right:0px;padding-left:4px;">First Name</th>
                	<th  style="padding-right:0px;padding-left:4px;">Last Name</th>
                	<th  style="padding-right:0px;padding-left:4px;">Company</th>
                	<th  style="padding-right:0px;padding-left:4px;">Username/EmailId</th>
                	<th  style="padding-right:0px;padding-left:4px;">Country</th>
					<th  style="padding-right:0px;padding-left:4px;">Last Log-in</th>
                </tr>
				</thead>
				<?php
				$count = count($usersData);
				for($i=0;$i<$count;$i++)
				{   
				    if((($i+1)%2)==0)
					{
				?>
				<tr  id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';" 
					onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';"
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"
				> <input type="hidden" name="action" id="action" value="none" />
					<td align="left" ><input type="checkbox" id="<?php echo "check".$usersData[$i]->user_id; ?>"    value="<?php echo $usersData[$i]->user_id; ?>" style="margin-left:1px;margin-right:0px;margin-top:0px;" ></td>
                	<td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->firstname,6,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->lastname,6,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->company,5,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->emailid,12,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->country,5,"<br/>\n",true); ?></td>
					<td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php if($usersData[$i]->last_login != ""){ echo date("m/d/Y",$usersData[$i]->last_login); }else{ echo "-"; }?></td>
                </tr>
				<?php
				    }else
                    {					
				?>
                <tr  id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
					onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';"
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"
				>	<input type="hidden" name="action" id="action" value="none" />
					<td  align="left" ><input type="checkbox" id="<?php echo "check".$usersData[$i]->user_id; ?>"    value="<?php echo $usersData[$i]->user_id; ?>" style="margin-left:1px;margin-right:0px;margin-top:0px;" ></td>
                	<td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->firstname,6,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->lastname,6,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->company,5,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->emailid,12,"<br/>\n",true); ?></td>
                    <td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->country,5,"<br/>\n",true); ?></td>
					<td  class="testButton"  onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php if($usersData[$i]->last_login != ""){ echo date("m/d/Y",$usersData[$i]->last_login); }else{ echo "-"; } ?></td>
                </tr>
                <?php
				    }
				}	
				?>
                
            </table>
		</div>	
		
		</form>
			
    </div><!-- end #module_content -->
    <div id="user_info">
	    
		<div id="user_info_header"><h1>User Stats</h1></div>
		<div id="right_stat">
		 	
		
		
		</div>
		
		
    </div>        
        
</div><!-- end #module_middle -->

</body>
</html>