<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New checklist</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/basic.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/layout.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" />
<!-- Popup Video -->
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/prettyPhoto.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate2.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	 $("#email").validate();

});
</script>
</head>
<body>
<div id="popup_checklist">
	<div id="popup_checklist_header">
   	  <div id="popup_checklist_header_title">
        	<h2>&nbsp;</h2>
        	<h1>
			<?php
			echo $checklistInfo->checklist_name;
			?>
			</h1>
        </div>
        
        <div id="popup_checklist_header_utilities">
        	<a href="javascript:parent.tb_remove()" class="close_link">Close</a>
            <div class="options">
            	<a class="email" href="<?php echo url::base(FALSE) ?>index.php/checklist/sendMail?checklistId=<?php echo $checklistId?>&userSession=<?php echo $userSession?>&keepThis=true">Email</a>                        
            	<a class="forward" href="javascript:openMail()">Forward</a>                        
            	<a class="export" href="<?php echo url::base(FALSE) ?>index.php/checklist/exportData?checklistId=<?php echo $checklistId?>&userSession=<?php echo $userSession?>&keepThis=true">Export</a>
            </div>
        </div>
    </div><!-- end #popup_checklist_header -->
    
    <div id="popup_checklist_content">
		<?php echo '<span style="color:red">'.$msg."</span>";?>
		<form name="email"id="email"  action="<?php echo url::base(FALSE) ?>index.php/checklist/sendMail?checklistId=<?php echo $checklistId?>&userSession=<?php echo $userSession?>&keepThis=true" method="post">
		<div id="emailbox" style="padding-left:20px;display:none">
		To:&nbsp;&nbsp;&nbsp;<input type="text" name="to" id="to" style="margin:0px 5px 3px 8px;width:300px" class="required" /><br>
		CC:&nbsp;&nbsp;<input type="text" name="cc" id="cc" style="margin:0px 5px 3px 10px;width:300px" /><br>
		BCC:<input type="text" name="bcc" id="bcc" style="margin:0px 5px 3px 10px;width:300px" /><input type="submit" value="Send" style="margin:0px 5px 3px 10px;" /><br>
		</div>
		</form>
    	<table class="popup_addusers_content_table thin">
					<?php
					$i=1;
					foreach($info as $cat=>$items)
					{
					?>
                	<tr class="odd section_title">
                    	<td><?php echo $cat?></td>
                        <td>&nbsp;</td>
                    </tr>
					<?php
					foreach($items as $item)
					{
					if($i%2==0)
					$class="even";
					else
					$class="odd";
					$i++;
					?>
                    <tr class="<?php echo $class ?>">
                    	<td><strong><?php echo $item['name'] ?>:</strong></td>
                        <td><?php echo $item['Ans'] ?></td>
                    </tr>
					<?php }?>
					<?php }?>
              </table>
    </div><!-- end #popup_checklist_content -->
</div><!-- end #popup_checklist -->
<script language="javascript">
showOrHide=true;
function openMail()
{
	if (showOrHide == true ) {
		$('#emailbox').show();
		showOrHide=false;
	} else if ( showOrHide == false ) {
	  $('#emailbox').hide();
	  showOrHide=true;
	}

}
</script>
</body>
</html>