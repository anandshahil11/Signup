<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New wizard</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/basic.css" type="text/css" media="screen"  />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	 $("#setting").validate();
	 $("#all").click(function()
	 {
		if($(this).attr('checked')==true)
		$(".all").attr('checked',true);
		else
		$(".all").attr('checked',false);
	 }
	 );
	  $(".eval").click(function()
	 {
		var val=document.getElementsByName('evalution[]');
		if(val[0].checked==true || val[1].checked==true || val[2].checked==true)
		$("#evaluation_checklist").attr('checked',true);
		else
		$("#evaluation_checklist").attr('checked',false);
	 }
	 );
});
</script>
</head>
<body >
<div id="popup_newchecklist">
<div id="popup_newchecklist_header">
<h1>New Checklist</h1>
</div><!-- end #popup_newchecklist_header -->
<form id="setting" name="setting"  action="" method="post">
<div id="popup_newchecklist_content">
<div id="popup_newchecklist_content_left">
	<label for="name">Name</label><br />
    <input name="name" id="name" class="inputbox required" value="<?php echo $name?>" /><br />
    <br />
    <input type="checkbox" class="checkbox" id="evaluation_checklist" <?php if(!empty($evaluation)) echo 'checked'; ?> /> 
    <label for="evaluation_checklist">Save as evaluation checklist</label><br />
    <div class="suboptions">
    	<input type="checkbox" class="checkbox eval" name="evalution[]" id="evalution" value="individuals" <?php if(strpos($evaluation,'individuals')!== false) echo 'checked'; ?> /> 
    	<label for="individuals">Evaluate individuals</label><br />
    	<input type="checkbox" class="checkbox eval" name="evalution[]"  id="evalution" value="companies" <?php if(strpos($evaluation,'companies')!== false) echo 'checked'; ?> /> 
    	<label for="companies">Evaluate companies</label><br />
    	<input type="checkbox" class="checkbox eval" name="evalution[]"  id="evalution" value="groups" <?php if(strpos($evaluation,'groups')!== false) echo 'checked'; ?> /> 
    	<label for="groups">Evaluate groups</label><br />
	</div>
</div><!-- end #popup_newchecklist_content_left -->

<div id="popup_newchecklist_content_right">

<label>Group</label>
<br />
           <div id="popup_newchecklist_wrapper">
           		<table class="popup_checklist_table">
                	<tr>
                    	<th><input type="checkbox" class="checkbox" id="all" /> 
                    	<strong>Select All</strong></th>
                    </tr>
					<?php
					foreach($groups as $row)		
					{
					?>
						<tr>
						<td class="odd"><input type="checkbox" <?php if(in_array($row->group_id,$selectedGroup)) echo ' checked ' ?>class="checkbox all" name="group[]" value="<?php echo $row->group_id ?>"/> 
						<?php echo $row->group_name ?></td>
						</tr>                    
					<?php
					}?>
                </table>
           </div>

</div><!-- end #popup_newchecklist_content_right -->
</div><!-- end #popup_newchecklist_content -->
<div id="popup_newchecklist_footer">
		<input type="submit" class="submit_moreinfo" value="" />
		 <input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
</div><!-- end #popup_newchecklist_footer -->
        </form>
</div><!-- end #popup_newchecklist -->
</body>
</html>