<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [13/April/11]
Page Description:: Module Summary Ques Answer View Page 
*********************************************/
?>
<?php
    $count = count($ques_ans_list);
	for($index=0;$index<$count;$index++)
	{   
	    $correctAnswerId = "ans".$ques_ans_list[$index]['correctanswer'];
        $correctAnswer = $ques_ans_list[$index][$correctAnswerId];
		if(isset($userAnswerList[$index]['answer']))
		{
		$userAnswerId = "ans".$userAnswerList[$index]['answer'];
		$userAnswer = $ques_ans_list[$index][$userAnswerId];
	    }else
		{
		    $userAnswer="";
		}
		if((($index+1)%2)==0)
		{
?>
<div class="summarydetails_content_odd">
	<p><?php echo $ques_ans_list[$index]['quesid'].".".htmlspecialchars($ques_ans_list[$index]['ques']);?></p>
	<p class="summarydetails_answers">
        <?php	
	        if(!empty($ques_ans_list[$index]['ans1']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans1'] AND $userAnswer==$ques_ans_list[$index]['ans1'] )
				{
					echo "<strong>"."A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
					if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans1'] AND $userAnswer==$ques_ans_list[$index]['ans1'])
				{
					echo "<strong style='color:red'>"."A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
				    if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans1'] AND $correctAnswer==$ques_ans_list[$index]['ans1'])
				{
					echo "A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
				    if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
					if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>
        <br/>
        <?php	
	        if(!empty($ques_ans_list[$index]['ans2']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans2'] AND $userAnswer==$ques_ans_list[$index]['ans2'] )
				{
					echo "<strong>"."B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
				    if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans2'] AND $userAnswer==$ques_ans_list[$index]['ans2'])
				{
					echo "<strong style='color:red'>"."B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
				    if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans2'] AND $correctAnswer==$ques_ans_list[$index]['ans2'])
				{
					echo "B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
				    if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
					if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>        
		<br/>
        <?php	
	        if(!empty($ques_ans_list[$index]['ans3']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans3'] AND $userAnswer==$ques_ans_list[$index]['ans3'] )
				{
					echo "<strong>"."C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans3'] AND $userAnswer==$ques_ans_list[$index]['ans3'])
				{
					echo "<strong style='color:red'>"."C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans3'] AND $correctAnswer==$ques_ans_list[$index]['ans3'])
				{
					echo "C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>
        <br/>
        <?php	
	        if(!empty($ques_ans_list[$index]['ans4']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans4'] AND $userAnswer==$ques_ans_list[$index]['ans4'] )
				{
					echo "<strong>"."D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
				    if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans4'] AND $userAnswer==$ques_ans_list[$index]['ans4'])
				{
					echo "<strong style='color:red'>"."D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
				    if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans4'] AND $correctAnswer==$ques_ans_list[$index]['ans4'])
				{
					echo "D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
				    if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
					if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>
        <br/>
    </p>
</div>
<?php
        }else
		{
?>
<div class="summarydetails_content_even">
	<p><?php echo $ques_ans_list[$index]['quesid'].".".htmlspecialchars($ques_ans_list[$index]['ques']);?></p>
	<p class="summarydetails_answers">
        <?php	
	        if(!empty($ques_ans_list[$index]['ans1']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans1'] AND $userAnswer==$ques_ans_list[$index]['ans1'] )
				{
					echo "<strong>"."A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
					if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans1'] AND $userAnswer==$ques_ans_list[$index]['ans1'])
				{
					echo "<strong style='color:red'>"."A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
				    if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans1'] AND $correctAnswer==$ques_ans_list[$index]['ans1'])
				{
					echo "A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
				    if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "A.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans1']);
					if(isset($eachQuesResponse[$index][1]))
					{ 
					    echo "(".$eachQuesResponse[$index][1].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>
        <br/>
        <?php	
	        if(!empty($ques_ans_list[$index]['ans2']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans2'] AND $userAnswer==$ques_ans_list[$index]['ans2'] )
				{
					echo "<strong>"."B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
				    if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans2'] AND $userAnswer==$ques_ans_list[$index]['ans2'])
				{
					echo "<strong style='color:red'>"."B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
				    if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans2'] AND $correctAnswer==$ques_ans_list[$index]['ans2'])
				{
					echo "B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
				    if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "B.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans2']);
					if(isset($eachQuesResponse[$index][2]))
					{ 
					    echo "(".$eachQuesResponse[$index][2].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>        
		<br/>
        <?php	
	        if(!empty($ques_ans_list[$index]['ans3']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans3'] AND $userAnswer==$ques_ans_list[$index]['ans3'] )
				{
					echo "<strong>"."C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans3'] AND $userAnswer==$ques_ans_list[$index]['ans3'])
				{
					echo "<strong style='color:red'>"."C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans3'] AND $correctAnswer==$ques_ans_list[$index]['ans3'])
				{
					echo "C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "C.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans3']);
				    if(isset($eachQuesResponse[$index][3]))
					{ 
					    echo "(".$eachQuesResponse[$index][3].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>
        <br/>
        <?php	
	        if(!empty($ques_ans_list[$index]['ans4']))
			{
				if(isset($userAnswerList[$index]['answer']) AND $correctAnswer==$ques_ans_list[$index]['ans4'] AND $userAnswer==$ques_ans_list[$index]['ans4'] )
				{
					echo "<strong>"."D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
				    if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"."</strong>*"; 
					}else
					{
					    echo "(0)"."</strong>*";
					}
				}elseif(isset($userAnswerList[$index]['answer']) AND $correctAnswer!=$ques_ans_list[$index]['ans4'] AND $userAnswer==$ques_ans_list[$index]['ans4'])
				{
					echo "<strong style='color:red'>"."D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
				    if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"."</strong>"; 
					}else
					{
					    echo "(0)"."</strong>";
					}
				}elseif($userAnswer!=$ques_ans_list[$index]['ans4'] AND $correctAnswer==$ques_ans_list[$index]['ans4'])
				{
					echo "D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
				    if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"."*"; 
					}else
					{
					    echo "(0)"."*";
					}
				}else
				{
					echo "D.&nbsp;".htmlspecialchars($ques_ans_list[$index]['ans4']);
					if(isset($eachQuesResponse[$index][4]))
					{ 
					    echo "(".$eachQuesResponse[$index][4].")"; 
					}else
					{
					    echo "(0)";
					}
				}
			}
        ?>
        <br/>
	</p>
</div>
<?php
        }
	}	
?>
