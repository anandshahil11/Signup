<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [13/April/11]
Page Description:: Module Detail Summary page 
*********************************************/
?>
<div id="popup_summarydetails_header_status">
	<p>Status</p>
	<p class="icon_square complete">
	        <?php 
			if(strtolower($userEachExamResult['result'])==='certified')
			{
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/pass.png" alt="certified">
			<?php
			}elseif(strtolower($userEachExamResult['result'])==='failed')
			{
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/fail.png" alt="failed">
			<?php
			}else
			{
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/incomplete.png" alt="incomplete">
			<?php
			}
			?>
			<?php echo $userEachExamResult['result'];?>
	</p>
</div>
			
<div id="popup_summarydetails_header_score">
	<p>Score:</p>
	<p><?php echo $userEachExamResult['result_percentage']."%";?></p>
</div>
			
<div id="popup_summarydetails_header_certificationdate">
	<p>Certification Date</p>
	<p><?php echo date('m/d/Y',strtotime($userEachExamResult['datetime']));?></p>
</div>

