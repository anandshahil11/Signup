<?php 
require_once('header.php');
?>
<script language="javascript">
	var url='<?php echo url::base(FALSE) ?>index.php/exam/newExamQuestion?id=';
	var durl='<?php echo url::base(FALSE) ?>index.php/exam/delExamQuestion?id=';
</script  >
<script language="JavaScript" type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/core.js"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/events.js"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/css.js"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/coordinates.js"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/drag.js"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/dragsort.js"></script>
<script language="JavaScript" type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/cookies.js"></script>
<div id="module_middle">
	<?php require_once('userLeftPanel2.php');?>    
    <div id="module_content" style="width:82%">
    	<div id="module_edit_header">
        	<h1><?php echo $examInfo->exam_name  ?>
			</h1>
            <div id="module_edit_header_options">
                <a href="<?php echo url::base(FALSE)."index.php/exam/newCategory?id=".$examId."&keepThis=true&TB_iframe=true&height=200&width=740"; ?>" class="edittemp_addnew thickbox" >Add new category</a>
				<a href="<?php echo url::base(FALSE)."index.php/exam/newExamQuest?id=".$examId."&keepThis=true&TB_iframe=true&height=480&width=755"; ?>" class="edittemp_addnew thickbox" >Add new item</a>
				<a href="<?php echo url::base(FALSE)."index.php/exam/exam?id=".$examId."&keepThis=true&TB_iframe=true&height=400&width=740"; ?>" class="thickbox edittemp_settings" >Settings</a>
				<?php if($examInfo->publish==0){ ?>
                <a href='<?php echo url::base(FALSE)."index.php/exam/publish?id=".$examId."'" ?> class="edit edittemp_publish" >publish</a>
				<?php }else{?>		
				<a href='<?php echo url::base(FALSE)."index.php/exam/unpublish?id=".$examId."'" ?> class="edit edittemp_publish" >Un Publish</a>
				<?php }?>
            </div><!-- /#module_edit_header_options -->
        </div><!-- /#module_edit_header -->
        <div id="module_edit_area">
		 
			<?php $msg=isset($_GET['msg'])?$_GET['msg']:'';if(!empty($msg))echo '<p style="color:red">&nbsp;'.$msg.'</p>';?>
			
        	 <form id="viewAll" name ="viewAll"  method="post">
     <input type="hidden" id="deleterow"  value=""/>
	 <input type="hidden" id="editid"  value=""/>
                <table class="module_edit_table"  id="datarow">
				<?php
				$rownum=0;
				foreach($CatRecords as $rowCat)
				{
				?>
                    <tr class="header">
                        <td colspan="4">
						<?php echo $rowCat->category_name."&nbsp;<a href='javascript:confirmDel(\"".url::base(FALSE)."index.php/exam/deleteCat?examId=".$examId."&CatId=".$rowCat->category_id."\")' ><img src='".url::base(FALSE)."media/img/icon_remove_proSeriesDark.gif'></a>" ?>
					<a href="<?php echo url::base(FALSE)."index.php/exam/newCategory?id=".$examId."&catId=".$rowCat->category_id."&keepThis=true&TB_iframe=true&height=200&width=740"; ?>" class="thickbox settingbutton" ><img src='<?php echo url::base(FALSE)?>media/img/icon_viewgroup.gif'></a>
						</td>
                    </tr>
					 <?php
	    		$i=0;
				$num=0;
				foreach($Questions as $row)
				{
					if($row->category_id==$rowCat->category_id)
					{
						$rownum++;
						if($i==0)
						{
							$i=1;
							echo '<tr><td colspan="4"><ul id="phoneticlong'.$rowCat->category_id.'">';

						}
						$num++;
						if($num%2==0)
						$class='odd';
						else
						$class='even';
						echo "<li id='".$row->category_id."/".$row->question_id."' class='".$class."' ><table><tr>";
						echo "<td class='cell_editnumber'><input name='name' id='name' class='inputbox' value='$rownum' /></td>";
						echo "<td class='cell_editname'>$row->question_title</td>";
						echo "<td class='cell_edittype'>$row->question_type</td>";
						echo "<td class='cell_editinfo'><a href='".url::base(FALSE)."index.php/exam/newExamQuest?id=".$examId."&itemId=".$row->question_id."&keepThis=true&TB_iframe=true&height=480&width=755' class='thickbox' ><img src='".url::base(FALSE)."media/img/icon_info.png' ></a><a href='javascript:confirmDel(\"".url::base(FALSE)."index.php/exam/deleteQuestion?examId=".$examId."&itemId=".$row->question_id."\")' ><img src='".url::base(FALSE)."media/img/icon_orangecirclexLg.png' width=21px heigth:21px></a></td>";
						echo '</tr></table></li>';
					}
				}
				if($i==1)
				echo '</ul>';
				?>
				<?php
				}
				?>
                </table>
            </form>
        </div><!-- /#module_edit_area -->
  </div><!-- end #module_content -->
    <div class="clearfloat"></div>
</div><!-- end #module_middle -->
<script language="JavaScript" type="text/javascript"><!--
	var dragsort = ToolMan.dragsort()
	var junkdrawer = ToolMan.junkdrawer()
	window.onload = function() {
		<?php 
		foreach($CatRecords as $rowCat)
		{
		?>
		dragsort.makeListSortable(document.getElementById("phoneticlong<?php echo $rowCat->category_id?>"),
		verticalOnly, saveOrder)
		<?php }?>
	}

	function verticalOnly(item) {
		item.toolManDragGroup.verticalOnly()
	}

	function speak(id, what) {
		var element = document.getElementById(id);
		element.innerHTML = 'Clicked ' + what;
	}

	function saveOrder(item) {
		var group = item.toolManDragGroup
		var list = group.element.parentNode
		var id = list.getAttribute("id")
		if (id == null) return
		group.register('dragend', function() {
			ToolMan.cookies().set("list-" + id, 
					junkdrawer.serializeList(list), 365)
		})
	}
	function AjaxOrder(arg)
	{
		currentId=arg.id;
		arr=currentId.split("/") ;
		listId=arr[0];
		//alert(listId);
		var tempUrl='<?php echo url::base(FALSE) ?>index.php/checklist/reArrange';
		order=ToolMan.junkdrawer().serializeList(document.getElementById('phoneticlong'+listId));
		$.get(tempUrl,{'checkList':<?php echo $examId?>,'positions':order});
	}
	function confirmDel(url)
	{
		if(confirm("Are you sure want to delete?"))
		{
			window.location.href=url;
		}
	}
	//-->
</script>
</body>
</html>
