<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New Exam</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/basic.css" type="text/css" media="screen"  />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" type="text/css"   />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/jquery.ui.all.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.ui.core.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.ui.widget.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.ui.mouse.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.ui.slider.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	 $("#setting").validate();
	 $("#all").click(function()
	 {
		if($(this).attr('checked')==true)
		$(".all").attr('checked',true);
		else
		$(".all").attr('checked',false);
	 }
	 );
	  $(".eval").click(function()
	 {
		var val=document.getElementsByName('evalution[]');
		if(val[0].checked==true || val[1].checked==true || val[2].checked==true)
		$("#evaluation_checklist").attr('checked',true);
		else
		$("#evaluation_checklist").attr('checked',false);
	 }
	 );
});
$(function() {
		$( "#slider-range" ).slider({
			value:<?php echo $passReq ?>,
			min: 0,
			max: 100,
			slide: function( event, ui ) {
				$( "#passvalue" ).val( ui.value +"%" );
			}
		});
		$( "#passvalue" ).val( $( "#slider-range" ).slider( "value" ) +"%"  );
	});
</script>
</head>
<body >
<div id="popup_newchecklist">
<div id="popup_newchecklist_header">
<h1>New Exam</h1>
</div><!-- end #popup_newchecklist_header -->
<form id="setting" name="setting"  action="" method="post">
<div id="popup_newchecklist_content">
<div id="popup_newchecklist_content_left">
	<label for="name">Name</label><br />
    <input name="name" id="name" class="inputbox required" value="<?php echo $name?>" /><br />
    <br />
    <div>
		<table>
		<tr>
		<td>
		<label >Passing Requirement</label>
		</td>
		<td>
		<input type="text" id="passvalue"  name="passvalue"  class="inputbox" style="width:50px;border:0; font-weight:bold;margin-left:6px" />
		</td>
		<td>
		<div id="slider-range" style="width:150px;"></div>
		</td>
		</tr>
		</table>
		<label >Total exam attempts</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input name="totalattempts" id="totalattempts" class="inputbox required" style="width:150px;margin-left:6px" value="<?php echo $totalAttempts?>"/><br />
		<label >Number of questions asked</label>&nbsp;&nbsp;<input name="numquest" id="numquest" class="inputbox required" style="width:150px" value="<?php echo $numberQuestion?>"/><br />
    	<input type="checkbox" class="checkbox eval" name="mandatory" id="mandatory" value="1" <?php if($alwaysMantetory==1)echo 'checked' ?> /> 
    	<label for="individuals">Always ask mandatory questions</label><br />
    	<input type="checkbox" class="checkbox eval" name="randomexamquestion"  id="randomexamquestion" value="1" <?php if($randomExam==1)echo 'checked' ?> /> 
    	<label for="companies">Randomize exam questions</label><br />
    	<input type="checkbox" class="checkbox eval" name="randomexamqans"  id="randomexamqans" value="1"<?php if($randomAns==1)echo 'checked' ?>  /> 
    	<label for="groups">Randomize exam answers</label><br />
	</div>
</div><!-- end #popup_newchecklist_content_left -->

<div id="popup_newchecklist_content_right">

<label>Group</label>
<br />
           <div id="popup_newchecklist_wrapper">
           		<table class="popup_checklist_table">
                	<tr>
                    	<th><input type="checkbox" class="checkbox" id="all" /> 
                    	<strong>Select All</strong></th>
                    </tr>
					<?php
					foreach($groups as $row)		
					{
					?>
						<tr>
						<td class="odd"><input type="checkbox" <?php if(in_array($row->group_id,$selectedGroup)) echo ' checked ' ?>class="checkbox all" name="group[]" value="<?php echo $row->group_id ?>"/> 
						<?php echo $row->group_name ?></td>
						</tr>                    
					<?php
					}?>
                </table>
           </div>

</div><!-- end #popup_newchecklist_content_right -->
</div><!-- end #popup_newchecklist_content -->
<div id="popup_newchecklist_footer">
		<input type="submit" class="submit_moreinfo" value="" />
		 <input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
</div><!-- end #popup_newchecklist_footer -->
        </form>
</div><!-- end #popup_newchecklist -->
</body>
</html>