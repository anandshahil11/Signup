<?php 
require_once('header.php');
?>
<script language="javascript">
	var url='<?php echo url::base(FALSE) ?>index.php/exam/viewExamQuestion?id=';
	var durl='<?php echo url::base(FALSE) ?>index.php/exam/delExam?id=';

</script>
<script type="text/javascript" >
//For selecting  and editing row
var idsArray=new Array();
var idsText='';
$(document).ready(function() {
$("#datarow tr").click(function(event) {
	var tr_id= ($(this).attr("id"));
	if(tr_id)
	{
		$(this).toggleClass("selected", this.clicked);
		$(this).removeClass('over');
	}
	var rowDel = $("#datarow td.exam"+tr_id).text();
	var id = $("#datarow td.exam"+tr_id).text();
	if($(this).attr('class')=='odd' || $(this).attr('class')=='even')
	{   
		removeByValue(idsArray,tr_id);
		idsText=idsArray.join(",");
	}
	else if($.inArray(tr_id, idsArray)<0)
	{   idsArray.push(tr_id);
		idsText=idsArray.join(",");
	}
	$('#deleterow').val(rowDel);
	$('#editid').val(idsText);
  });
  function removeByValue(arr, val) {
    for(var i=0; i<arr.length; i++) {
        if(arr[i] == val) {
            arr.splice(i, 1);
            break;
        }
    }
}
$(function() {
    $('table tbody tr').mouseover(function() {
		if($(this).attr('class')!='odd selected' && $(this).attr('class')!='even selected')
        $(this).addClass('over');
    }).mouseout(function() {
        $(this).removeClass('over');
	});
	});

// for confirmation box

$('.ask').click(function(e) {

	 var del = $('#deleterow').val();
	 if(del == '' || del == 0)
		{
			alert("Please select record to delete");
			return  false;
		}
	 
	 if(del)
	 {
		e.preventDefault();
		var href =durl+idsText;
		del = 0;
		if(confirm('Do you really want to delete this Exam?')) {
			window.location = href;
		 }
				
	}

});
 
//finish conformation 

$('.edit').click(function(e) {

	 var id = $('#editid').val();
	 if(id == '' || id == 0)
	{
			alert("Please select record to edit");
			return false;

	}
	if(id.indexOf(',')==-1)
	{
		e.preventDefault();
		var href =url+id;
		id = 0;

			window.location = href;
				
	}else
	{
		alert('Please select only one row for edit');
		return false;
	}

});

}); 
</script  >
<div id="module_middle">
	<?php require_once('userLeftPanel2.php');?>
    <div id="module_content" style="width:82%">
    	<div id="module_edit_header">
        	<h1>All Exams</h1>
            <div id="module_edit_header_options">
				<a href="" class="ask settingbutton user_delete" >Delete</a>
            	<a href="" class="edit editbutton user_edit" >Edit</a>
				<a href="<?php echo url::base(FALSE)."index.php/exam/exam?keepThis=true&TB_iframe=true&height=400&width=740"; ?>" class="settingbutton thickbox edittemp_addnew" >Add</a>
			</div>
        </div><!-- end #module_edit_header -->
		 <form id="viewAll" name ="viewAll"  method="post">
     <input type="hidden" id="deleterow"  value=""/>
	 <input type="hidden" id="editid"  value=""/>
            <table id="datarow">
            	<tr>
                	<th align="center">checklist Name</th>
                	<th align="center">Identification Number</th>
                	<th align="center">Last Used</th>
                	<th align="center">Created</th>
					<th align="center">Author</th>
                </tr>
				 <?php
	    		$i=1;
				$num=0;
				foreach($records as $row)
				{
					$num++;
					if($num%2==0)
					$class='odd';
					else
					$class='even';
					echo "<tr id=".$row->exam_id." class='".$class."' >";
					echo "<td >$row->exam_name </td>";
					echo "<td class='td_center exam".$row->exam_id."' style='padding-top:6px;padding-bottom:6px'>$row->exam_id</td>";
					if($row->exam_last_used  =='0000-00-00')
					echo "<td class='td_center' >-</td>";
					else
					echo "<td class='td_center' >$row->exam_last_used </td>";
					echo "<td class='td_center' >$row->exam_created </td>";
					echo "<td class='td_center' >$row->firstname $row->lastname</td></a>";
					echo '</tr>';
				}
				?>
            </table>
		</form>
    </div><!-- end #module_content -->
    <div class="clearfloat"></div>
</div><!-- end #module_middle -->
</body>
</html>