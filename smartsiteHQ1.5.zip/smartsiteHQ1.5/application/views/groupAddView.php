<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [1/March/11]
Page Description:: Group ADD View  page 
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/thickbox.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script.js"></script>
<script type="text/javascript">
/*$(document).ready(function(){
	$('input[type= "submit"]').click(function()
	{
		if($(this).val()=='Save')
		{	
			$('#groupName').fadeIn();
			$('#groupName').attr('class','required');
			$('#checkgroup').fadeIn();
			$('#checkgroup').attr('class','required');
			$('#category').fadeIn();
			$('#category').attr('class','required');
			$('#checkgroup').fadeIn();
			$('#checkgroup').attr('class','required');
		}	
	}
	);
	
	$('#update').click(function()
	{
		if($(this).val()=='Update')
		{	
			$('#groupName').fadeIn();
			$('#groupName').attr('class','required');
			$('#checkgroup').fadeIn();
			$('#checkgroup').attr('class','required');
			$('#category').fadeIn();
			$('#category').attr('class','required');
			$('#checkgroup').fadeIn();
			$('#checkgroup').attr('class','required');
		}	
	}
	);
	 $("#setting").validate();

});*/
//initiate validator on load
	$(function() {
	// validate contact form on keyup and submit
	$("#setting").validate({
	//set the rules for the field names
	rules: {
	groupName: {
	required: true,
	minlength: 2
	},
	category: {
	required: true,
	minlength: 2
	},
	
	},
	//set messages to appear inline
	messages: {
	groupName: "*Please enter Group Name",
	category: "*Please enter Group Category"
	
	}
	});
	});

</script>
<style type="text/css">
	.error {
	color: red;
	font: 12pt verdana;
	padding-left: 10px
	}
</style>
</head>
<body>
<div id="popup_newgroup">
	<div id="popup_newgroup_header">
		<?php 
		if($_GET['id']=='setting')
		{
		?>
			<h1>New Group</h1>
		<?php 
		}
		else
		{ ?>
			<h1>Edit Group</h1>
		<?php
		} ?>
		
    </div>
    <div id="popup_newgroup_content"> 
    <form name='groupsetting' id='setting' action='' method='post' enctype='multipart/form-data'>
    <input type="hidden"  id="groupManager" name="groupManager"  value="<?php echo $_GET['user'];?>"/>
    <input type="hidden"  id="companyId" name="companyId" value="<?php echo $_GET['companyid'];?>"/>    
    <div id="popup_newgroup_content_middle">
    	<div id="popup_newgroup_inputwrapper" class="clearfix">
                <div class="popup_newuser_inputwrapper_left">
                	<label for="first_name">Group Name</label><br />
                	<input type="text" name="groupName" id="groupName" class="inputbox" value='<?php if($_GET['id'] != 'setting')echo $groupname;?>' />
                </div>
                
                <div class="popup_newuser_inputwrapper_left">
                	<label for="last_name">Category</label><br />
                	<input type="text" name="category" id="category" class="inputbox" value='<?php if($_GET['id'] != 'setting')echo $category;?>' />
                </div>
           </div>
		   <div id="popup_newgroup_inputwrapper" class="clearfix">
                <div class="popup_newuser_inputwrapper_left">
                	<label for="first_name">Group Description</label><br />
                	<input type="text" name="groupDesc" id="groupDesc" class="inputbox" value='<?php if($_GET['id'] != 'setting')echo $groupdesc;?>' />
                </div>
				<div class="popup_newuser_inputwrapper_left">
                	<label for="last_name">Group Manager</label><br />
                	<select name="adminList" id="adminList" class="inputbox">
					    <?php 
						if($_GET['id'] == 'setting')
						{
						    $count = count($userAdminList);
							for($index=0;$index<$count;$index++)
							{
							    echo "<option value='".$userAdminList[$index]->user_id."' >".$userAdminList[$index]->username."</option>";
							}	
						}else
						{
						    $count = count($userAdminList);
							for($index=0;$index<$count;$index++)
							{
							    if($groupmanager == $userAdminList[$index]->username)
								{
								    echo "<option value='".$userAdminList[$index]->user_id."' selected='selected' >".$userAdminList[$index]->username."</option>";
								}else
								{
								    echo "<option value='".$userAdminList[$index]->user_id."' >".$userAdminList[$index]->username."</option>";
								}
							}	
						}
					    ?>
					</select>
                </div>
                
                
           </div>
           
           
    </div><!-- end #popup_newgroup_content_middle -->
        
    <div id="popup_newgroup_content_bottom">
	    <?php 
		if($_GET['id']=='setting')
		{
		?>
       	<input type="submit" class="submit_moreinfo" value="" />
		<?php
		}else
		{
		?>
		<input type="submit" name="update"  class="update_moreinfo" value="" />
		<?php
		}
		?>
		<a href="#"><input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
    </div><!-- end #popup_newgroup_content_bottom -->
    </form>
    </div><!-- end #popup_newgroup_content -->
</div><!-- end #popup_newuser -->
</body>
</html>
