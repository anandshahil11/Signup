<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [1/March/11]
Page Description:: Group  View All  page 
*********************************************/
require_once('header.php');
?>
<script type="text/javascript">

function tb_init(){
	$(document).click(function(e){
	e = e || window.event;
	var el = e.target || e.scrElement || null;
	if(el && el.parentNode && !el.className || !/thickbox/.test(el.className))
	el = el.parentNode;
	if(!el || !el.className || !/thickbox/.test(el.className))
	return;
	var t = el.title || el.name || null;
	var a = el.href || el.alt;
	var g = el.rel || false;
	tb_show(t,a,g);
	el.blur();
	return false;
	});
};

//var url='<?php echo url::base(FALSE) ?>index.php/user/group/';
var durl='<?php echo url::base(FALSE) ?>index.php/user/deleteGroup/<?php echo $companyid;?>/<?php echo $userid;?>?groupid=';
$(document).ready(function()
{
    $("#GroupTable tr").click(function(event) 
	{
		var tr_id= $(this).val();
		$('#deleterow').val(tr_id);
		$('#editid').val(tr_id);
		
    });
	
    //To Delete Group 
    $('.delete').click(function(e) 
	{
        var del = $('#deleterow').val();
		if(del == '' || del == 0)
		{
			alert("Please select record to delete");
			return  false;
		}
		 
		if(del)
		{
			e.preventDefault();
			var href =durl+del;
			del = 0;
			if(confirm('Do you really want to delete this group?')) 
			{
				window.location = href;
			}
					
		}

	});
	
	$('.edit').click(function(e) 
	{
        var id = $('#editid').val();
		var user = '<?php echo $user; ?>';
		var userid = '<?php echo $userid; ?>';
		var companyid = '<?php echo $companyid; ?>';
		var url = '<?php echo url::base(FALSE) ?>index.php/user/setting?user='+user+'&userid='+userid+'&companyid='+companyid+'&id='+id+'&type=I&keepThis=true&TB_iframe=true&height=400&width=510';
		if(id == '' || id == 0)
		{
			alert("Please select record to edit");
			return false;
        }
		if(id)
		{
			e.preventDefault();
			var href =url;
			id = 0;
            //window.location = href;
			$('#lightlink').attr('href',url);
			
		}else
		{
			alert('Please select only one row for edit');
			return false;
		}
		
		

    });
	
	$('.analytics').click(function(e) 
	{
        var id = $('#editid').val();
		var url = '<?php echo url::base(FALSE) ?>index.php/group/viewDetailGroup?companyid=<?php echo $companyid;?>&groupid='+id;
		if(id == '' || id == 0)
		{
			alert("Please select group to view users");
			return false;
        }
		if(id)
		{
			e.preventDefault();
			var href =url;
			id = 0;
            window.location = href;
			$('#lightlink').attr('href',url);
			
		}else
		{
			alert('Please select only one row for edit');
			return false;
		}
	});	
	

});
</script>
<div id="module_middle">
    <?php require_once('userLeftPanel.php');?>
	<div id="module_content" style="width:82%">
		<form id="viewAll" name ="viewAll"  method="post">
        <input type="hidden" id="deleterow"  value=""/>
	    <input type="hidden" id="editid"  value=""/>
    	<div id="module_edit_header">
        	<h1>All Groups</h1>
			<div id="module_edit_header_options">
                <a class="user_view analytics" href="#">View Users</a>
				<a class="edit user_edit thickbox" id="lightlink" href="#" style="text-decoration:none;color:black;" >
				Edit Group</a>
                <a href="<?php echo url::base(FALSE)."index.php/user/setting?user=$user&userid=$userid&companyid=$companyid&id=setting&type=I&keepThis=true&TB_iframe=true&height=400&width=510"; ?>"  
				   style="text-decoration:none;color:black;" 
				   class="thickbox edittemp_addnew duplicate" >
				Add Group</a>
                <a class="user_delete delete" href="#">Delete Group</a>
				
            </div>
        </div><!-- end #module_edit_header -->
		
           
            <table width="100%" border="0" id="GroupTable" cellpadding="0" cellspacing="0" class="tablesorter">
            	<thead>
				<tr>
                	<th>Group Name</th>
                	<th>Category</th>
                	<th>Group Id</th>
                	<th>Participants</th>
                	<th>Manager</th>
					<th>Client</th>
                </tr>
				</thead>
				<?php
				$count = count($groupData);
				for($i=0;$i<$count;$i++)
				{   
				    if((($i+1)%2)==0)
					{
				?>
				<tr  id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';" 
					onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $groupData[$i]->group_id; ?>';this.class='selected';"
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"
				>
                	<td><?php echo $groupData[$i]->group_name; ?></td>
                    <td><?php echo $groupData[$i]->group_category; ?></td>
                    <td><?php echo $groupData[$i]->group_id; ?></td>
                    <td><?php echo $groupData[$i]->participants; ?></td>
                    <td><?php echo $groupData[$i]->group_manager; ?></td>
					<td><?php echo $groupData[$i]->company_name; ?></td>
                </tr>
				<?php
				    }else
                    {					
				?>
                <tr  id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
					onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $groupData[$i]->group_id; ?>';this.class='selected';"
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"
				>
                	<td><?php echo $groupData[$i]->group_name; ?></td>
                    <td><?php echo $groupData[$i]->group_category; ?></td>
                    <td><?php echo $groupData[$i]->group_id; ?></td>
                    <td><?php echo $groupData[$i]->participants; ?></td>
                    <td><?php echo $groupData[$i]->group_manager; ?></td>
					<td><?php echo $groupData[$i]->company_name; ?></td>
                </tr>
                <?php
				    }
				}	
				?>
                
            </table>
			</form>
			
    </div><!-- end #module_content -->
    <!--<div id="user_info">
	    
		<div id="user_info_header"><h1>Group Stats</h1></div>
    </div>-->
    <div class="clearfloat"></div>	
        
</div><!-- end #module_middle -->

</body>
</html>