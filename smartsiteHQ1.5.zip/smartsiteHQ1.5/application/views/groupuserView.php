<?php 
/********************************************
AUTHOR:: Anupama C
Version:: 2.0
Date:: [09/March/11]
Page Description::Users in Group page 
*********************************************/
require_once('header.php');
$groupid = $_GET['groupid'];
$companyid = $_GET['companyid'] ;

?>

<script type="text/javascript">

function tb_init(){
	$(document).click(function(e){
	e = e || window.event;
	var el = e.target || e.scrElement || null;
	if(el && el.parentNode && !el.className || !/thickbox/.test(el.className))
	el = el.parentNode;
	if(!el || !el.className || !/thickbox/.test(el.className))
	return;
	var t = el.title || el.name || null;
	var a = el.href || el.alt;
	var g = el.rel || false;
	tb_show(t,a,g);
	el.blur();
	return false;
	});
};

//var url='<?php echo url::base(FALSE) ?>index.php/user/group/';
var durl='<?php echo url::base(FALSE) ?>index.php/group/deleteGroupUser?companyid=<?php echo $companyid ;?>&groupid=<?php echo $groupid ;?>&userid=';
var rmurl='<?php echo url::base(FALSE) ?>index.php/group/removeUserGroup?companyid=<?php echo $companyid ;?>&groupid=<?php echo $groupid ;?>&userid=';
var dgurl='<?php echo url::base(FALSE) ?>index.php/group/deleteFullGroup?companyid=<?php echo $companyid ;?>&groupid=<?php echo $groupid ;?>';
$(document).ready(function()
{
    $("#myTable tr").click(function(event) 
	{
		var tr_id= $(this).val();
		$('#deleterow').val(tr_id);
		$('#editid').val(tr_id);
		
    });
	
    //To Delete user
    $('.delete').click(function(e) 
	{
        var del = $('#deleterow').val();
		if(del == '' || del == 0)
		{
			alert("Please select user to delete");
			return  false;
		}
		 
		if(del)
		{
			e.preventDefault();
			var href =durl+del;
			del = 0;
			if(confirm('Do you really want to delete this User?')) 
			{
				window.location = href;
			}
					
		}

	});
	
	
	
	//To Delete Group
    $('.deleteg').click(function(e) 
	{
     
			e.preventDefault();
			var href =dgurl;
			del = 0;
			if(confirm('Do you really want to delete this Group?')) 
			{
				window.location = href;
			}
		

	});
	
	$('.edit').click(function(e) 
	{
        var id = $('#editid').val();
		var companyid = '<?php echo $companyid; ?>';
		var groupid = '<?php echo $groupid ; ?>';
		var url = '<?php echo url::base(FALSE) ?>index.php/group/groupSetting?companyid='+companyid+'&groupid='+groupid+'&id='+id+'&type=I&keepThis=true&TB_iframe=true&height=500&width=780';
		if(id == '' || id == 0)
		{
			alert("Please select record to edit");
			return false;
        }
		if(id)
		{
			e.preventDefault();
			var href =url;
			id = 0;
			$('#lightlink').attr('href',url);
			
		}else
		{
			alert('Please select only one row for edit');
			return false;
		}

    });
	
	//To Remove user
    $('.remove').click(function(e) 
	{
        var del = $('#deleterow').val();
		if(del == '' || del == 0)
		{
			alert("Please select user to remove from this group");
			return  false;
		}
		 
		if(del)
		{
			e.preventDefault();
			var href =rmurl+del;
			del = 0;
			if(confirm('Are you sure want to remove this user from this group? This will not delete the user.')) 
			{
				window.location = href;
			}
					
		}

	});
	
	$('.export').click(function(e) 
	{
        var checkgroup = $('#checkgroup').val();
		if(checkgroup == '')
		{
			alert('Please select users to export');
			return  false;
		}
		var companyid = '<?php echo $companyid; ?>';
		var groupid = '<?php echo $groupid ; ?>';
		var url = '<?php echo url::base(FALSE).'index.php/group/exportUser?companyid='.$companyid.'&groupid='.$groupid;?>';
		url +='&check='+checkgroup; 
		if(checkgroup)
		$('.export').attr('href',url);
	});

	
});

var checked =  new Array();
var i = 0;
</script>

<script type="text/javascript">
//ADDED  for left FORM SUBMISSION
$(function() {
	
	$(".testButton").click(function() {
	
		var id = $(this).val();
		$("#right_stat").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
		var userid = $(this).val();
		var groupid = <?php echo $groupid;?>;
		var companyid = '<?php echo $companyid; ?>';
		var action = $("input#action").val();
		var dataString ='companyid='+companyid+'&userid='+userid+'&groupid='+groupid+'&action='+action;
		$.ajax({
			type: "POST",
			url: "<?php echo url::base(FALSE) ?>/index.php/user/rightuserPane/",
			data: dataString,
			success: function(data) {
				
				$('#right_stat').html(data);			
			}
	});
		
		$("#check"+id).attr('checked','checked');
		checked[i++] = $("#check"+id+":checked").val() ;
		$('#checkgroup').val(checked);
		
	
});

$(".testButton").dblclick(function() {
	var id = $(this).val();
	$("#check"+id+":checkbox").removeAttr('checked');
	if($("#check"+id+":checkbox").is(':not(:checked)'))
		{
			$("#check"+id+":checkbox").removeAttr('checked');
			$("#myTable thead tr th:first input:checkbox").removeAttr('checked');
			var index ;
			for (var j=0;j<checked.length;j++)
			{
				if(checked[j] == id)
				{
					index = j;
					checked.splice(index,1,"");
				}
			}
			
		}
		var arr = new Array();
		var k= 0;
		for(var i=0;i < checked.length;i++)
		{
			if(checked[i]!='')
			{
				arr[k++] = checked[i];
			}
		}
		$('#checkgroup').val(arr);
		
});


$("#myTable tbody tr  input:checkbox").click(function() {
	var id = $(this).val();
	if($("#check"+id+":checkbox").is(':checked'))
	{
		checked[i++] = $("#check"+id+":checked").val();
		$("#check"+id).attr('checked','checked');	
	}
		
	if($("#check"+id+":checkbox").is(':not(:checked)'))
	{
		$("#check"+id+":checkbox").removeAttr('checked');
		$("#myTable thead tr th:first input:checkbox").removeAttr('checked');
		var index ;
		for (var j=0;j<checked.length;j++)
		{
			if(checked[j] == id)
			{
				index = j;
				checked.splice(index,1,"");
			}
		}
		
	}
		
	$('#checkgroup').val(checked);
	
	$("#right_stat").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
	var userid = $(this).val();
	var groupid = <?php echo $groupid;?>;
	var companyid = '<?php echo $companyid; ?>';
	var action = $("input#action").val();
	var dataString ='companyid='+companyid+'&userid='+userid+'&groupid='+groupid+'&action='+action;
	$.ajax({
		type: "POST",
		url: "<?php echo url::base(FALSE) ?>/index.php/user/rightuserPane/",
		data: dataString,
		success: function(data) {
			
			$('#right_stat').html(data);			
		}
	});
		
	//alert(checked);
});

$("#myTable thead tr th:first input:checkbox").click(function() {
	
		var checkedStatus = this.checked;
		$("#myTable  input:checkbox").each(function() {	
				this.checked = checkedStatus;
				if($(this).val() != 'selectAll')
				checked[i++] = $(this).val();
		});
		if($(this).is(':not(:checked)'))
		{
			 $("#myTable  input:checkbox").each(function() {
				$(this).removeAttr('checked');
				checked = new Array();
			});
		}
		$('#checkgroup').val(checked);
		//alert(checked);
	});
		
});

</script>


<div id="module_middle">
    <?php require_once('userLeftPanel.php');?>
	<div id="module_content" >
		<form id="viewAll" name ="viewAll"  method="post">
        <input type="hidden" id="deleterow"  value=""/>
	    <input type="hidden" id="editid"  value=""/>
		<input type="hidden" id="checkgroup" name="checkgroup"  value=""/>
    	<div id="module_edit_header" style="height:60px;background:url(../img/moduleEditHeader_bg.gif);">
        	<h1><?php echo $groupData[0]->group_name; ?></h1>
			<p>
			<?php
			if(isset($_GET['msg']))
			echo '<span style="color:red">'.$_GET['msg']."</span>";
			?>
			</p>
			<div id="module_edit_header_options" style="margin-left:-10px;">
                <a style="padding-left:18px;margin-left:-10px;" class="thickbox addusers edittemp_addnew" href="<?php echo url::base(FALSE).'index.php/group/groupSetting?companyid='.$companyid.'&groupid='.$groupid.'&id=setting&type=I&keepThis=true&TB_iframe=true&height=500&width=780'; ?>"  style="text-decoration:none;color:black;" > New User</a>
				<a style="padding-left:18px;margin-left:-10px;" class="deleteg user_delete" href="#" style="text-decoration:none;color:black;">Delete Group</a>
				<a style="padding-left:18px;margin-left:-10px;" class="delete user_delete" href="#" style="text-decoration:none;color:black;">Delete User</a>
				<a style="padding-left:18px;margin-left:-10px;" class="export user_export" href="#" style="text-decoration:none;color:black;">
				Export User
				</a>
				<a style="padding-left:18px;margin-left:-10px;" class="edit thickbox user_edit" id="lightlink" href="#" style="text-decoration:none;color:black;" >
				Edit User
				</a>
				<a style="padding-left:18px;margin-left:-10px;" class="remove user_delete" href="#" style="text-decoration:none;color:black;">Delete User from this Group</a>
				
            </div>
        </div><!-- end #module_edit_header -->

		
           
            <table width="90%" border="0" id="myTable" cellpadding="0" cellspacing="0" class="tablesorter">
            	<thead>
				<tr>
					<th width="1%" align="left" style="padding-right:0px;padding-left:0px;"> 
					<input type="checkbox" name="selectAll"  value="selectAll"   style="margin-left:18px;margin-right:0px;margin-top:0px;margin-bottom:0px;padding-right:0px;padding-left:0px;"></th>
                	<th width="10%" style="padding-right:0px;padding-left:4px;">First Name</th>
                	<th width="10%" style="padding-right:0px;padding-left:4px;">Last Name</th>
                	<th width="18%" style="padding-right:0px;padding-left:4px;">Company</th>
                	<th width="20%" style="padding-right:0px;padding-left:4px;">Username/EmailId</th>
                	<th width="18%" style="padding-right:0px;padding-left:4px;">Country</th>
					<th width="10%" style="padding-right:0px;padding-left:4px;">Last Log-in</th>
                </tr>
				</thead>
				<?php
				$count = count($usersData);
				if($count>0){
				for($i=0;$i<$count;$i++)
				{   
				    if((($i+1)%2)==0)
					{
				?>
				<tr    id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
				   onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';"
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';" 
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"> 
					<input type="hidden" name="action" id="action" value="none" />
					<td width="1%" align="left" ><input type="checkbox" id="<?php echo "check".$usersData[$i]->user_id; ?>"  value="<?php echo $usersData[$i]->user_id; ?>" style="margin-left:1px;margin-right:0px;margin-top:0px;" ></td>
                	<td width="10%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->firstname,10,"<br/>\n",true); ?></td>
                    <td width="10%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->lastname,10,"<br/>\n",true); ?></td>
                    <td width="18%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->company,9,"<br/>\n",true); ?></td>
                    <td width="20%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->emailid,20,"<br/>\n",true); ?></td>
                    <td width="18%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->country,9,"<br/>\n",true); ?></td>
					<td width="10%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php if($usersData[$i]->last_login != ""){ echo date("m/d/Y",$usersData[$i]->last_login); }else{ echo "-"; }?></td>
                </tr>
				<?php
				    }else
                    {					
				?>
                <tr    id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
					onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';"
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"
				>   <input type="hidden" name="action" id="action" value="none" />
					<td width="1%" align="left" ><input type="checkbox" id="<?php echo "check".$usersData[$i]->user_id; ?>"  value="<?php echo $usersData[$i]->user_id; ?>" style="margin-left:1px;margin-right:0px;margin-top:0px;" ></td>
                	<td width="10%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->firstname,10,"<br/>\n",true); ?></td>
                    <td width="10%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->lastname,10,"<br/>\n",true); ?></td>
                    <td width="18%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->company,9,"<br/>\n",true); ?></td>
                    <td width="20%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->emailid,20,"<br/>\n",true); ?></td>
                    <td width="18%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php echo wordwrap($usersData[$i]->country,9,"<br/>\n",true); ?></td>
					<td width="10%" class="testButton" onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]->user_id; ?>';this.class='selected';" ><?php if($usersData[$i]->last_login != ""){ echo date("m/d/Y",$usersData[$i]->last_login); }else{ echo "-"; } ?></td>
                </tr>
                <?php
				    }
				}
                }else{
				?>
				<tr id='0'>
					<td width="5%" align="left" ><input type="checkbox" name="N/A"  value="N/A" style="margin-left:1px;"></td>
				    <td>NA</td>
                    <td>NA</td>
                    <td>NA</td>
                    <td>NA</td>
                    <td>NA</td>
					<td>NA</td>
				</tr>
				<?php
				} 				
				?>
                
            </table>
			</form>
			
    </div><!-- end #module_content -->
    <div id="user_info">
	    
		<div id="user_info_header"><h1>User Stats</h1></div>
			 <div id="right_stat" style="margin:0 auto;padding-left:2px;">
		 
				
			 </div>
		
		
		
    </div>        
        
</div><!-- end #module_middle -->

</body>

</html>