<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Smartsite HQ 1.5 </title>

<!-- Header -->

<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<?php require_once('link.php');?>
</head>
<body id="module_body">
<div id="module_header_bg">
	<div id="module_head">
    	<div id="module_head_left">
        	<img src="<?php echo url::base(FALSE) ?>media/img/logo_expandSmartSiteHQ.png" alt="Expand Smart Site logo" />
        </div><!-- end #module_head_left -->
        <div id="module_head_center">
        	<a href="#">Dashboard</a>
            <a class="<?php if(!isset($type)){ echo 'selected';}?>" href="<?php echo url::site("user/group/$userid",'http');?>" title="Users">Users</a>
            <a class="<?php if(isset($type)and $type=='module'){ echo 'selected';}?>" href="<?php echo url::site("wizard/viewAll?set=1",'http');?>" title="Modules">Modules</a>
		</div><!-- end #module_head_center -->
        
        <div id="module_head_right">
        	<h1><?php echo $role; ?></h1>
            <h2><?php echo $username; ?></h2>
            <a class="logout" href="<?php echo url::site("login/logout",'http');?>">Logout</a>
        </div><!-- end #module_head_right -->
    </div><!-- end #module_head -->
</div><!-- end #module_header_bg -->

