<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [15/March/11]
Page Description:: Import User view page 
*********************************************/
require_once('header.php');
?>

<div id="module_middle" style="max-height:575px;">
    <?php require_once('userLeftPanel.php');?>
	<div id="module_content" style="width: 82%; max-height: 575px;">
		<div id="module_content_header">
        	<div id="module_content_header_left_import" >
        		<h1>Import Users</h1>
				<p>
					You can
					<a href="<?php echo url::base(FALSE) ?>upload/user_informations.csv" target="_top" style="color:#686868;text-decoration:underline;">download a template</a> 
					file or create your own CSV file from scratch.</p>
            </div>
        </div><!-- end #module_content_header -->
		<div id="form_body" >
			<div id="inputfile" style="background-color: skyblue; text-align: center;">
			<?php 
			    echo $response;
			?>
			
			<p>&nbsp;</p>
				<form id="import" name="import" method="post" action="<?php echo url::base(FALSE).'index.php/group/importUser?companyid='.$companyid;?>" enctype="multipart/form-data">                
				&nbsp;&nbsp;&nbsp;<input type="file" name="csv_upload" size="90" id="csv_upload"  style="width:400px; height:25px;margin:5px 1px 5px 5px;" /> 
					<input type="submit" name="submit" value="submit" src="<?php echo url::base(FALSE) ?>media/img/browse_button.png" style="width:80px; height:25px;margin-top:6px;margin-bottom:6px;margin-left:240px;" />
				</form> 
			<p>&nbsp;</p>
			</div>
			<!--<div class="clear"></div>-->
			<div class="import_body" style="color:black;text-align: center; font-family:Myriad Pro, Verdanda, sans-serif;">
				 <h4>Make sure that your CSV file is in the following form and that the email is set for each user:</h4>
				 <p>&nbsp;</p>
				 <h5 style="color:#686868;font-family:Myriad pro,Verdana, sans-serif;"><b>Sample data as spreadsheet</b></h5>
				 <table width="80%" border="0"  class="blue_zebra_import" style="margin-right:2px;">
				   <tr >
					 <th scope="col" bgcolor="skyblue">First Name</th>
					 <th scope="col" class="border" >Last Name</th>
					 <th scope="col" class="border"> Company</th>
					 <th scope="col" class="border"> Email Address</th>
					 <th scope="col" class="border"> Country</th>
					 <th scope="col" class="border" > Role</th>
				   </tr>
				   <tr>
					 <td>John</td>
					 <td>Doe</td>
					 <td>Expand</td>
					 <td>john.doe@example.com</td>
					 <td>USA</td>
					 <td>User</td>
				   </tr>
				   
				 </table>
				 <p>&nbsp;</p>
				 <h5 style="color:#686868;font-family:Myriad pro,Verdana, sans-serif;"><b>Sample data as plain text</b></h5>
				 <p style="font-family:Myriad pro, Verdana, sans-serif;">&quot;First Name&quot;,&quot;Last Name&quot;,&quot;Company&quot;,&quot;Email Address&quot;,&quot;Country&quot;,&quot;Role&quot;<br />

				 &quot;John&quot;,&quot;Doe&quot;,&quot;Expand&quot;,&quot;john.doe@example.com&quot;,&quot;US&quot;,&quot;User&quot;</p>
				 <p>&nbsp;</p>
			 
			</div>
			<p>&nbsp;</p>
			<p>&nbsp;</p>

			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
	   
		</div>

		
	</div><!-- end #module_content -->
    
    <div class="clearfloat"></div>       
        
</div><!-- end #module_middle -->

</body>
</html>