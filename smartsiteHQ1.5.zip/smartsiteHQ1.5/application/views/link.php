<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/basic.css" type="text/css" media="screen"  />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/tablesorter.css" type="text/css"   />
<script src="<?php echo url::base(FALSE) ?>media/js/jquery-1.4.4.min.js" type="text/javascript" charset="utf-8"></script>
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" type="text/css" media="screen" charset="utf-8" />
<script src="<?php echo url::base(FALSE) ?>media/js/jquery.prettyPhoto.js" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-tablesorter.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/tablesorter.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/rowOverOut.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/thickbox.css" />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/thickbox.js"></script>