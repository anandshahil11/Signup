<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Media</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/basic.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/layout.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" />
<!-- Popup Video -->
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/prettyPhoto.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/main.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	$('input[type="radio"]').click(function()
	{
		if($(this).val()=='image')
		{	
			$('#imageblk').fadeIn();
			$('#videoblk').fadeOut();
			$('#image').attr('class','required');
			$('#videoUrl').attr('class','');
			$('#ipadlink').attr('class','');
		}else
		{
			$('#imageblk').fadeOut();
			$('#videoblk').fadeIn();
			$('#image').attr('class','');
			$('#videoUrl').attr('class','required');
			$('#ipadlink').attr('class','required');
			
		}
	}
	);
	 $("#mediaupload").validate();

});
function chkImage()
{
	var imgpath = document.getElementById('image').value;
	if(imgpath != "")
	{
	// code to get File Extension..
		var arr1 = new Array;
		arr1 = imgpath.split("\\");
		var len = arr1.length;
		var img1 = arr1[len-1];
		var filext = img1.substring(img1.lastIndexOf(".")+1);
		filext=filext.toLowerCase();
		// Checking Extension
		if(filext == "jpg" || filext == "jpeg" || filext == "gif" || filext == "bmp" || filext == "png")
		{
		}
	    else
		{
			alert("Invalid File Format Selected");
			return false;
		}
	}
}
</script>
</head>
<body>
<div id="popup_moreinfo" style="margin-top:0px;height:200px">
	<div id="popup_moreinfo_header">
    	<h1>More Info</h1>
    </div>
    
    <div id="popup_moreinfo_content">
    	<form name="mediaupload" id="mediaupload" action="" method="post" enctype="multipart/form-data" onsubmit="return chkImage()">
			<div id="popup_moreinfo_content_middle">
					<?php if(isset($_GET['msg']))echo "<span style='color:red'>".$_GET['msg']."</span><br/>"; ?>

				 <?php if($mode == 'edit')
				{ 
				if($mediatype == 'image')
				{ ?>
            	<label>Media Type</label><br />
				<input type="radio" value="image" name="mediatype" class="required radio" checked />
				<label class="radio_label" for="opt1a">Image</label>
                <input type="radio" value="video" name="mediatype"  class="required radio" />
				<label class="radio_label" for="opt1b">Video</label>
				<?php }
				else
				{
				?>
				<label>Media Type</label><br />
				<input type="radio" value="image" name="mediatype" class="required radio"  />
				<label class="radio_label" for="opt1a">Image</label>
                <input type="radio" value="video" name="mediatype"  class="required radio" checked />
				<label class="radio_label" for="opt1b">Video</label>
				<?php 
				}
				?>
               <div id="imageblk" <?php if($mediatype == 'video') echo 'style="display:none"';?> >
				<label>File</label><br />
			    <input type="file" name="image"  id="image" class="<?php if($mediatype == 'image') echo 'required';?>"  style="width:230px" />
				<a href="#" class="screenshot" rel="<?php echo url::base(FALSE) ?>media/serviceimage/<?php echo $mediaValue?>" style="text-decoration:none">(Uploaded Image)</a>
				<br />
				(File Types:jpeg,jpg,gif,png,bmp)
				</div>
				<br />
				<div id="videoblk"  <?php if($mediatype == 'image')echo 'style="display:none"';?>>
				<label>Web Video:</label><br />
				<textarea name="videoUrl" id="videoUrl" style="width:300px;height:60px" <?php if($mediatype == 'video') echo 'required';?> ><?php if($mediatype == 'video')
			{
				$mediaValue = preg_replace('(\r\n|\r|\n)','',$mediaValue);
				echo $mediaValue ;
			}
			?></textarea><br>
				<label>iPad Video:</label><br />
				<input type="text" name="ipadlink"  id="ipadlink" style="width:300px"  value="<?php echo $mediaIpadValue?>" />
				</div>
				<?php }else{?>
				<label>Media Type</label><br />
                <input type="radio" value="image" name="mediatype" class="required radio" checked />
				<label class="radio_label" for="opt1a">Image</label>
                <input type="radio" value="video" name="mediatype"  class="required radio" />
				<label class="radio_label" for="opt1b">Video</label>
				<br />
				<div id="imageblk">
				<label>File</label><br />
			    <input type="file" name="image"  id="image" class="required"  /><br />
				(File Types:jpeg,jpg,gif,png,bmp)
				</div>
				<br />
				<div id="videoblk" style="display:none">
				<label>Web Video:</label><br />
				<textarea name="videoUrl" id="videoUrl" style="width:300px;height:60px" > </textarea>
				<br />
				<label>iPad Video:</label><br />
				<input type="text" name="ipadlink"  id="ipadlink"  style="width:300px"  />
				</div>
				<?php }?>
				<label for="media_description">Media Title</label><br />
				<input type="text" name="title"  id="title" class="required" style="width:300px" value="<?php echo $mediatile?>" />
				<br />
                <label for="media_description">Media Description</label><br />
                <textarea name="detailtext" style="width:300px" ><?php 
	if($mode == 'edit')
	{
		$detailtext= preg_replace('(\r\n|\r|\n)','',$detailtext);
		echo $detailtext;
	}
?></textarea>
			
        	</div><!-- end #popup_moreinfo_content_middle -->
        
        	<div id="popup_moreinfo_content_bottom">
            	<?php 
	if($mode == 'edit')
	{
	?>
		<input type="submit" class="submit_moreinfo" name="update"  value="" />
	<?php
	}else{?>
		<input type="submit" name="submit" value="" class="submit_moreinfo"/>
	<?php }?>
	<input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
        	</div>
        </form>
    </div><!-- end #popup_moreinfo_content -->
</div><!-- end #popup_setting -->
</body>
</html>
