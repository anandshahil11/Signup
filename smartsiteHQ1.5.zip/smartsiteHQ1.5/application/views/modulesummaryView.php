<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [13/April/11]
Page Description:: Module Summary Page 
*********************************************/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Users</title>

<!-- Header -->

<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<?php require('link.php');?>
<script type="text/javascript">

    function summaryDetails(examid)
	{
	    var userid = "<?php echo $userid; ?>";
		$.ajax({
		    type:"GET",
		    url:'<?php echo url::base(FALSE) ?>index.php/user/getModuleDetails?userid='+userid+'&examid='+examid,
		    success:function(data) 
			{
				$('#summary').html(data);
			}
		});
	}
	
	function eachModuleQuesDetials(examid)
	{
	    var userid = "<?php echo $userid;?>";
		$.ajax({
		    type:"GET",
			url:'<?php echo url::base(FALSE) ?>index.php/user/getModuleQuesDetails?userid='+userid+'&examid='+examid,
			success:function(data)
			{
			    $('#popup_summarydetails_content').html(data);
			}
		});
	}
</script>
</head>

<body style="background:#000">

<div id="popup_summarydetails">
	<div id="popup_summarydetails_header">
    	<div id="popup_summarydetails_header_left">
   	    <h1><?php echo $firstname." ".$lastname; ?></h1>
		<?php 
		    $count = count($userExamResult); 
		?>
            <form id="" action="">
            	<select name="" id="">
				    <?php 
					for($ini=0;$ini<$count;$ini++)
					{
                	    echo '<option value="'.$userExamResult[$ini]['exam_id'].'" onclick="summaryDetails(this.value);eachModuleQuesDetials(this.value)">'.$userExamResult[$ini]['examname'].'</option>';
                    }
					?>
                </select>
            </form>
        </div>
        <div id="summary">
			<div id="popup_summarydetails_header_status">
				<p>Status</p>
				<p class="icon_square complete">&nbsp;</p>
			</div>
			
			<div id="popup_summarydetails_header_score">
				<p>Score:</p>
				<p>&nbsp;</p>
			</div>
			
			<div id="popup_summarydetails_header_certificationdate">
				<p>Certification Date</p>
				<p>&nbsp;</p>
			</div>
		</div>
    </div><!-- end #popup_summarydetails_header -->
    
    <div id="popup_summarydetails_title">
    	<h2>Questions</h2>
    </div>
    <div id="popup_summarydetails_content">
        &nbsp;		
    </div><!-- end #popup_summarydetails_content -->
	
    
    <div id="popup_newchecklist_footer">
    	<!--<a href="#" class="summarydetails_close"></a>-->
		<a href="#"><input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
		
    </div>
</div><!-- end #popup_summarydetails -->
</body>
</html>
