<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New wizard</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/basic.css" type="text/css" media="screen"  />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	 $("#setting").validate();

});
</script>
</head>
<body >
<div id="popup_newchecklist" style="height:150px">
<div id="popup_newchecklist_header">
<h1>New Category</h1>
</div><!-- end #popup_newchecklist_header -->
<form id="setting" action="" method="post">
<div id="popup_newchecklist_content" style="height:100px">
<div id="popup_newchecklist_content_left" style="height:100px">
	<label for="name">Name</label><br />
    <input name="name" id="name" class="inputbox required" value="<?php echo $catName ?>"/><br />
</div><!-- end #popup_newchecklist_content_left -->
</div><!-- end #popup_newchecklist_content -->
<div id="popup_newchecklist_footer">
		<input type="submit" class="submit_moreinfo" value="" />
		 <input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
</div><!-- end #popup_newchecklist_footer -->
        </form>
</div><!-- end #popup_newchecklist -->
</body>
</html>