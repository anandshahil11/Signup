<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New Exam Questions</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/basic.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/layout.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" />
<!-- Popup Video -->
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/prettyPhoto.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate2.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/main.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	 $("#viewAll").validate();

});
</script>
<script type="text/javascript">
$(document).ready(function(){
	$('input[name="mediatype"]').click(function()
	{
		if($(this).val()=='image')
		{	
			$('#imageblk').fadeIn();
			$('#videoblk').fadeOut();
			$('#image').attr('class','required text');
			$('#mediatitle').attr('class','required text');
			$('#videoUrl').attr('class','');
		}else
		{
			$('#imageblk').fadeOut();
			$('#videoblk').fadeIn();
			$('#image').attr('class','text');
			$('#mediatitle').attr('class','required text');
			$('#videoUrl').attr('class','required');
			
		}
	}
	);
	 $("#mediaupload").validate();

});
function chkImage()
{
	var imgpath = document.getElementById('image').value;
	if(imgpath != "")
	{
	// code to get File Extension..
		var arr1 = new Array;
		arr1 = imgpath.split("\\");
		var len = arr1.length;
		var img1 = arr1[len-1];
		var filext = img1.substring(img1.lastIndexOf(".")+1);
		filext=filext.toLowerCase();
		// Checking Extension
		if(filext == "jpg" || filext == "jpeg" || filext == "gif" || filext == "bmp" || filext == "png")
		{
		}
	    else
		{
			alert("Invalid File Format Selected");
			return false;
		}
	}
}
</script>
</head>
<body>
<style type="text/css">
.add{
padding:4px 10px !important;
}
.todo input{
width:350px !important;
}
#moreinfo_center_header {
	clear:both;
	margin-bottom:0px; !important;
}
input{
margin:0px;
}
</style>
<div id="popup_editnew_item">
	<div id="popup_editnew_item_header">
    	<h1>Edit/New Questions</h1>
    </div>
<form id="viewAll" name ="viewAll"  method="post" ENCTYPE = "multipart/form-data" onsubmit="return chkImage()">
<div id="popup_editnew_item_content">
<table>
<tr>
<td>
            <?php
		$arrType=array(
		"Multiple Selection"
		);
		?>
		<select name="tempType" id="tempType" class="required" onchange="changeForm(this)"  >
		<?php
		foreach($arrType as $row)
		{
			echo '<option value="'.$row.'"';
			echo ' selected ';
			echo '>'.$row.'</option>';
		}
		?>
		</select>
</td>
<td>&nbsp;&nbsp;&nbsp;
            <select name="Cat" id="Cat" class="required">
		<option value="">Select Category</option>
		<?php
		foreach($cat as $row)
		{
			echo '<option value="'.$row->category_id.'"';
			if($row->category_id==$itemCat)
			echo ' selected ';
			echo '>'.$row->category_name.'</option>';
		}
		?>
		</select>
</td>
</tr>
</table>
		
            	<input type="text" name="title" id="title" class="textbox required" value="<?php echo $itemTitle?>" /><br />
           <input type="text" name="desc" id="desc" class="textbox" value="<?php echo $itemDesc?>" /><br />
		<table class="pro_series_wizard" style="width:75%">
		 <tr>
		 <td>*select all correct answers
		<ul class="todoList" id="todoList1" >
				<?php
				$count=is_object($arrOptions)?$arrOptions->count():0;
				if($count==0)
				{
					$listnum=1;
					echo '<li id="todo-1" class="todo"><input type="checkbox" id="check-1"  class="exambox" style="width:0px !important;"/><div class="text"><a href="#" class="add" id="addButton1"></a><a href="#" class="remove" id="deleteButton1"></a><a href="#" class="edit save">Option</a></div></li>';
				}else
				{
					$listnum=0;
					foreach($arrOptions as $row)
					{
						$listnum++;
						echo '<li id="todo-'.$row->answer_id.'" class="todo"><input type="checkbox" id="check-'.$row->answer_id .'"';
						if($row->correct_answer==1)
						echo ' checked ';
						echo 'class="exambox" style="width:0px !important;"/><div class="text"><a href="#" class="add" id="addButton1"></a><a href="#" class="remove" id="deleteButton1"></a><a href="#" class="edit save">'.$row->answer_text.'</a></div></li>';
					}
				$listnum=$row->answer_id ;
				}
				?>
			</ul>
			<script language="javascript">
			var listnum=<?php echo $listnum?>;
			</script>
			<input type="hidden" name="options" id="options" />
		</td>
		</tr>
		</table>
<table class="options_select_table_checkboxes">
                <tr>
                	<td><br/><input type="checkbox" class="checkbox" name="mandatory" value="1" <?php if($itemNext==1) echo 'checked' ?> />
            <label for="1b">Mandatory Question</label></td>
                </tr>
            </table>
      </div><!-- /#popup_editnew_item_content -->
        
  <div id="popup_editnew_item_moreinfo">
        	<div id="popup_editnew_item_moreinfo_left">
            	<h2>More Info</h2>
            </div><!-- /#popup_editnew_item_moreinfo_left -->
            
            <div id="popup_editnew_item_moreinfo_center">
            	<div id="moreinfo_center_header">
                	<p>Select type of Media:</p>
                    <input type="radio" value="image" name="mediatype" class="radio text"  <?php if($mediatype == 'image' ) echo 'checked';?> />
                    <label for="2a">Image</label>
                    <input type="radio" value="video" name="mediatype"  class="radio text" <?php if($mediatype == 'video') echo 'checked';?>  />
                    <label for="2b">Video</label>
                </div>
                
                <div id="imageblk"  <?php if($mediatype == 'video')echo 'style="display:none"';?> >
				<input type="file" name="image"  id="image" class="<?php if($mediatype == 'image' && $videoUrl=='' ) echo 'required';?> text"  />
				<br />
				(File Types:jpeg,jpg,gif,png,bmp)<?php if($mediatype=='image') {?>
				<a href="#" class="screenshot" rel="<?php echo url::base(FALSE) ?>media/serviceimage/<?php echo $videoUrl?>" style="text-decoration:none">(Uploaded Image)</a>
				<?php }?>
				</div>
				<div  id="videoblk"  <?php if($mediatype == 'image' || $mediatype == '' )echo 'style="display:none"';?> >
				<textarea name="videoUrl" id="videoUrl" style="width:285px;height:40px" ><?php echo $videoUrl ?></textarea>
				 <input type="text" name="ipadlink"  id="ipadlink" class="textbox"  value="<?php echo $ipadlink ?>" />
				</div>
               <input type="text" name="mediatitle"  id="mediatitle" class="textbox" value="<?php echo $mediatitle ?>" />
            </div><!-- /#popup_editnew_item_moreinfo_center -->
            
            <div id="popup_editnew_item_moreinfo_right">
				<textarea name="mediadetailtext" style="width:300px" ><?php echo $mediadetailtext ?></textarea>
      </div><!-- /#popup_editnew_item_moreinfo_right -->
        </div><!-- /#popup_editnew_item_moreinfo -->
        
        <div id="popup_editnew_item_footer">
        	<input type="submit" id="submitbut" class="submit_submittopool" value="" />
			<input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
        </div><!-- /#popup_editnew_item_footer -->
    </form>
</div><!-- /#popup_editnew_item -->
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script3.js"></script>
</body>
</html>
