<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New checklist</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/basic.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/layout.css" />
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" />
<!-- Popup Video -->
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/prettyPhoto.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate2.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/main.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	 $("#viewAll").validate();

});
</script>
<script type="text/javascript">
$(document).ready(function(){
	$('.reqopt').click(function() {
		if($(this).val()=='fraction(.2)')
		$('#decimals').attr('class','required text');
		else
		{
			$('#decimals').val('');
			$('#decimals').attr('class','text');
		}
	});
	$('input[name="mediatype"]').click(function()
	{
		if($(this).val()=='image')
		{	
			$('#imageblk').fadeIn();
			$('#videoblk').fadeOut();
			$('#image').attr('class','required text');
			$('#mediatitle').attr('class','required text');
			$('#videoUrl').attr('class','');
		}else
		{
			$('#imageblk').fadeOut();
			$('#videoblk').fadeIn();
			$('#image').attr('class','text');
			$('#mediatitle').attr('class','required text');
			$('#videoUrl').attr('class','required');
			
		}
	}
	);
	 $("#mediaupload").validate();

});
function chkImage()
{
	var imgpath = document.getElementById('image').value;
	if(imgpath != "")
	{
	// code to get File Extension..
		var arr1 = new Array;
		arr1 = imgpath.split("\\");
		var len = arr1.length;
		var img1 = arr1[len-1];
		var filext = img1.substring(img1.lastIndexOf(".")+1);
		filext=filext.toLowerCase();
		// Checking Extension
		if(filext == "jpg" || filext == "jpeg" || filext == "gif" || filext == "bmp" || filext == "png")
		{
		}
	    else
		{
			alert("Invalid File Format Selected");
			return false;
		}
	}
}
function minMaxMan(value)
{
 if(value==false)
 {
	$('#min').attr('class',"textbox number");
	$('#max').attr('class',"textbox number");
	$('#fraction1').attr('disabled',false);
	$('#fraction2').attr('disabled',false);
 }
 else
 {
	$('#min').attr('class',"textbox required number");
	$('#max').attr('class',"textbox required number");
	$('#fraction1').attr('disabled',true);
	$('#fraction2').attr('disabled',true);
 }
}
function changeBox()
{
	format=$('#format').val();
	if(format=='Fraction')
	{
		$('#decimalLabel').show();
		$('#decimals').show();
		$('#currencyLab').hide();
		$('#currency').hide();
		$('#currency').val('');
		$('#popup_editnew_item_option_fouroffour').show();
		$('#fractionOption').show(); 
		$('.reqopt').attr('class',"radio required");
	}
	else if(format=='Currency')
	{
		$('#decimalLabel').hide();
		$('#decimals').hide();
		$('#currencyLab').show();
		$('#decimals').val('');
		$('#currency').show();
		$('#popup_editnew_item_option_fouroffour').hide();
		$('#fractionOption').hide();
		$('.reqopt').attr('class',"radio");
		
	}else
	{
		$('#decimalLabel').hide();
		$('#decimals').hide();
		$('#decimals').val('');
		$('#currency').val('');
		$('#currencyLab').hide();
		$('#currency').hide();
		$('#popup_editnew_item_option_fouroffour').hide();
		$('#fractionOption').hide();
		$('.reqopt').attr('class',"radio");
	}
}

</script>
</head>
<body>
<style type="text/css">
.add{
padding:4px 10px !important;
}
.todo input{
width:350px !important;
}
#moreinfo_center_header {
	clear:both;
	margin-bottom:0px; !important;
}
input{
margin:0px;
}
</style>
<div id="popup_editnew_item">
	<div id="popup_editnew_item_header">
    	<h1>Edit/New Item</h1>
    </div>
<form id="viewAll" name ="viewAll"  method="post" ENCTYPE = "multipart/form-data" onsubmit="return chkImage()">
<div id="popup_editnew_item_content">
<table>
<tr>
<td>
            <?php
		$arrType=array(
		"Number",
		"Date",
		"Checkbox Only",
		"Multiple Selection",
		"Binary",
		"Text Entry",
		"User Data",
		"Calculation",
		"Summary"
		);
		?>
		<select name="tempType" id="tempType" class="required" onchange="changeForm(this)"  >
		<option value="">Select</option>
		<?php
		foreach($arrType as $row)
		{
			echo '<option value="'.$row.'"';
			if($row==$type)
			echo ' selected ';
			echo '>'.$row.'</option>';
		}
		?>
		</select>
</td>
<td>&nbsp;&nbsp;&nbsp;
            <select name="Cat" id="Cat" class="required">
		<option value="">Select Category</option>
		<?php
		foreach($cat as $row)
		{
			echo '<option value="'.$row->category_id.'"';
			if($row->category_id==$itemCat)
			echo ' selected ';
			echo '>'.$row->category_name.'</option>';
		}
		?>
		</select>
</td>
</tr>
</table>
		
            	<input type="text" name="title" id="title" class="textbox required" value="<?php echo $itemTitle?>" /><br />
           <input type="text" name="desc" id="desc" class="textbox" value="<?php echo $itemDesc?>" /><br />
        
            <?php
		if($type=='Number')
		{
		?>
            <div id="popup_editnew_item_options">
            	<div id="popup_editnew_item_option_oneoffour">
                	<p>Entry Format</p>
                    <div class="option_box">
                    	<table>
                        	<tr>
                            	<td>
                        			<input type="radio" class="text required" value="text" name="entryformat" <?php if($entryFormat=='text') echo 'checked'?> onclick="minMaxMan(false)"  />
                        		</td>
                                <td>
                        			<input value="" class="adjust_textbox" readonly />
                        		</td>
							</tr>
                            <tr>
                            	<td>
                                	<input type="radio" class="text required" value="slider" name="entryformat" <?php if($entryFormat=='slider') echo 'checked'?> onclick="minMaxMan(true)" />
                                </td>
                                <td>
                                	<div class="slider_area"> <img src="<?php echo url::base(FALSE) ?>media/img/icon_slider.png" alt="slider" /></div>
                                </td>
                            </tr>
                        </table>
                    </div><!-- /.option_box -->
                </div><!-- /#popup_editnew_item_option_oneoffour -->
                
                <div id="popup_editnew_item_option_twooffour">
                	<p>Range</p>
                    <div class="option_box">
                    	<table>
                        	<tr>
                            	<td><label for="min" />Min</label></td>
                                <td><input type="text" name="min" id="min" class="textbox <?php if($entryFormat=='slider') echo 'required'?> number" value="<?php echo $Min ?>" /></td>
                            </tr>
                            <tr>
                            	<td><label for="max" />Max</label></td>
                                <td><input type="text" name="max" id="max" class="textbox <?php if($entryFormat=='slider') echo 'required'?> number" value="<?php echo $Max ?>" /></td>
                            </tr>
                        </table>
                    </div><!-- /.option_box -->
            </div><!-- /#popup_editnew_item_option_twooffour -->
                <div id="popup_editnew_item_option_threeoffour">
                	<p>&nbsp;</p>
                  <?php
		$arrFormat=array(
		"General",
		"Currency",
		"Degrees",
		"Fraction",
		"Percentage"
		);
		?>
		<select name="format" id="format" class="text required" onchange="changeBox()">
		<option value="">Select Format</option>
		<?php
		foreach($arrFormat as $row)
		{
			echo '<option value="'.$row.'"';
			if($row==$format)
			echo ' selected ';
			echo '>'.$row.'</option>';
		}
		?>
		</select><br />
                    
                    <label for="decimals" id="decimalLabel" <?php if($format!='Fraction')echo 'style="display:none"' ?> />Decimals</label> 	<select name="decimals" id="decimals" class="text <?php if($fractionFormat=='fraction(.2)') echo 'required'?>" <?php if($format!='Fraction')echo 'style="display:none"' ?> >
		<option value="">Select</option>
		<?php
		for($i=1;$i<=5;$i++)
		{
			echo '<option value="'.$i.'"';
			if($i==$Decimals)
			echo ' selected ';
			echo '>'.$i.'</option>';
		}
		?>
		</select>
		 <label for="currency" id="currencyLab" <?php if($format!='Currency')echo 'style="display:none"' ?> />Currency:</label> 	<select name="currency" id="currency" class="text <?php if($format=='Currency')echo 'required' ?>"  <?php if($format!='Currency')echo 'style="display:none"' ?> >
		<option value="">Select</option>
		<?php
		$curr=array("Dollar","Euro","Yen","Pound");
		$selCur='';
		foreach($curr as $cur)
		{
			echo '<option value="'.$cur.'"';
			if($cur==$curFormat)
			echo ' selected ';
			echo '>'.$cur.'</option>';
		}
		?>
		</select>
                </div><!-- /#popup_editnew_item_option_fouroffour -->
			
                <div id="popup_editnew_item_option_fouroffour" <?php if($format!='Fraction')echo 'style="display:none"' ?>>
                	<p>Fraction Format</p>
                    <div class="option_box" id="fractionOption">
                        <table class="radio_layout_table">
                                <tr>
                                    <td>
                                       <input type="radio" class="radio reqopt <?php if($format=='Fraction')echo 'required' ?>" value="fraction(1/5)"  id="fraction1" name="fraction" <?php if($fractionFormat=='fraction(1/5)') echo 'checked'?> />
                                    </td>
                                    <td>
                                        <label for="3a">1/5</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                       <input type="radio" class="radio reqopt <?php if($format=='Fraction')echo 'required' ?>" value="fraction(1/5th)"id="fraction2"  name="fraction" <?php if($fractionFormat=='fraction(1/5th)') echo 'checked'?> />
                                    </td>
                                    <td>
                                        <label for="3b">1/5th</label>
                                    </td>
                                </tr>
                                <tr>
								   <td>
                                        <input type="radio" class="radio reqopt <?php if($format=='Fraction')echo 'required' ?>" value="fraction(.2)" id="fraction3" name="fraction" <?php if($fractionFormat=='fraction(.2)') echo 'checked'?> />
                                 
                                    </td>
                                    <td>
                                        <label for="3c">0.2</label>
                                    </td>
                                </tr>
                            </table>
                        </div><!-- /.option_box -->
                </div><!-- /#popup_editnew_item_option_threeoffour -->
                         </div><!-- /#popup_editnew_item_options -->
   
                
            
		<?php
		}
		?> 
		
		<?php
		if($type=='Multiple Selection')
		{
		?>
		<table class="pro_series_wizard" style="width:75%">
		 <tr>
		 <td>
		<ul class="todoList" id="todoList1" >
				<?php
				$count=is_object($arrOptions)?$arrOptions->count():0;
				if($count==0)
				{
					$listnum=1;
					echo '<li id="todo-1" class="todo"><div class="text"><a href="#" class="add" id="addButton1"></a><a href="#" class="remove" id="deleteButton1"></a><a href="#" class="edit save">Option</a></div></li>';
				}else
				{
					$listnum=0;
					foreach($arrOptions as $row)
					{
						$listnum++;
						echo '<li id="todo-'.$listnum.'" class="todo"><div class="text"><a href="#" class="add" id="addButton1"></a><a href="#" class="remove" id="deleteButton1"></a><a href="#" class="edit save">'.$row->item_options_value.'</a></div></li>';
					}
				$listnum=count($arrOptions);
				}
				?>
			</ul>
			<script language="javascript">
			var listnum=<?php echo $listnum?>;
			</script>
			<input type="hidden" name="options" id="options" />
		</td>
		</tr>
		</table>
		<?php
		}?>
		<?php
		if($type=='Binary')
		{
		?>
			<table width="100px">
			<tr>
			<td >Unselected<input type="text" name="unselectedText"  id="uselected"  id="type" class="text required" value="<?php echo $unselectedEntry ?>" style="margin:0px" /></td>
			</tr>
			<tr>
			<td >Selected <input type="text" name="selectedText"  id="selected"  id="type" class="text required" value="<?php echo $selectedEntry ?>" style="margin:0px" /></td>
			</tr>
			</table>
		<?php }?>
		<?php
		if($type=='Date')
		{
		?>
			 <div id="popup_editnew_item_options_lesspad">
   	  		  <div id="popup_editnew_item_option_twosmall_one">
                <p>Auto Entry</p>
                    <div class="option_box_large">
                    	<table class="radio_layout_table">
                            <tr>
                                <td>
                                    <input type="radio" class="radio required" value="autoEntry" name="dateEntry" <?php if($dateAutoEntry=='autoEntry') echo 'checked'?> />
                                </td>
                                <td>
                                    <label for="3a">Auto Entry Only</label>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                   <input type="radio" class="radio required" value="autoEntryFirst" name="dateEntry" <?php if($dateAutoEntry=='autoEntryFirst') echo 'checked'?>  />
                                </td>
                                <td>
                                    <label for="3b">Auto Entry First</label>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                   <input type="radio" class="radio required" value="Manual" name="dateEntry" <?php if($dateAutoEntry=='Manual') echo 'checked'?>   />
                                </td>
                                <td>
                                    <label for="3c">Manual Entry Only</label>
                                </td>
                            </tr>
                        </table>
                  </div><!-- /.option_box -->
                </div><!-- /#popup_editnew_item_option_twosmall_one -->
                
                <div id="popup_editnew_item_option_twosmall_two">
                <p>Date Format</p>
                    <div class="option_box_large">
                    	<table class="radio_layout_table">
                            <tr>
                                <td>
                                   <input type="radio" class="radio" value="format1(january 31st,2011)" name="dateFormat" <?php if($dateFormat=='format1(january 31st,2011)') echo 'checked'?> />
                                </td>
                                <td>
                                    <label for="4a">January 31st, 2011</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="radio" class="radio" value="format2(1/31/2011)" name="dateFormat" <?php if($dateFormat=='format2(1/31/2011)') echo 'checked'?> />
                                </td>
                                <td>
                                    <label for="4b">1/31/2011</label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                   <input type="radio" class="raio" value="format3(31/1/2011)" name="dateFormat" <?php if($dateFormat=='format3(31/1/2011)') echo 'checked'?> />
                                </td>
                                <td>
                                    <label for="4c">31/1/2001</label>
                                </td>
                            </tr>
                        </table>
                  </div><!-- /.option_box -->
                </div><!-- /#popup_editnew_item_option_twosmall_two -->
          </div><!-- /#popup_editnew_item_options_lesspad -->
		<?php }?>
		<?php
		if($type=='User Data')
		{
		?>
			 <div id="popup_editnew_item_options_lesspad">
   	  		  <div id="popup_editnew_item_option_threeequal_left">
              	<?php
		$arrFormat=array(
		"Name",
		"Country"
		);
		?>
		<select name="profileField" id="profileField" class="text required">
		<option value="">Select Field</option>
		<?php
		foreach($arrFormat as $row)
		{
			echo '<option value="'.$row.'"';
			if($row==$profileType)
			echo ' selected ';
			echo '>'.$row.'</option>';
		}
		?>
                </select>
              </div><!-- /#popup_editnew_item_option_threeequal_left -->
              
              <div id="popup_editnew_item_option_threeequal_center">
              	<p>Entry Type</p>
                <div class="option_box_small">
                    <table class="radio_layout_table">
                        <tr>
                            <td>
                               <input type="radio"class="radio required" value="AutoEntry" name="entryType" <?php if($profileEntryType=='AutoEntry') echo 'checked'?> />
                            </td>
                            <td>
                                <label for="3a">Auto entry based on log-in</label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                               <input type="radio"class="radio required" value="manual" name="entryType" <?php if($profileEntryType=='manual') echo 'checked'?> />
                            </td>
                            <td>
                                <label for="3b">Manual entry</label>
                            </td>
                        </tr>
                    </table>
                  </div><!-- /.option_box -->
              </div><!-- /#popup_editnew_item_option_threeequal_center -->
              
              <div id="popup_editnew_item_option_threeequal_right" style="width:200px">
              	<p>Name Format</p>
                <div class="option_box">
                    <table class="radio_layout_table">
                        <tr>
                            <td>
                               <input type="radio" class="radio" value="firstname,Lastname" name="nameformat" <?php if($profileNameFormat=='firstname,Lastname') echo 'checked'?> />
                            </td>
                            <td>
                                <label for="4a">First name, Last name</label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                               <input type="radio"class="radio" value="lastname,firstname" name="nameformat" <?php if($profileNameFormat=='lastname,firstname') echo 'checked'?> />
                            </td>
                            <td>
                                <label for="4b">Last name, First name</label>
                            </td>
                        </tr>
                        <tr>
                            <td>
                               <input type="radio"class="radio required" value="lastname" name="nameformat" <?php if($profileNameFormat=='lastname') echo 'checked'?> />
                            </td>
                            <td>
                                <label for="4c">Last name only</label>
                            </td>
                        </tr>
                    </table>
                  </div><!-- /.option_box -->
              </div><!-- /#popup_editnew_item_option_threeequal_right -->
         	</div><!-- /#popup_editnew_item_options_lesspad -->
            
		<?php }?>
		<?php
		if($type=='Text Entry')
		{
		?>
			 <div id="popup_editnew_item_options_lesspad">
            	<div id="popup_editnew_item_option_smalloftwo">
                	<p>Total number of characters</p>
					<input type="text" name="maxchar"  id="maxchar"  id="type" class="adjust_textbox" value="<?php echo $totalChar ?>" />
                </div><!-- /#popup_editnew_item_option_smalloftwo -->
                
                <div id="popup_editnew_item_option_largeoftwo">
                	<div class="clearfix">
                        <div id="popup_editnew_item_option_largeoftwo_headingleft">
                            <input type="checkbox" class="checkbox" value="evalution" name="evalution" <?php if($useSelectionList) echo 'checked' ?> />

                            <label for="2a">Use Value List</label>
                        </div>
                    </div><!-- /#popup_editnew_item_option_largeoftwo_heading -->
                    
                    <div class="option_box">
						<table class="pro_series_wizard issue" style="width:100%">
						<tr>
						<td class="tdall">
                    	<ul class="todoList" id="todoList2" >
				<?php
				$count=is_object($arrOptions)?$arrOptions->count():0;
				if($count==0)
				{
					$listnum=1;
					echo '<li id="todo-1" class="todo"><div class="text"><a href="#" class="add" id="addButton2"></a><a href="#" class="remove" id="deleteButton2"></a><a href="#" class="edit save">Option</a></div></li>';
				}else
				{
					$listnum=0;
					foreach($arrOptions as $row)
					{
						$listnum++;
						echo '<li id="todo-'.$listnum.'" class="todo"><div class="text"><a href="#" class="add" id="addButton2"></a><a href="#" class="remove" id="deleteButton2"></a><a href="#" class="edit save">'.$row->item_options_value.'</a></div></li>';
					}
				$listnum=count($arrOptions);
				}
				?>
			</ul>
			</td>
			</tr>
			</table>
			<script language="javascript">
			var listnum=<?php echo $listnum?>;
			</script>
			<input type="hidden" name="options" id="options" />
                    </div><!-- /.option_box -->
                </div><!-- /#popup_editnew_item_option_largeoftwo -->
            </div><!-- /#popup_editnew_item_options -->
            
		<?php }?>
		<?php
		if($type=='Calculation')
		{
		?>
		<div id="popup_editnew_item_options_lesspad">
       	  <div id="popup_editnew_item_option_twoequal_left" class="equals">
                	<div id="twoequal_left_dropdowns">
                    	<select name="Field1" id="Field1"  class="text required">
				<option value="">Selected Numerical Title/Input Question</option>
				<?php
				foreach($CLitem as $row)
				{
					echo '<option value="'.$row->items_id.'"';
					if($row->items_id==$quest1)
					echo ' selected ';
					echo '>'.$row->items_title.'</option>';
				}
				?>
				</select>
                 <select name="Field2" id="Field2"  class="text required">
				<option value="">Selected Numerical Title/Input Question</option>
				<?php
				foreach($CLitem as $row)
				{
					echo '<option value="'.$row->items_id.'"';
					if($row->items_id==$quest2)
					echo ' selected ';
					echo '>'.$row->items_title.'</option>';
				}
				?>
				</select>
                    </div><!-- /#twoequal_left_dropdowns -->
                </div><!-- /#popup_editnew_item_option_twoequal_left -->
                
              <div id="popup_editnew_item_option_twoequal_right" style="width:320px">
       	  <?php
				$arrOperator=array(
				"Plus",
				"Minus",
				"Mulitple  By",
				"Divide By"
				);
				?>
				<select name="Operator" id="Operator" class="text required">
				<option value="">Select Operator</option>
				<?php
				foreach($arrOperator as $row)
				{
					echo '<option value="'.$row.'"';
					if($row==$math)
					echo ' selected ';
					echo '>'.$row.'</option>';
				}
				?>
				</select>
                </div><!-- /#popup_editnew_item_option_twoequal_right -->
            </div><!-- /#popup_editnew_item_options_lesspad -->
		<?php }?>
		<?php
		if($type=='Summary')
		{
		?>
		 <br/>
			<table style="width:500px;" class="pro_series_wizard issue">
			<tr>
				<td class="tdall" style="vertical-align:top">
					<div id="popup_editnew_item_option_summaryleft">
				<?php
				$arrOperator=array(
				"Total Of",
				"Average Of",
				"Count Of",
				"Minimum",
				"Maximum",
				"Standard Deviation"
				);
				?>
				<select name="Operator" id="Operator" class="text required">
				<option value="">Select Summary</option>
				<?php
				foreach($arrOperator as $row)
				{
					echo '<option value="'.$row.'"';
					if($row==$summary)
					echo ' selected ';
					echo '>'.$row.'</option>';
				}
				?>
				</option>
				</div>
			</td>
			<td class="tdall" style="vertical-align:top">
			  <ul id="todoList3" >
			  <?php
			  $count=is_object($arrFields)?$arrFields->count():0;
			  if($count==0)
			  {
			  ?>
			   <li>
			   <div id="popup_editnew_item_option_summaryright">
			  <select name="Field[]" id="Field"  class="text required">
				<option value="">select Numerical Title/Question</option>
				<?php
				foreach($CLitem as $row2)
				{
					echo '<option value="'.$row2->items_id.'"';
					echo '>'.$row2->items_title.'</option>';
				}
				?>
				</select>
				<img src="<?php echo url::base(FALSE) ?>media/img/icon_add.png" id="addbutton3"/>
				<img src="<?php echo url::base(FALSE) ?>media/img/icon_remove.png" id="deletebutton3"/>
				</div></li>
			  <?php
			  }
			  foreach($arrFields as $row1)
			  {
			  ?>
			  <li style="width:250px">
			  <select name="Field[]" id="Field"  class="text required">
				<option value="">select Field</option>
				<?php
				foreach($CLitem as $row2)
				{
					echo '<option value="'.$row2->items_id.'"';
					if($row2->items_id==$row1->item_summary_checklist_id)
					echo ' selected ';
					echo '>'.$row2->items_title.'</option>';
				}
				?>
				</select>
				<img src="<?php echo url::base(FALSE) ?>media/img/icon_add.png" id="addbutton3"/>
				<img src="<?php echo url::base(FALSE) ?>media/img/icon_remove.png" id="deletebutton3"/>
				</div></li>
				<?php
				}
				?>
			</ul>
		</td>
			</td>
			</tr>
			</table>
			<?php }?>
<table class="options_select_table_checkboxes">
		<?php
		if($type=='Multiple Selection')
		{
		?>
		<tr>
             <td><input type="checkbox" class="checkbox" name="optext" value="1" <?php if($optionalText=='1') echo 'checked'?> />
            <label for="1b">Provide optional text entry field</label></td>
                </tr>
		<?php
		}?>
                <tr>
                	<td> <input type="checkbox" class="checkbox" name="nextline" value="1" <?php if($itemNext==1) echo 'checked' ?> />
            <label for="1b">Require to proceed to next item</label></td>
                </tr>
                <tr>
                	<td><input type="checkbox" class="checkbox" name="submitreq" value="1" <?php if($itemSubmit==1) echo 'checked' ?> />
            <label for="1c">Require to submit</label></td>
                </tr>
            </table>
      </div><!-- /#popup_editnew_item_content -->
        
  <div id="popup_editnew_item_moreinfo">
        	<div id="popup_editnew_item_moreinfo_left">
            	<h2>More Info</h2>
            </div><!-- /#popup_editnew_item_moreinfo_left -->
            
            <div id="popup_editnew_item_moreinfo_center">
            	<div id="moreinfo_center_header">
                	<p>Select type of Media:</p>
                    <input type="radio" value="image" name="mediatype" class="radio text"  <?php if($mediatype == 'image' ) echo 'checked';?> />
                    <label for="2a">Image</label>
                    <input type="radio" value="video" name="mediatype"  class="radio text" <?php if($mediatype == 'video') echo 'checked';?>  />
                    <label for="2b">Video</label>
                </div>
                
                <div id="imageblk"  <?php if($mediatype == 'video')echo 'style="display:none"';?> >
				<input type="file" name="image"  id="image" class="<?php if($mediatype == 'image' && $videoUrl=='' ) echo 'required';?> text"  />
				<br />
				(File Types:jpeg,jpg,gif,png,bmp)<?php if($mediatype=='image') {?>
				<a href="#" class="screenshot" rel="<?php echo url::base(FALSE) ?>media/serviceimage/<?php echo $videoUrl?>" style="text-decoration:none">(Uploaded Image)</a>
				<?php }?>
				</div>
				<div  id="videoblk"  <?php if($mediatype == 'image' || $mediatype == '' )echo 'style="display:none"';?> >
				<textarea name="videoUrl" id="videoUrl" style="width:285px;height:40px" ><?php echo $videoUrl ?></textarea>
				 <input type="text" name="ipadlink"  id="ipadlink" class="textbox"  value="<?php echo $ipadlink ?>" />
				</div>
               <input type="text" name="mediatitle"  id="mediatitle" class="textbox" value="<?php echo $mediatitle ?>" />
            </div><!-- /#popup_editnew_item_moreinfo_center -->
            
            <div id="popup_editnew_item_moreinfo_right">
				<textarea name="mediadetailtext" style="width:300px" ><?php echo $mediadetailtext ?></textarea>
      </div><!-- /#popup_editnew_item_moreinfo_right -->
        </div><!-- /#popup_editnew_item_moreinfo -->
        
        <div id="popup_editnew_item_footer">
        	<input type="submit" id="submitbut" class="submit_submittopool" value="" />
			<input type="button"  class="cancel" onclick="parent.tb_remove()" ></a>
        </div><!-- /#popup_editnew_item_footer -->
    </form>
</div><!-- /#popup_editnew_item -->
<script language="javascript">
var imgUrl='<?php echo url::base(FALSE) ?>media/images/';
function changeForm(obj)
{
	var url='<?php echo url::base(FALSE) ?>index.php/checklist/newCheckList?type='+obj.value+'&id=<?php echo $checklistId?>&itemId=<?php echo $itemId?>';
	window.location.href=url;
}
</script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script2.js"></script>
</body>
</html>
