<script language="javascript">
    function openPopup(url)
	{
	    window.open(url,'welcome','width=500,height=400,menubar=no,status=no,location=no,toolbar=no,scrollbars=no,top=100');

    }
	tb_init();
	function tb_init(){
	
		$(document).click(function(e){
		e = e || window.event;
		var el = e.target || e.scrElement || null;
		if(el && el.parentNode && !el.className || !/thickbox/.test(el.className))
		el = el.parentNode;
		if(!el || !el.className || !/thickbox/.test(el.className))
		return;
		var t = el.title || el.name || null;
		var a = el.href || el.alt;
		var g = el.rel || false;
		tb_show(t,a,g);
		el.blur();
		return false;
		});
	};
</script>
<style type="text/css">
    #lastlogin_header 
	{
		height: 18px;
		width: 100%;
		background: #666;
		color: #fff;
		border-bottom: #000 solid 0.5px;
		padding: 15px 0 10px 10px;
    }
</style>

<div class="name"><h2 style="color:#fff; "><?php echo wordwrap($firstname."  ".$lastname,16,"<br/>\n",true); ?></h2><br>
</a>
</div>
<div class="exam">
<div id="lastlogin_header">
<p><strong>Total Logins&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span class="white" ><?php echo $userLoginNum;?></span></strong></p>
</div>
<div id="lastlogin_header">
<p><strong>Last Login&nbsp;&nbsp;&nbsp;&nbsp <span class="white" ><?php 
													if($userLastlogin=='')
													{
														echo '-';
													}else
													{
														echo date("m/d/Y",$userLastlogin);
													}	
											?> 
                                            </span></strong></p>
</div>											


<?php
	$count = count($userExamResult);
	if($count>0)
	{
?>
	<a href="<?php echo url::base(FALSE)."index.php/user/moduleSummary?userid=$userid&keepThis=true&TB_iframe=false&height=500&width=780"; ?>"  
	   style="text-decoration:none;color:black;" class="thickbox summary" >
	<img src="<?php echo url::base(FALSE) ?>media/img/moduleSummary.png" alt='Module Summary'>
    </a>	
	
<?php
    }else
	{
?>
	<img src="<?php echo url::base(FALSE) ?>media/img/moduleSummary.png" alt='Module Summary'>
<?php	
	}
    for($i=0;$i<$count;$i++)
	{			
        if($userExamResult[$i]['exam_id']!='')
		{
?>	
<p><strong><span class="white" >&nbsp;&nbsp;<?php echo $userExamResult[$i]['examname']; ?><br/></span></strong></p>
<p>&nbsp;&nbsp;&nbsp;
			<?php 
			if(strtolower($userExamResult[$i]['result'])==='certified')
			{
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/pass.png" alt="certified">
			<?php
			}elseif(strtolower($userExamResult[$i]['result'])==='failed')
			{
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/fail.png" alt="failed">
			<?php
			}else
			{
			?>
			<img src="<?php echo url::base(FALSE) ?>media/img/incomplete.png" alt="incomplete">
			<?php
			}
			?>
<span class="white" style="font-size:10pt;"><?php echo $userExamResult[$i]['result']; ?></span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span class="white" style="font-size:10pt;"><?php echo date("m/d/Y",strtotime($userExamResult[$i]['date'])); ?></span>
</p>
<p><span class="white" style="font-size:10pt;">&nbsp;&nbsp;&nbsp;scored:<?php echo $userExamResult[$i]['percentage']; ?>%<br/></span></p>

			
<?php                                        												
        }
    }	
?>
</div>
<?php	
	
/*	}else
	{ 
		echo $userData;
	}
*/
?>
