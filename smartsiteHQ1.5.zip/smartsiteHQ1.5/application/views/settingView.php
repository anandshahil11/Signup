<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>New wizard</title>
<!-- Header -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content=" " />
<meta name="keywords" content=" " />
<meta name="Author" content=" " />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/basic.css" type="text/css" media="screen"  />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/prettyPhoto.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript">
function setval()
{ 
	document.setting.selectedgroups.value = '';
	for (i=0; i<document.setting.checkgroup.length; i++)
	{
		if (document.setting.checkgroup[i].checked==true) {
			if(document.setting.checkgroup[i].value != (document.setting.selectedgroups.value +":"))
				document.setting.selectedgroups.value += document.setting.checkgroup[i].value + ":";
			
		}
	}

	
}

function setvalinfomedia()
{
	if (document.setting.showicon.checked == true)
		{
			document.setting.infomedia.value = 1;
		}
	else 
		document.setting.infomedia.value = 0;
		document.setting.showicon.value=document.setting.infomedia.value;
}

$(document).ready(function(){
	$('input[type= "submit"]').click(function()
	{
		if($(this).val()=='Save')
		{	
			$('#modulename').fadeIn();
			$('#modulename').attr('class','required');
			$('#checkgroup').fadeIn();
			$('#checkgroup').attr('class','required');
		}	
	}
	);
	
	$('#update').click(function()
	{
		if($(this).val()=='Save')
		{	
			$('#modulename').fadeIn();
			$('#modulename').attr('class','required');
			$('#checkgroup').fadeIn();
			$('#checkgroup').attr('class','required');
		}	
	}
	);
	 $("#setting").validate();

});

</script>
</head>
<body>
<div id="popup_header">
<h1>New Wizard</h1>
</div><!-- end #popup_newchecklist_header -->
<form name='setting' id='setting' action='' method='post' enctype='multipart/form-data'>
<input type="hidden"  id="selectedgroups" name="selectedgroups"  value=""/>
<input type="hidden"  id="infomedia" name="infomedia" value=""/>
 <table  style="margin:0 auto;">
<tr >
<td style="padding:10px;width:120px"><b>Module Name:</b></td>
<td style="width:120px"><input type="text" name="modulename" id="modulename" style="width:300px;margin-left:0px" value='<?php if($_GET['id'] != 'setting')echo $modulename;?>' /></td>
</tr>
<tr>
<td style="padding:10px"><b>Select Group:</b></td>
<td>
                            <div class="popup_newuser_checklist_wrapper_bottom">
                            <table class="new_user_table">
                                <?php 
	 if($_GET['id']=='setting')
	 {
		$i=0;
		 foreach($groups as $row)
		 {	
			$i++;
			if($i%2==0)
			$class="odd";
			else
			$class="even";
		 	echo "<tr ><td class='".$class."'>".$row->group_name ."</td>";
			echo "<td class='".$class."' ><input style='margin:0px'  type='checkbox' name='checkgroup' id='checkgroup' value='".$row->group_id."' onClick='javascript:setval();'></td>";
		    echo "</tr>";
		 }	
	 }
	 else
	 {
		if($checkgroup!='')
	 	$check = explode(":",$checkgroup);
		else
		$check =array();
        $groupName = array();
        $groupId = array();
		$i=0;
	 	 foreach($groups as $index=>$row)		
		 {
		 	$groupName[$index] = $row->group_name;
		 	$groupId[$index] = $row->group_id;   
		 }
		 foreach($check as $row)
		{	
			$i++;
			if($i%2==0)
			$class="odd";
			else
			$class="even";
					$temp = array_keys($groupId, $row);
					$index = implode("", $temp);
		 			echo "<tr><td class='".$class."' >".$groupName[$index] ."</td>";
		 		    echo "<td class='".$class."'><input type='checkbox' style='margin:0px'  name='checkgroup'  checked  id='checkgroup' check  value='".$groupId[$index]."' onClick='javascript:setval();'></td>";
		    	    echo "</tr>";
		}
	 	 $noncheck = array_diff($groupId,$check);
		 $i=0;
		 foreach($noncheck as $row)
			{			
				$i++;
			if($i%2==0)
			$class="odd";
			else
			$class="even";
					$temp = array_keys($groupId, $row);
					$index = implode("", $temp);
		 			echo "<tr><td class='".$class."' >".$groupName[$index] ."</td>";
		 		    echo "<td class='".$class."'><input type='checkbox' style='margin:0px' name='checkgroup' id='checkgroup'  value='".$groupId[$index]."' onClick='javascript:setval();'></td>";
		    	    echo "</tr>";
			}
	
				
	 }	
	 ?>
                            </table>
                            </div><!-- end .popup_newuser_checklist_wrapper_bottom -->
</td>
</tr>
<tr>
<td></td>
<?php 
if($_GET['id'] == 'setting')
{
  echo '<td align="left" style="padding:2px"><input type="checkbox" name="showicon"  style="margin:0px" id="showicon" onClick="javascript:setvalinfomedia();"   />Show info and media icon when present</td>';
}else
{
	echo '<td align="left" style="padding:2px"><input type="checkbox" name="showicon"   style="margin:0px" id="showicon" onClick="javascript:setvalinfomedia();" ';
	if($showicon) echo "checked";
	echo ' />Show info and media icon when present</td>';
}
	?>

</tr>
<tr>
<td></td>
<?php if($_GET['id']=='setting')
		echo '<td style="padding-top:10px"><input type="submit" name="submit" id="submit"	class="submit_moreinfo" value=" " /> <input type="button"  class="cancel" onclick="parent.tb_remove()" ></a></td>';
	  else
	  	echo '<td style="padding-top:10px"><input type="submit" name="update" id="update" class="submit_moreinfo" value=" " /> <input type="button"  class="cancel" onclick="parent.tb_remove()" ></a></td>';
	
?>

</tr>
</table>
</form>             
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/thickbox.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script language="javascript">
	var url='<?php echo url::base(FALSE) ?>index.php/wizard/';
</script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script.js"></script>

</body>
</html>
