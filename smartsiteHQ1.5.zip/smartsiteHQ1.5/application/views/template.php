<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>

	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Expand Smart Site | Login</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="description" content=" " />
	<meta name="keywords" content=" " />
	<meta name="Author" content=" " />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>/media/css/basic.css" type="text/css" media="all"  />
	<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>/media/css/login.css" type="text/css" media="all"  />

	<style type="text/css">
	<!--html { background:#FFFFFF url(<?php //echo url::base(FALSE) ?>kohana11.png) 50% 0 no-repeat; }
	body { width: 58em; margin: 0px auto 0em; font-size: 60%; font-family: Arial, sans-serif; color: #273907; line-height: 1.5; text-align: center; }
	h1 { font-size: 3em; font-weight: normal; text-transform: uppercase; color: #fff; }
	a { color: inherit; }
	code { font-size: 1.3em; }
	ul { list-style: none; padding: 2em 0; }
	ul li { display: inline; padding-right: 1em; text-transform: uppercase; }
	ul li a { padding: 0.5em 1em; background: #69ad0f; border: 1px solid #569f09; color: #fff; text-decoration: none; }
	ul li a:hover { background: #569f09; }-->
	.box { padding: 0em; background: transparent;margin: 0px 2px;}
	<!--.copyright { font-size: 0.9em; text-transform: uppercase; color: #557d10; }-->
	</style>

</head>
<body>

    
    <?php //$title=(isset($title))? html::specialchars($title):'';   ?>  
	<?php //echo "<font color='red'>$title</font>" ?>
	<?php $content=(isset($content))? $content:'';
	      echo $content;
	?>



	

</body>
</html>