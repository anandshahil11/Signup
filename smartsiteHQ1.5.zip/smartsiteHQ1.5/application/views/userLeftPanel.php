<?php
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [24/Feb/11]
Page Description:: user Left Panel   page 
*********************************************/
?>  

	<div id="module_sidebar">
    	<h1>User Library</h1>
		    <form  method="post" action="<?php echo url::site("userSearch/userLib?companyid=$companyid ");?>" class="module_search_dropdown">
                <input  name="search" type="text" value="Search" onClick="this.value=''" />
				<input type="hidden" name="submit" value="submit"/>
            </form>
        
        <ul class="module_search_options">
        	<li class="<?php if(isset($type)&& $type=='group'){ echo 'selected';} ?>"><a class="user_view_groups" href="<?php echo url::site("user/group/$userid")?>">View Groups</a></li>
            <li class="<?php if(isset($type)&& $type=='user'){ echo 'selected';} ?>"><a class="user_view_users" href="<?php echo url::site("user/viewUsers/$userid/$companyid")?>">View Users</a></li>
			<li class="<?php if(isset($type)&& $type=='adduser'){ echo 'selected';} ?>">
			<a class="thickbox user_add_new_user" href="<?php echo url::base(FALSE)."index.php/user/userSetting?userid=$userid&companyid=$companyid&id=setting&type=I&keepThis=true&TB_iframe=true&height=500&width=780"; ?>">Add New User</a>
			</li>
            <li class="<?php if(isset($type)&& $type=='importuser'){ echo 'selected';} ?>"><a class="user_import_users" href="<?php echo url::base(FALSE).'index.php/group/importUser?companyid='.$companyid;?>">Import Users</a></li>
            <li class="<?php if(isset($type)&& $type=='search'){ echo 'selected';} ?>"><a class="module_select_advanced" href="<?php echo url::base(FALSE).'index.php/userSearch/search?companyid='.$companyid;?>">Advanced Search</a></li>
        </ul>
    </div><!-- end #module_sidebar -->
