<?php
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [24/Feb/11]
Page Description:: user Left Panel   page 
*********************************************/
?>    
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.cookie.js"></script>
<script language="javascript">
$(document).ready(function () {
  <?php
  if(isset($_GET['set']))
  {
  ?>
  var checkCookie = 3;
  $.cookie("nav-itemnew", 3);
  <?php
  }else
  {
  ?>
  var checkCookie = $.cookie("nav-itemnew");
  <?php
  }?>
  if (checkCookie != "") {
	$('#navmenu > li > a:eq('+checkCookie+')').addClass('active').next().show();
  }
  $('#navmenu > li > a').click(function(){
     var navIndex = $('#navmenu > li > a').index(this);
	  $.cookie("nav-itemnew", navIndex);
	  $('#navmenu li ul').slideUp();
	   if ($(this).next().is(":visible")){
		   $(this).next().slideUp();
	   } else {
	   $(this).next().slideToggle();
	   }
	   $('#navmenu li a').removeClass('active');
	   $(this).addClass('active');
  });
});
</script>
<style>
#navmenu li ul {display: none;}
</style>
	<div id="module_sidebar">
    <h1>Modules</h1>
        <ul class="module_search_select" id="navmenu">
        	<li><a class="module_search_dialogues" href="#">Dialogues</a></li>
            <li><a class="module_search_exams" href="#">Exams</a>
			<ul>
					<li><a href="<?php echo url::base(FALSE)."index.php/exam/exam?keepThis=true&TB_iframe=true&height=400&width=740"; ?>" class="settingbutton thickbox" >Create Exam</a></li>
                	<li><a href="<?php echo url::site("exam/viewAll")?>">Edit Exam</a></li>
                	<li><a href="#">View Completed</a></li>
             </ul>
			</li>
            <li><a class="module_search_checklists" href="#">Checklists</a>
            	<ul>
					<li><a href="<?php echo url::base(FALSE)."index.php/checklist/setting?keepThis=true&TB_iframe=true&height=400&width=740"; ?>" class="settingbutton thickbox" >Create New Checklist</a></li>
                	<li><a href="<?php echo url::site("checklist/viewAll")?>">Edit Checklist</a></li>
                	<li><a href="<?php echo url::site("checklist/search")?>">View Completed</a></li>
                </ul>
            </li>
            <li><a class="module_search_wizards" href="#">Wizards</a>
				<ul>
				<li ><a class="module_select_all" href="<?php echo url::site("wizard/viewAll")?>">Wizards</a></li>
				<li ><a class="module_select_all" href="<?php echo url::site("wizardsearch/search")?>">Advanced Search</a></li>
				</ul>
			</li>
            <li><a class="module_search_surveys" href="#">Surveys</a></li>
			<li><a class="module_search_wizards" href="#">Resources</a>
				<ul>
				<li ><a class="module_select_all" href="<?php echo url::site("resource/viewCategories")?>">View Categories</a></li>
				<li >
				<a class="thickbox module_select_all" href="<?php echo url::base(FALSE)."index.php/resource/createCategory?&id=setting&type=I&keepThis=true&TB_iframe=true&height=400&width=510"; ?>">Create New Category</a></li>
				<li ><a class="module_select_all" href="<?php echo url::site("resource/viewResources")?>">View Resources</a></li>
				<li ><a class="module_select_all thickbox" href="<?php echo url::site("resource/addResource?id=setting&type=I&keepThis=true&TB_iframe=true&height=400&width=510")?>">Add New Resource</a></li>
				</ul>
			</li>
        </ul>
    </div><!-- end #module_sidebar --><!-- end #module_sidebar -->
