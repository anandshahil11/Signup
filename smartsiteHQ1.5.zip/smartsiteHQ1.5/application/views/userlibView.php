<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [03/March/11]
Page Description:: Users  View All  page 
*********************************************/
require_once('header.php');
?>
<script type="text/javascript">

function tb_init(){
	$(document).click(function(e){
	e = e || window.event;
	var el = e.target || e.scrElement || null;
	if(el && el.parentNode && !el.className || !/thickbox/.test(el.className))
	el = el.parentNode;
	if(!el || !el.className || !/thickbox/.test(el.className))
	return;
	var t = el.title || el.name || null;
	var a = el.href || el.alt;
	var g = el.rel || false;
	tb_show(t,a,g);
	el.blur();
	return false;
	});
};

var durl='<?php echo url::base(FALSE) ?>index.php/user/deleteUser/<?php echo $userid;?>/<?php echo $companyid;?>?userid=';
$(document).ready(function()
{
    $("#myTable tr").click(function(event) 
	{
		var tr_id= $(this).val();
		$('#deleterow').val(tr_id);
		$('#editid').val(tr_id);
		
    });
	
    //To Delete record 
    $('.delete').click(function(e) 
	{
        var del = $('#deleterow').val();
		if(del == '' || del == 0)
		{
			alert("Please select record to delete");
			return  false;
		}
		 
		if(del)
		{
			e.preventDefault();
			var href =durl+del;
			del = 0;
			if(confirm('Do you really want to delete this user?')) 
			{
				window.location = href;
			}
					
		}

	});
	
	$('.edit').click(function(e) 
	{
        var id = $('#editid').val();
		var companyid = '<?php echo $companyid; ?>';
		var userid = '<?php echo $userid; ?>';
		var url = '<?php echo url::base(FALSE) ?>index.php/user/userSetting?userid='+userid+'&companyid='+companyid+'&id='+id+'&type=I&keepThis=true&TB_iframe=true&height=500&width=780';
		if(id == '' || id == 0)
		{
			alert("Please select record to edit");
			return false;
        }
		if(id)
		{
			e.preventDefault();
			var href =url;
			id = 0;
            //window.location = href;
			$('#lightlink').attr('href',url);
			
		}else
		{
			alert('Please select only one row for edit');
			return false;
		}

    });

	
	
});
</script>

<script type="text/javascript">
//ADDED  for left FORM SUBMISSION
$(function() {
	
	$(".testButton").click(function() {
		$("#right_stat").html(' <div class="ajaxloading"><img src="<?php echo url::base(FALSE) ?>media/img/loading.gif"/></div>');							
		var userid = $(this).val();
		var action = $("input#action").val();
		var companyid = '<?php echo $companyid; ?>';
		var dataString ='companyid='+companyid+'&userid='+userid+'&action='+action;
		$.ajax({
			type: "POST",
			url: "<?php echo url::base(FALSE) ?>/index.php/user/rightuserPane/",
			data: dataString,
			success: function(data) {
				
				$('#right_stat').html(data);			
			}
	});
	return false;
});
});
</script>
<div id="module_middle">
    <?php require_once('userLeftPanel.php');?>
	<div id="module_content">
		<form id="viewAll" name ="viewAll"  method="post">
        <input type="hidden" id="deleterow"  value=""/>
	    <input type="hidden" id="editid"  value=""/>
    	<div id="module_content_header">
        	<div id="module_content_header_left">
        		<h1>User Library</h1>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
            </div>
            
            <div id="module_content_header_right" style="width:50px;float:left;">
                <!--<table>
				
                <tr class="options">
					<td>
                    <?php
					/*if(!isset($groupid))
					{
					    $groupid="";
					}*/
                    ?>					
					<a class="export" href="<?php //echo url::base(FALSE).'index.php/group/exportUser?companyid='.$companyid.'&groupid='.$groupid;?>">Export Users</a>
					</td>
					<td>
					<a class="edit thickbox" id="lightlink" href="#" style="text-decoration:none;color:black;" >
					Edit User</a>
					</td>
				</tr>
				<tr class="options">
					<td>
					<a href="<?php //echo url::base(FALSE)."index.php/user/userSetting?userid=$userid&companyid=$companyid&id=setting&type=I&keepThis=true&TB_iframe=true&height=500&width=780"; ?>"  
					   style="text-decoration:none;color:black;" 
					   class="thickbox addusers" >
					Add User</a>
					</td>
					<td>
					<a class="delete" href="#">Delete User</a>
					</td>
				</tr>
				</table>--->
            </div>
        </div><!-- end #module_content_header -->
		
           
            <table width="100%" border="0" id="myTable" cellpadding="0" cellspacing="0" class="tablesorter">
            	<thead>
				<tr>
                	<th>First Name</th>
                	<th>Last Name</th>
                	<th>Company</th>
                	<th>Username/EmailId</th>
                	<th>Country</th>
					<th>Last Log-in</th>
                </tr>
				</thead>
				<?php
				$count = count($usersData);
				for($i=0;$i<$count;$i++)
				{   
				    if((($i+1)%2)==0)
					{
				?>
				<tr class="testButton" id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';" 
					onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]['id']; ?>';this.class='selected';"
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"
				> <input type="hidden" name="action" id="action" value="none" />
                	<td><?php echo $usersData[$i]['first']; ?></td>
                    <td><?php echo $usersData[$i]['last']; ?></td>
                    <td><?php echo $usersData[$i]['company']; ?></td>
                    <td><?php echo $usersData[$i]['emailid']; ?></td>
                    <td><?php echo $usersData[$i]['country']; ?></td>
					<td><?php if($usersData[$i]['last_login']== ""){echo "-"; }else{echo date("m/d/Y",$usersData[$i]['last_login']); }?></td>
                </tr>
				<?php
				    }else
                    {					
				?>
                <tr class="testButton" id='<?php echo ($i+1);?>' 
				   onmouseover="rowOver('<?php echo ($i+1)?>',1);this.style.cursor='pointer';this.style.fontWeight='normal';" 
			        onmouseout="rowOver('<?php echo ($i+1)?>',0);this.style.fontWeight='normal';"
					onclick="selectRow('<?php echo ($i+1)?>');this.value='<?php echo $usersData[$i]['id']; ?>';this.class='selected';"
				    ondblclick="deSelectRow('<?php echo ($i+1)?>');"
				>	<input type="hidden" name="action" id="action" value="none" />
                	<td><?php echo $usersData[$i]['first']; ?></td>
                    <td><?php echo $usersData[$i]['last']; ?></td>
                    <td><?php echo $usersData[$i]['company']; ?></td>
                    <td><?php echo $usersData[$i]['emailid']; ?></td>
                    <td><?php echo $usersData[$i]['country']; ?></td>
					<td><?php if($usersData[$i]['last_login']!= ""){ echo "-"; }else{ echo date("m/d/Y",$usersData[$i]['last_login']); } ?></td>
                </tr>
                <?php
				    }
				}	
				?>
                
            </table>
			</form>
			
			<?php 
					if($count<=0)
					{
						echo $searchResult;
					}
			?>
    </div><!-- end #module_content -->
    <div id="user_info">
	    
		<div id="user_info_header"><h1>User Stats</h1></div>
		<div id="right_stat">
		 	
		
		
		</div>
		
		
    </div>        
        
</div><!-- end #module_middle -->

</body>
</html>