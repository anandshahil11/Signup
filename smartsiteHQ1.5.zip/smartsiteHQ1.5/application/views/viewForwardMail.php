<?php 
/********************************************
AUTHOR:: Anand Sharma
Version:: 2.0
Date:: [16/May/11]
Page Description:: View Resource Category Items page 
*********************************************/

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="<?php echo url::base(FALSE) ?>media/css/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="<?php echo url::base(FALSE) ?>media/css/layout.css" type="text/css"   />
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/thickbox.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script.js"></script>
<script language="javascript">
	$(function(){
		$('#sendmail').click(function()
		{
			var email=$('#to').val();
			var subject = $('#subject').val();
			
			if(email=='')
			{
				alert('Please enter atleast one TO address');
				return false;
			}
			if(subject=='')
			{
				alert('Please enter a subject');
				return false;
			}
			
			
		}
		);
	});
</script>
<style type='text/css'>
	.blue_zebra {
		border-bottom: #fff solid 2px;
	}

	.blue_zebra tbody tr {
		height: 20px;
	}

	.blue_zebra tbody td, .blue_zebra thead th {
		padding: 2px 20px;
	}

	.blue_zebra thead th {
		background-color: #000;
		color:#FFF;
		font-family:Verdana;
		font-size:11pt;
		font-weight:bold;
	}
	.blue_zebra tr {
		color:#000;
		font-family:Verdana;
		font-size:11pt;
	}
	.emailheader {
		background-color: #fff;
		color:#000;
		font-family:Verdana;
		font-size:11pt;
		font-weight:bold;
	}
	
</style>
</head>
<body style="background:#fff">
<div id="mail" >
<form name="email" action="" method="post" >
	<table width="95%" border-right=1px>
	<tr>
	<td width="10%" class="emailheader" style="text-align:right;font-size:12px;">To:</td>
	<td width="90%" class="emailheader"><input type="text" style="width:500px;height:20px;margin-left:1px;" id="to" name="to"/></th>
	</tr>
	<tr>
	<td class="emailheader" style="text-align:right;font-size:12px;">CC:</td>
	<td class="emailheader"><input type="text" style="width:500px;height:20px;margin-left:1px;" id="cc" name="cc"/></th>
	</tr>
	<tr>
	<td class="emailheader" style="text-align:right;font-size:12px;">BCC:</td>
	<td class="emailheader"><input type="text" style="width:500px;height:20px;margin-left:1px;" id="bcc" name="bcc"/></th>
	</tr>
	<tr>
	<td  class="emailheader" style="text-align:right;font-size:12px;">Subject:</td>
	<td class="emailheader"><input type="text" readonly="readonly" style="width:500px;height:20px;margin-left:1px;" value="<?php echo $subject?>" id="subject" name="subject"/></th>
	</tr>
	<tr>
	<td class="emailheader" style="text-align:right;font-size:12px;">From:</td>
	<td class="emailheader"><input type="text" readonly="readonly" style="width:500px;height:20px;margin-left:1px;" value="<?php echo $sender?>" id="from" name="from"/>&nbsp;
	     <input type="submit" style="margin-bottom:14px;margin-left:1px;margin-right:16px;margin-top:4px;" value="Send Mail" id="sendmail" name="sendmail-submit"/>
	</td>
	</tr>
	
	</table>
	<?php if($message!=''){ echo $message; }else { echo '&nbsp;'; }?>
	<?php echo $html;?>
	<a href="#"><input type="button"  style="margin-left:45%;margin-right:45%;margin-top:1px;" class="cancel" onclick="parent.tb_remove()" ></a>
	
	
	
	
</form>
</div>
</body>
</html>
