<?php 
/********************************************
AUTHOR:: Murugan A
Version:: 2.0
Date:: [24/Feb/11]
Page Description:: wizard creation  page 
*********************************************/
require_once('header.php');
?>
<?php if($_GET['id'])
			$id = $_GET['id']; 
	  else
			$id = 'setting';
?>
<div id="module_middle">
	<?php require_once('userLeftPanel2.php');?>
    <div id="module_content" style="width:82%">
    	<div id="module_edit_header">
		<?php
			if(isset($_GET['msg']))
			echo '<span style="color:red" id="message">'.$_GET['msg']."<br></span>";
			?>
        	<h1>Pro Series Wizard</h1>
            <div id="module_edit_header_options">
				<?php if($wizardInfo->publish_wizard==0){ ?>
                <a href="<?php echo url::base(FALSE)."index.php/wizardSetting/publish?action=publish&id=".$id;?>" class="publishbutton edittemp_publish">Publish</a>
				<?php }else{?>		
				<a href="<?php echo url::base(FALSE)."index.php/wizardSetting/publish?action=unpublish&id=".$id;?>" class="publishbutton edittemp_publish">Un Publish</a>
				<?php }?>
				
                <a href="<?php echo url::base(FALSE)."index.php/wizardSetting/setting?id=".$id."&type=I&keepThis=true&TB_iframe=true&height=400&width=500"; ?>" class="settingbutton thickbox wizard_settings">Settings</a>
            </div>
        </div><!-- end #module_edit_header -->
        
        <div id="edit_tables" style="scroll:yes;width:100%" >
            <table class="pro_series_wizard issue">
            	<tr>
                	<th>
                    	<span class="edit_label">Issue</span>
                   		<a href="#" class="add" id="addButton1">Add</a>
                    	<a href="#" class="remove" id="deleteButton1">Remove</a>
                    </th>
                </tr>
                <tr style="background-color:#F0F0F0">
				<td>
				<div style="overflow-y:scroll;height:270px">
                	<ul class="todoList" id="todoList1" >
				<?php
				$i=0;
				foreach($results as $row)
				{
					$i++;
					if($i%2==0)
					$class='odd';
					else
					$class='even';
					echo '<li id="todo-'.$row->issue_id.'" class="todo '.$class.'">';
					echo '<div class="text" style="position:relative;"><a href="#" class="edit even" id="edit1" style="width:500px">'.$row->issue_name.'</a><a href="'.url::base(FALSE).'index.php/wizard/media?id='.$row->issue_id.'&type=I&keepThis=true&TB_iframe=true&height=465&width=510"  class="thickbox" style="float:right"><img src="'.url::base(FALSE).'media/img/icon_info.png"></a> 
						  </div>';
					echo '</li>';
				} 
				?>
			</ul>
			</div>
			</td>
                </tr>
                </table>
            
            <table class="pro_series_wizard symptom">
            	<tr>
                	<th>
                    	<span class="edit_label">Symptom</span>
                   		<a href="#" class="add" id="addButton2">Add</a>
                    	<a href="#" class="remove" id="deleteButton2">Remove</a>
                    </th>
                </tr>
                <tr style="background-color:#F0F0F0">
                	<td>
						<div style="overflow-y:scroll;height:270px">
						<ul class="todoList" id="todoList2">
						
						</ul>
						</div>
					</td>
                </tr>
            </table>
            
            <table class="pro_series_wizard cause">
            	<tr>
                	<th>
                    	<span class="edit_label">Cause</span>
                   		<a href="#" class="add" id="addButton3">Add</a>
                    	<a href="#" class="remove" id="deleteButton3">Remove</a>
                    </th>
                </tr>
                <tr style="background-color:#F0F0F0">
                	<td>
						<div style="overflow-y:scroll;height:270px">
						<ul class="todoList" id="todoList3">
						
						</ul>
						</div>
					</td>
                </tr>
            </table>
    		<div class="clearfloat"></div>
        </div><!-- end #edit_tables -->
        
        <table class="pro_series_wizard solution" >
           	<tr>
            	<th><span class="edit_label">Solution</span>
                   	<a href="#" class="add" id="addButton4">Add</a>
                   <a href="#" class="remove" id="deleteButton4">Remove</a>
            </tr>
            <tr class="even">
                	<td>
						<ul class="todoList" id="todoList4" style="width:100%">
						
						</ul>
					</td>
                </tr>
        </table>    
		 <table class="pro_series_wizard solution" >
           	<tr>
            	<th><span class="edit_label">Solution Steps</span>
                   	<a href="#" class="add" id="addButton5">Add</a>
                   <a href="#" class="remove" id="deleteButton5">Remove</a>
            </tr>
            <tr class="even">
                	<td>
						<ul class="todoList" id="todoList5" style="width:100%">
						
						</ul>
					</td>
                </tr>
        </table>    
    </div><!-- end #module_content -->
    <div class="clearfloat"></div>
</div><!-- end #module_middle -->
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/jquery-ui.min.js"></script>
<script language="javascript">
	var url='<?php echo url::base(FALSE) ?>index.php/wizard/';
	var baseUrl='<?php echo url::base(FALSE) ?>';
	var id=<?php echo $_GET['id']?>;
</script>
<script type="text/javascript" src="<?php echo url::base(FALSE) ?>media/js/script.js"></script>