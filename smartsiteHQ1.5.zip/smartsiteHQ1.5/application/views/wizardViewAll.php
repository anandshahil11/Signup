<?php 
require_once('header.php');
?>
<script type="text/javascript" >
//For selecting  and editing row
var idsArray=new Array();
var idsText='';
$(document).ready(function() {
/*
$("#datarow tr").dblclick(function(event) {
	
	var rowCount = $('#datarow tr').length;
	var tr_id= ($(this).attr("id"));
	if(tr_id)
		$(this).toggleClass("selected"); 
		
	for(var i = 1; i<=(rowCount-1); i++)
	{
		if(i == tr_id)
		{
			
				var url = $("#aTest"+i).attr("href");
				
  		 		if(url)
  	  		 	{	  
	    			location.href = url ;
   				 }
		}
	}

  });
*/
$("#datarow tr").click(function(event) {
	var tr_id= ($(this).attr("id"));
	if(tr_id)
	{
		$(this).toggleClass("selected", this.clicked);
		$(this).removeClass('over');
	}
	var rowDel = $("#datarow td.wizardid"+tr_id).text();
	var id = $("#datarow td.wizardid"+tr_id).text();
	if($(this).attr('class')=='odd' || $(this).attr('class')=='even')
	{  
		removeByValue(idsArray,tr_id);
		idsText=idsArray.join(",");
	}
	else if($.inArray(tr_id, idsArray)<0)
	{   idsArray.push(tr_id);
		idsText=idsArray.join(",");
	}
	$('#deleterow').val(rowDel);
	$('#editid').val(idsText);
  });
 function removeByValue(arr, val) {
    for(var i=0; i<arr.length; i++) {
        if(arr[i] == val) {
            arr.splice(i, 1);
            break;
        }
    }
}
$(function() {
    $('table tbody tr').mouseover(function() {
		if($(this).attr('class')!='odd selected' && $(this).attr('class')!='even selected')
        $(this).addClass('over');
    }).mouseout(function() {
        $(this).removeClass('over');
	});
	});

// for confirmation box

$('.ask').click(function(e) {

	 var del = $('#deleterow').val();
	 if(del == '' || del == 0)
		{
			alert("Please select record to delete");
			return  false;
		}
	 
	 if(del)
	 {
		e.preventDefault();
		var href =durl+idsText;
		del = 0;
		if(confirm('Do you really want to delete this wizard?')) {
			window.location = href;
		 }
				
	}

});
 
//finish conformation 

$('.edit').click(function(e) {

	 var id = $('#editid').val();
	 if(id == '' || id == 0)
	{
			alert("Please select record to edit");
			return false;

	}
	 if(id.indexOf(',')==-1)
	 {
		e.preventDefault();
		var href =url+id;
		id = 0;

			window.location = href;
				
	}else
	{
		alert('Please select only one row for edit');
		return false;
	}

});

}); 
</script  >
<script language="javascript">
	var url='<?php echo url::base(FALSE) ?>index.php/wizard?id=';
	var durl='<?php echo url::base(FALSE) ?>index.php/wizard/deleteWizard?id=';

</script>
<div id="module_middle">
	<?php require_once('userLeftPanel2.php');?>
    <div id="module_content" style="width:82%">
    	<div id="module_edit_header">
        	<h1>All Wizards</h1>
            <div id="module_edit_header_options">
				<a href="" class="ask settingbutton user_delete" >Delete</a>
            	<a href="" class="edit editbutton user_edit" >Edit</a>
				<a class="settingbutton thickbox edittemp_addnew" href="<?php echo url::base(FALSE)."index.php/wizardSetting/setting?id=setting&type=I&keepThis=true&TB_iframe=true&height=400&width=500"; ?>"  >Add</a>
			</div>
        </div><!-- end #module_edit_header -->
		 <form id="viewAll" name ="viewAll"  method="post">
     <input type="hidden" id="deleterow"  value=""/>
	 <input type="hidden" id="editid"  value=""/>
            <table id="datarow">
            	<tr>
                	<th align="center">Wizard Name</th>
                	<th align="center">Identification Number</th>
                	<th align="center">Last Used</th>
                	<th align="center">Created</th>
					<th align="center">Author</th>
                </tr>
				 <?php
	    		$i=1;
				$num=0;
				foreach($records as $row)
				{
					$num++;
					if($num%2==0)
					$class='odd';
					else
					$class='even';
					echo "<tr id=".$row->wizard_id." class='".$class."' >";
					echo "<td >$row->wizard_name </td>";
					echo "<td class='td_center wizardid".$row->wizard_id."' style='padding-top:6px;padding-bottom:6px'>$row->wizard_id</td>";
					if($row->last_used=='0000-00-00')
					echo "<td class='td_center' >-</td>";
					else
					echo "<td class='td_center' >$row->last_used </td>";
					echo "<td class='td_center' >$row->created_date </td>";
					echo "<td class='td_center' >$row->wizard_author </td></a>";
					echo '</tr>';
				}
				?>
            </table>
		</form>
    </div><!-- end #module_content -->
    <div class="clearfloat"></div>
</div><!-- end #module_middle -->
</body>
</html>