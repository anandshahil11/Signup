<?php 
require_once('header.php');
?>
<script language="javascript">
var url='<?php echo url::base(FALSE) ?>index.php/wizardSearch';
</script>
<div id="module_middle" >
	<?php require_once('userLeftPanel2.php');?>
	   <div id="module_content" style="width:82%">
    	<div id="module_edit_header">
        	<h1>Advanced Search</h1>
        </div><!-- end #module_edit_header -->
		</div>
		<div style="float:left;padding-top:10px;padding-left:10px;width:75%" >
		<table id="maintable">
	<tr id="row1">
    <td colspan="2">
	<table>
    <tr>
    	<td>
		<select name="wizardname1"  id="wizardname1"  style="width:300px" onchange="changeRows()">
		<option value="">Select</option>
		<?php
		foreach($results as $row)
		{
			echo '<option value="'.$row->wizard_id.'">'.$row->wizard_name.'</option>';
		}
		?>
		</select>
		</td>
		<td>
		<select name="issue1" id="issue1" style="width:300px" onchange="getlist(this,1)">
		<option value="">Select</option>
		<?php
		$arr=array("Issues","Symptom","Cause","Solution");
		foreach($arr as $ele)
		{
			echo '<option value="'.$ele.'">'.$ele.'</option>';
		}
		?>
		</select>
		</td>
		<td>
		<img src="<?php echo url::base(FALSE) ?>media/img/icon_add.png" onclick="add()">
		<img src="<?php echo url::base(FALSE) ?>media/img/icon_remove.png" onclick="remove()">
		</td>
		<td id="display1">
		</td>
    </tr>
	 <tr>
		<td>
			<select name="options1" id="options1"  style="width:300px" onchange="getDatas2(1)">
			<option value="">Select</option>
			<?php
			$arr=array("Is","Is Not");
			foreach($arr as $ele)
			{
				echo '<option value="'.$ele.'">'.$ele.'</option>';
			}
			?>
			</select>
			</td>
			<td>
			<select name="problems1" id="problems1" style="width:300px" onchange="getDatas(1)">
			<option value="">Select</option>
			</select>
			</td>
	</tr>
	</table>
	</td>
	</tr>
    </table>
	</div>
    <div id="module_content" style="width:79.5%">
	<br/>
	<table  id="datarow" width="100%" style="margin-left:10px;margin-top:5px;border:1px solid #000">
	    <tr>
	    	<th>name</td>
	    	<th>Type</td>
	    	<th>Wizard</td>
	    	<th>Views</td>
	    	<th>Created</td>
	    </tr>
    </table>
    </div><!-- end #module_content -->
    <div class="clearfloat"></div>
</div><!-- end #module_middle -->
<script language="javascript">
rownum=1;
function getlist(obj,boxnum)
{
	tempUrl=url+'/getList';
	wizardId=$('#wizardname1').val();
	
	//forming all the value
	value='?wizardId='+document.getElementById('wizardname1').value;
	for(i=1;i<boxnum;i++)
	{
		value=value+'&'+document.getElementById('issue'+i).value+'='+document.getElementById('problems'+i).value;
	}
	for(i=boxnum+1;i<=rownum;i++)
	{
		$('#row'+i).remove();
		rownum=rownum-1;
	}
	tempUrl=tempUrl+value;
	//alert(tempUrl);
	$.get(tempUrl,{'listopt':obj.value,'rand':Math.random()},function(msg){ 
		$('#problems'+boxnum).html(msg);
	});
	$('.row').remove();
}
function add()
{
	if(rownum<4){
		rownum=rownum+1;
		val='<tr id="row'+rownum+'">';
		val+='<td style="padding-top:10px"><table>';
		val+='<tr>';
		val+='<td>';
		val+='<select id="wizardname'+rownum+'" name="wizardname'+rownum+'" style="width:300px">';
		val+='<option value="'+$('#wizardname1').val()+'">'+$('#wizardname1 option:selected').text() +'</option>';
		val+='</select>';
		val+='</td>';
		val+='<td>';
		val+='<select id="issue'+rownum+'" name="issue'+rownum+'" style="width:300px" onchange="getlist(this,'+rownum+')">';
		selectedValue=document.getElementById('issue'+(rownum-1)).value;
		tempUrl=url+'/getOptions?selectedValue='+selectedValue;
		//alert(tempUrl);
		$.ajax({url:tempUrl,
		success:function(msg){ 
			val+=msg;
		},async:false});
		val+='</select>';
		val+='</td>';
		val+='<td>';
		val+='<img src="<?php echo url::base(FALSE) ?>media/img/icon_add.png" onclick="add()">';
		val+='<img src="<?php echo url::base(FALSE) ?>media/img/icon_delete.png" onclick="remove()">';
		val+='</td>';
		val+='<td id="display'+rownum+'">';
		val+='</td>';
		val+='</tr>';
		val+='<tr>';
		val+='<td>';
		val+='<select id="options'+rownum+'" name="options'+rownum+'" style="width:300px" onchange="getDatas2('+rownum+')">';
		val+=$('#options1').html();
		val+='</select>';
		val+='</td>';
		val+='<td>';
		val+='<select id="problems'+rownum+'" name="problems'+rownum+'" style="width:300px" onchange="getDatas('+rownum+')">';
		val+=$('#problems1').html();
		val+='</select>';
		val+='</td>';
		val+='</tr>';
		val+='</table></td></tr>';
		$('#maintable > tbody:last').append(val);
	}
}
function remove()
{
	if(rownum>1)
	{
		$('#row'+rownum).remove();
		rownum=rownum-1;
	}
}
function getDatas(selNum)
{
		tempUrl=url+'/getDatas';
		value='?wizardId='+document.getElementById('wizardname1').value;
		for(i=1;i<=rownum;i++)
		{
			if(document.getElementById('issue'+i).value!='')
			{
				value=value+'&'+document.getElementById('issue'+i).value+'='+document.getElementById('problems'+i).value+'&'+
					  document.getElementById('issue'+i).value+'Cri='+document.getElementById('options'+i).value;
			}
		}
		lastIssue=document.getElementById('issue'+selNum).value;
		tempUrl=tempUrl+value+'&lastIssue='+lastIssue;
		//alert(tempUrl);
		$('.row').remove();
		$.ajax({url:tempUrl,
		success:function(xml){ 
			$(xml).find('rowcount').each(function(){
				$('#display'+selNum).html('&nbsp;&nbsp;&nbsp;&nbsp;<b>'+$(this).text()+'</b>'); 
			});
			i=0;
			$(xml).find('rows').each(function(){
				i++;
				if(i%2==0)
				sty='odd';
				else
				sty='even';
				val="<tr class='row "+sty+"'>";
				val+='<td >'+ $(this).find('name').text()+"</td>";
				val+='<td >'+ $(this).find('type').text()+"</td>";
				val+='<td >'+ $(this).find('wizard').text()+"</td>";
				val+='<td >'+ $(this).find('views').text()+"</td>";
				val+='<td >'+ $(this).find('created').text()+"</td>";
				val+='</tr>';
				$('#datarow > tbody:last').append(val);
			});
		}});
		for(i=selNum+1;i<=rownum;i++)
		{
			$('#row'+i).remove();
			rownum=rownum-1;
		}
		
}
function getDatas2(selNum)
{
	if(document.getElementById('problems'+selNum).value!='')
	{
		getDatas(selNum)
	}
}
function changeRows()
{
	//alert(rownum);
	for(i=2;i<=rownum;i++)
	{
		$('#row'+i).remove();
		rownum=rownum-1;
	}
	$('#problems1').val('');
	$('#options1').val('');
	$('#issue1').val('');
	$('.row').remove();
	$('#display1').html('');
}
</script>
</body>
</html>