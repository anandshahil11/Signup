$(document).ready(function(){
	/* The following code is executed once the DOM is loaded */
	var IssueId=0;
	var symptomId=0;
	var causeId=0;
	var solutionId=0;
	var solutionStepId=0;
	var text;
	var oldType;
	$('#todoList1 li').live('click',function(e){
		$('#message').hide();
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		$('#todoList1 li').attr('style','border-color:#EEEEEE');
		currentTODO.data('id',currentTODO.attr('id')).attr('style','background-color:#ACD2E4');
		IssueId=currentTODO.attr('id').replace('todo-','');
		if (e.target.nodeName == 'DIV' || e.target.nodeName == 'LI' || e.target.nodeName == 'A') {
			getSymptom();
			$('#todoList3').html('');
			$('#todoList4').html('');
			$('#todoList5').html('');
			symptomId=0;
			causeId=0;
			solutionId=0;
			solutionStepId=0;
		}
	});
	
	// A global variable, holding a jQuery object 
	// containing the current todo item:
	var currentTODO;
	// When a double click occurs, just simulate a click on the edit button:
	$('.todo').live('dblclick',function(){
		$(this).find('a.edit').click();
	});
	
	//get symptom
	function getSymptom()
	{
		tempUrl='';
		tempUrl=url+'ajaxSymptom?id='+id;
		$.get(tempUrl,{'action':'getsymptom','issueId':IssueId,'rand':Math.random()},function(msg){ 
			$('#todoList2').html('');
			if(msg!='')
			$(msg).hide().appendTo('#todoList2').fadeIn();
		});
	}
	//loop for issue - sorting
	$("#todoList1").sortable({
		axis		: 'y',				// Only vertical movements allowed
		containment	: 'window',			// Constrained by the window
		update		: function(){		// The function is called after the todos are rearranged
			tempUrl='';
			tempUrl=url+'ajaxIssue?id='+id;
			// The toArray method returns an array with the ids of the todos
			tempUrl=url+'ajaxIssue?id='+id;;
			var arr = $("#todoList1").sortable('toArray');
			// Striping the todo- prefix of the ids:
			arr = $.map(arr,function(val,key){
				return val.replace('todo-','');
			});
			// Saving with AJAX
			$.get(tempUrl,{action:'rearrange','positions':"'"+arr+"'"});
		},
		/* Opera fix: */
		stop: function(e,ui) {
			ui.item.css({'top':'0','left':'0'});
		}
	});
	//For issue - deleting 
	$('#deleteButton1').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxIssue';
		if(currentTODO)
		{
			if(confirm('Are you sure you want to delete?'))
			{
				$.get(tempUrl,{"action":"delete","id":currentTODO.data('id').replace('todo-','')},function(msg){
				currentTODO.fadeOut('fast');
				currentTODO.remove();
				currentTODO='';
				})
			}
		}else{
			alert('Please select anyone');
		}
	});
	
	//For issue - adding 
	$('#addButton1').click(function(e){
		tempUrl=url+'ajaxIssue?id='+id;
		$.get(tempUrl,{'action':'new','text':'Enter Issue','rand':Math.random()},function(msg){
			$(msg).hide().appendTo('#todoList1').fadeIn();
		});
		// Updating the timestamp:
		timestamp = (new Date()).getTime();
		e.preventDefault();
	});
	$('.todo a').live('click',function(e){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		e.preventDefault();
	});
	// Listening for a click on a edit button
	$('#todoList1 .todo a.edit,#todoList2 .todo a.edit').live('dblclick',function(){
		var container = currentTODO.find('.text');
		if(!currentTODO.data('origText'))
		{
			// Saving the current value of the ToDo so we can
			// restore it later if the user discards the changes:
			currentTODO.data('origText',container.text());
		}
		else
		{
			// This will block the edit button if the edit box is already open:
			return false;
		}
		$('<input type="text">').val(container.text()).appendTo(container.empty());
		// Appending the save and cancel links:
		container.append(
			'<div class="editTodo">'+
				'<a class="saveChanges" href="#">Save</a><a class="discardChanges"  href="#">Cancel</a>'+
			'</div>'
		);
		
	});
	// Listening for a click on a edit button
	$('#todoList3 .todo a.edit').live('dblclick',function(){
		var container = currentTODO.find('.text');
		var spantext = currentTODO.find('span');
		if(!currentTODO.data('origText'))
		{
			// Saving the current value of the ToDo so we can
			// restore it later if the user discards the changes:
			currentTODO.data('origText',currentTODO.find('.edit').text());
		}
		else
		{
			// This will block the edit button if the edit box is already open:
			return false;
		}
		valtext=currentTODO.find('.edit').text();
		oldType=spantext.text();
		$('<table><tr><td style="width:220px;border:0 !important;color:#000000 !important;padding-top:3px !important;align:left;"><input type="text" id="valtext"></td><td style="width:220px;border:0 !important;color:#000000 !important;padding:0px !important;align:left;"><select id="type"><option value=""></option><option value="Rare">Rare</option><option value="Unusual">Unusual</option><option value="Common">Common</option></select></td></tr></table>').appendTo(container.empty());
		$('#type').val(oldType);
		$('#valtext').val(valtext);
		// Appending the save and cancel links:
		container.append(
			'<div class="editTodo">'+
				'<a class="saveChanges" href="#">Save</a><a class="discardChanges"  href="#">Cancel</a>'+
			'</div>'
		);
		
	});
	// Listening for a click on a edit button
	$('#todoList4 .todo a.edit,#todoList5 .todo a.edit').live('dblclick',function(){
		var container = currentTODO.find('.text');
		if(!currentTODO.data('origText'))
		{
			// Saving the current value of the ToDo so we can
			// restore it later if the user discards the changes:
			currentTODO.data('origText',container.text());
		}
		else
		{
			// This will block the edit button if the edit box is already open:
			return false;
		}
		$('<input type="text" style="width:400px">').val(container.text()).appendTo(container.empty());
		// Appending the save and cancel links:
		container.append(
			'<div class="editTodo">'+
				'<a class="saveChanges" href="#">Save</a><a class="discardChanges"  href="#">Cancel</a>'+
			'</div>'
		);
		
	});
	// The cancel edit link:
	$('#todoList1 .todo a.discardChanges').live('click',function(){
		currentTODO.find('.text')
					.html('<a href="#" class="edit">'+currentTODO.data('origText')+'</a> <a href="'+url+'/media?id='+currentTODO.data('id')+'&type=I&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a>')
					.end()
					.removeData('origText');
				tb_init("a.thickbox, area.thickbox, input.thickbox");
	});
	
	// The save changes link:
	$('#todoList1 .todo a.saveChanges').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxIssue?id='+id;
		var text = currentTODO.find("input[type=text]").val();
		$.get(tempUrl,{'action':'edit','id':currentTODO.data('id'),'text':text});
		currentTODO.removeData('origText')
					.find(".text")
					.html('<a href="#" class="edit">'+text+'</a> <a href="'+url+'/media?id='+currentTODO.data('id')+'&type=I&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a> ');
					 tb_init("a.thickbox, area.thickbox, input.thickbox");	
					});
	//for symptom
	$('#todoList2 li').live('click',function(e){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		$('#todoList2 li').attr('style','border-color:#EEEEEE');
		currentTODO.data('id',currentTODO.attr('id')).attr('style','background-color:#ACD2E4');
		symptomId=currentTODO.attr('id').replace('todo-','');
		if (e.target.nodeName == 'DIV' || e.target.nodeName == 'LI' || e.target.nodeName == 'A') 
		{
			getCause()
			$('#todoList4').html('');
			$('#todoList5').html('');
			causeId=0;
			solutionId=0;
			solutionStepId=0;
		}

	});
	//symptom sorting
	$("#todoList2").sortable({
		axis		: 'y',				// Only vertical movements allowed
		containment	: 'window',			// Constrained by the window
		update		: function(){		// The function is called after the todos are rearranged
			// The toArray method returns an array with the ids of the todos
			tempUrl='';
			tempUrl=url+'ajaxSymptom?id='+id;
			var arr = $("#todoList2").sortable('toArray');
			// Striping the todo- prefix of the ids:
			arr = $.map(arr,function(val,key){
				return val.replace('todo-','');
			});
			// Saving with AJAX
			$.get(tempUrl,{action:'rearrange','issueId':IssueId,'positions':"'"+arr+"'"});
		},
		/* Opera fix: */
		stop: function(e,ui) {
			ui.item.css({'top':'0','left':'0'});
		}
	});
	//For symptom - deleting 
	$('#deleteButton2').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxSymptom';
		if(currentTODO)
		{
			if(confirm('Are you sure you want to delete?'))
			{
				$.get(tempUrl,{"action":"delete","id":currentTODO.data('id').replace('todo-','')},function(msg){
				currentTODO.fadeOut('fast');
				currentTODO.remove();
				currentTODO='';
				})
			}
		}else{
			alert('Please select anyone');
		}
	});
	//For symptom - adding 
	$('#addButton2').click(function(e){
		tempUrl='';
		tempUrl=url+'ajaxSymptom?id='+id;
		if(IssueId!=0)
		{
			$.get(tempUrl,{'action':'newSymptom','text':'Enter Symptom','issueId':IssueId,'rand':Math.random()},function(msg){
				$(msg).hide().appendTo('#todoList2').fadeIn();
			});
			// Updating the timestamp:
			timestamp = (new Date()).getTime();
			e.preventDefault();
		}else
		alert('Please select anyone Issue');
	});
	
	// The cancel edit link:
	$('#todoList2 .todo a.discardChanges').live('click',function(){
		currentTODO.find('.text')
					.html('<a href="#" class="edit">'+currentTODO.data('origText')+'</a> <a href="'+url+'/media?id='+currentTODO.data('id')+'&type=S&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a>')
					.end()
					.removeData('origText');
					tb_init("a.thickbox, area.thickbox, input.thickbox");
	});
	
	// The save changes link:
	$('#todoList2 .todo a.saveChanges').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxSymptom?id='+id;
		var text = currentTODO.find("input[type=text]").val();
		$.get(tempUrl,{'action':'edit','id':currentTODO.data('id'),'text':text});
		currentTODO.removeData('origText')
					.find(".text")
					.html('<a href="#" class="edit">'+text+'</a> <a href="'+url+'/media?id='+currentTODO.data('id')+'&type=S&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a>');
					tb_init("a.thickbox, area.thickbox, input.thickbox");
	});
	//get cause
	function getCause()
	{
		tempUrl='';
		tempUrl=url+'ajaxCause?id='+id;
		$.get(tempUrl,{'action':'getCause','symptomId':symptomId,'rand':Math.random()},function(msg){ 
			$('#todoList3').html('');
			if(msg!='')
			$(msg).hide().appendTo('#todoList3').fadeIn();
		});
	}
	//For cause - adding 
	$('#addButton3').click(function(e){
		tempUrl='';
		tempUrl=url+'ajaxCause?id='+id;
		if(symptomId!=0)
		{
			$.get(tempUrl,{'action':'newCause','text':'Enter Cause','symptomId':symptomId,'rand':Math.random()},function(msg){
				$(msg).hide().appendTo('#todoList3').fadeIn();
			});
			// Updating the timestamp:
			timestamp = (new Date()).getTime();
			e.preventDefault();
		}else
		alert('Please select anyone Symptom');
	});
	//For cause - deleting 
	$('#deleteButton3').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxCause';
		if(currentTODO)
		{
			if(confirm('Are you sure you want to delete?'))
			{
				$.get(tempUrl,{"action":"deleteCause","id":currentTODO.data('id').replace('todo-','')},function(msg){
				currentTODO.fadeOut('fast');
				currentTODO.remove();
				currentTODO='';
				})
			}
		}else{
			alert('Please select anyone');
		}
	});
	//for cuase
	$('#todoList3 li').live('click',function(e){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		$('#todoList3 li').attr('style','border-color:#EEEEEE');
		currentTODO.data('id',currentTODO.attr('id')).attr('style','background-color:#ACD2E4');
		causeId=currentTODO.attr('id').replace('todo-','');
		if (e.target.nodeName == 'DIV' || e.target.nodeName == 'LI' || e.target.nodeName == 'A') 
		{
			getSolution();
			solutionId=0;
			solutionStepId=0;
			$('#todoList5').html('');
		}
	});
	
	// The cancel edit link:
	$('#todoList3 .todo a.discardChanges').live('click',function(){
		var type = currentTODO.find("select").val();
		currentTODO.find('.text')
					.html('<a href="#" class="edit">'+currentTODO.data('origText')+'</a> <a href="'+url+'/media?id='+currentTODO.data('id')+'&type=C&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a><span style="float:right">'+type+'</span>')
					.end()
					.removeData('origText');
					tb_init("a.thickbox, area.thickbox, input.thickbox");
	});
	// The save changes for cause:
	$('#todoList3 .todo a.saveChanges').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxCause?id='+id;
		var text = currentTODO.find("input[type=text]").val();
		var type = currentTODO.find("select").val();
		$.get(tempUrl,{'action':'editCause','id':currentTODO.data('id'),'text':text,'type':type});
		currentTODO.removeData('origText')
					.find(".text")
					.html('<a href="#" class="edit">'+text+'</a><a href="'+url+'/media?id='+currentTODO.data('id')+'&type=C&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a><span style="float:right">'+type+'</span>');
					tb_init("a.thickbox, area.thickbox, input.thickbox");
	});
	//cause sorting
	$("#todoList3").sortable({
		axis		: 'y',				// Only vertical movements allowed
		containment	: 'window',			// Constrained by the window
		update		: function(){		// The function is called after the todos are rearranged
			// The toArray method returns an array with the ids of the todos
			tempUrl='';
			tempUrl=url+'ajaxCause?id='+id;
			var arr = $("#todoList3").sortable('toArray');
			// Striping the todo- prefix of the ids:
			arr = $.map(arr,function(val,key){
				return val.replace('todo-','');
			});
			// Saving with AJAX
			$.get(tempUrl,{action:'rearrange','symptomId':symptomId57
			,'positions':"'"+arr+"'"});
		},
		/* Opera fix: */
		stop: function(e,ui) {
			ui.item.css({'top':'0','left':'0'});
		}
	});
	//get solution
	function getSolution()
	{
		tempUrl='';
		tempUrl=url+'ajaxSolution?id='+id;
		$.get(tempUrl,{'action':'getSolution','causeId':causeId,'rand':Math.random()},function(msg){ 
			$('#todoList4').html('');
			if(msg!='')
			$(msg).hide().appendTo('#todoList4').fadeIn();
		});
	}
	//For solution - adding 
	$('#addButton4').click(function(e){
		tempUrl='';
		tempUrl=url+'ajaxSolution?id='+id;
		if(causeId!=0)
		{
			$.get(tempUrl,{'action':'newSolution','text':'Enter Solution Title','causeId':causeId,'rand':Math.random()},function(msg){
				$(msg).hide().appendTo('#todoList4').fadeIn();
			});
			// Updating the timestamp:
			timestamp = (new Date()).getTime();
			e.preventDefault();
		}else
		alert('Please select anyone Cause');
	});
		//for solution
	$('#todoList4 li').live('click',function(e){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		$('#todoList4 li').attr('style','border-color:#EEEEEE');
		currentTODO.data('id',currentTODO.attr('id')).attr('style','background-color:#ACD2E4');
		solutionId=currentTODO.attr('id').replace('todo-','');
		if (e.target.nodeName == 'DIV' || e.target.nodeName == 'LI' || e.target.nodeName == 'A') 
		getSolutionSteps();
	});
	
	// The cancel edit link:
	$('#todoList4 .todo a.discardChanges').live('click',function(){
		currentTODO.find('.text')
					.html('<a href="#" class="edit">'+currentTODO.data('origText')+'</a>')
					.end()
					.removeData('origText');
	});
	// The save changes for solution title:
	$('#todoList4 .todo a.saveChanges').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxSolution?id='+id;
		var text = currentTODO.find("input[type=text]").val();
		$.get(tempUrl,{'action':'editSolution','id':currentTODO.data('id'),'text':text});
		currentTODO.removeData('origText')
					.find(".text")
					.html('<a href="#" class="edit">'+text+'</a>');
	});
	// Listening for a click on a edit button
	$('.todo a.edit2').live('dblclick',function(){
		var container = currentTODO.find('.text2');
		text=container.text();
		$('<input type="text" style="width:400px">').val(container.text()).appendTo(container.empty());
		// Appending the save and cancel links:
		container.append(
			'<div class="editTodo">'+
				'<a class="saveChanges2" href="#">Save</a>  <a class="discardChanges2" href="#">Cancel</a>'+
			'</div>'
		);
		
	});
	
	// The cancel edit link:
	$('#todoList4 .todo a.discardChanges2').live('click',function(){
		currentTODO.find('.text2')
					.html('<a href="#" class="edit">'+currentTODO.data('origText')+'</a> ')
					.end()
					.removeData('origText');
	});
		// The save changes for solution subtitle:
	$('#todoList4 .todo a.saveChanges2').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxSolution?id='+id;
		var text = currentTODO.find("input[type=text]").val();
		$.get(tempUrl,{'action':'editSolutionSubtitle','id':currentTODO.data('id'),'text':text});
		currentTODO.removeData('origText')
					.find(".text2")
					.html('<a href="#" class="edit">'+text+'</a>');
	});

	// The cancel edit link:
	$('.todo a.discardChanges2').live('click',function(){
		currentTODO.find('.text2')
					.html('<a href="#" class="edit2">'+text+'</a>')
					.end()
					.removeData('origText');
	});
	//For solution - deleting 
	$('#deleteButton4').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxSolution';
		if(currentTODO)
		{
			if(confirm('Are you sure you want to delete?'))
			{
				$.get(tempUrl,{"action":"deleteSolution","id":currentTODO.data('id').replace('todo-','')},function(msg){
				currentTODO.fadeOut('fast');
				currentTODO.remove();
				currentTODO='';
				})
			}
		}else{
			alert('Please select anyone');
		}
	});
	//solution sorting
	$("#todoList4").sortable({
		axis		: 'y',				// Only vertical movements allowed
		containment	: 'window',			// Constrained by the window
		update		: function(){		// The function is called after the todos are rearranged
			// The toArray method returns an array with the ids of the todos
			tempUrl='';
			tempUrl=url+'ajaxSolution?id='+id;
			var arr = $("#todoList4").sortable('toArray');
			// Striping the todo- prefix of the ids:
			arr = $.map(arr,function(val,key){
				return val.replace('todo-','');
			});
			// Saving with AJAX
			$.get(tempUrl,{action:'rearrangeSolution','causeId':causeId
			,'positions':"'"+arr+"'"});
		},
		/* Opera fix: */
		stop: function(e,ui) {
			ui.item.css({'top':'0','left':'0'});
		}
	});
	//for solution steps
	$('#todoList5 li').live('click',function(e){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		$('#todoList5 li').attr('style','border-color:#EEEEEE');
		currentTODO.data('id',currentTODO.attr('id')).attr('style','background-color:#ACD2E4');
		solutionStepId=currentTODO.attr('id').replace('todo-','');
	});
	//get solution steps
	function getSolutionSteps()
	{
		tempUrl='';
		tempUrl=url+'ajaxSolution?id='+id;
		$.get(tempUrl,{'action':'getSolutionSteps','solutionId':solutionId,'rand':Math.random()},function(msg){ 
			$('#todoList5').html('');
			if(msg!='')
			$(msg).hide().appendTo('#todoList5').fadeIn();
		});
	}
	//For solution steps - adding 
	$('#addButton5').click(function(e){
		tempUrl='';
		tempUrl=url+'ajaxSolution?id='+id;
		if(solutionId!=0)
		{
			$.get(tempUrl,{'action':'newSolutionSteps','text':'Enter Solution Steps','solutionId':solutionId,'rand':Math.random()},function(msg){
				$(msg).hide().appendTo('#todoList5').fadeIn();
			});
			// Updating the timestamp:
			timestamp = (new Date()).getTime();
			e.preventDefault();
		}else
		alert('Please select anyone Solution');
	});
	//solution steps sorting
	$("#todoList5").sortable({
		axis		: 'y',				// Only vertical movements allowed
		containment	: 'window',			// Constrained by the window
		update		: function(){		// The function is called after the todos are rearranged
			// The toArray method returns an array with the ids of the todos
			tempUrl='';
			tempUrl=url+'ajaxSolution?id='+id;
			var arr = $("#todoList5").sortable('toArray');
			// Striping the todo- prefix of the ids:
			arr = $.map(arr,function(val,key){
				return val.replace('todo-','');
			});
			// Saving with AJAX
			$.get(tempUrl,{action:'rearrangeSolutionSteps','solutionId':solutionId
			,'positions':"'"+arr+"'"});
		},
		/* Opera fix: */
		stop: function(e,ui) {
			ui.item.css({'top':'0','left':'0'});
		}
	});
	
	// The cancel edit link:
	$('#todoList5 .todo a.discardChanges').live('click',function(){
		currentTODO.find('.text')
					.html('<a href="#" class="edit">'+currentTODO.data('origText')+'</a> <a href="'+url+'/media?id='+currentTODO.data('id')+'&type=S&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a>')
					.end()
					.removeData('origText');
					tb_init("a.thickbox, area.thickbox, input.thickbox");
	});
	
	// The save changes for solution title:
	$('#todoList5 .todo a.saveChanges').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxSolution?id='+id;
		var text = currentTODO.find("input[type=text]").val();
		$.get(tempUrl,{'action':'editSolutionSteps','solutionStepId':currentTODO.data('id'),'text':text});
		currentTODO.removeData('origText')
					.find(".text")
					.html('<a href="#" class="edit">'+text+'</a><a href="'+url+'/media?id='+currentTODO.data('id')+'&type=ST&keepThis=true&TB_iframe=true&height=465&width=510" class="thickbox" style="float:right"><img src="'+baseUrl+'/media/img/icon_info.png"></a>');
					tb_init("a.thickbox, area.thickbox, input.thickbox");
	});
	//For solution - deleting 
	$('#deleteButton5').live('click',function(){
		tempUrl='';
		tempUrl=url+'ajaxSolution';
		if(currentTODO)
		{
			if(confirm('Are you sure you want to delete?'))
			{
				$.get(tempUrl,{"action":"deleteSolutionSteps","id":currentTODO.data('id').replace('todo-','')},function(msg){
				currentTODO.fadeOut('fast');
				currentTODO.remove();
				currentTODO='';
				})
			}
		}else{
			alert('Please select anyone');
		}
	});
	
	
}); // Closing $(document).ready()