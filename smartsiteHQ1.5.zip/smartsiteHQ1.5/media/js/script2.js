$(document).ready(function(){
	/* The following code is executed once the DOM is loaded */
	var text;
	var currentTODO;
	$('#todoList1 li').live('click',function(e){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		$('#todoList1 li').attr('style','border-color:#EEEEEE');
		currentTODO.data('id',currentTODO.attr('id')).attr('style','border-color:#9be0f9');
	});
	$('.todo').live('dblclick',function(){
		$(this).find('a.edit').click();
	});
	
	$("#todoList1").sortable({
		axis		: 'y',				// Only vertical movements allowed
		containment	: 'window',			// Constrained by the window
		update		: function(){		// The function is called after the todos are rearranged
			var arr = $("#todoList1").sortable('toArray');
			// Striping the todo- prefix of the ids:
			arr = $.map(arr,function(val,key){
				return val.replace('todo-','');
			});
			// Saving with AJAX
		},
		/* Opera fix: */
		stop: function(e,ui) {
			ui.item.css({'top':'0','left':'0'});
		}
	});
	
	$('#deleteButton1').live('click',function(){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		if(currentTODO)
		{
			if(confirm('Are you sure you want to delete?'))
			{
				currentTODO.fadeOut('fast');
				currentTODO.remove();
				currentTODO='';
			}
		}else{
			alert('Please select anyone');
		}
	});
	$('#addButton1').live('click',function(){
		listnum=listnum+1;
		msg='<li id="todo-'+listnum+'" class="todo"><div class="text"><a href="#" class="add" id="addButton1"><a href="#" class="remove" id="deleteButton1"></a><a href="#" class="edit save">Option</a></div></li>';
		$(msg).hide().appendTo('#todoList1').fadeIn();
		// Updating the timestamp:
		timestamp = (new Date()).getTime();
	});
	$('.todo a').live('click',function(e){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		e.preventDefault();
	});
	$('#todoList1 .todo a.edit').live('dblclick',function(){
		var container = currentTODO.find('.text');
		if(!currentTODO.data('origText'))
		{
			// Saving the current value of the ToDo so we can
			// restore it later if the user discards the changes:
			currentTODO.data('origText',container.text());
		}
		else
		{
			// This will block the edit button if the edit box is already open:
			return false;
		}
		$('<input type="text">').val(container.text()).appendTo(container.empty());
		// Appending the save and cancel links:
		container.append(
			'<div class="editTodo">'+
				'<a class="saveChanges" href="#">Save</a><a class="discardChanges"  href="#">Cancel</a>'+
			'</div>'
		);
		
	});
	$('#todoList1 .todo a.discardChanges').live('click',function(){
		currentTODO.find('.text')
					.html('<a href="#" class="add" id="addButton1"></a><a href="#" class="remove" id="deleteButton1"></a><a href="#" class="edit save">'+currentTODO.data('origText')+'</a>')
					.end()
					.removeData('origText');
	});
	$('#todoList1 .todo a.saveChanges').live('click',function(){
		var text = currentTODO.find("input[type=text]").val();
		currentTODO.removeData('origText')
					.find(".text")
					.html('<a href="#" class="add" id="addButton1"></a><a href="#" class="remove" id="deleteButton1"></a><a href="#" class="edit save">'+text+'</a>');
	});
	var options;
	$('#submitbut').live('click',function(){
		$('#options').val('');
		$('.save').each(function(){
			options=$('#options').val()+';;'+$(this).html();
			$('#options').val(options);
		}
		);
	});
	$('#todoList2 li').live('click',function(){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		$('#todoList2 li').attr('style','border-color:#EEEEEE');
		currentTODO.data('id',currentTODO.attr('id')).attr('style','border-color:#9be0f9');
	});
	$("#todoList2").sortable({
		axis		: 'y',				// Only vertical movements allowed
		containment	: 'window',			// Constrained by the window
		update		: function(){		// The function is called after the todos are rearranged
			var arr = $("#todoList2").sortable('toArray');
			// Striping the todo- prefix of the ids:
			arr = $.map(arr,function(val,key){
				return val.replace('todo-','');
			});
			// Saving with AJAX
		},
		/* Opera fix: */
		stop: function(e,ui) {
			ui.item.css({'top':'0','left':'0'});
		}
	});
	$('#deleteButton2').live('click',function(){
		currentTODO = $(this).closest('.todo');
		currentTODO.data('id',currentTODO.attr('id').replace('todo-',''));
		if(currentTODO)
		{
			if(confirm('Are you sure you want to delete?'))
			{
				currentTODO.fadeOut('fast');
				currentTODO.remove();
				currentTODO='';
			}
		}else{
			alert('Please select anyone');
		}
	});
	$('#addButton2').live('click',function(e){
		listnum=listnum+1;
		msg='<li id="todo-'+listnum+'" class="todo"><div class="text"><a href="#" class="add" id="addButton2"></a><a href="#" class="remove" id="deleteButton2"></a><a href="#" class="edit save">Option</a></div></li>';
		$(msg).hide().appendTo('#todoList2').fadeIn();
		// Updating the timestamp:
		timestamp = (new Date()).getTime();
		e.preventDefault();
	});
		$('#todoList2 .todo a.edit').live('dblclick',function(){
		var container = currentTODO.find('.text');
		if(!currentTODO.data('origText'))
		{
			// Saving the current value of the ToDo so we can
			// restore it later if the user discards the changes:
			currentTODO.data('origText',container.text());
		}
		else
		{
			// This will block the edit button if the edit box is already open:
			return false;
		}
		$('<input type="text">').val(container.text()).appendTo(container.empty());
		// Appending the save and cancel links:
		container.append(
			'<div class="editTodo">'+
				'<a class="saveChanges" href="#">Save</a><a class="discardChanges"  href="#">Cancel</a>'+
			'</div>'
		);
		
	});
	$('#todoList2 .todo a.discardChanges').live('click',function(){
		currentTODO.find('.text')
					.html('<a href="#" class="add" id="addButton2"></a><a href="#" class="remove" id="deleteButton2"></a><a href="#" class="edit save">'+currentTODO.data('origText')+'</a>')
					.end()
					.removeData('origText');
	});
	$('#todoList2 .todo a.saveChanges').live('click',function(){
		var text = currentTODO.find("input[type=text]").val();
		currentTODO.removeData('origText')
					.find(".text")
					.html('<a href="#" class="add" id="addButton2"></a><a href="#" class="remove" id="deleteButton2"></a><a href="#" class="edit save">'+text+'</a> ');
	});
	$('#addbutton3').live('click',function(e){
		$("li:first").clone().appendTo('#todoList3').fadeIn();
		timestamp = (new Date()).getTime();
		e.preventDefault();
	});
	$('#deletebutton3').live('click',function(e){
		$(this).parent().remove();
	});
}); // Closing $(document).ready()