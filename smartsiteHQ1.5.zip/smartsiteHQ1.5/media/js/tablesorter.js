	
	// add parser through the tablesorter addParser method 
    $.tablesorter.addParser({
        // set a unique id 
        id: 'inline',
        is: function(s){
            // return false so this parser is not auto detected 
            return false;
        },
        format: function(s){
            // format your data for normalization 
            return s.replace(new RegExp(/<.*?>/),"");
        },
        // set type, either numeric or text
        type: 'text'
    });


	
	$(document).ready(function() { 

	$ ("#myTable").tablesorter({ widgets: ['zebra'],headers: {
		0: {
		//sorter:'inline'
		sorter:false
		} }
    });
    
	$ ("#GroupTable").tablesorter({ widgets: ['zebra'],headers: {
		0: {
		//sorter:'inline'GroupTable
		sorter:'inline'
		} }
    });
	
	
	 // Adds "over" class to rows on mouseover 
	 $(".tablesorter tr").mouseover(function(){ $(this).removeClass("even odd").addClass("over"); }); 
	 // Removes "over" class from rows on mouseout 
	 $(".tablesorter tr").mouseout(function(){ $(this).removeClass("over").addClass(this.rowIndex % 2 == 0 ? "odd" : "even");
     }); 

   });
	