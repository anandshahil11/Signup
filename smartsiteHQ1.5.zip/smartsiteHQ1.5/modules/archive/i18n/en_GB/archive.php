<?php defined('SYSPATH') or die('No direct access allowed.');

$lang = array
(
	'driver_not_supported' => 'The requested Archive driver, %s, was not found.',
	'driver_implements'    => 'The requested Archive driver, %s, does not implement Archive_Driver.',
	'directory_unwritable' => 'The directory you requested to save the file in, %s, is unwritable. Please correct the permissions and try again.',
	'filename_conflict'    => 'The requested archive filename, %s, already exists and is not writable. Please remove the conflicting file and try again.'
);