<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'El directorio en el que intentas guardar el archivo, %s, no tiene permiso de escritura. Cambia los permisos de escritura e intentalo de nuevo.',
	'filename_conflict'    => 'El archivo, %s, ya existe y no tiene permiso de escritura. Por favor, borra el archivo en conflicto e intentalo de nuevo.',
);