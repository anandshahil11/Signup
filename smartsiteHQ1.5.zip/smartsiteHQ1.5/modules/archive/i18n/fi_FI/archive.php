<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'Hakemisto %s johon yritit tallentaa tiedostoa ei voida kirjoittaa. Korjaa oikeudet ja yritä uudelleen.',
	'filename_conflict'    => 'Tiedosto %s on jo olemassa eikä siihen voida kirjoittaa. Poista olemassaoleva tiedosto ja yritä uudelleen.'
);