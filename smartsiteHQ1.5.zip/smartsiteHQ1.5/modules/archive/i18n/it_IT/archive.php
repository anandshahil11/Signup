<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'directory_unwritable' => 'La cartella in cui si è scelto di salvare il file, %s, è protetta in scrittura. Impostare opportunamente i permessi prima di ritentare.',
	'filename_conflict'    => 'L\'archivio richiesto, %s, è già esistente ed è protetto in scrittura. Ritentare dopo aver rimosso il file in conflitto.',
);