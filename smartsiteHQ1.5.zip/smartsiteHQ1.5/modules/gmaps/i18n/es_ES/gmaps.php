<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_marker'		=> 'Los parametros del marcador son incorrectos (latitud: %s, longitud: %s)',
	'invalid_dimensions'	=> 'Las dimensones del mapa son incorrectas (ancho: %s, alto: %s)',
);