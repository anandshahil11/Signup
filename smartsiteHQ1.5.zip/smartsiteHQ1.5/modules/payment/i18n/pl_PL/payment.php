<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'required'                 => 'Nie dostarczono wymaganych pól takich jak: %s.',
	'gateway_connection_error' => 'Wystąpił błąd w czasie łączenia z obsługą płatności. Proszę skontaktować się z administratorem jeśli nadal występuje problem.',
	'invalid_certificate'      => 'Certyfikat jest nieprawidłowy.',
	'no_dlib'                  => 'Nie można załadować dynamicznej biblioteki: %s',
	'error'                    => 'Wystąpił błąd podczas przetwarzania operacji płatności: %s',
);