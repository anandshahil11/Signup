<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'requires_mcrypt'   => 'Käyttääksesi Encrypt-kirjastoa, mcrypt tulee olla kytkettynä PHP-asennukessasi.',
	'no_encryption_key' => 'Käyttääksesi Encrypt-kirjastoa, tulee salausavain olla määriteltynä asetuksissa.'
);
