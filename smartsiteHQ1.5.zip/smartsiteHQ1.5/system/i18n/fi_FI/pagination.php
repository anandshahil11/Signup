<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group' => 'Ryhmää %s ei ole määritetty sivutusasetuksissa.',
	'page'     => 'sivu',
	'pages'    => 'sivua',
	'item'     => 'juttu', // horrible translation
	'items'    => 'juttua',
	'of'       => ' / ',
	'first'    => 'ensimmäinen',
	'last'     => 'viimeinen',
	'previous' => 'edellinen',
	'next'     => 'seuraava',
);
