<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Suoritustestit',
	'post_data'    => 'POST-tiedot',
	'no_post'      => 'Ei POST-tietoa',
	'session_data' => 'Sessio-tiedot',
	'no_session'   => 'Ei sessio-tietoa',
	'queries'      => 'Tietokantakyselyt',
	'no_queries'   => 'Ei kyselyitä',
	'no_database'  => 'Tietokantaa ei ladattu',
	'cookie_data'  => 'Cookie-tiedot',
	'no_cookie'    => 'Ei cookie-tietoa',
);
