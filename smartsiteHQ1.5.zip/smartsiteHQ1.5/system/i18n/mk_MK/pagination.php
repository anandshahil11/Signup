<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'page'     => 'страна',
	'pages'    => 'страни',
	'item'     => 'item',
	'items'    => 'items',
	'of'       => 'од',
	'first'    => 'прва',
	'last'     => 'последна',
	'previous' => 'претходна',
	'next'     => 'следна',
);
