<?php defined('SYSPATH') or die('No direct script access.'); 

Event::add_after('system.pre_routing', array('Router', 'setup'), 'replace_hyphens');  
function replace_hyphens() 
{ 
	Router::$controller = str_replace('-', '_', Router::$controller); 
	
	if(Router::$controller != 'media')
	{
		Router::$method = str_replace('-', '_', Router::$method);
	}  
} 