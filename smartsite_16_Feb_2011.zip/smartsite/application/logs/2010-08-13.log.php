<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-08-13 10:17:56 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, login, could not be found. in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 841
2010-08-13 10:18:30 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, login, could not be found. in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 841
2010-08-13 12:26:37 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, album, could not be found. in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 841
2010-08-13 13:17:22 +05:30 --- error: Uncaught Kohana_Exception: The has property does not exist in the User_Model class. in file C:/xampp/htdocs/kohana/system/libraries/ORM.php on line 364
2010-08-13 14:12:44 +05:30 --- error: Uncaught Kohana_Exception: The has property does not exist in the User_Model class. in file C:/xampp/htdocs/kohana/system/libraries/ORM.php on line 364
2010-08-13 14:33:46 +05:30 --- error: Uncaught PHP Error: Object of class ORM_Iterator could not be converted to string in file C:/xampp/htdocs/kohana/modules/auth/libraries/drivers/Auth/ORM.php on line 91
2010-08-13 16:20:58 +05:30 --- error: Uncaught Kohana_Database_Exception: There was an error connecting to the database: Unknown database 'smartsite' in file C:/xampp/htdocs/kohana/system/libraries/Database.php on line 223
2010-08-13 16:21:07 +05:30 --- error: Uncaught Kohana_Database_Exception: There was an error connecting to the database: Unknown database 'smartsite' in file C:/xampp/htdocs/kohana/system/libraries/Database.php on line 223
