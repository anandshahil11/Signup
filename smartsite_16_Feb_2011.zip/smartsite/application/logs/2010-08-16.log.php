<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-08-16 11:55:23 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/login, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 12:05:08 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, admin/question_sets, could not be found. in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 841
2010-08-16 12:28:49 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, admin/question_sets, could not be found. in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 841
2010-08-16 12:30:30 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, admin/question_sets/questions, could not be found. in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 841
2010-08-16 12:31:03 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, admin/question_sets/questions/index, could not be found. in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 841
2010-08-16 12:56:23 +05:30 --- error: Uncaught Kohana_Database_Exception: There was an SQL error: Table 'smartsite.question_sets' doesn't exist - SELECT *
FROM (`question_sets`) in file C:/xampp/htdocs/kohana/system/libraries/drivers/Database/Mysql.php on line 371
2010-08-16 15:12:51 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 15:51:46 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 15:55:30 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 16:00:10 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 16:00:15 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 16:20:08 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 16:22:04 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 16:22:24 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
2010-08-16 16:22:45 +05:30 --- error: Uncaught Kohana_Exception: The requested view, admin/modules/form, could not be found in file C:/xampp/htdocs/kohana/system/core/Kohana.php on line 1162
