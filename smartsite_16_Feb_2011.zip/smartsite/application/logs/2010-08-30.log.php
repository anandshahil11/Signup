<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-08-30 10:56:38 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/kohana/application/models/exam_question.php on line 72
2010-08-30 11:01:57 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/kohana/application/models/exam_question.php on line 74
2010-08-30 11:57:21 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/kohana/application/models/exam_user_answer.php on line 73
2010-08-30 11:58:55 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/kohana/application/models/exam_user_answer.php on line 73
2010-08-30 12:01:40 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/kohana/application/models/exam_user_answer.php on line 73
2010-08-30 12:01:42 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/kohana/application/models/exam_user_answer.php on line 73
2010-08-30 18:03:11 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-30 18:03:12 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-30 18:03:49 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-30 18:03:52 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-30 18:04:15 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 26
2010-08-30 18:04:16 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/expand/application/views/smartsite/img/logout_btn.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
2010-08-30 18:05:30 +05:30 --- error: Uncaught Kohana_404_Exception: The page you requested, applicati/img/logout_btn.png, could not be found. in file C:/xampp/htdocs/expand/system/core/Kohana.php on line 841
