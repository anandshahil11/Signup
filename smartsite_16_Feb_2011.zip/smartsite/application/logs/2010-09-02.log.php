<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-09-02 14:14:44 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 75
2010-09-02 14:23:49 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 75
2010-09-02 14:24:42 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 75
2010-09-02 14:32:15 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 75
2010-09-02 14:54:32 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::siteAnalytics() in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 219
2010-09-02 18:28:30 +05:30 --- error: Uncaught PHP Error: array_combine() [<a href='function.array-combine'>function.array-combine</a>]: Both parameters should have an equal number of elements in file C:/xampp/htdocs/expand/application/models/exam_question.php on line 158
