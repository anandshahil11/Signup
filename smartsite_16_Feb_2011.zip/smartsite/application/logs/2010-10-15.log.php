<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-15 07:12:47 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, 404.shtml, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:10:48 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, api, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:10:49 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:10:50 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:10:51 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:12:48 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:13:08 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:13:11 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:17:17 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:17:25 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:17:40 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2010-10-15 13:20:13 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
