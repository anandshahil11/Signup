<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-23 02:48:58 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, robots.txt, could not be found. in file system/core/Kohana.php on line 841
