<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-12-29 11:57:53 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 11:57:53 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 11:58:57 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 11:58:57 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 11:59:19 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 12:00:55 -07:00 --- error: Uncaught PHP Error: mysql_num_fields(): supplied argument is not a valid MySQL result resource in file application/models/new_user_information.php on line 129
2010-12-29 12:02:06 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 13:52:47 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 13:52:47 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 13:52:50 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 13:52:50 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 13:52:50 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 13:52:50 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 14:04:44 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 14:04:44 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 14:04:47 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 14:04:47 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 19:09:19 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 19:09:34 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 19:11:50 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 19:11:53 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2010-12-29 19:11:56 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
