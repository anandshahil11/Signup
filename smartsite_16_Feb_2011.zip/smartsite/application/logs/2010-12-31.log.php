<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-12-31 04:18:15 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-12-31 04:18:15 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-12-31 04:26:45 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
