<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-02-01 00:27:56 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2011-02-01 11:03:16 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2011-02-01 11:03:16 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
