<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-02-13 00:36:44 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-02-13 21:44:11 -07:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/user_contact.php on line 83
