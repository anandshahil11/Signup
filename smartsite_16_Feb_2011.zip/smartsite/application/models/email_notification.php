<?php defined('SYSPATH') or die('No direct script access.');
class Email_Notification_Model extends Model {
 
	public function __construct(){
		parent::__construct();
	}
	
	public function getEmailId($company){
	    
		$query="SELECT emailid FROM email_notification WHERE company='$company'";
		$result=mysql_query($query);
		while($row=mysql_fetch_array($result)){
			$emailid=$row[0];
		}
		return $emailid;
	}
	
	public function getEmailByid($id){
	        $con=mysql_connect('localhost','expandi4_smart','Expand4040!');
                mysql_select_db('expandi4_smartsite'); 
		$query="SELECT company FROM smartsite.question_sets WHERE id='$id'";
		$result=mysql_query($query,$con);
		while($row=mysql_fetch_array($result)){
			$company=$row[0];
		}
		$query="SELECT emailid FROM smartsite.email_notification WHERE company='$company'";
		$result=mysql_query($query,$con);
		while($row=mysql_fetch_array($result)){
			$emailid=$row[0];
		}
		return $emailid;
		
	}
    public function updateEmail($examid,$emails){

        $query="SELECT company FROM question_sets WHERE id='".$examid."'";
        $result=$this->db->query($query);
        $company=$result[0]->company;
        $sql="update email_notification set emailid='".$emails."' where company='".$company."'";
        $this->db->query($sql);
    }	
	public function appendEmail($examid,$emails){

        $query="SELECT company FROM question_sets WHERE id='".$examid."'";
        $result=$this->db->query($query);
        $company=$result[0]->company;
        $sql="update email_notification set emailid='".$emails."' where company='".$company."'";
        $this->db->query($sql);
    }	
}	