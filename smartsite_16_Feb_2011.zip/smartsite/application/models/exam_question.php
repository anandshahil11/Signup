<?php defined('SYSPATH') or die('No direct script access.');
class Exam_Question_Model extends ORM{
        protected $has_and_belongs_to_many = array('exam_question_sets');
 
 
 	//public $data_schema = array();
 	
	public function __construct(){   
		parent::__construct();

	}

	
	function get_questions_result($setid,$startdate,$enddate){
		
		// To get No of user given specific exam based on exam ID
		$query2="SELECT sess_id, count(question_set_id)
				 FROM exam_user_answers
				 WHERE question_set_id =$setid
				 AND datetime BETWEEN  '$startdate' AND  '$enddate' 
				 GROUP BY sess_id";
		$result2 = mysql_query($query2);
		$num_of_users = mysql_num_rows($result2);
		$no_of_ques_answered=array();
		$i=0;
		$sess=array();
		while($row = mysql_fetch_array($result2)){
					$sess[$i]=$row[0];
					$no_of_ques_answered[$i]= $row[1];
					$i++;
		}
		$countanswer=count($no_of_ques_answered);	
		//To count no of question in exam_question table for each set
		$query3="SELECT count(id_in_set)
				 FROM exam_questions
				 WHERE setId =$setid"; 
		$result3 = mysql_query($query3);
		while($row = mysql_fetch_array($result3)){
					$no_of_ques_inset= $row[0];
		}
        $no_of_completion=0;		
		for($i=0;$i<$countanswer;$i++){
			if($no_of_ques_inset==$no_of_ques_answered[$i]){
				$no_of_completion++;
			}
		}
		// TO calculate average score for one Exam set given by all users
		$count=array();
		$totalcorrectans=0;
		for($i=0;$i<count($no_of_ques_answered);$i++)
		{
			$query="SELECT a.question_id,a.answer,b.id_in_set,b.correctanswer
			FROM exam_user_answers a,exam_questions b
			WHERE a.question_set_id=$setid 
			AND b.setId=$setid 
			AND a.question_id=b.id_in_set 
			AND b.correctanswer=a.answer 
			AND a.datetime BETWEEN  '$startdate' AND  '$enddate' 
			AND a.sess_id=$sess[$i]";
			$result = mysql_query($query);
			$count[$i]=mysql_num_rows($result);
			$totalcorrectans=$totalcorrectans+$count[$i];
		}
		if(empty($count)){
		    $averagescore=MESSAGE;
		}else{
		    $averagescore=round(($totalcorrectans/(count($count)*$no_of_ques_inset))*100);
		}
		$noofuser=$num_of_users;
		$noofcompletion=$no_of_completion;
		return $averagescore.":".$noofuser.":".$noofcompletion;
	}
	
	function get_questions_set($setid){
			$query="SELECT id_in_set,text
					 FROM exam_questions
					 WHERE setId =$setid ORDER BY id"; 
			$result=mysql_query($query);
			$count=mysql_num_rows($result);

			for($i=0;$i<$count;$i++){
			        $row = mysql_fetch_array($result);
					$questions['id'][$i]= $row[0];
					$questions['ques'][$i]=$row[1];
			
			}
		return $questions;
	}
	
	function each_ques($examid,$quesid){
	
		//To get Exam  name and Exam id
		$query1='SELECT text,answer1,answer2,answer3,answer4,correctanswer FROM exam_questions where id_in_set="'.$quesid.'" and setId="'.$examid.'"' ;
		$result1 = mysql_query($query1); 
		$ques_ans=array();
		while($row = mysql_fetch_array($result1)){
			$ques_ans['ques']= $row['text'];
			$ques_ans['ans1']=$row['answer1'];
			$ques_ans['ans2']=$row['answer2'];
			$ques_ans['ans3']=$row['answer3'];
			$ques_ans['ans4']=$row['answer4'];
			$ques_ans['correctanswer']=$row['correctanswer'];
		}
	
	return $ques_ans;
	}
	
	
	
	// To get All Quiz list
	function ques_set($startdate,$enddate){
		$query="
	        SELECT question_set_id,count(question_set_id)
			FROM exam_user_answers
			WHERE
			 datetime
			BETWEEN '$startdate'
			AND '$enddate'
			group by question_set_id
			";
		$result=mysql_query($query);
		$digiExamList=array();
		$digiClick=array();
		$digiExamName=array();
		while($row=mysql_fetch_array($result)){
			$digiExamList[]=$row[0];
			$digiClick[]=$row[1];
			
		}
		if(count($digiExamList)>0){
		    
			for($i=0;$i<count($digiExamList);$i++){
				$query="SELECT name
						FROM exam_question_sets
						WHERE id=$digiExamList[$i]
						";
				$result=mysql_query($query);
				while($row=mysql_fetch_array($result)){
					$digiExamName[]=$row[0];
				}
			}
			$final=array_combine($digiExamName,$digiClick);
		}else{
			$final="No Quiz has been given";
		}	
	    return $final;
	
	}
	
	
	//To Calculate question set id 
	function get_ques_setid($startdate,$enddate){
		$query="SELECT question_set_id
				FROM exam_user_answers
				WHERE datetime BETWEEN '$startdate' AND '$enddate'
			    group by question_set_id
				";
		$result=mysql_query($query);
		$list=array();
        while($row=mysql_fetch_array($result)){
		    $list[]=$row[0];
			
		}
        return $list;
	
	}
	
}