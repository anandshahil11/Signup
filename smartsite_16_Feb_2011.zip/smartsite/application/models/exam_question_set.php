<?php defined('SYSPATH') or die('No direct script access.');
class Exam_Question_Set_Model extends ORM{
        protected $has_and_belongs_to_many = array('exam_question_sets');
        //public $data_schema = array();
 	
	public function __construct(){   
		parent::__construct();
		
	}
	
	
	//To Get  Quiz name
	function get_ques_name(){
		$query="SELECT name
				FROM exam_question_sets
				
				";
		$result=mysql_query($query);
		$list=array();
		$i=1;
        while($row=mysql_fetch_array($result)){
		    $list[$i]=$row[0];
			$i++;
			
		}	
	    return $list;
	
	}
	
	public function getExamName($examid){
	
		$query="SELECT name from exam_question_sets WHERE id=$examid";
		$result=mysql_query($query);
		$examName=array();
		while($row=mysql_fetch_array($result)){
			$examName[]=$row[0];
		}
		return $examName;
	}
	
	public function getexamList($company){
	    $examlist=array();
		$query="SELECT id , name FROM exam_question_sets
		        WHERE company='$company'";
		$result=mysql_query($query);
		$i=0;
        while($row=mysql_fetch_array($result)){
		    $examlist[$i]['id']=$row[0];
		    $examlist[$i]['name']=$row[1];
		    $i++;
		}
        return $examlist;		
	}
	
	
}