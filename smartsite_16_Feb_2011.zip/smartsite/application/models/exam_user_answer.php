<?php defined('SYSPATH') or die('No direct script access.');
class Exam_User_Answer_Model extends ORM{
        protected $has_and_belongs_to_many = array('exam_question_sets');
        //public $data_schema = array();
 	
	public function __construct(){   
		parent::__construct();
        }
	
	function get_correct($examid,$quesid,$startdate,$enddate){
		
		 //To Get CORRECT ANSWER
        $count2=array();
		for($i=0;$i<count($quesid);$i++){
		$query2="SELECT count(b.answer)
		FROM exam_questions a , exam_user_answers b
		WHERE a.setId=$examid AND b.question_set_id=$examid AND a.id_in_set=$quesid[$i] AND b.question_id=$quesid[$i]
		AND a.correctanswer=b.answer AND b.datetime BETWEEN  '$startdate' AND  '$enddate' ";
		
		$result1=mysql_query($query2);
		    while($row=mysql_fetch_array($result1)){
		        //List of Correct answers given by User for specific set
		        $count2[$i]=$row[0];
		    }

		}


		return $count2;
	}
	
	function get_incorrect($examid,$quesid,$correctanswer,$startdate,$enddate){
		$count1=array();
		$count3=array();
		for($i=0;$i<count($quesid);$i++){
		$query="SELECT count(answer) FROM exam_user_answers WHERE question_set_id=$examid and question_id=$quesid[$i]
		         AND datetime BETWEEN  '$startdate' AND  '$enddate'";
		$result=mysql_query($query);
		while($row=mysql_fetch_array($result)){
		    $count1[$i]=$row[0];
		}
		$count3[$i]=$count1[$i]-$correctanswer[$i];
		
		}

		return $count3;
	
	}
	
	
	function get_ques_result($examid,$quesid,$startdate,$enddate){
		$query="SELECT answer,count(answer)
                FROM exam_user_answers
				WHERE question_set_id =$examid
				AND question_id=$quesid AND datetime BETWEEN  '$startdate' AND  '$enddate'
				GROUP BY answer";
		$result=mysql_query($query);
		
		$answer=array();
		$i=0;
		while($row=mysql_fetch_array($result)){
			$answer['answer'][$i]=$row[0];
			$answer['answercount'][$i]=$row[1];
		    $i++;
		}
	    return $answer;
	}
	
	function get_user_questions_result($setid,$empid){
		$query2="SELECT sess_id, count(question_set_id)
				 FROM exam_user_answers
				 WHERE question_set_id =$setid
				 AND userid=$empid
				 GROUP BY sess_id";

		$result2 = mysql_query($query2);
		$num_of_users = mysql_num_rows($result2);
		$no_of_ques_answered=array();
		$i=0;
		$sess=array();
			while($row = mysql_fetch_array($result2)){
					$sess[$i]=$row[0];
					$no_of_ques_answered[$i]= $row[1];
					$i++;
				}
		$countanswer=count($no_of_ques_answered);	
		$query3="SELECT count(id_in_set)
				 FROM exam_questions
				 WHERE setId =$setid"; 
		$result3 = mysql_query($query3);
			while($row = mysql_fetch_array($result3)){
					$no_of_ques_inset= $row[0];
				}
        $no_of_completion=0;		
		for($i=0;$i<$countanswer;$i++){
			if($no_of_ques_inset==$no_of_ques_answered[$i]){
				$no_of_completion++;
			}
		}
		
		
		// TO calculate average score for one Exam set given by all users
		$count=array();
		$totalcorrectans=0;
		for($i=0;$i<count($no_of_ques_answered);$i++)
		{
		$query="SELECT a.question_id,a.answer,b.id_in_set,b.correctanswer
		FROM exam_user_answers a,exam_questions b
		WHERE a.question_set_id=$setid 
		AND b.setId=$setid 
		AND a.question_id=b.id_in_set 
		AND b.correctanswer=a.answer 
		AND a.sess_id=$sess[$i]";
		$result = mysql_query($query);
		$count[$i]=mysql_num_rows($result);
		$totalcorrectans=$totalcorrectans+$count[$i];
		}
		if(empty($count)){
		    $averagescore=MESSAGE;
		}else{
		    $averagescore=round(($totalcorrectans/(count($count)*$no_of_ques_inset))*100);
		}
		$noofuser=$num_of_users;
		$noofcompletion=$no_of_completion;
		
		return $averagescore.":".$noofuser.":".$noofcompletion;
	}
	
    public function getExamset($empid){
	
	    $query="SELECT DISTINCT (question_set_id)
                FROM exam_user_answers
                WHERE userid =$empid";
		$result=mysql_query($query);
		$count=mysql_num_rows($result);
		if($count>0){
		        $i=0;
			$examSet=array();
			while($row=mysql_fetch_array($result)){
				$examSet[$i]=$row[0];
			    $i++;
			}
        }else{
			$examSet=EXAMMESSAGE;
		}		
	    return $examSet; 
	}
	
	
}