<?php defined('SYSPATH') or die('No direct script access.');
class New_User_Information_Model extends ORM{
    public function __construct(){   
		parent::__construct();

	}
	
	
	// To get all fields name
	public function getFieldsname(){
	    $query="SELECT * FROM new_user_informations";
        $result=mysql_query($query);
		$i = 0;
		$fields=array();
		while ($i < mysql_num_fields($result)) {
			$meta = mysql_fetch_field($result, $i);
			if (!$meta) {
				echo "No information available<br />\n";
			}
			$fields[]=$meta->name;
			$i++;
		}
        return $fields;
		
	}
	
	//To Remove Column from new_user_informations table
	public function getFieldremove($remove){
	
	    $query="SELECT * FROM new_user_informations";
        $result=mysql_query($query);
	    $columns = mysql_num_fields($result);
       
		for ($i = 0; $i < $columns; $i++) {
			$field_array[] = mysql_field_name($result, $i);
		}
		if (in_array($remove, $field_array)) {
			$query="ALTER TABLE new_user_informations DROP `$remove`";
			$result=mysql_query($query);
			return True;
		}	
		return False;
	
	}
	
	//To Get back old new_user_informations table
	public function getFieldadd(){
	    $query="DROP TABLE new_user_informations";
		$result=mysql_query($query);
	    $query1="CREATE TABLE IF NOT EXISTS `new_user_informations` (
				  `id` int(20) NOT NULL auto_increment,
				  `first name` varchar(255) NOT NULL,
				  `last name` varchar(255) NOT NULL,
				  `company` varchar(255) NOT NULL,
				  `email address/Username` varchar(255) NOT NULL,
				  `mailing address` varchar(100) ,
				  `state` varchar(255),
				  `country` varchar(255),
				  `phone number` varchar(255),
				  `role` varchar(255) DEFAULT 'user',
				   PRIMARY KEY  (`id`)
				) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ";
        $result1=mysql_query($query1);
	    
		return 0;
	
	}
	
	//To insert data into user_informations , users , roles and new_user_data table
	
	public function setTable($fname,$lname,$company,$comp_orig,$email,$empNumber,$title,$territory,$role,$division,$passwordEncrypt,$newColumn,$newColumnvalue,$sender){
	    
		$query1="
		        INSERT INTO user_informations(`first name`,`last name`,`company`,company_orig,`email address`,`mailing address`,`state`,`country`,`phone number`,role)
		        VALUES('$fname','$lname','$company','$comp_orig','$email','$empNumber','$title','$division','$territory','$role') 
		        "; 
		//@mysql_query($query1) or die('Not Able to Insert in user_informations'.mysql_error());
		@mysql_query($query1);
         
		$error = mysql_error();
		$lastIdcount=mysql_insert_id();
		if ($error === '') {
        	$userName = $email;
			$query2="INSERT INTO users(id,email,username,password,company,company_orig)
					 VALUES($lastIdcount,'$email','$userName','$passwordEncrypt','$company','$comp_orig')"; 
			@mysql_query($query2); 	
			$lastInsertid=mysql_insert_id();
			
			if(($newColumn!==NULL) and ($newColumnvalue!==NULL)){
				$countNewColumn=count($newColumn);
				for($i=0;$i<$countNewColumn;$i++){
					//echo $newColumn[$i]."--".$newColumnvalue[$i]."<br/>";
					$newCol=addslashes(strip_tags(trim($newColumn[$i])));
					$newColValue=addslashes(strip_tags(trim($newColumnvalue[$i])));
					$query="INSERT INTO new_user_data(id,column_name,column_value)
     					    VALUES($lastInsertid,'$newCol','$newColValue')
						   ";
					@mysql_query($query);	   
				
				}
			}
			$error_users=mysql_error(); 
			$result_error="";
			if($error_users===''){
				if($lastInsertid!=0){
					include('Mail.php');
					include('Mail/mime.php');   
					$recipient=$_POST['email'];
					$html='Welcome to The Roland Academy Resource Service Center!<br>http://demo.getexpanded.com/roland/index.php/welcome<br><br>
						   Your username is: '.$email.'<br><br>
						   Your Password is:'.strip_tags(trim($_POST['fname'])).addslashes(strip_tags(trim($_POST['lname'])));
					$subject='Username and Password Details';
					$headers = array(
						  'From'          => $sender,
						  'Return-Path'   => $sender,
						  'Subject'       => $subject
						);
					$crlf = "\n";
					$mime = new Mail_mime($crlf);
					$text = 'This is a text message.';  // Text version of the email
					$mime->setTXTBody($text);
					$mime->setHTMLBody($html);
					$body = $mime->get();
					$headers = $mime->headers($headers);
					$mail = Mail::factory('mail');
					$result=$mail->send($recipient, $headers, $body);
					$import3="INSERT INTO roles(id,name,company) VALUES($lastInsertid,'$role','$company')";		  
					@mysql_query($import3) or die('Could not inserted in roles table'.mysql_error());
				}
			}else{
			    $result_error="The error message generated was $error_users";
			}
            if($result_error===''){			
			    $result="User Data inserted Successfully";
			}else{
			    $result=$result_error; 
			}
        }else{
		    $result="The error message generated was $error";
			
		}		
        return $result; 		
	}
	
	// To add columns in new_user_informations Table
	public function addField($customField){
		$fields=mysql_query('SHOW COLUMNS from new_user_informations');
		while($row=mysql_fetch_row($fields)) {
			$field_array[] = $row[0];
		}
        if (!in_array($customField, $field_array)){
			$result = mysql_query("ALTER TABLE new_user_informations ADD `$customField` VARCHAR(50)");
		}
		$fields=mysql_query('SHOW COLUMNS from new_user_informations');
		while($row=mysql_fetch_row($fields)) {
			$field_array_new[] = $row[0];
		}
		return $field_array_new;
	}
	
	
}	
?>