<?php defined('SYSPATH') or die('No direct script access.');
 
class Questions_Model extends Model{
 
 	public $data_schema = array();
 	
	public function __construct(){
		parent::__construct();
		$con=mysql_connect('localhost','expandi4_smart','Expand4040!');
                mysql_select_db('expandi4_smartsite'); 

	}
	
	function getExamid($company){
	    $query="SELECT id , name
		        FROM question_sets
				WHERE `company`='$company'";
		$result=mysql_query($query);
        $examInfo = array();
		$count=0;
		while($row=mysql_fetch_array($result)){
		    $examInfo[$count]['id']=$row[0];
			$examInfo[$count]['name']=$row[1];
			$count++;
		}		
	    return $examInfo; 
	}
	
	function get_questions_in_set($set_id){
		$results = $this->db->getwhere('questions',array('setId'=>$set_id))->result_array(FALSE);
		
		return $results;
		
	}
	
	function get_question($id){
		$results = $this->db->getwhere('questions',array('id'=>$id))->result_array(FALSE);
		if ( count($results) > 0 ){
			return $results[0];
		}
	}
	
	function update($data,$id){
		$this->db->from('questions')->set($data)->where(array('id'=>$id))->update();
		return TRUE;
	}
	
	function create($data){
		$query = $this->db->insert('questions',$data);
		return $query->insert_id();
	}
	
	public function delete($id){
		$this->db->delete('questions',array('id'=>$id));
	}
	
	//New function to get list of question based on exam set id
	function get_questions_set($setid){       
	        
			$query="SELECT id_in_set,text
					 FROM questions
					 WHERE setId =$setid AND id_in_set NOT IN ('consumerfor','businessfor','healthform')
					 ORDER BY id"; 
			$result=mysql_query($query);
			$count=mysql_num_rows($result);
			for($i=0;$i<$count;$i++){
			        $row = mysql_fetch_array($result);
					$questions['id'][$i]= $row[0];
					$questions['ques'][$i]=$row[1];
			
			}
		return $questions;
	}
	
	// CREATED function to get all the answers of each question set
	function each_ques($examid,$quesid){
	    
		$query1='SELECT text,answer1,answer2,answer3,answer4,response_type 
		         FROM questions where id_in_set="'.$quesid.'" and setId="'.$examid.'"' ;
		$result1 = mysql_query($query1); 
		$ques_ans=array();
		while($row = mysql_fetch_array($result1)){
			$ques_ans['ques']= $row['text'];
			$ques_ans['ans1']=$row['answer1'];
			$ques_ans['ans2']=$row['answer2'];
			$ques_ans['ans3']=$row['answer3'];
			$ques_ans['ans4']=$row['answer4'];
			$ques_ans['res_type']=$row['response_type'];
			
		}
	
		return $ques_ans;
	}
	
	// To get All Flash exam list
	function ques_set($examid,$startdate,$enddate){
	    $query="
	        SELECT question_set_id,count(question_set_id)
			FROM user_answers
			WHERE question_set_id='$examid' 
			AND datetime BETWEEN '$startdate' AND '$enddate'
			group by question_set_id
			";
		$result=mysql_query($query);
		$digiExamList=array();
		$digiClick=array();
		$digiExamName=array();
		while($row=mysql_fetch_array($result)){
			$digiExamList[]=$row[0];
			$digiClick[]=$row[1];
			
		}
		if(count($digiExamList)>0){
		    
			for($i=0;$i<count($digiExamList);$i++){
				$query="SELECT name
						FROM question_sets
						WHERE id=$digiExamList[$i]
						";
				$result=mysql_query($query);
				while($row=mysql_fetch_array($result)){
					$digiExamName[]=$row[0];
				}
			}
			$final=array_combine($digiExamName,$digiClick);
	    }else{
			$final="No Flash exam has been given";
		}	
		return $final;
	
	}
	
	//To get no of hits for each exam set
	
	function getClicks($examid,$startdate,$enddate){
        
		$query="SELECT question_id,count(question_id)
			FROM user_answers
			WHERE question_set_id=$examid  AND
			datetime BETWEEN '$startdate' AND '$enddate'
			group by question_id";
		$result=mysql_query($query);
		

        $clicks=array();
		$i=0;
        while($row=mysql_fetch_array($result)){
			$clicks[$i]['quesid']=$row[0];
			$clicks[$i]['asked']=$row[1];	
			$i++;
		}
		return $clicks; 	
 		
	}
	
	// TO get response of each question
	function getResponses($examid,$startdate,$enddate){
	    $query="SELECT question_id, count( question_id )
				FROM user_answers
				WHERE question_set_id ='$examid'
				AND answer != 'No Answer'
				AND STATUS = 'asked'
				AND datetime
					BETWEEN '$startdate'
					AND '$enddate'
				GROUP BY question_id";
		$result=mysql_query($query);
		$response=array();
		$i=0;
        while($row=mysql_fetch_array($result)){
			$response[$i]['quesid']=$row[0];
			$response[$i]['respond']=$row[1];	
			$i++;
		}
		return $response; 		
	}
	
	
	
	//To Calculate question set id 
	function get_ques_setid($examid,$startdate,$enddate){
		$query="SELECT question_set_id
				FROM user_answers
				WHERE  question_set_id='$examid' AND
				datetime BETWEEN '$startdate' AND '$enddate'
			    group by question_set_id
				";
		$result=mysql_query($query);
		$list=array();
		
        while($row=mysql_fetch_array($result)){
            $list[]=$row[0];
		}
	    return $list;
	
	}
	
}