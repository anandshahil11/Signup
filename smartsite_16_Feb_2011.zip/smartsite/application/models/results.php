<?php defined('SYSPATH') or die('No direct script access.');
 
class Results_Model extends Model {
 
	public function __construct(){
		parent::__construct();
	}
	
	function get_questions($set=1){
		return $this->db->getwhere('questions',array('set'=>$set))->result_array(FALSE);
	}
	
	
	function get_user_multiplechoice_answers($question_id){
		$question = $this->db->getwhere('questions',array('id'=>$question_id))->result_array(FALSE);
		$answers = $this->db->getwhere('user_answers',array('question_set_id'=>$question[0]['set'],'question_id'=>$question[0]['id_in_set']))->result_array(FALSE);
		if ( count($answers) > 0 ){
			$answer_arr = array();
			foreach ($answers as $answer){
				if ( $answer != '' ){
					$answer_arr[] = $answer['answer'];
				}
			}
		}
		
		return $answer_arr;
	}
	
	function get_user_checkbox_answers($question_id){
		$question = $this->db->getwhere('questions',array('id'=>$question_id))->result_array(FALSE);
		$answers = $this->db->getwhere('user_answers',array('question_set_id'=>$question[0]['set'],'question_id'=>$question[0]['id_in_set']))->result_array(FALSE);
		
		if ( count($answers) > 0 ){
			$answer_arr = array();
			
			foreach ($answers as $answer){
				$answer_explode = explode(',',$answer['answer']);
				foreach($answer_explode as $ind_answer){
					if ( $ind_answer != '' ){
						$answer_arr[] = $ind_answer;
					}
				}
			}
		}
		
		return $answer_arr;
		
	}
	
	function get_user_text_answers($question_id){
		$question = $this->db->getwhere('questions',array('id'=>$question_id))->result_array(FALSE);
		$answers = $this->db->getwhere('user_answers',array('question_set_id'=>$question[0]['set'],'question_id'=>$question[0]['id_in_set']))->result_array(FALSE);
		return $answers;
	}
		
	function get_user_answers_calculated($question_id){
		$questions = new Questions_Model;
		$question = $questions->get_question($question_id);
		
		$user_answer_arr = array();
		
		if ( $question['response_type'] == 'multiplechoice') {	
			$user_answers = $this->get_user_multiplechoice_answers($question_id);
			if ( count($user_answers) > 0 ){
				foreach ($user_answers as $answer){
					$user_answer_arr[$answer]['total']++;
				}
				
				foreach ($user_answer_arr as $key=>$answer ){
					$user_answer_arr[$key]['percent'] = number_format((($answer['total'] / count($user_answers) ) * 100), 2);
				}
			}
		}
		elseif ( $question['response_type'] == 'text' ){
			$user_answer_arr['results'] = array();
			$user_answers = $this->get_user_text_answers($question_id);
			for ( $i=0;$i<count($user_answers); $i++){
				$user_answer_arr['results'][$i] = $user_answers[$i]['answer'];
			}
		}
		elseif($question['response_type'] == 'checkboxes'){
			$user_answer_arr['results'] = array();
			$user_answers = $this->get_user_checkbox_answers($question_id);
			for ($i=0; $i<count($user_answers); $i++ ){
				$user_answer_arr['results'][$user_answers[$i]['answer']]++;
			}
		}
		
				
		//============================================================
		// 	Let's see how many and what percentage of the surveyees answer this
		//============================================================
		//get the total number of surveys taken
		$surveyees = $this->db->query("SELECT * FROM user_answers where question_set_id = ".$question['set']." GROUP BY sess_id")->result_array(FALSE);
		$num_of_surveyees = count($surveyees);
		//get the number of times this question was answered
		$question_answers = $this->db->query("SELECT * FROM user_answers WHERE question_set_id = ".$question['set']." AND question_id = '".$question['id_in_set']."'")->result_array(FALSE);
		$answered = count($question_answers);
		$user_answer_arr['number_answered'] = $answered;
		$user_answer_arr['number_taken'] = $num_of_surveyees;
		
		$user_answer_arr['percent_answered'] = 0;
		if ( $num_of_surveyees > 0 ){
			$user_answer_arr['percent_answered'] = ceil((($answered/$num_of_surveyees) * 100)) . "%";
		}
		
		
		
		$user_answer_arr['type'] = $question['response_type'];

		return $user_answer_arr;
		
	}
	
	function get_set_results($set_id){
		$questions_model = new Questions_Model;
		$questions = $questions_model->get_questions_in_set($set_id); //get questions
		$questions_return = array();
		$questions_return[] = array(
			'Question Text',
			'ID',
			'Type',
			'Answer 1',
			'Answer 1 Total',
			'Answer 1 Percentage',
			'Answer 2',
			'Answer 2 Total',
			'Answer 2 Percentage',			
			'Answer 3',
			'Answer 3 Total',
			'Answer 3 Percentage',
			'Answer 4',
			'Answer 4 Total',
			'Answer 4 Percentage',
			'Percentage Answered',
			'Total Answered',
			'Total Surveyees'
		);
		for ( $i=0; $i<count($questions); $i++ ){
			if ( strpos($questions[$i]['text'],'*') !== FALSE ){
				//run our processing
				$questions_return[$questions[$i]['id_in_set']] = array(
					'text'=>$questions[$i]['text'],
					'id_in_set'=>$questions[$i]['id_in_set'],
					'type'=>$questions[$i]['response_type']
				);
				
				$results = $this->get_user_answers_calculated($questions[$i]['id']);//get results
				//print_r($results);
				
				for( $j=1;$j<=4; $j++ ){
					if ( $questions[$i]['answer'.$j] != '' ){
						$questions_return[$questions[$i]['id_in_set']]['answer_'.$j.'_text'] = str_replace('*','',$questions[$i]['answer'.$j]);
						$questions_return[$questions[$i]['id_in_set']]['answer_'.$j.'_total'] = intval($results[$j]['total']);
						$questions_return[$questions[$i]['id_in_set']]['answer_'.$j.'_percent'] = floatval($results[$j]['percent']).'%';
					}
					else{ 
						$questions_return[$questions[$i]['id_in_set']]['answer_'.$j.'_text'] = '';
						$questions_return[$questions[$i]['id_in_set']]['answer_'.$j.'_total'] = '';
						$questions_return[$questions[$i]['id_in_set']]['answer_'.$j.'_percent'] = '';
					}
				}
				
				$questions_return[$questions[$i]['id_in_set']]['percent_answered'] = $results['percent_answered'];
				$questions_return[$questions[$i]['id_in_set']]['total_answered'] = $results['number_answered'];
				$questions_return[$questions[$i]['id_in_set']]['total_surveyees'] = $results['number_taken'];
				//$questions_return[] = array( 'question'=>$questions[$i],'results'=>$this->get_user_answers_calculated($questions[$i]['id']));//get results
			}
		}
		return $questions_return;
	}
}