<?php defined('SYSPATH') OR die('No direct access allowed.');

class User_Model extends Auth_User_Model{
	protected $has_and_belongs_to_many = array('roles');
 
	public function unique_key($id = NULL){
		if ( ! empty($id) AND is_string($id) AND ! ctype_digit($id) ){
			return 'username';
		}
        return parent::unique_key($id);
	}
	
	public function getUsers($company,$startdate,$enddate){
	    $startdate=strtotime($startdate);
		$enddate=strtotime($enddate);
 		$query="SELECT id,email,username,logins,last_login
				FROM users
				WHERE 
				company LIKE '%$company%' AND
				(last_login BETWEEN '$startdate' AND '$enddate')";
		$result=mysql_query($query);
        $list=array();
		$i=0;
        while($row=mysql_fetch_array($result)){
			$list[$i][]=$row[0];
			$list[$i][]=$row[1];
			$list[$i][]=$row[2];
			$list[$i][]=$row[3];
			$i++;
		}		
		return $list;
	}
	
	//To Get users last login
	public function getuserlastLogin($userInfo){
		for($i=0;$i<count($userInfo);$i++){
		   $id=$userInfo[$i]['id'];
		   $query="SELECT id,last_login,logins
                   FROM users WHERE id='$id'
				  ";
		   $result=mysql_query($query);
           while($row=mysql_fetch_array($result)){
		    $userLogin[$i]['id']=$row[0];
		    $userLogin[$i]['lastLogin']=$row[1];
			$userLogin[$i]['noofLogins']=$row[2];
		    
			}		   
		
		} 
	    return $userLogin; 	
	}
	
	
	//To Get search users last login
	public function getSearchuserlastLogin($idArray){
		$list = "'". implode("', '", $idArray) ."'";
	    $query="SELECT id,last_login,logins
		        FROM users WHERE id IN($list)
				";
		$result=mysql_query($query);
		$i=0;
        while($row=mysql_fetch_array($result)){
		    $userLogin[$i]['id']=$row[0];
		    $userLogin[$i]['lastLogin']=$row[1];
			$userLogin[$i]['noofLogins']=$row[2];
		    $i++; 
		}
        return $userLogin; 		
	}
	
	public function getuserLoginnum($empid){
	    
	    $query="SELECT logins FROM users WHERE id='$empid'";
		$result=mysql_query($query);
        $logins=0;
		while($row=mysql_fetch_array($result)){
		    $logins=$row[0];
		}
		return $logins;
	}
	
	public function getuserLastloginnum($empid){
	    
	    $query="SELECT last_login FROM users WHERE id='$empid'";
		$result=mysql_query($query);
        $lastLogin=0;
		while($row=mysql_fetch_array($result)){
		    $lastLogin=$row[0];
		}
		return $lastLogin;
	}
	
	public function getuserExamresult($empid){
	    
	    $query="SELECT er.exam_set_id , er.result , er.sess_id  , er.datetime , eqs.name
                FROM exam_result er , exam_question_sets eqs
                WHERE er.userid='$empid' AND er.exam_set_id=eqs.id
                ORDER BY datetime DESC";
		$result=mysql_query($query);
        $examResult=array();
		$ini=0;
		$numofattempts=mysql_num_rows($result);
        while($row=mysql_fetch_array($result)){
            $examResult[$ini]['exam_id']=$row[0];
            $examResult[$ini]['result']=$row[1];
            $examResult[$ini]['noofattempt']=$numofattempts;
            $examResult[$ini]['date']=$row[3];
            $examResult[$ini]['examname']=$row[4];
            $ini++;
            break;
        }
		return $examResult;
	}
 
}