<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'      => 'Ryhmää %s ei ole määritelty asetuksissasi.',
	'extension_not_loaded' => 'PHP laajennus %s tulee olla ladattu käyttääksesi tätä ajuria.',
	'unwritable'           => 'Asetuksissa määriteltyyn tallennushakemistoon %s ei voida kirjoittaa.',
	'resources'            => 'Resurssin lisääminen välimuistiin ei onnistu, koska resurssia ei voi serialisoida.',
	'driver_error'         => '%s',
);