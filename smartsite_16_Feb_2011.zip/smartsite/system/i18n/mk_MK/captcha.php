<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'file_not_found' => 'Назначената датотека, %s, не е пронајдена. Потврдете дека датотеките постојат користејќи <tt>file_exists</tt> пред да ги користите.',
	'requires_GD2'   => 'За библиотеката Captcha задолжителен е GD2 со FreeType поддршка. Молиме погледнете на http://php.net/gd_info за повеќе информации.',

);
