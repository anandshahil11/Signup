<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'       => 'Групата %s не е дефинирана во оваа конфигурација.',
	'error'                 => 'Се појави SQL грешка: %s',
	'connection'            => 'Грешка при конектирање со датабазата: %s',
	'invalid_dsn'           => 'DSN-от кој го имате напишано не е валиден: %s',
	'must_use_set'          => 'Мора да напишете SET услов во ова query.',
	'must_use_where'        => 'Мора да напишете WHERE услов во ова query.',
	'must_use_table'        => 'Мора да ја напишете табелата во датабазата во ова query.',
	'table_not_found'       => 'Табелата %s не постои во базата на податоци.',
	'not_implemented'       => 'Повиканата метода, %s, не е поддржана од овој драјвер.',
	'result_read_only'      => 'Query резултатите можат само да се читаат (read only).'
);