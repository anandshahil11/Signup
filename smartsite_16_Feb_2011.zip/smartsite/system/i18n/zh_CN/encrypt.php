<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'undefined_group'   => '配置没有定义 %s 组。',
	'requires_mcrypt'   => '使用加密（Encrypt）库，必须在 PHP 中开启 mcrypt',
	'no_encryption_key' => '使用加密（Encrypt）库, 必须在配置文件中设定加密关键字'
);
