<?php

$lang = array
(
	'general_error' => '发送邮件过程中发生错误。'
);