<?php defined('SYSPATH') or die('No direct script access.');
 
class In_Out_Model extends Model 
{
 	public $limit;
 	public $record_count = 0;
 	public $page = 1;
 	public $search_field = '';
 	public $search_phrase = '';
 	
	public function __construct()
	{
		parent::__construct();
	}
	
	public function get_all($arr='')
	{	
	   
		$offset = ($this->page - 1) * $this->limit;
		//added by ANAND
		//echo "I am in In_out , system/models folder<br/><br/>";
		//echo '$this->data_schema["table"]'.$this->data_schema['table']."<br/>";
		
		$records = $this->db->get($this->data_schema['table'],$this->limit,$this->get_offset())->result_array(FALSE);
		//added by Anand
		//var_dump($records);
		//echo '<br/>$this->data_schema["fields"] ';var_dump($this->data_schema['fields']) ;
		//echo "<br/>is_array($field['relates_to']";
		//============================================================
		// 	Relationships
		//		We're going to loop through the schema to see if there are any relationships.  If there are
		//		we are populating an array that will have the key as the field and the value to be the external_table
		//============================================================
		$relationships = array();
		foreach($this->data_schema['fields'] as $field)
		{
			if ( $field=='relates_to' and is_array($field['relates_to'])  )
			{
				$relationships[$field['name']] = $field['relates_to'];
			}
		}
		
		if ( count($relationships) > 0 )
		{
			for ($i=0; $i<count($records); $i++)
			{
				foreach($relationships as $key=>$relationship)
				{
					$relationship_data = $this->db->getwhere($relationship['table'],array('id'=>$records[$i][$key]))->result_array(FALSE);
					if ( count($relationship_data) > 0 )
					{
						$records[$i][$key] = array('id'=>$records[$i]['id']);
						$relationship_data = $relationship_data[0];
						
						//leaving this open to the option that later down the line, we can specify what fields we want back
						foreach ($relationship_data as $field=>$value)
						{
							$records[$i][$key][$field] = $value;
						}
					}
				}
			}
		}
		
		return $records;
	}
		
	public function get($id)
	{
		$record = $this->db->getwhere($this->data_schema['table'],array('id'=>$id))->result_array(FALSE);
		return $record[0];
	}
	
	public function search()
	{
		
		//============================================================
		// 	Run once for the total count
		//============================================================
		$records = $this->db
			->from($this->data_schema['table'])
			->like($this->search_field,$this->search_phrase)
			->get()
			->result_array(FALSE);

		$this->record_count = count($records);
			
		//============================================================
		// 	Run again with offset
		//============================================================	
		$records = $this->db
			->from($this->data_schema['table'])
			->like($this->search_field,$this->search_phrase)
			->limit($this->limit)
			->offset($this->get_offset())
			->get()
			->result_array(FALSE);
			
		return $records;
	}
	
	public function create($data)
	{
		$query = $this->db->insert($this->data_schema['table'],$data);
		return $query->insert_id();
	}
	
	public function update($data,$id)
	{	
		$this->db->from($this->data_schema['table'])->set($data)->where(array('id'=>$id))->update();
	}
	
	public function delete($id)
	{
		$this->db->delete($this->data_schema['table'],array('id'=>$id));
	}
	
	public function get_count()
	{
		$count = $this->db->count_records($this->data_schema['table']);
		$this->record_count = $count;
		return $count;
	}
	
	public function get_total_pages()
	{
		if ( $this->limit == 0 )
		{
			return "You must set a limit";
		}
		
		$total_pages = ceil($this->record_count / $this->limit);
		return $total_pages;
	}
	
	public function set_page($page)
	{
		if ( $page != '' )
		{
			$this->page = $page;
		}
	}
	
	function get_offset()
	{
		$offset = ($this->page - 1) * $this->limit;
		return $offset;
	}
	
	function set_limit($limit)
	{
		$this->limit = $limit;
	}
}