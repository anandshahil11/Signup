<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-08-25 12:59:13 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/kohana/application/controllers/smartsite.php on line 14
2010-08-25 13:00:01 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file C:/xampp/htdocs/kohana/application/controllers/smartsite.php on line 14
2010-08-25 17:52:18 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/kohana/application/views/smartsite/learninganalytic.php on line 210
