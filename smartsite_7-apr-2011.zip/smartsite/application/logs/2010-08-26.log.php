<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-08-26 15:43:53 +05:30 --- error: Uncaught PHP Error: array_keys() expects parameter 1 to be array, string given in file C:/xampp/htdocs/kohana/application/controllers/smartsite.php on line 57
2010-08-26 18:15:17 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/kohana/application/models/exam_question.php on line 66
2010-08-26 18:15:48 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/kohana/application/models/exam_question.php on line 66
2010-08-26 18:16:12 +05:30 --- error: Uncaught PHP Error: Division by zero in file C:/xampp/htdocs/kohana/application/models/exam_question.php on line 66
