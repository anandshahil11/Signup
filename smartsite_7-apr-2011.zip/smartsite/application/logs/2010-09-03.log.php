<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-09-03 10:53:38 +05:30 --- error: Uncaught PHP Error: array_keys() expects parameter 1 to be array, boolean given in file C:/xampp/htdocs/expand/application/views/smartsite/siteAnalytics.php on line 73
2010-09-03 10:56:14 +05:30 --- error: Uncaught PHP Error: Invalid argument supplied for foreach() in file C:/xampp/htdocs/expand/application/views/smartsite/siteAnalytics.php on line 73
2010-09-03 11:11:22 +05:30 --- error: Uncaught PHP Error: array_combine() [<a href='function.array-combine'>function.array-combine</a>]: Both parameters should have at least 1 element in file C:/xampp/htdocs/expand/application/models/questions.php on line 124
2010-09-03 11:39:46 +05:30 --- error: Uncaught PHP Error: array_combine() [<a href='function.array-combine'>function.array-combine</a>]: Both parameters should have at least 1 element in file C:/xampp/htdocs/expand/application/models/questions.php on line 126
2010-09-03 11:47:28 +05:30 --- error: Uncaught PHP Error: array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #1 is not an array in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 291
2010-09-03 11:48:27 +05:30 --- error: Uncaught PHP Error: array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #1 is not an array in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 293
2010-09-03 11:52:17 +05:30 --- error: Uncaught PHP Error: array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #1 is not an array in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 298
2010-09-03 12:10:22 +05:30 --- error: Uncaught PHP Error: array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #1 is not an array in file C:/xampp/htdocs/expand/application/controllers/smartsite.php on line 297
