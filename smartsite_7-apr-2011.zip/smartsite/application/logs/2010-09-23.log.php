<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-09-23 11:16:49 +05:30 --- error: Uncaught PHP Error: Missing argument 3 for Answers_Model::get_user_contact(), called in C:\xampp\htdocs\expand\application\controllers\smartsite.php on line 1260 and defined in file C:/xampp/htdocs/expand/application/models/answers.php on line 115
2010-09-23 12:47:42 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for User_Model::getuserlastLogin(), called in C:\xampp\htdocs\expand\application\controllers\smartsite.php on line 853 and defined in file C:/xampp/htdocs/expand/application/models/user.php on line 45
2010-09-23 12:47:49 +05:30 --- error: Uncaught PHP Error: Missing argument 1 for User_Model::getuserlastLogin(), called in C:\xampp\htdocs\expand\application\controllers\smartsite.php on line 853 and defined in file C:/xampp/htdocs/expand/application/models/user.php on line 45
2010-09-23 14:34:22 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 15
2010-09-23 14:34:45 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 15
2010-09-23 14:34:46 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 15
2010-09-23 14:37:04 +05:30 --- error: Uncaught PHP Error: mysql_fetch_array() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 15
2010-09-23 14:59:46 +05:30 --- error: Uncaught PHP Error: mysql_num_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 14
2010-09-23 15:42:23 +05:30 --- error: Uncaught PHP Error: mysql_affected_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 33
2010-09-23 15:44:29 +05:30 --- error: Uncaught PHP Error: mysql_affected_rows() expects parameter 1 to be resource, boolean given in file C:/xampp/htdocs/expand/application/models/user_contact.php on line 33
