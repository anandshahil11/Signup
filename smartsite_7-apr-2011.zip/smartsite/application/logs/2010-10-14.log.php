<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-14 00:10:40 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/user_contact.php on line 89
2010-10-14 00:10:53 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/user_contact.php on line 89
2010-10-14 00:11:55 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/user_contact.php on line 89
2010-10-14 00:14:09 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/user_contact.php on line 89
2010-10-14 06:10:23 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-10-14 06:19:56 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-10-14 21:38:52 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-14 21:38:55 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-14 23:08:32 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-14 23:08:35 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
