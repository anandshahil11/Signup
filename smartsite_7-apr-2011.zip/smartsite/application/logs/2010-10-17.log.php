<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-17 16:15:27 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-10-17 16:15:27 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-17 19:25:40 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-10-17 19:36:09 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, apple-touch-icon-precomposed.png, could not be found. in file system/core/Kohana.php on line 841
2010-10-17 19:36:09 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, apple-touch-icon.png, could not be found. in file system/core/Kohana.php on line 841
2010-10-17 19:36:11 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-10-17 19:36:12 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-17 20:26:45 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
