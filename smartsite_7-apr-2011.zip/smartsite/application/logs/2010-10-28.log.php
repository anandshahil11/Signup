<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-28 05:57:57 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-10-28 05:58:48 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
