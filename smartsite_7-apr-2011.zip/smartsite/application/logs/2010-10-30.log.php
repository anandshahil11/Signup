<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-10-30 07:24:42 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-30 07:24:43 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-10-30 07:57:47 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/displayAnswerResearchPane, could not be found. in file system/core/Kohana.php on line 841
