<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-03 00:55:38 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-11-03 03:13:27 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2010-11-03 10:48:43 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-03 10:48:48 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-03 12:12:17 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
