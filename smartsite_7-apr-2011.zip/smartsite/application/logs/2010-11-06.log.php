<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-06 00:33:15 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 00:33:23 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 00:34:09 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 00:34:35 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 00:35:48 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 00:35:51 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 07:54:19 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/research.php on line 213
2010-11-06 07:56:54 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/research.php on line 213
2010-11-06 07:57:00 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/research.php on line 213
2010-11-06 07:57:09 -06:00 --- error: Uncaught PHP Error: mysql_num_rows(): supplied argument is not a valid MySQL result resource in file application/models/research.php on line 213
2010-11-06 08:38:13 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 08:38:46 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 08:38:49 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 08:41:29 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-06 08:41:34 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
