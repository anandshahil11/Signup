<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-12 00:00:51 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-12 05:20:15 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/researchChart.png, could not be found. in file system/core/Kohana.php on line 841
2010-11-12 05:21:10 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/researchChart.png, could not be found. in file system/core/Kohana.php on line 841
