<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-17 08:23:46 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
