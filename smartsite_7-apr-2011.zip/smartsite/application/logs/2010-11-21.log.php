<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-21 00:21:57 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-21 00:22:01 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-21 01:25:33 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-21 01:25:39 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-21 01:25:41 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, expand/smartsite/img/emailgroup_btn.png, could not be found. in file system/core/Kohana.php on line 841
2010-11-21 01:25:41 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-21 01:25:43 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-21 01:25:44 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
