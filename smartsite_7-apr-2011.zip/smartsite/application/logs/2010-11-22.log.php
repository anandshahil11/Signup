<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-11-22 11:06:54 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-22 11:06:57 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2010-11-22 22:57:40 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, expand/smartsite/img/emailgroup_btn.png, could not be found. in file system/core/Kohana.php on line 841
