<?php defined('SYSPATH') or die('No direct script access.'); ?>

2010-12-27 04:10:56 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2010-12-27 04:10:56 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2010-12-27 04:11:18 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2010-12-27 04:11:18 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2010-12-27 14:07:53 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
