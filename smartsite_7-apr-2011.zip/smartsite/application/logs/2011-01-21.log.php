<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-01-21 04:56:56 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-01-21 04:57:57 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2011-01-21 08:49:54 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, media/css/basics.css, could not be found. in file system/core/Kohana.php on line 841
2011-01-21 16:00:33 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-01-21 16:00:40 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
