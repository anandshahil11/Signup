<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-02-04 04:50:02 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-02-04 04:50:05 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-02-04 08:12:58 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-02-04 08:13:01 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-02-04 12:51:54 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2011-02-04 12:51:54 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2011-02-04 13:17:55 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2011-02-04 13:17:55 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
