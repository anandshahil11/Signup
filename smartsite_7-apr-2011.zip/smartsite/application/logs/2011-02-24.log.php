<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-02-24 13:08:41 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, www.raediantdesign.com/img/upgrade.html, could not be found. in file system/core/Kohana.php on line 841
2011-02-24 13:49:33 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
