<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-03-10 15:12:19 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:12:19 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:22:40 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:22:57 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:23:18 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:23:36 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:23:39 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:24:17 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:24:27 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:24:29 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:24:34 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:24:39 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-10 15:25:12 -07:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
