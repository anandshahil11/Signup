<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-03-14 09:20:40 -06:00 --- error: Uncaught PHP Error: Missing argument 1 for Smartsite_Controller::index() in file application/controllers/smartsite.php on line 415
2011-03-14 11:47:31 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-14 11:47:34 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-14 11:53:19 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-14 12:32:51 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-14 12:32:56 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
