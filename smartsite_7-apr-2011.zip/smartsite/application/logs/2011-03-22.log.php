<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-03-22 08:17:26 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-22 08:17:29 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-22 08:18:19 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/loginSmartsite_btn.PNG, could not be found. in file system/core/Kohana.php on line 841
2011-03-22 08:18:19 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, smartsite/img/logo.png, could not be found. in file system/core/Kohana.php on line 841
