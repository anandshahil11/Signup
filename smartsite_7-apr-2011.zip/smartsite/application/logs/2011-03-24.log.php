<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-03-24 04:59:25 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
2011-03-24 04:59:28 -06:00 --- error: Uncaught Kohana_404_Exception: The page you requested, favicon.ico, could not be found. in file system/core/Kohana.php on line 841
