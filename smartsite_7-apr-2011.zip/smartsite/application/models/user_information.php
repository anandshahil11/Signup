<?php defined('SYSPATH') or die('No direct script access.');
class User_Information_Model extends ORM{
    protected $has_and_belongs_to_many = array('exam_question_sets');
    public function __construct(){   
		parent::__construct();

	}
	
	public function getuserInformation($company){
	    $query="SELECT * FROM user_informations 
		            WHERE company LIKE '%$company%'
			        ORDER BY `first name` ASC , `last name` ASC";
		$result=mysql_query($query);
		$userInfo=array();
		$i=0;
		while($row=mysql_fetch_array($result)){

			$userInfo[$i]['id']=$row[0];
			$userInfo[$i]['first']=$row[1];
			$userInfo[$i]['last']=$row[2];
			$userInfo[$i]['company']=$row[3];
			$userInfo[$i]['company_orig']=$row['company_orig'];
			$userInfo[$i]['emailid']=$row[4];
			$userInfo[$i]['mailingaddress']=$row[5];
			$userInfo[$i]['state']=$row[6];
			$userInfo[$i]['country']=$row[7];
            $i++;
		}
		return $userInfo;
	
	}
	
	public function getusersearchInformation($company,$trimmed_array){
		foreach ($trimmed_array as $trimm){
			  
			 $query = "SELECT * 
			           FROM user_informations 
				       WHERE company LIKE '%$company%' AND 
				       (`first name` LIKE '%$trimm%' OR `last name` like '%$trimm%' OR `email address` like '%$trimm%') ORDER BY id  ASC" ; 
			 $numresults=mysql_query ($query);
             $row_num_links_main =mysql_num_rows ($numresults);
			 $numresults = mysql_query ($query) or die ( "Couldn't execute query" );
		        $userInfo=array();
		        $i=0;
			    while($row= mysql_fetch_array ($numresults)){

				$userInfo[$i]['id']=$row[0];
				$userInfo[$i]['first']=$row[1];
				$userInfo[$i]['last']=$row[2];
				$userInfo[$i]['company']=$row[3];
				$userInfo[$i]['company_orig']=$row['company_orig'];
				$userInfo[$i]['emailid']=$row[4];
			    $userInfo[$i]['mailingaddress']=$row[5];
			    $userInfo[$i]['state']=$row[6];
			    $userInfo[$i]['country']=$row[7];
 
				$i++;
				}
		}	
		return $userInfo;
}
	
	// To get data based on Employee id
	public function getuserData($empid){

	    $query="SELECT * FROM user_informations WHERE id='$empid'";
        $result=mysql_query($query);
		while($row=mysql_fetch_array($result)){
		    $userdata['id']=$row[0];
		    $userdata['first']=$row[1];
		    $userdata['last']=$row[2];
		    $userdata['company']=$row['company_orig'];
		    $userdata['emailid']=$row[4];
		    $userdata['mailingaddress']=$row[5];
		    $userdata['state']=$row[6];
		    $userdata['country']=$row[7];
			$userdata['role']=$row[8];
		}
		return $userdata;		
	
	}
	
	// To Delete User Information from DB
	public function deleteuserInformation($empid){
	    $query1="DELETE FROM user_informations WHERE id='$empid'";
		$result1=mysql_query($query1);
	    $success1=mysql_affected_rows();
		$query2="DELETE FROM users WHERE id='$empid'";
		$result2=mysql_query($query2);
	    $success2=mysql_affected_rows();
		$query3="DELETE FROM roles WHERE id='$empid'";
		$result3=mysql_query($query3);
	    $success3=mysql_affected_rows();
		$query4="DELETE FROM new_user_data WHERE id='$empid'";
		$result4=mysql_query($query4);
		$success4=mysql_affected_rows();
		if($success1>0 ){
			$result="Successfully Deleted";
		}else{
		     
		    $result="Either Database Problem or user doesnt Exists.";
		}
		return $result;
		
	}
	
	
	// To get all fields name
	public function getFieldsname(){
	    $query="SELECT * FROM new_user_informations";
        $result=mysql_query($query);
		$i = 0;
		$fields=array();
		while ($i < mysql_num_fields($result)) {
			$meta = mysql_fetch_field($result, $i);
			if (!$meta) {
				echo "No information available<br />\n";
			}
			$fields[]=$meta->name;
			$i++;
		}
		return $fields;
	}
	
	// to Update User data
	public function getuserUpdate($empid,$firstname,$lastname,$company,$country,$role){
	    $query = "UPDATE user_informations 
		         SET `first name`='$firstname' ,
				 `last name`='$lastname' ,`company_orig`='$company',
                  `country`='$country' ,`role`='$role'
				 WHERE `id`='$empid'";
	    $result = mysql_query($query);
		
		$query1 = "UPDATE users
		           SET `company_orig`='$company'
				   WHERE `id`='$empid'";
		$result1 = mysql_query($query1);

        $last_insert_id = mysql_insert_id();
        $query2 = "UPDATE roles
		           SET `name`='$role'
				   WHERE `id`='$empid'";
        $result2 = mysql_query($query2);				   
        		
	}
	
}	
	