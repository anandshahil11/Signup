<?php defined('SYSPATH') OR die('No direct access allowed.');

class In_Out_Controller extends Admin_Controller 
{

	function __construct()
	{
		parent::__construct();	
	}
	
	function index()
	{
		$this->model->set_page($_REQUEST['page']);
		$this->model->set_limit(20);
		$data['records'] = $this->model->get_all();
		$data['count'] = $this->model->get_count();
		$data['current_page'] = $this->model->page;
		$data['total_pages'] = $this->model->get_total_pages();
		$data['schema'] = $this->schema;
		$this->template->content = View::factory('admin/modules/list')->set($data);
	}
	
	function search()
	{
		$this->model->set_page($_REQUEST['page']);
		$this->model->set_limit(20);
		$this->model->search_field = $_REQUEST['search_field'];
		$this->model->search_phrase = ($_REQUEST['search']);
		$data['records'] = $this->model->search();
		$data['current_page'] = $this->model->page;
		$data['total_pages'] = $this->model->get_total_pages();
		$data['search'] = TRUE;
		$data['search_phrase'] = $this->model->search_phrase;
		$data['search_field'] = $this->model->search_field;
		$data['schema'] = $this->schema;
		$this->template->content = View::factory('admin/modules/list')->set($data);
	}
	
	function edit($arr='')
	{
		if ( $_POST )
		{	
			$data = form::get_input(array('schema'=>$this->schema));
			$this->model->update($data,$this->input->post('id'));
			url::redirect('admin/'.Router::$controller);
		}
		else
		{
			$data['schema'] = $this->model->data_schema;
			$data['record'] = $this->model->get($this->uri->segment(4));
			$data['nextaction'] = 'edit';
			
			//load any passed data into view			
			if ( is_array($arr['data']) )
			{
				foreach($arr['data'] as $key=>$value)
				{
					$data[$key]=$value;
				}
			}	
				
			if ( $arr['view'] != '' && is_array($arr))
			{
				$this->template->content = View::factory($arr['view'])->set($data);
			}
			else
			{
				$this->template->content = View::factory('admin/modules/form')->set($data);
			}
		}
	}
	
	function create($arr='')
	{
		if ( $_POST )
		{	
			$data = form::get_input(array('schema'=>$this->schema));
			$this->model->create($data);
			url::redirect('admin/'.Router::$controller);
		}
		else
		{
			$data['schema'] = $this->model->data_schema;
			$data['nextaction'] = 'create';
			
			//load any passed data into view
			if ( is_array($arr['data']) )
			{
				foreach($arr['data'] as $key=>$value)
				{
					$data[$key]=$value;
				}
			}	
			
			if ( $arr['view'] != '' )
			{
				$this->template->content = View::factory($arr['view'])->set($data);
			}
			else
			{
				$this->template->content = View::factory('admin/modules/form')->set($data);
			}
		}
	}
	
	function delete()
	{	
		if ( $_POST )
		{
			$this->model->delete($this->input->post('id'));
			$this->auto_render=false;
		}
		else
		{
			url::redirect('admin/'.Router::$controller);
		}
	}
}
