<?php defined('SYSPATH') or die('No direct script access.');

class form extends form_Core{	
	
	//============================================================
	// 	THIS FUNCTION WILL PULL INFO BASED ON THE FORM PREFIX
	//============================================================
	public static function get_input($arr = '' )
	{
		$input = Input::instance();		
		
		//if no data is passed, we're assuming that we're going to be using POST as our data
		if ( !is_array($arr['data']) )
		{
			$arr['data'] = $input->post();
			foreach ($_FILES as $key=>$value)
			{
				$arr['data'][$key] = $value;
			}
		}
				
		//if no prefix is defined, we're going to default to the schema prefix
		if ( $arr['form_prefix'] == '' )
		{
			$arr['form_prefix'] = $arr['schema']['form_prefix'];
		}
		
		//we need to make sure the prefix ends with an underscore
		if ( substr($arr['form_prefix'],-1) != '_' )
		{
			$arr['form_prefix'] .= '_';
		}	
		
		
		//start our return array		
		$return_arr = array();
		
		//loop through each piece of data
		foreach ($arr['data'] as $key=>$value)
		{
			//if it starts with our prefix
			if ( substr($key,0,strlen($arr['form_prefix'])) == $arr['form_prefix'] )
			{
				// out the prefix for return 
				$rendered_key = substr($key,strlen($arr['form_prefix']));
				
				//see if we have a fields array set up in the schema, if not, simply return text
				if ( !is_array($arr['schema']) || count($arr['schema']['fields']) == 0 )
				{
					$return_arr[$rendered_key] = $value;
				}
				else //if we do have a fields array in the schema...
				{
					//we will loop through the schema fields to make sure we've got the one
					foreach ($arr['schema']['fields'] as $field )
					{
						if ( $field['name'] == $rendered_key )
						{
							$field_to_compare = $field;
						}
					}
					
					//switch vars for easy coding
					$field = $field_to_compare;
					
					//now, based on the field type, we make our actions happen
					switch($field['type'])
					{
						case 'datetext':
							if ( $value != '' )
							{
								$return_arr[$rendered_key] = date("Y-m-d",strtotime($value));
							}
							break;
						case 'image':
							if ( $input->post($key.'_current') == '' )
							{
								$return_arr[$rendered_key] = form::process_image(array('file'=>$key,'field'=>$field));
							}
							unset($return_arr[$rendered_key.'_current']);
							break;
						case 'file':
							if ( $input->post($key.'_current') == '' )
							{
								$return_arr[$rendered_key] = form::process_file(array('file'=>$key,'field'=>$field));
							}
							unset($return_arr[$rendered_key.'_current']);
							break;
						case 'custom':
							if ( $input->post($rendered_key.'_current') == '' )
							{
								$return_arr[$rendered_key] = custom_form::process_custom_field(array('field'=>$field,'post_var'=>$key,'post_data'=>$value));
							}
							break;
						/*case '': //do nothing with the field if we didn't tell it to
							break;*/
						default:
							$return_arr[$rendered_key] = $value;
					}	
				}
			}
		}
		
		return $return_arr;
	}
	
	public static function m_input($arr='')
	{
		//set up default rendered name
		$arr['field']['rendered_name'] = $arr['field']['name'];
		
		//add underscore to form_prefix
		if ( $arr['prefix'] != '' )
		{
			$arr['prefix'] .= '_';
			$arr['field']['rendered_name'] = $arr['prefix'].$arr['field']['name'];
		}
		
		if ( @!is_array($arr['record']) )
		{
			$arr['record'] = array();
		}
		
		if ( $arr['value'] == '' )
		{
			$arr['value'] = $arr['record'][$arr['field']['name']];
		}
		
		switch($arr['field']['type'])
		{
			case 'text':
				$output['field'] = form::input($arr['field']['rendered_name'],$arr['value'],form::render_input_options($arr['field']));
				break;
			case 'image':
				$output['field'] = View::factory('admin/modules/form_partials/image')->set(array('value'=>$arr['value'],'field'=>$arr['field']));
				break;
			case 'file':
				$output['field'] = View::factory('admin/modules/form_partials/file')->set(array('value'=>$arr['value'],'field'=>$arr['field']));
				break;			
			/*
			case 'file':
				$output['field'] = form::upload($arr['field']['rendered_name']);
				break;
			*/
			case 'textarea':
				$output['field'] = form::textarea($arr['field']['rendered_name'],$arr['value'],form::render_textarea_options($arr['field']));
				break;
			case 'dropdown':
				$output['field'] = form::dropdown($arr['field']['rendered_name'], form::render_dropdown_options($arr['field'],array('id','name')), $arr['value']);
				break;
			case 'datetext':
				$output['field'] = form::input($arr['field']['rendered_name'],form::render_date_display(array('date'=>$arr['value'])));
				break;
			case 'checkbox':
				$output['field'] = form::checkbox($arr['field']['rendered_name'],$arr['field']['checked_val'],form::checkbox_checked($arr['value']));
				//$output['field'] = form::checkbox($arr['field']['rendered_name'],$arr['value'],form::checkbox_checked(array('orig_value'=>$arr['record'][$arr['field']['name']],'checked'=>$arr['checked'])));
				break;
		}
		
		//add semicolon to label
		if ( $arr['field']['label'] != '' )
		{
			$arr['field']['label'] = $arr['field']['label'] . ':';
		}
		
		//pull notes
		if ( $arr['field']['notes'] != '' )
		{
			$output['notes'] = '<span class="notes">('.$arr['field']['notes'].')</span>';
		}
		
		//add label to output
		$output['label'] = form::label($arr['field']['rendered_name'],$arr['field']['label']);
		
		return $output;
	}
	
	//============================================================
	// 	PRIVATE FUNCTIONS
	//============================================================
	
	private function render_input_options($field)
	{
		if ( $field['size'] != '' )
		{
			return ' size="'.$field['size'].'"';
		}
		else
		{
			return ' size="45"';
		}
		
		if ( $field['class'] != '' )
		{
			return ' class="'.$field['class'].'"';
		}
	}
	
	private function render_textarea_options($field)
	{
		$return_str = '';
		if ( $field['cols'] != '' )
		{
			$return_str .= ' cols="'.$field['cols'].'"';
		}
		else
		{
			$return_str .= ' cols="85"';
		}
		
		if ( $field['rows'] != '' )
		{
			$return_str .= ' rows="'.$field['rows'].'"';
		}
		else
		{
			$return_str .= ' rows="7"';
		}
		
		return $return_str;
	}
	
	private function render_dropdown_options($field,$return_arr = '')
	{
		$db = Database::instance();
		if ( $field['relates_to'] != '' )
		{
			$array_to_return = array(''=>'Choose One');
			$results = $db->get($field['relates_to'])->result_array(FALSE);
			foreach ($results as $result)
			{
				$array_to_return[$result[$return_arr[0]]] = $result[$return_arr[1]];
			}
		}
		else
		{
			$array_to_return = array(''=>'Choose One');
			foreach ($field['options'] as $key=>$val)
			{
				$array_to_return[$key] = $val;
			}
		}
		
		return $array_to_return;
	}

	private function render_date_display($arr)
	{
		$date = '';
		if ( $arr['date'] != '' && strpos('0000-00-00',$arr['date']) === FALSE )
		{
			$date = date("M j, Y",strtotime($arr['date']));
		}
		return $date;
	}	

	private function process_image($arr)
	{
		if ( upload::required($_FILES[$arr['file']] ) )
		{
			$filename = upload::save($arr['file']);
			$local_dir = 'media/images/'.$arr['field']['dest_dir'];
			if ( $arr['field']['local_dir'] != '' )
			{
				$local_dir = $arr['field']['local_dir'].$arr['field']['dest_dir'];
			}
			
		 	$upload_dir = DOCROOT.$local_dir;
		 	if ( !is_dir($upload_dir) )
		 	{
		 		mkdir($upload_dir, 0777, true); //create the directory and any missing parents
		 	}
		 	
			// Resize, sharpen, and save the image
			$img = new Image($filename);
			if ( $arr['field']['width'] != '' )
			{
				$img->resize($arr['field']['width'],10000,Image::WIDTH);
			}
			
			$img->save($upload_dir.'/'.basename($filename));
		 
			// Remove the temporary file
			unlink($filename);
			return str_replace(APPPATH.'tmp',''.$local_dir,$filename);
		}
		else
		{
			return '';
		}
	}

	private function process_file($arr)
	{
		if ( upload::required($_FILES[$arr['file']] ) )
		{
			$local_dir = 'media/documents/'.$arr['field']['dest_dir'];
			if ( $arr['field']['local_dir'] != '' )
			{
				$local_dir = $arr['field']['local_dir'].$arr['field']['dest_dir'];
			}
			
		 	$upload_dir = DOCROOT.$local_dir;
		 	if ( !is_dir($upload_dir) )
		 	{
		 		mkdir($upload_dir, 0777, true); //create the directory and any missing parents
		 	}
		 	
			$filename = upload::save($arr['file'],$_FILES[$arr['field']['rendered_name']]['name'],$upload_dir);
		 	
			// Remove the temporary file
			return $local_dir.'/'.end(explode('/',$filename));
		}
		else
		{
			return '';
		}
	}
	
	private function checkbox_checked($arr)
	{
		if ( $arr['orig_value'] != '' || $arr['checked'] )
		{
			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}
}