<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => 'Benchmark-Tests',
	'post_data'    => 'POST-Daten:',
	'no_post'      => 'Keine POST-Daten',
	'session_data' => 'Session-Daten',
	'no_session'   => 'Keine Session-Daten',
	'queries'      => 'Datenbank-Anfragen',
	'no_queries'   => 'Keine Anfragen',
	'no_database'  => 'Datenbank nicht geladen',
	'cookie_data'  => 'Cookie-Daten',
	'no_cookie'    => 'Keine Cookie-Daten',
);
