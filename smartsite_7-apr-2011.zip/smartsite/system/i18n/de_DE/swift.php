<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'general_error' => 'Fehler beim Senden einer E-Mail aufgetreten.'
);