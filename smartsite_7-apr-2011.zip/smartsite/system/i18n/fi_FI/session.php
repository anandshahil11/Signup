<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'session_name, %s, ei kelpaa. Se tulee sisältää vähintään yhden kirjaimen, sekä vain aakkosnumeerisia merkkejä ja alaviivoja.',
);