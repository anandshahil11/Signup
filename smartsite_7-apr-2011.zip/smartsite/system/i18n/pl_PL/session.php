<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => 'Nieprawidłowa session_name, %s. Powinna zawierać wyłącznie znaki alfanumeryczne i przynajmniej jedną literę.',
);