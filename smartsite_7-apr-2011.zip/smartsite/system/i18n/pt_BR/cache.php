<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
    'undefined_group'      => 'O grupo %s não esta definido em sua configuação.',
	'extension_not_loaded' => 'A extenção %s do PHP deve estar carregada para usar este driver.',
	'unwritable'           => 'O local configurado para guardar, %s, não é gravável.',
	'resources'            => 'O cache de recursos é impossível, porque recursos não podem ser serializados.',
	'driver_error'         => '%s',
);