<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'benchmarks'   => '基准测试',
	'post_data'    => 'Post 数据',
	'no_post'      => '无 Post 数据',
	'session_data' => 'Session 数据',
	'no_session'   => '无 Session 数据',
	'queries'      => '数据库查询',
	'no_queries'   => '无查询语句',
	'no_database'  => '数据库未加载',
	'cookie_data'  => 'Cookie 数据',
	'no_cookie'    => '无 Cookie 数据',
);
