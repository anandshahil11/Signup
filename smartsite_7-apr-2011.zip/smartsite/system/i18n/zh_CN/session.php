<?php defined('SYSPATH') OR die('No direct access allowed.');

$lang = array
(
	'invalid_session_name' => '无效的 Session 名：%s。只能包含字母，数字和下划线。此外，至少还需要一个字母存在。',
);