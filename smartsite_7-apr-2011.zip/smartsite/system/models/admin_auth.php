<?php defined('SYSPATH') or die('No direct script access.');
 
class Admin_Auth_Model extends Model 
{
 
	public function __construct()
	{
		parent::__construct();
		$this->session = Session::instance();
		//echo "echo please ".$this->session->get('admin_logged_in');
		
	}
	
	function login()
	{
		$this->session->set('admin_logged_in',TRUE);
	}
		
	function logged_in()
	{   /*commented by ANAND */
		/*if ( $this->session->get('admin_logged_in') )
		{*/
			return TRUE;
		/*}
		else
		{
			return FALSE;
		}*/
	}
	
	function logout()
	{
		$this->session->destroy();
	}
}